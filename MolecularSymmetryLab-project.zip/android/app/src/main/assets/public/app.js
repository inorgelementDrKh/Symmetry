(()=>{var ad={H:1.008,B:10.81,C:12.011,N:14.007,O:15.999,F:18.998,S:32.06,Cl:35.45,Br:79.904,I:126.904,Xe:131.29,P:30.974,Fe:55.845,Co:58.933,Re:186.207,Tl:204.38},Ar={H:.31,B:.84,C:.76,N:.71,O:.66,F:.57,S:1.05,Cl:1.02,Br:1.2,I:1.39,Xe:1.4,P:1.07,Fe:1.32,Co:1.26,Re:1.51,Tl:1.55},Vc={H:1.1,B:1.92,C:1.7,N:1.55,O:1.52,F:1.47,S:1.8,Cl:1.75,Br:1.85,I:1.98,Xe:2.16,P:1.8,Fe:2,Co:2,Re:2,Tl:1.96},Xo={H:16777215,B:16747115,C:7044351,N:3107839,O:16723285,F:3014560,S:16769050,Cl:2089034,Br:16738816,I:12664319,Xe:58879,P:16752394,Fe:16734751,Co:16732067,Re:47103,Tl:13958970},Le=Math.PI/180,_e=(i,t,e=0)=>[i*Math.cos(t*Le),i*Math.sin(t*Le),e],Rn=i=>{let t=Math.hypot(...i);return i.map(e=>e/t)},te=(i,t)=>i.map(e=>e*t),ze=(i,t)=>i.map((e,n)=>e+t[n]),Go=i=>i.map(t=>-t),Gc=(i,t)=>{let e=Math.cos(t*Le),n=Math.sin(t*Le);return[i[0]*e-i[1]*n,i[0]*n+i[1]*e,i[2]]},On=[[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]].map(Rn);function Vo(i){let t=[["C",0,0,-.77],["C",0,0,.77]];for(let e=0;e<3;e++)t.push(["H",..._e(1.0277,90+120*e,-.77-.3633)]),t.push(["H",..._e(1.0277,90+120*e+i,.77+.3633)]);return t}function od(){let i=(s,r)=>{let a=s*.9428;return[a*Math.cos(r*Le),a*Math.sin(r*Le),-s/3]},t=[0,0,-.77],e=[["Br",1.94,0],["Cl",1.77,120],["H",1.09,240]],n=[["C",...t],["C",...Go(t)]];for(let[s,r,a]of e){let o=ze(t,i(r,a));n.push([s,...o]),n.push([s,...Go(o)])}return n}function Wc(){let i=[["B",0,0,0]];for(let t=0;t<3;t++){let e=_e(1.36,90+120*t),n=Rn(Go(e)),s=Gc(n,113);i.push(["O",...e]),i.push(["H",...ze(e,te(s,.96))])}return i}function ld(){let i=(1+Math.sqrt(5))/2,t=[];for(let n of[1,-1])for(let s of[1,-1])t.push([0,n,s*i],[n,s*i,0],[s*i,0,n]);let e=[];for(let n of t)e.push(["B",...te(Rn(n),1.693)]);for(let n of t)e.push(["H",...te(Rn(n),2.893)]);return e}var Cr=(i,t)=>[i[1]*t[2]-i[2]*t[1],i[2]*t[0]-i[0]*t[2],i[0]*t[1]-i[1]*t[0]];function Wo(i,t){let e=[];for(let n=0;n<t;n++){let s=Gc(i,360*n/t);e.push(n%2?[s[0],s[1],-s[2]]:s)}return e}function Xc(i,t,e,n=.96){let s=Rn(i.map((u,f)=>u-t[f])),r=Math.abs(s[2])<.9?[0,0,1]:[1,0,0],a=Rn(Cr(s,r)),o=Cr(s,a),l=Math.cos(71.5*Le),c=Math.sin(71.5*Le);return ze(i,te(ze(te(s,l),te(ze(te(a,Math.cos(e*Le)),te(o,Math.sin(e*Le))),c)),n))}function cd(){let i=Rn([1,1,1]),t=Rn([1,-1,0]),e=Rn(Cr(i,t)),n=u=>ze(te(i,1/3),te(ze(te(t,Math.cos(u*Le)),te(e,Math.sin(u*Le))),Math.sqrt(8)/3)),s=te(i,1.53),r=ze(s,te(n(25),1.43)),a=ze(s,te(n(145),1.09)),o=ze(s,te(n(265),1.09)),l=Xc(r,s,70),c=[["C",0,0,0]];for(let[u,f]of[["C",s],["O",r],["H",a],["H",o],["H",l]])for(let h of Wo(f,4))c.push([u,...h]);return c}function hd(){let i=[0,0,-.77],t=[["C",...i],["C",0,0,.77]],e=[1.348*Math.cos(15*Le),1.348*Math.sin(15*Le),-.77-.477],n=Xc(e,i,80);for(let s of Wo(e,6))t.push(["O",...s]);for(let s of Wo(n,6))t.push(["H",...s]);return t}function ud(){return Wc().map(([i,t,e,n])=>i==="H"?[i,t,e,n+.45]:[i,t,e,n])}function dd(i){let t=[["C",-.6695,0,0],["C",.6695,0,0]];for(let e of[1,-1]){t.push(["H",-1.2315,.9288*e,0]);let n=Math.cos(i*Le),s=Math.sin(i*Le);t.push(["H",1.2315,.9288*e*n,.9288*e*s])}return t}function zc(i){let t=[["Fe",0,0,0]];for(let e=0;e<5;e++){t.push(["C",..._e(1.21,72*e,1.66)],["H",..._e(2.29,72*e,1.66)]);let n=i?36:0;t.push(["C",..._e(1.21,72*e+n,-1.66)],["H",..._e(2.29,72*e+n,-1.66)])}return t}function fd(){let i=[["Re",0,0,-1.12],["Re",0,0,1.12]];for(let t of[-1,1])for(let e=0;e<4;e++)i.push(["Cl",..._e(2.222,90*e,t*(1.12+.554))]);return i}function pd(){let i=[];for(let t=0;t<8;t++)i.push(["S",..._e(2.35,45*t,t%2?-.49:.49)]);return i}function md(){let i=[];for(let t=0;t<6;t++){let e=t%2?-1:1,n=.25*e;i.push(["C",..._e(1.446,60*t,n)]),i.push(["H",..._e(1.446,60*t,n+1.09*e)]),i.push(["H",..._e(1.446+1.027,60*t,n-.364*e)])}return i}function gd(){let e=[[1,1,1],[1,-1,-1],[-1,1,-1],[-1,-1,1]],n=[];for(let[s,r,a]of e)n.push(["C",.9*s,.9*r,.9*a],["H",(.9+.629)*s,(.9+.629)*r,(.9+.629)*a]);for(let s=0;s<3;s++)for(let r of[1,-1]){let a=[0,0,0];a[s]=1;let o=e.filter(u=>u[s]===r),l=Rn(Cr(a,o[0].map((u,f)=>u-o[1][f]))),c=te(a,r*1.766);n.push(["C",...c]);for(let u of[1,-1])n.push(["H",...ze(ze(c,te(a,r*.648)),te(l,.877*u))])}return n}function _d(){let i=[];for(let t of[1,-1])for(let e of[1,-1])for(let n of[1,-1])i.push(["C",.785*t,.785*e,.785*n],["H",1.414*t,1.414*e,1.414*n]);return i}function xd(){let i=[["Co",0,0,0]],t=[[1,0,0],[0,1,0],[0,0,1]];for(let e=0;e<3;e++)for(let n of[1,-1]){let s=t[e],r=t[(e+1)%3],a=te(s,1.95*n);i.push(["N",...a]);for(let o of[1,-1])i.push(["O",...ze(ze(a,te(s,.62*n)),te(r,1.074*o))])}return i}function yd(){return[["B",-.885,0,0],["B",.885,0,0],["H",0,0,.993],["H",0,0,-.993],["H",1.466,1.038,0],["H",1.466,-1.038,0],["H",-1.466,1.038,0],["H",-1.466,-1.038,0]]}function vd(){let i=[];for(let t=0;t<3;t++){i.push(["C",..._e(.8776,90+120*t)]);for(let e of[1,-1])i.push(["H",..._e(1.459,90+120*t,.913*e)])}return i}function bd(){let i=[["Tl",0,0,2.41]];for(let t=0;t<5;t++)i.push(["C",..._e(1.207,72*t)],["H",..._e(2.287,72*t)]);return i}var Sd=[{id:"chfclbr",name:"Bromochlorofluoromethane",formula:"CHFClBr",expected:"C1",atoms:[["C",0,0,0],["H",...te(On[0],1.09)],["F",...te(On[1],1.35)],["Cl",...te(On[2],1.77)],["Br",...te(On[3],1.94)]],note:"Four different substituents. Nothing maps the molecule onto itself except doing nothing, so E is the only operation. It is chiral."},{id:"ch2clf",name:"Chlorofluoromethane",formula:"CH<sub>2</sub>ClF",expected:"Cs",atoms:[["C",0,0,0],["Cl",...te(On[0],1.77)],["F",...te(On[1],1.35)],["H",...te(On[2],1.09)],["H",...te(On[3],1.09)]],note:"One mirror plane passes through C, Cl and F and swaps the two hydrogens."},{id:"meso-ci",name:"meso-1,2-Dibromo-1,2-dichloroethane (anti)",formula:"C<sub>2</sub>H<sub>2</sub>Br<sub>2</sub>Cl<sub>2</sub>",expected:"Ci",atoms:od(),note:"In the anti conformer, the midpoint of the C\u2013C bond is an inversion centre. Every atom has an identical partner directly opposite it. No axis or plane is present."},{id:"h2o2",name:"Hydrogen peroxide",formula:"H<sub>2</sub>O<sub>2</sub>",expected:"C2",atoms:[["O",0,0,-.73],["O",0,0,.73],["H",...ze([0,0,-.73],te([.9848,0,-.1736],.97))],["H",...ze([0,0,.73],te([.9848*Math.cos(111.5*Le),.9848*Math.sin(111.5*Le),.1736],.97))]],note:"The skew shape (dihedral about 111\xB0) keeps a single C\u2082 axis, which bisects the H\u2013O\u2013O\u2013H twist. Mirror planes and i are lost, so it is chiral."},{id:"h2o",name:"Water",formula:"H<sub>2</sub>O",expected:"C2v",atoms:[["O",0,0,0],["H",.757,0,.586],["H",-.757,0,.586]],note:"A C\u2082 axis through O, the molecular plane, and a second plane at right angles to it that contains the axis."},{id:"nh3",name:"Ammonia",formula:"NH<sub>3</sub>",expected:"C3v",atoms:[["N",0,0,0],...[0,1,2].map(i=>["H",..._e(.9377,90+120*i,-.3816)])],note:"The pyramid has one C\u2083 axis and three \u03C3\u1D65 planes, each holding N and one H."},{id:"brf5",name:"Bromine pentafluoride",formula:"BrF<sub>5</sub>",expected:"C4v",atoms:[["Br",0,0,0],["F",0,0,1.69],...[0,1,2,3].map(i=>["F",..._e(1.7633,90*i,.1543)])],note:"A square pyramid. The Br lone pair sits opposite the apex and is not drawn. One C\u2084 axis, four vertical planes."},{id:"hcl",name:"Hydrogen chloride",formula:"HCl",expected:"C\u221Ev",atoms:[["Cl",0,0,0],["H",0,0,1.27]],note:"Linear but with unlike ends. Any rotation about the bond axis works (C\u221E), and every plane containing the axis is a mirror (\u03C3\u1D65)."},{id:"tdce",name:"trans-1,2-Dichloroethene",formula:"C<sub>2</sub>H<sub>2</sub>Cl<sub>2</sub>",expected:"C2h",atoms:[["C",-.665,0,0],["C",.665,0,0],["Cl",-1.5892,1.4506,0],["Cl",1.5892,-1.4506,0],["H",-1.205,-.935,0],["H",1.205,.935,0]],note:"Planar and centrosymmetric. The C\u2082 axis is perpendicular to the molecular plane, which itself is \u03C3\u2095. Together they generate i."},{id:"boh3",name:"Boric acid",formula:"B(OH)<sub>3</sub>",expected:"C3h",atoms:Wc(),note:"Flat, with all three O\u2013H bonds turned the same way. C\u2083 plus \u03C3\u2095 makes an S\u2083 axis, but there are no vertical mirrors."},{id:"ethane-30",name:"Ethane, twisted 30\xB0",formula:"C<sub>2</sub>H<sub>6</sub>",expected:"D3",atoms:Vo(30),note:"Half-way between eclipsed and staggered. Mirrors and i disappear, leaving C\u2083 and three perpendicular C\u2082 axes. It is chiral."},{id:"c2h4",name:"Ethylene",formula:"C<sub>2</sub>H<sub>4</sub>",expected:"D2h",atoms:[["C",-.667,0,0],["C",.667,0,0],["H",-1.2315,.9288,0],["H",-1.2315,-.9288,0],["H",1.2315,.9288,0],["H",1.2315,-.9288,0]],note:"Three mutually perpendicular C\u2082 axes, three mirror planes (one is the molecular plane) and an inversion centre."},{id:"allene",name:"Allene (propadiene)",formula:"C<sub>3</sub>H<sub>4</sub>",expected:"D2d",atoms:[["C",0,0,0],["C",0,0,1.31],["C",0,0,-1.31],["H",.934,0,1.866],["H",-.934,0,1.866],["H",0,.934,-1.866],["H",0,-.934,-1.866]],note:"The two CH\u2082 planes are at 90\xB0. There is no C\u2084 and no \u03C3\u2095, yet an S\u2084 axis exists: turn 90\xB0 and reflect. This is a genuine improper axis."},{id:"bf3",name:"Boron trifluoride",formula:"BF<sub>3</sub>",expected:"D3h",atoms:[["B",0,0,0],...[0,1,2].map(i=>["F",..._e(1.313,90+120*i)])],note:"C\u2083, three C\u2082 axes along the B\u2013F bonds, \u03C3\u2095 (the molecular plane), three \u03C3\u1D65 and an S\u2083 axis."},{id:"ethane-0",name:"Ethane, eclipsed",formula:"C<sub>2</sub>H<sub>6</sub>",expected:"D3h",atoms:Vo(0),note:"With the CH\u2083 groups eclipsed, a \u03C3\u2095 plane cuts the C\u2013C bond in half. Compare the staggered form next."},{id:"ethane-60",name:"Ethane, staggered",formula:"C<sub>2</sub>H<sub>6</sub>",expected:"D3d",atoms:Vo(60),note:"Staggered ethane has no \u03C3\u2095, but it has i and an S\u2086 axis along the C\u2013C bond. Spin 60\xB0 and reflect: all atoms land on equivalent atoms."},{id:"xef4",name:"Xenon tetrafluoride",formula:"XeF<sub>4</sub>",expected:"D4h",atoms:[["Xe",0,0,0],...[0,1,2,3].map(i=>["F",..._e(1.95,90*i)])],note:"Square planar: C\u2084 perpendicular to the plane, four C\u2082 axes (two through F atoms, two between them), \u03C3\u2095, two \u03C3\u1D65, two \u03C3d, S\u2084 and i. Order 16."},{id:"if7",name:"Iodine heptafluoride",formula:"IF<sub>7</sub>",expected:"D5h",atoms:[["I",0,0,0],["F",0,0,1.786],["F",0,0,-1.786],...[0,1,2,3,4].map(i=>["F",..._e(1.858,72*i)])],note:"A pentagonal bipyramid. Fivefold symmetry is allowed in a molecule even though it never occurs in crystals. C\u2085, five C\u2082, \u03C3\u2095, five \u03C3\u1D65, S\u2085."},{id:"benzene",name:"Benzene",formula:"C<sub>6</sub>H<sub>6</sub>",expected:"D6h",atoms:[...[0,1,2,3,4,5].map(i=>["C",..._e(1.397,60*i)]),...[0,1,2,3,4,5].map(i=>["H",..._e(2.481,60*i)])],note:"The classic D\u2086h example: C\u2086, six perpendicular C\u2082 axes (3 + 3), \u03C3\u2095, three \u03C3\u1D65, three \u03C3d, i and S\u2086. Order 24."},{id:"co2",name:"Carbon dioxide",formula:"CO<sub>2</sub>",expected:"D\u221Eh",atoms:[["C",0,0,0],["O",0,0,1.16],["O",0,0,-1.16]],note:"Linear and symmetric: all the symmetry of HCl plus i, \u03C3\u2095 and infinitely many perpendicular C\u2082 axes."},{id:"ch4",name:"Methane",formula:"CH<sub>4</sub>",expected:"Td",atoms:[["C",0,0,0],...On.map(i=>["H",...te(i,1.09)])],note:"Four C\u2083 axes (through each C\u2013H), three C\u2082 axes, six \u03C3d planes and three S\u2084 axes. No inversion centre."},{id:"sf6",name:"Sulfur hexafluoride",formula:"SF<sub>6</sub>",expected:"Oh",atoms:[["S",0,0,0],...[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]].map(i=>["F",...te(i,1.56)])],note:"The octahedron: 3 C\u2084, 4 C\u2083, 6 C\u2082, 3 \u03C3\u2095, 6 \u03C3d, i, S\u2084 and S\u2086. Order 48."},{id:"b12h12",name:"closo-Dodecaborate dianion",formula:"B<sub>12</sub>H<sub>12</sub><sup>2\u2212</sup>",expected:"Ih",atoms:ld(),note:"The icosahedron: 6 C\u2085, 10 C\u2083, 15 C\u2082, 15 mirror planes, i, plus S\u2081\u2080 and S\u2086 axes. Order 120, the largest of the cubic and icosahedral groups."},{id:"pentaerythritol",name:"Pentaerythritol (idealised)",formula:"C(CH<sub>2</sub>OH)<sub>4</sub>",expected:"S4",atoms:cd(),note:"Four identical arms twisted the same way around a central carbon. No mirror plane, no inversion centre and no C\u2084 axis, yet turning 90\xB0 and reflecting is a symmetry. The point group has only E, C\u2082, S\u2084 and S\u2084\xB3."},{id:"hexol",name:"Hexahydroxyethane, twisted",formula:"C<sub>2</sub>(OH)<sub>6</sub>",expected:"S6",atoms:hd(),note:"Staggered like ethane, but every O\u2013H points the same way around the axis. That removes the \u03C3d planes of D\u2083d and leaves C\u2083, i and the S\u2086 axis (rotate 60\xB0, reflect)."},{id:"boh3-prop",name:"Boric acid, propeller form",formula:"B(OH)<sub>3</sub>",expected:"C3",atoms:ud(),note:"Lift each hydrogen out of the plane in the same sense and \u03C3\u2095 is lost. Only the C\u2083 axis remains, and the molecule is a chiral propeller."},{id:"sf4",name:"Sulfur tetrafluoride",formula:"SF<sub>4</sub>",expected:"C2v",atoms:[["S",0,0,0],["F",1.643,0,-.1],["F",-1.643,0,-.1],["F",0,1.197,.977],["F",0,-1.197,.977]],note:"A see-saw. The lone pair on S (not drawn) sits in the equatorial plane. One C\u2082 axis and two vertical planes."},{id:"h2co",name:"Formaldehyde",formula:"H<sub>2</sub>CO",expected:"C2v",atoms:[["C",0,0,0],["O",0,0,1.205],["H",.935,0,-.526],["H",-.935,0,-.526]],note:"Planar, with the C\u2082 axis along C=O. One \u03C3\u1D65 is the molecular plane, the other cuts through it and swaps the hydrogens."},{id:"chcl3",name:"Chloroform",formula:"CHCl<sub>3</sub>",expected:"C3v",atoms:[["C",0,0,0],["H",0,0,1.073],...[0,1,2].map(i=>["Cl",..._e(1.677,90+120*i,-.5405)])],note:"Like ammonia: a C\u2083 axis along C\u2013H and three \u03C3\u1D65 planes, each holding H, C and one Cl."},{id:"cptl",name:"Cyclopentadienylthallium",formula:"CpTl",expected:"C5v",atoms:bd(),note:"A five-membered ring capped by one atom. The C\u2085 axis passes through Tl and the ring centre, with five vertical planes."},{id:"hcn",name:"Hydrogen cyanide",formula:"HCN",expected:"C\u221Ev",atoms:[["H",0,0,-1.065],["C",0,0,0],["N",0,0,1.156]],note:"Linear with different ends, so no inversion centre and no \u03C3\u2095. Same group as HCl."},{id:"socl2",name:"Thionyl chloride",formula:"SOCl<sub>2</sub>",expected:"Cs",atoms:[["S",0,0,0],["O",0,0,1.44],["Cl",1.2536,1.5389,-.588],["Cl",1.2536,-1.5389,-.588]],note:"A trigonal pyramid with three different corner atoms (O, Cl, Cl). The only symmetry is the plane through S and O that swaps the two chlorines."},{id:"tw-ethylene",name:"Ethylene, twisted 30\xB0",formula:"C<sub>2</sub>H<sub>4</sub>",expected:"D2",atoms:dd(30),note:"Twist one CH\u2082 group and the planes and inversion centre vanish, but three perpendicular C\u2082 axes remain. A chiral D\u2082 molecule."},{id:"b2h6",name:"Diborane",formula:"B<sub>2</sub>H<sub>6</sub>",expected:"D2h",atoms:yd(),note:"Two terminal BH\u2082 groups share a plane, and two bridging hydrogens lie above and below it. Three C\u2082 axes, three planes and an inversion centre."},{id:"pcl5",name:"Phosphorus pentachloride",formula:"PCl<sub>5</sub>",expected:"D3h",atoms:[["P",0,0,0],["Cl",0,0,2.19],["Cl",0,0,-2.19],...[0,1,2].map(i=>["Cl",..._e(2.04,90+120*i)])],note:"A trigonal bipyramid. The equatorial plane is \u03C3\u2095 and the three equatorial P\u2013Cl bonds are the C\u2082 axes."},{id:"c3h6",name:"Cyclopropane",formula:"C<sub>3</sub>H<sub>6</sub>",expected:"D3h",atoms:vd(),note:"C\u2083 is perpendicular to the ring. Each of the three C\u2082 axes runs through one carbon and the midpoint of the opposite C\u2013C bond. The ring plane is \u03C3\u2095, and it swaps the two hydrogens on every carbon."},{id:"re2cl8",name:"Octachlorodirhenate(III)",formula:"[Re<sub>2</sub>Cl<sub>8</sub>]<sup>2\u2212</sup>",expected:"D4h",atoms:fd(),note:"A quadruple Re\u2013Re bond holds the two ReCl\u2084 squares eclipsed. Turn one square by 45\xB0 (staggered) and the group would drop to D\u2084d."},{id:"s8",name:"Cyclo-octasulfur (crown)",formula:"S<sub>8</sub>",expected:"D4d",atoms:pd(),note:"The crown ring has an S\u2088 axis, which also gives C\u2084. Four C\u2082 axes and four \u03C3d planes lie between them. There is no \u03C3\u2095 and no inversion centre."},{id:"fc-ecl",name:"Ferrocene, eclipsed",formula:"Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub>",expected:"D5h",atoms:zc(!1),note:"Two Cp rings directly above each other. The group is the same as for IF\u2087. The plane \u03C3\u2095 passes through Fe and swaps the two rings."},{id:"fc-stag",name:"Ferrocene, staggered",formula:"Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub>",expected:"D5d",atoms:zc(!0),note:"Rotate one ring by 36\xB0 and \u03C3\u2095 is lost, but i and an S\u2081\u2080 axis appear. The same relationship as eclipsed and staggered ethane."},{id:"chair",name:"Cyclohexane, chair",formula:"C<sub>6</sub>H<sub>12</sub>",expected:"D3d",atoms:md(),note:"C\u2083 through the ring centre, three C\u2082 axes between opposite bonds, three \u03C3d planes, i and S\u2086. The six axial hydrogens point alternately up and down."},{id:"adamantane",name:"Adamantane",formula:"C<sub>10</sub>H<sub>16</sub>",expected:"Td",atoms:gd(),note:"A fragment of the diamond lattice. Four CH groups form a tetrahedron, six CH\u2082 groups bridge its edges: 4 C\u2083, 3 C\u2082, 3 S\u2084 and 6 \u03C3d."},{id:"cubane",name:"Cubane",formula:"C<sub>8</sub>H<sub>8</sub>",expected:"Oh",atoms:_d(),note:"A carbon cube with an H on each corner. Same group as SF\u2086, even though the atoms sit on the vertices rather than the face centres."},{id:"conitro",name:"Hexanitrocobaltate(III) (idealised)",formula:"[Co(NO<sub>2</sub>)<sub>6</sub>]<sup>3\u2212</sup>",expected:"Th",atoms:xd(),note:"Six NO\u2082 groups on an octahedron, each lying in a different coordinate plane in a cyclic pattern. This destroys the C\u2084 axes and \u03C3d planes of O_h but keeps i, three \u03C3\u2095 and four C\u2083."},{id:"c2h2",name:"Acetylene",formula:"C<sub>2</sub>H<sub>2</sub>",expected:"D\u221Eh",atoms:[["H",0,0,-1.665],["C",0,0,-.6],["C",0,0,.6],["H",0,0,1.665]],note:"Linear and symmetric, like CO\u2082. Any linear molecule with identical ends is D\u221Eh."}];function Md(i){let t=0,e=[0,0,0];for(let[n,s,r,a]of i){let o=ad[n];t+=o,e[0]+=o*s,e[1]+=o*r,e[2]+=o*a}return e.map(n=>n/t)}function Td(i){let t=[];for(let e=0;e<i.length;e++)for(let n=e+1;n<i.length;n++){let s=i[e],r=i[n];Math.hypot(s.p[0]-r.p[0],s.p[1]-r.p[1],s.p[2]-r.p[2])<1.2*(Ar[s.el]+Ar[r.el])&&t.push([e,n])}return t}var Hc=["C1","Cs","Ci","C2","C3","S4","S6","C2v","C3v","C4v","C5v","C\u221Ev","C2h","C3h","D2","D3","D2h","D3h","D4h","D5h","D6h","D\u221Eh","D2d","D3d","D4d","D5d","Td","Th","Oh","Ih"],Ed=Sd.map((i,t)=>({m:i,i:t})).sort((i,t)=>Hc.indexOf(i.m.expected)-Hc.indexOf(t.m.expected)||i.i-t.i).map(i=>i.m),gn=Ed.map(i=>{let t=Md(i.atoms),e=i.atoms.map(([s,r,a,o])=>({el:s,p:[r-t[0],a-t[1],o-t[2]]})),n=Math.max(...e.map(s=>Math.hypot(...s.p)+.5));return{...i,atoms:e,bonds:Td(e),radius:n}});var $o={chfclbr:["\u0628\u0631\u0648\u0645\u0648\u200C\u06A9\u0644\u0631\u0648\u200C\u0641\u0644\u0648\u0626\u0648\u0631\u0648\u0645\u062A\u0627\u0646","\u0686\u0647\u0627\u0631 \u0627\u0633\u062A\u062E\u0644\u0627\u0641 \u0645\u062A\u0641\u0627\u0648\u062A. \u062C\u0632 \xAB\u0647\u06CC\u0686 \u06A9\u0627\u0631\u06CC \u0646\u06A9\u0631\u062F\u0646\xBB \u0647\u06CC\u0686 \u0639\u0645\u0644\u06CC \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0628\u0631 \u062E\u0648\u062F\u0634 \u0646\u0645\u06CC\u200C\u0646\u06AF\u0627\u0631\u062F\u061B \u067E\u0633 \u06CC\u06A9\u0633\u0627\u0646\u06CC \u062A\u0646\u0647\u0627 \u0639\u0645\u0644 \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A. \u0645\u0648\u0644\u06A9\u0648\u0644 \u06A9\u0627\u06CC\u0631\u0627\u0644 \u0627\u0633\u062A."],ch2clf:["\u06A9\u0644\u0631\u0648\u200C\u0641\u0644\u0648\u0626\u0648\u0631\u0648\u0645\u062A\u0627\u0646","\u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0632 \u06A9\u0631\u0628\u0646\u060C \u06A9\u0644\u0631 \u0648 \u0641\u0644\u0648\u0626\u0648\u0631 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F \u0648 \u062F\u0648 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0631\u0627 \u0628\u0627 \u0647\u0645 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F."],socl2:["\u062A\u06CC\u0648\u0646\u06CC\u0644 \u06A9\u0644\u0631\u06CC\u062F","\u0647\u0631\u0645 \u0645\u062B\u0644\u062B\u06CC \u0628\u0627 \u0633\u0647 \u0631\u0623\u0633 \u0645\u062A\u0641\u0627\u0648\u062A (\u0627\u06A9\u0633\u06CC\u0698\u0646\u060C \u06A9\u0644\u0631\u060C \u06A9\u0644\u0631). \u062A\u0646\u0647\u0627 \u062A\u0642\u0627\u0631\u0646\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A \u06A9\u0647 \u0627\u0632 \u06AF\u0648\u06AF\u0631\u062F \u0648 \u0627\u06A9\u0633\u06CC\u0698\u0646 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F \u0648 \u062F\u0648 \u06A9\u0644\u0631 \u0631\u0627 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F."],"meso-ci":["\u0645\u0632\u0648-\u06F1\u060C\u06F2-\u062F\u06CC\u200C\u0628\u0631\u0648\u0645\u0648-\u06F1\u060C\u06F2-\u062F\u06CC\u200C\u06A9\u0644\u0631\u0648\u0627\u062A\u0627\u0646 (\u0622\u0646\u062A\u06CC)","\u062F\u0631 \u0647\u0645\u0633\u0627\u0646\u0647\u0654 \u0622\u0646\u062A\u06CC\u060C \u0648\u0633\u0637 \u067E\u06CC\u0648\u0646\u062F C\u2013C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u0633\u062A. \u0647\u0631 \u0627\u062A\u0645 \u062F\u0631\u0633\u062A \u062F\u0631 \u0633\u0645\u062A \u0645\u0642\u0627\u0628\u0644 \u06CC\u06A9 \u0647\u0645\u200C\u0627\u0631\u0632 \u062F\u0627\u0631\u062F. \u0647\u06CC\u0686 \u0645\u062D\u0648\u0631 \u06CC\u0627 \u0635\u0641\u062D\u0647\u200C\u0627\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."],h2o2:["\u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u067E\u0631\u0627\u06A9\u0633\u06CC\u062F","\u0634\u06A9\u0644 \u06A9\u062C (\u0632\u0627\u0648\u06CC\u0647\u0654 \u062F\u0648\u0648\u062C\u0647\u06CC \u0646\u0632\u062F\u06CC\u06A9 \u06F1\u06F1\u06F1\xB0) \u0641\u0642\u0637 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0631\u0627 \u0646\u06AF\u0647 \u0645\u06CC\u200C\u062F\u0627\u0631\u062F \u06A9\u0647 \u067E\u06CC\u0686\u0634 H\u2013O\u2013O\u2013H \u0631\u0627 \u0646\u0635\u0641 \u0645\u06CC\u200C\u06A9\u0646\u062F. \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u0632 \u0628\u06CC\u0646 \u0645\u06CC\u200C\u0631\u0648\u0646\u062F\u061B \u067E\u0633 \u0645\u0648\u0644\u06A9\u0648\u0644 \u06A9\u0627\u06CC\u0631\u0627\u0644 \u0627\u0633\u062A."],"boh3-prop":["\u0628\u0648\u0631\u06CC\u06A9 \u0627\u0633\u06CC\u062F\u060C \u0634\u06A9\u0644 \u067E\u0631\u0648\u0627\u0646\u0647\u200C\u0627\u06CC","\u0627\u06AF\u0631 \u0647\u0631 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0631\u0627 \u0647\u0645\u200C\u062C\u0647\u062A \u0627\u0632 \u0635\u0641\u062D\u0647 \u0628\u06CC\u0631\u0648\u0646 \u0628\u06CC\u0627\u0648\u0631\u06CC\u0645\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0632 \u0628\u06CC\u0646 \u0645\u06CC\u200C\u0631\u0648\u062F. \u0641\u0642\u0637 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0645\u06CC\u200C\u0645\u0627\u0646\u062F \u0648 \u0645\u0648\u0644\u06A9\u0648\u0644 \u06CC\u06A9 \u067E\u0631\u0648\u0627\u0646\u0647\u0654 \u06A9\u0627\u06CC\u0631\u0627\u0644 \u0627\u0633\u062A."],pentaerythritol:["\u067E\u0646\u062A\u0627\u0627\u0631\u06CC\u062A\u0631\u06CC\u062A\u0648\u0644 (\u0622\u0631\u0645\u0627\u0646\u06CC)","\u0686\u0647\u0627\u0631 \u0628\u0627\u0632\u0648\u06CC \u06CC\u06A9\u0633\u0627\u0646 \u06A9\u0647 \u0647\u0645\u06AF\u06CC \u0647\u0645\u200C\u062C\u0647\u062A \u067E\u06CC\u0686 \u062E\u0648\u0631\u062F\u0647\u200C\u0627\u0646\u062F. \u0646\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0647\u0633\u062A\u060C \u0646\u0647 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0646\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4\u061B \u0628\u0627 \u0627\u06CC\u0646 \u062D\u0627\u0644 \u0686\u0631\u062E\u0634 \u06F9\u06F0\xB0 \u0648 \u0633\u067E\u0633 \u0628\u0627\u0632\u062A\u0627\u0628 \u06CC\u06A9 \u0639\u0645\u0644 \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A\u060C \u06CC\u0639\u0646\u06CC \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4. \u0627\u06CC\u0646 \u06AF\u0631\u0648\u0647 \u0641\u0642\u0637 \u06CC\u06A9\u0633\u0627\u0646\u06CC\u060C \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0648 \u062F\u0648 \u0639\u0645\u0644 \u0627\u0632 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0631\u0627 \u062F\u0627\u0631\u062F."],hexol:["\u0647\u06AF\u0632\u0627\u0647\u06CC\u062F\u0631\u0648\u06A9\u0633\u06CC\u200C\u0627\u062A\u0627\u0646\u060C \u067E\u06CC\u0686\u200C\u062E\u0648\u0631\u062F\u0647","\u0645\u0627\u0646\u0646\u062F \u0627\u062A\u0627\u0646 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627 (staggered) \u0627\u0633\u062A\u060C \u0627\u0645\u0627 \u0647\u0645\u0647\u0654 \u067E\u06CC\u0648\u0646\u062F\u0647\u0627\u06CC O\u2013H \u0647\u0645\u200C\u062C\u0647\u062A\u200C\u0627\u0646\u062F. \u0627\u06CC\u0646 \u06A9\u0627\u0631 \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u06AF\u0631\u0648\u0647 D\u2083d \u0631\u0627 \u062D\u0630\u0641 \u0645\u06CC\u200C\u06A9\u0646\u062F \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6 (\u0686\u0631\u062E\u0634 \u06F6\u06F0\xB0 \u0648 \u0628\u0627\u0632\u062A\u0627\u0628) \u0645\u06CC\u200C\u0645\u0627\u0646\u062F."],h2o:["\u0622\u0628","\u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0627\u0632 \u0627\u06A9\u0633\u06CC\u0698\u0646 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F. \u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0648 \u0635\u0641\u062D\u0647\u0654 \u062F\u0648\u0645 \u06A9\u0647 \u0639\u0645\u0648\u062F \u0628\u0631 \u0622\u0646 \u0627\u0633\u062A \u0648 \u0645\u062D\u0648\u0631 \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F\u060C \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC\u200C\u0627\u0646\u062F."],sf4:["\u06AF\u0648\u06AF\u0631\u062F \u062A\u062A\u0631\u0627\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u0633\u0627\u062E\u062A\u0627\u0631 \u0627\u0644\u0627\u06A9\u0644\u0646\u06AF\u06CC. \u062C\u0641\u062A\u200C\u0627\u0644\u06A9\u062A\u0631\u0648\u0646 \u0646\u0627\u067E\u06CC\u0648\u0646\u062F\u06CC \u06AF\u0648\u06AF\u0631\u062F (\u0631\u0633\u0645 \u0646\u0634\u062F\u0647) \u062F\u0631 \u0635\u0641\u062D\u0647\u0654 \u0627\u0633\u062A\u0648\u0627\u06CC\u06CC \u0627\u0633\u062A. \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0648 \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC."],h2co:["\u0641\u0631\u0645\u0627\u0644\u062F\u0647\u06CC\u062F","\u0645\u0633\u0637\u062D \u0627\u0633\u062A \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u062F\u0631 \u0627\u0645\u062A\u062F\u0627\u062F C=O \u0642\u0631\u0627\u0631 \u062F\u0627\u0631\u062F. \u06CC\u06A9\u06CC \u0627\u0632 \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0627\u0633\u062A \u0648 \u062F\u06CC\u06AF\u0631\u06CC \u0627\u0632 \u0622\u0646 \u0639\u0628\u0648\u0631 \u0645\u06CC\u200C\u06A9\u0646\u062F \u0648 \u062F\u0648 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0631\u0627 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F."],nh3:["\u0622\u0645\u0648\u0646\u06CC\u0627\u06A9","\u0647\u0631\u0645 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0648 \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u062F\u0627\u0631\u062F \u06A9\u0647 \u0647\u0631 \u06A9\u062F\u0627\u0645 \u0646\u06CC\u062A\u0631\u0648\u0698\u0646 \u0648 \u06CC\u06A9 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0631\u0627 \u062F\u0631 \u0628\u0631 \u0645\u06CC\u200C\u06AF\u06CC\u0631\u062F."],chcl3:["\u06A9\u0644\u0631\u0648\u0641\u0631\u0645","\u0645\u0627\u0646\u0646\u062F \u0622\u0645\u0648\u0646\u06CC\u0627\u06A9: \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u062F\u0631 \u0627\u0645\u062A\u062F\u0627\u062F C\u2013H \u0648 \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u06A9\u0647 \u0647\u0631 \u06CC\u06A9 H\u060C C \u0648 \u06CC\u06A9 Cl \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F."],brf5:["\u0628\u0631\u0645 \u067E\u0646\u062A\u0627\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u0647\u0631\u0645 \u0645\u0631\u0628\u0639\u06CC. \u062C\u0641\u062A\u200C\u0627\u0644\u06A9\u062A\u0631\u0648\u0646 \u0646\u0627\u067E\u06CC\u0648\u0646\u062F\u06CC \u0628\u0631\u0645 \u0631\u0648\u0628\u0647\u200C\u0631\u0648\u06CC \u0631\u0623\u0633 \u0627\u0633\u062A \u0648 \u0631\u0633\u0645 \u0646\u0634\u062F\u0647. \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4\u060C \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648 \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC."],cptl:["\u0633\u06CC\u06A9\u0644\u0648\u067E\u0646\u062A\u0627\u062F\u06CC\u200C\u0627\u0646\u06CC\u0644 \u062A\u0627\u0644\u06CC\u0645","\u06CC\u06A9 \u062D\u0644\u0642\u0647\u0654 \u067E\u0646\u062C\u200C\u0639\u0636\u0648\u06CC \u06A9\u0647 \u06CC\u06A9 \u0627\u062A\u0645 \u0631\u0648\u06CC \u0622\u0646 \u0646\u0634\u0633\u062A\u0647 \u0627\u0633\u062A. \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5 \u0627\u0632 \u062A\u0627\u0644\u06CC\u0645 \u0648 \u0645\u0631\u06A9\u0632 \u062D\u0644\u0642\u0647 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F \u0648 \u067E\u0646\u062C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u062F\u0627\u0631\u062F."],hcl:["\u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u06A9\u0644\u0631\u06CC\u062F","\u062E\u0637\u06CC \u0628\u0627 \u062F\u0648 \u0633\u0631 \u0646\u0627\u0647\u0645\u0627\u0646\u0646\u062F. \u0647\u0631 \u0686\u0631\u062E\u0634\u06CC \u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u067E\u06CC\u0648\u0646\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A (\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u221E) \u0648 \u0647\u0631 \u0635\u0641\u062D\u0647\u200C\u0627\u06CC \u06A9\u0647 \u0645\u062D\u0648\u0631 \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F \u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0627\u0633\u062A."],hcn:["\u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0633\u06CC\u0627\u0646\u06CC\u062F","\u062E\u0637\u06CC \u0628\u0627 \u062F\u0648 \u0633\u0631 \u0645\u062A\u0641\u0627\u0648\u062A\u061B \u067E\u0633 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0646\u062F\u0627\u0631\u062F. \u06AF\u0631\u0648\u0647 \u0622\u0646 \u0628\u0627 HCl \u06CC\u06A9\u06CC \u0627\u0633\u062A."],tdce:["\u062A\u0631\u0627\u0646\u0633-\u06F1\u060C\u06F2-\u062F\u06CC\u200C\u06A9\u0644\u0631\u0648\u0627\u062A\u0646","\u0645\u0633\u0637\u062D \u0648 \u062F\u0627\u0631\u0627\u06CC \u0645\u0631\u06A9\u0632 \u062A\u0642\u0627\u0631\u0646. \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0628\u0631 \u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0639\u0645\u0648\u062F \u0627\u0633\u062A \u0648 \u062E\u0648\u062F \u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0633\u062A. \u0627\u06CC\u0646 \u062F\u0648 \u0628\u0627 \u0647\u0645 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0631\u0627 \u0645\u06CC\u200C\u0633\u0627\u0632\u0646\u062F."],boh3:["\u0628\u0648\u0631\u06CC\u06A9 \u0627\u0633\u06CC\u062F","\u0645\u0633\u0637\u062D\u060C \u0628\u0627 \u0647\u0631 \u0633\u0647 \u067E\u06CC\u0648\u0646\u062F O\u2013H \u062F\u0631 \u06CC\u06A9 \u062C\u0647\u062A. \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0647\u0645\u0631\u0627\u0647 \u0628\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0631\u0627 \u0645\u06CC\u200C\u062F\u0647\u062F\u060C \u0627\u0645\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."],"tw-ethylene":["\u0627\u062A\u06CC\u0644\u0646\u060C \u067E\u06CC\u0686\u200C\u062E\u0648\u0631\u062F\u0647 \u06F3\u06F0\xB0","\u0627\u06AF\u0631 \u06CC\u06A9 \u06AF\u0631\u0648\u0647 CH\u2082 \u0631\u0627 \u0628\u067E\u06CC\u0686\u0627\u0646\u06CC\u0645\u060C \u0635\u0641\u062D\u0647\u200C\u0647\u0627 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u0632 \u0628\u06CC\u0646 \u0645\u06CC\u200C\u0631\u0648\u0646\u062F\u060C \u0627\u0645\u0627 \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u062F\u0648\u200C\u0628\u0647\u200C\u062F\u0648 \u0639\u0645\u0648\u062F \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F. \u0645\u0648\u0644\u06A9\u0648\u0644\u06CC \u06A9\u0627\u06CC\u0631\u0627\u0644 \u0628\u0627 \u06AF\u0631\u0648\u0647 D\u2082."],"ethane-30":["\u0627\u062A\u0627\u0646\u060C \u067E\u06CC\u0686\u200C\u062E\u0648\u0631\u062F\u0647 \u06F3\u06F0\xB0","\u0645\u06CC\u0627\u0646\u0647\u0654 \u062D\u0627\u0644\u062A \u067E\u0648\u0634\u06CC\u062F\u0647 \u0648 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627. \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0646\u0627\u067E\u062F\u06CC\u062F \u0645\u06CC\u200C\u0634\u0648\u0646\u062F \u0648 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0648 \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F\u06CC \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F. \u0645\u0648\u0644\u06A9\u0648\u0644 \u06A9\u0627\u06CC\u0631\u0627\u0644 \u0627\u0633\u062A."],c2h4:["\u0627\u062A\u06CC\u0644\u0646","\u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u062F\u0648\u200C\u0628\u0647\u200C\u062F\u0648 \u0639\u0645\u0648\u062F\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 (\u06CC\u06A9\u06CC \u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644) \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC."],b2h6:["\u062F\u06CC\u200C\u0628\u0648\u0631\u0627\u0646","\u062F\u0648 \u06AF\u0631\u0648\u0647 BH\u2082 \u0627\u0646\u062A\u0647\u0627\u06CC\u06CC \u062F\u0631 \u06CC\u06A9 \u0635\u0641\u062D\u0647\u200C\u0627\u0646\u062F \u0648 \u062F\u0648 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u067E\u0644\u200C\u0633\u0627\u0632 \u0628\u0627\u0644\u0627 \u0648 \u067E\u0627\u06CC\u06CC\u0646 \u0622\u0646 \u0642\u0631\u0627\u0631 \u062F\u0627\u0631\u0646\u062F. \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC."],bf3:["\u0628\u0648\u0631 \u062A\u0631\u06CC\u200C\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u062F\u0631 \u0627\u0645\u062A\u062F\u0627\u062F \u067E\u06CC\u0648\u0646\u062F\u0647\u0627\u06CC B\u2013F\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC (\u0635\u0641\u062D\u0647\u0654 \u0645\u0648\u0644\u06A9\u0648\u0644)\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F3."],"ethane-0":["\u0627\u062A\u0627\u0646\u060C \u067E\u0648\u0634\u06CC\u062F\u0647 (eclipsed)","\u0648\u0642\u062A\u06CC \u06AF\u0631\u0648\u0647\u200C\u0647\u0627\u06CC CH\u2083 \u0631\u0648\u06CC \u0647\u0645 \u0645\u06CC\u200C\u0627\u0641\u062A\u0646\u062F\u060C \u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u067E\u06CC\u0648\u0646\u062F C\u2013C \u0631\u0627 \u0646\u0635\u0641 \u0645\u06CC\u200C\u06A9\u0646\u062F. \u0634\u06A9\u0644 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627 \u0631\u0627 \u062F\u0631 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0639\u062F\u06CC \u0645\u0642\u0627\u06CC\u0633\u0647 \u06A9\u0646\u06CC\u062F."],pcl5:["\u0641\u0633\u0641\u0631 \u067E\u0646\u062A\u0627\u06A9\u0644\u0631\u06CC\u062F","\u062F\u0648\u0647\u0631\u0645 \u0645\u062B\u0644\u062B\u06CC. \u0635\u0641\u062D\u0647\u0654 \u0627\u0633\u062A\u0648\u0627\u06CC\u06CC \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0633\u062A \u0648 \u0633\u0647 \u067E\u06CC\u0648\u0646\u062F \u0627\u0633\u062A\u0648\u0627\u06CC\u06CC P\u2013Cl \u0647\u0645\u0627\u0646 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0647\u0633\u062A\u0646\u062F."],c3h6:["\u0633\u06CC\u06A9\u0644\u0648\u067E\u0631\u0648\u067E\u0627\u0646","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0628\u0631 \u062D\u0644\u0642\u0647 \u0639\u0645\u0648\u062F \u0627\u0633\u062A. \u0647\u0631 \u06CC\u06A9 \u0627\u0632 \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0627\u0632 \u06CC\u06A9 \u06A9\u0631\u0628\u0646 \u0648 \u0645\u06CC\u0627\u0646\u0647\u0654 \u067E\u06CC\u0648\u0646\u062F C\u2013C \u0631\u0648\u0628\u0647\u200C\u0631\u0648 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F. \u0635\u0641\u062D\u0647\u0654 \u062D\u0644\u0642\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0633\u062A \u0648 \u062F\u0648 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0647\u0631 \u06A9\u0631\u0628\u0646 \u0631\u0627 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F."],xef4:["\u0632\u0646\u0648\u0646 \u062A\u062A\u0631\u0627\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u0645\u0633\u0637\u062D \u0645\u0631\u0628\u0639\u06CC: \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0639\u0645\u0648\u062F \u0628\u0631 \u0635\u0641\u062D\u0647\u060C \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 (\u062F\u0648 \u062A\u0627 \u0627\u0632 \u0627\u062A\u0645\u200C\u0647\u0627\u06CC F \u0648 \u062F\u0648 \u062A\u0627 \u0645\u06CC\u0627\u0646 \u0622\u0646\u200C\u0647\u0627)\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC\u060C \u062F\u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC\u060C \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC. \u0645\u0631\u062A\u0628\u0647 \u06F1\u06F6."],re2cl8:["\u0627\u06A9\u062A\u0627\u06A9\u0644\u0631\u0648\u062F\u06CC\u200C\u0631\u0646\u0627\u062A(III)","\u067E\u06CC\u0648\u0646\u062F \u0686\u0647\u0627\u0631\u06AF\u0627\u0646\u0647\u0654 Re\u2013Re \u062F\u0648 \u0645\u0631\u0628\u0639 ReCl\u2084 \u0631\u0627 \u0631\u0648\u06CC \u0647\u0645 \u0646\u06AF\u0647 \u0645\u06CC\u200C\u062F\u0627\u0631\u062F (\u067E\u0648\u0634\u06CC\u062F\u0647). \u0627\u06AF\u0631 \u06CC\u06A9 \u0645\u0631\u0628\u0639 \u06F4\u06F5\xB0 \u0628\u0686\u0631\u062E\u062F (\u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627)\u060C \u06AF\u0631\u0648\u0647 \u0628\u0647 D\u2084d \u0645\u06CC\u200C\u0631\u0633\u062F."],if7:["\u06CC\u062F \u0647\u067E\u062A\u0627\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u062F\u0648\u0647\u0631\u0645 \u067E\u0646\u062C\u200C\u0636\u0644\u0639\u06CC. \u062A\u0642\u0627\u0631\u0646 \u067E\u0646\u062C\u200C\u06AF\u0627\u0646\u0647 \u062F\u0631 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0645\u062C\u0627\u0632 \u0627\u0633\u062A\u060C \u0647\u0631\u0686\u0646\u062F \u062F\u0631 \u0628\u0644\u0648\u0631 \u0647\u0631\u06AF\u0632 \u062F\u06CC\u062F\u0647 \u0646\u0645\u06CC\u200C\u0634\u0648\u062F. \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5\u060C \u067E\u0646\u062C \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u067E\u0646\u062C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F5."],"fc-ecl":["\u0641\u0631\u0648\u0633\u0646\u060C \u067E\u0648\u0634\u06CC\u062F\u0647","\u062F\u0648 \u062D\u0644\u0642\u0647\u0654 Cp \u062F\u0631\u0633\u062A \u0631\u0648\u06CC \u0647\u0645. \u06AF\u0631\u0648\u0647 \u0622\u0646 \u0628\u0627 IF\u2087 \u06CC\u06A9\u06CC \u0627\u0633\u062A. \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0632 \u0622\u0647\u0646 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F \u0648 \u062F\u0648 \u062D\u0644\u0642\u0647 \u0631\u0627 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F."],benzene:["\u0628\u0646\u0632\u0646","\u0645\u062B\u0627\u0644 \u06A9\u0644\u0627\u0633\u06CC\u06A9 D\u2086h: \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F6\u060C \u0634\u0634 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F\u06CC (\u06F3 + \u06F3)\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6. \u0645\u0631\u062A\u0628\u0647 \u06F2\u06F4."],co2:["\u06A9\u0631\u0628\u0646 \u062F\u06CC\u200C\u0627\u06A9\u0633\u06CC\u062F","\u062E\u0637\u06CC \u0648 \u0645\u062A\u0642\u0627\u0631\u0646: \u0647\u0645\u0647\u0654 \u062A\u0642\u0627\u0631\u0646 HCl \u0628\u0647\u200C\u0639\u0644\u0627\u0648\u0647\u0654 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0648 \u0628\u06CC\u200C\u0634\u0645\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F\u06CC."],c2h2:["\u0627\u0633\u062A\u06CC\u0644\u0646","\u062E\u0637\u06CC \u0648 \u0645\u062A\u0642\u0627\u0631\u0646 \u0645\u0627\u0646\u0646\u062F CO\u2082. \u0647\u0631 \u0645\u0648\u0644\u06A9\u0648\u0644 \u062E\u0637\u06CC \u0628\u0627 \u062F\u0648 \u0633\u0631 \u06CC\u06A9\u0633\u0627\u0646 D\u221Eh \u0627\u0633\u062A."],allene:["\u0622\u0644\u0646 (\u067E\u0631\u0648\u067E\u0627\u062F\u06CC\u200C\u0627\u0646)","\u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062F\u0648 \u06AF\u0631\u0648\u0647 CH\u2082 \u0628\u0631 \u0647\u0645 \u0639\u0645\u0648\u062F\u0646\u062F. \u0646\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u062F\u0627\u0631\u062F \u0648 \u0646\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u0627\u0645\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u062F\u0627\u0631\u062F: \u06F9\u06F0\xB0 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F \u0648 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F. \u0627\u06CC\u0646 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0648\u0627\u0642\u0639\u06CC \u0627\u0633\u062A."],"ethane-60":["\u0627\u062A\u0627\u0646\u060C \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627","\u0627\u062A\u0627\u0646 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0646\u062F\u0627\u0631\u062F\u060C \u0627\u0645\u0627 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6 \u062F\u0631 \u0627\u0645\u062A\u062F\u0627\u062F C\u2013C \u062F\u0627\u0631\u062F. \u06F6\u06F0\xB0 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F \u0648 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F: \u0647\u0645\u0647\u0654 \u0627\u062A\u0645\u200C\u0647\u0627 \u0631\u0648\u06CC \u0627\u062A\u0645\u200C\u0647\u0627\u06CC \u0647\u0645\u200C\u0627\u0631\u0632 \u0645\u06CC\u200C\u0627\u0641\u062A\u0646\u062F."],chair:["\u0633\u06CC\u06A9\u0644\u0648\u0647\u06AF\u0632\u0627\u0646\u060C \u0635\u0646\u062F\u0644\u06CC","\u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0627\u0632 \u0645\u0631\u06A9\u0632 \u062D\u0644\u0642\u0647\u060C \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0645\u06CC\u0627\u0646 \u067E\u06CC\u0648\u0646\u062F\u0647\u0627\u06CC \u0631\u0648\u0628\u0647\u200C\u0631\u0648\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6. \u0634\u0634 \u0647\u06CC\u062F\u0631\u0648\u0698\u0646 \u0622\u06A9\u0633\u06CC\u0627\u0644 \u06CC\u06A9\u06CC\u200C\u062F\u0631\u0645\u06CC\u0627\u0646 \u0628\u0627\u0644\u0627 \u0648 \u067E\u0627\u06CC\u06CC\u0646\u200C\u0627\u0646\u062F."],s8:["\u0633\u06CC\u06A9\u0644\u0648-\u0627\u06A9\u062A\u0627\u06AF\u0648\u06AF\u0631\u062F (\u062A\u0627\u062C\u06CC)","\u062D\u0644\u0642\u0647\u0654 \u062A\u0627\u062C\u06CC \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F8 \u062F\u0627\u0631\u062F \u06A9\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0631\u0627 \u0647\u0645 \u0645\u06CC\u200C\u062F\u0647\u062F. \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0648 \u0686\u0647\u0627\u0631 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u0645\u06CC\u0627\u0646 \u0622\u0646\u200C\u0647\u0627\u0633\u062A. \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0646\u062F\u0627\u0631\u062F."],"fc-stag":["\u0641\u0631\u0648\u0633\u0646\u060C \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627","\u0627\u06AF\u0631 \u06CC\u06A9 \u062D\u0644\u0642\u0647 \u06F3\u06F6\xB0 \u0628\u0686\u0631\u062E\u062F\u060C \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0627\u0632 \u0628\u06CC\u0646 \u0645\u06CC\u200C\u0631\u0648\u062F\u060C \u0627\u0645\u0627 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F1\u06F0 \u067E\u062F\u06CC\u062F\u0627\u0631 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F\u061B \u0647\u0645\u0627\u0646 \u0631\u0627\u0628\u0637\u0647\u0654 \u0627\u062A\u0627\u0646 \u067E\u0648\u0634\u06CC\u062F\u0647 \u0648 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627."],ch4:["\u0645\u062A\u0627\u0646","\u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 (\u0627\u0632 \u0647\u0631 \u067E\u06CC\u0648\u0646\u062F C\u2013H)\u060C \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u0634\u0634 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u0648 \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4. \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0646\u062F\u0627\u0631\u062F."],adamantane:["\u0622\u062F\u0627\u0645\u0627\u0646\u062A\u0627\u0646","\u0642\u0637\u0639\u0647\u200C\u0627\u06CC \u0627\u0632 \u0634\u0628\u06A9\u0647\u0654 \u0627\u0644\u0645\u0627\u0633. \u0686\u0647\u0627\u0631 \u06AF\u0631\u0648\u0647 CH \u06CC\u06A9 \u0686\u0647\u0627\u0631\u0648\u062C\u0647\u06CC \u0645\u06CC\u200C\u0633\u0627\u0632\u0646\u062F \u0648 \u0634\u0634 \u06AF\u0631\u0648\u0647 CH\u2082 \u0644\u0628\u0647\u200C\u0647\u0627\u06CC \u0622\u0646 \u0631\u0627 \u067E\u0644 \u0645\u06CC\u200C\u0632\u0646\u0646\u062F: \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648 \u0634\u0634 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC."],conitro:["\u0647\u06AF\u0632\u0627\u0646\u06CC\u062A\u0631\u0648\u06A9\u0628\u0627\u0644\u062A\u0627\u062A(III) (\u0622\u0631\u0645\u0627\u0646\u06CC)","\u0634\u0634 \u06AF\u0631\u0648\u0647 NO\u2082 \u0631\u0648\u06CC \u06CC\u06A9 \u0647\u0634\u062A\u200C\u0648\u062C\u0647\u06CC\u060C \u06A9\u0647 \u0647\u0631 \u06A9\u062F\u0627\u0645 \u0628\u0647\u200C\u0635\u0648\u0631\u062A \u0686\u0631\u062E\u0647\u200C\u0627\u06CC \u062F\u0631 \u06CC\u06A9 \u0635\u0641\u062D\u0647\u0654 \u0645\u062E\u062A\u0635\u0627\u062A\u06CC \u0642\u0631\u0627\u0631 \u062F\u0627\u0631\u062F. \u0627\u06CC\u0646 \u06A9\u0627\u0631 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648 \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u06AF\u0631\u0648\u0647 O_h \u0631\u0627 \u0627\u0632 \u0628\u06CC\u0646 \u0645\u06CC\u200C\u0628\u0631\u062F\u060C \u0627\u0645\u0627 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0648 \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0631\u0627 \u0646\u06AF\u0647 \u0645\u06CC\u200C\u062F\u0627\u0631\u062F."],sf6:["\u06AF\u0648\u06AF\u0631\u062F \u0647\u06AF\u0632\u0627\u0641\u0644\u0648\u0626\u0648\u0631\u06CC\u062F","\u0647\u0634\u062A\u200C\u0648\u062C\u0647\u06CC: \u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4\u060C \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u0634\u0634 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u0633\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC\u060C \u0634\u0634 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648 \u06F6. \u0645\u0631\u062A\u0628\u0647 \u06F4\u06F8."],cubane:["\u06A9\u0648\u0628\u0627\u0646","\u0645\u06A9\u0639\u0628\u06CC \u0627\u0632 \u06A9\u0631\u0628\u0646 \u0628\u0627 \u06CC\u06A9 H \u0631\u0648\u06CC \u0647\u0631 \u06AF\u0648\u0634\u0647. \u06AF\u0631\u0648\u0647 \u0622\u0646 \u0628\u0627 SF\u2086 \u06CC\u06A9\u06CC \u0627\u0633\u062A\u060C \u0647\u0631\u0686\u0646\u062F \u0627\u062A\u0645\u200C\u0647\u0627 \u0631\u0648\u06CC \u0631\u0623\u0633\u200C\u0647\u0627 \u0646\u0634\u0633\u062A\u0647\u200C\u0627\u0646\u062F \u0648 \u0646\u0647 \u0645\u0631\u06A9\u0632 \u0648\u062C\u0647\u200C\u0647\u0627."],b12h12:["\u062F\u06CC\u200C\u0622\u0646\u06CC\u0648\u0646 \u06A9\u0644\u0648\u0632\u0648-\u062F\u0648\u062F\u06A9\u0627\u0628\u0648\u0631\u0627\u062A","\u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC: \u0634\u0634 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5\u060C \u062F\u0647 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u067E\u0627\u0646\u0632\u062F\u0647 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F2\u060C \u067E\u0627\u0646\u0632\u062F\u0647 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F1\u06F0 \u0648 \u06F6. \u0645\u0631\u062A\u0628\u0647 \u06F1\u06F2\u06F0\u060C \u0628\u0632\u0631\u06AF\u200C\u062A\u0631\u06CC\u0646 \u0645\u0631\u062A\u0628\u0647 \u062F\u0631 \u06AF\u0631\u0648\u0647\u200C\u0647\u0627\u06CC \u0645\u06A9\u0639\u0628\u06CC \u0648 \u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC."]};var bi=(i,t)=>i[0]*t[0]+i[1]*t[1]+i[2]*t[2],Bn=(i,t)=>[i[1]*t[2]-i[2]*t[1],i[2]*t[0]-i[0]*t[2],i[0]*t[1]-i[1]*t[0]],Rr=(i,t)=>[i[0]+t[0],i[1]+t[1],i[2]+t[2]],$c=(i,t)=>[i[0]-t[0],i[1]-t[1],i[2]-t[2]],Pr=i=>Math.hypot(i[0],i[1],i[2]),Hi=i=>{let t=Pr(i);return t<1e-6?null:[i[0]/t,i[1]/t,i[2]/t]};function Gi(i,t,e){let n=Math.cos(e),s=Math.sin(e),r=bi(t,i)*(1-n),a=Bn(t,i);return[i[0]*n+a[0]*s+t[0]*r,i[1]*n+a[1]*s+t[1]*r,i[2]*n+a[2]*s+t[2]*r]}function qc(i,t){let e=2*bi(i,t);return[i[0]-e*t[0],i[1]-e*t[1],i[2]-e*t[2]]}function qo(i){for(let t=0;t<3;t++)if(Math.abs(i[t])>1e-4)return i[t]<0?[-i[0],-i[1],-i[2]]:i;return i}var wd=i=>qo(i).map(t=>Math.round(t*400)).join(","),ti=(i,t)=>Math.abs(bi(i,t))>.9995,Vi=(i,t)=>Math.abs(bi(i,t))<.02,en=(i,t="",e="")=>({b:i,s:String(t),x:e}),Si=i=>`${i.b}${i.s?`<sub>${i.s}</sub>`:""}${i.x||""}`,Ad=i=>`${i.b}${i.s}${i.x||""}`,Cd=[2,3,4,5,6],Rd=[3,4,5,6,8,10,12];function Pd(i){let t=/^([A-Za-z]+)(\d*|∞)([a-z]*)$/.exec(i);if(!t)return null;let[,e,n,s]=t,r=n==="\u221E"?1/0:parseInt(n||"1",10);return r===1/0?"\u221E":e==="C"&&s===""?r:e==="C"&&(s==="v"||s==="h")||e==="D"&&s===""?2*r:e==="D"&&(s==="h"||s==="d")?4*r:e==="S"?r:i==="Cs"||i==="Ci"?2:{T:12,Td:24,Th:24,O:24,Oh:48,I:60,Ih:120}[i]??null}function Mi(i){let t=/^([CDS])(\d+|∞)([a-z]?)$/.exec(i);return t?`${t[1]}<sub>${t[2]}</sub>${t[3]}`:i}function Yc(i){var ht;let t=i.map(Y=>Y.p),e=i.map(Y=>Y.el),n=t.length,s=Y=>{let J=new Set;for(let nt=0;nt<n;nt++){let O=Y(t[nt]),H=-1;for(let at=0;at<n;at++)if(e[at]===e[nt]&&Math.hypot(t[at][0]-O[0],t[at][1]-O[1],t[at][2]-O[2])<.08){H=at;break}if(H<0)return!1;J.add(H)}return J.size===n},r=(Y,J)=>s(nt=>Gi(nt,Y,2*Math.PI/J)),a=(Y,J)=>s(nt=>qc(Gi(nt,Y,2*Math.PI/J),Y)),o=Y=>s(J=>qc(J,Y)),l=s(Y=>[-Y[0],-Y[1],-Y[2]]),c=t.reduce((Y,J)=>Pr(J)>Pr(Y)?J:Y,[0,0,0]),u=Hi(c),f=!!u&&t.every(Y=>Pr(Bn(Y,u))<.02),h=[],p=[];if(!f){let Y=new Set,J=new Set,nt=at=>{let ut=!1;for(let ct of at){let bt=wd(ct);if(!Y.has(bt)){Y.add(bt);let Lt=0,At=0;for(let kt of Cd)r(ct,kt)&&(Lt=kt);for(let kt of Rd)a(ct,kt)&&(At=kt);(Lt||At)&&!h.some(kt=>ti(kt.dir,ct))&&(h.push({dir:qo(ct),n:Lt,sn:At}),ut=!0)}J.has(bt)||(J.add(bt),o(ct)&&!p.some(Lt=>ti(Lt.normal,ct))&&(p.push({normal:qo(ct)}),ut=!0))}return ut},O=[],H=at=>{let ut=Hi(at);ut&&O.push(ut)};for(let at=0;at<n;at++){H(t[at]);for(let ut=at+1;ut<n;ut++)H(Bn(t[at],t[ut])),e[at]===e[ut]&&(H(Rr(t[at],t[ut])),H($c(t[at],t[ut])))}nt(O);for(let at=0;at<3;at++){let ut=h.map(Lt=>Lt.dir).concat(p.map(Lt=>Lt.normal)),ct=[],bt=Lt=>{let At=Hi(Lt);At&&ct.push(At)};for(let Lt=0;Lt<ut.length;Lt++)for(let At=Lt+1;At<ut.length;At++)if(bt(Bn(ut[Lt],ut[At])),bt(Rr(ut[Lt],ut[At])),bt($c(ut[Lt],ut[At])),ut.length<=14)for(let kt=At+1;kt<ut.length;kt++)for(let ee of[1,-1])for(let Gt of[1,-1])bt(Rr(Rr(ut[Lt],[ee*ut[At][0],ee*ut[At][1],ee*ut[At][2]]),[Gt*ut[kt][0],Gt*ut[kt][1],Gt*ut[kt][2]]));if(!nt(ct))break}}let _=h.filter(Y=>Y.n>=2),b=_.reduce((Y,J)=>Math.max(Y,J.n),0),m=_.filter(Y=>Y.n>=3),d=!f&&m.length>=2,E=Y=>_.filter(J=>J.n===Y).length,A=null;if(!f&&!d&&b>=2){let Y=_.filter(J=>J.n===b);A=Y.length===1?Y[0]:b===2?Y.find(J=>J.sn===4)||Y[0]:null}let y=A?A.n:0,S=A?_.filter(Y=>Y!==A&&Vi(Y.dir,A.dir)):[],M=A?p.filter(Y=>ti(Y.normal,A.dir)):[],C=A?p.filter(Y=>Vi(Y.normal,A.dir)):[],x="C1",T="";f?x=l?"D\u221Eh":"C\u221Ev":d?E(5)?x=l?"Ih":"I":E(4)?x=l?"Oh":"O":x=l?"Th":p.length?"Td":"T":A?S.length===y?x=M.length?`D${y}h`:C.length===y?`D${y}d`:`D${y}`:M.length?x=`C${y}h`:C.length?x=`C${y}v`:A.sn===2*y?x=`S${2*y}`:x=`C${y}`:x=p.length?"Cs":l?"Ci":"C1";let P=new Map;if(A&&y>=4&&y%2===0&&/^(D\d+h|C\d+v)$/.test(x)&&C.length===y){let Y=Math.abs(A.dir[2])<.9?[0,0,1]:[1,0,0],J=Hi(Bn(A.dir,Y)),nt=Bn(A.dir,J),O=Lt=>Math.atan2(bi(Lt,nt),bi(Lt,J)),H=O(C[0].normal),at=new Map(C.map(Lt=>{let At=((O(Lt.normal)-H)%Math.PI+Math.PI)%Math.PI;return[Lt,Math.round(At/(Math.PI/y))%y]})),ut=Lt=>t.filter(At=>Math.abs(bi(At,Lt.normal))<.08).length,ct=[0,0];for(let Lt of C)ct[at.get(Lt)%2]+=ut(Lt);let bt=ct[1]>ct[0]?1:0;for(let Lt of C)P.set(Lt,at.get(Lt)%2===bt?"v":"d")}let F=Y=>{if(!A||Y===A||!Vi(Y.dir,A.dir)||Y.n!==2||y<3)return"";if(P.size){let J=Hi(Bn(A.dir,Y.dir)),nt=C.find(O=>ti(O.normal,J));return nt&&P.get(nt)==="d"?"\u2033":"\u2032"}return"\u2032"},N=[],B=Y=>(Y.id=`${Y.kind}${N.length}`,Y.typeKey=Ad(Y.label),N.push(Y),Y);B({kind:"E",label:en("E"),op:{type:"id"}});let R=d;if(f){let Y=Hi(Bn(u,Math.abs(u[0])<.9?[1,0,0]:[0,1,0])),J=Bn(u,Y);B({kind:"C",n:1/0,dir:u,label:en("C","\u221E"),op:{type:"rot",axis:u,angle:Math.PI/3}}),l&&B({kind:"S",n:1/0,dir:u,label:en("S","\u221E"),op:{type:"imp",axis:u,angle:Math.PI/3},implied:!0}),B({kind:"sigma",normal:Y,label:en("\u03C3","v"),infinite:!0,op:{type:"refl",normal:Y}}),B({kind:"sigma",normal:J,label:en("\u03C3","v"),infinite:!0,hidden:!0,op:{type:"refl",normal:J}}),l&&(B({kind:"i",label:en("i"),op:{type:"inv"}}),B({kind:"sigma",normal:u,label:en("\u03C3","h"),op:{type:"refl",normal:u}}),B({kind:"C",n:2,dir:Y,label:en("C","2","\u2032"),infinite:!0,op:{type:"rot",axis:Y,angle:Math.PI}}),B({kind:"C",n:2,dir:J,label:en("C","2","\u2032"),infinite:!0,hidden:!0,op:{type:"rot",axis:J,angle:Math.PI}}))}else{l&&B({kind:"i",label:en("i"),op:{type:"inv"}});let Y=[..._].sort((J,nt)=>nt.n-J.n);for(let J of Y)B({kind:"C",n:J.n,dir:J.dir,label:en("C",J.n,F(J)),op:{type:"rot",axis:J.dir,angle:2*Math.PI/J.n},principal:J===A});for(let J of Y.concat(h.filter(nt=>nt.n<2)))if(J.sn>=3){let nt=p.some(H=>ti(H.normal,J.dir)),O=J.n===J.sn&&nt;B({kind:"S",n:J.sn,dir:J.dir,label:en("S",J.sn),implied:O,op:{type:"imp",axis:J.dir,angle:2*Math.PI/J.sn}})}for(let J of p){let nt="\u03C3",O="";if(A)if(ti(J.normal,A.dir))O="h";else if(P.has(J))O=P.get(J);else{let H=S.some(at=>Vi(at.dir,J.normal));O=S.length===y&&!H?"d":"v"}else R&&(x==="Td"?O="d":x==="Th"?O="h":x==="Oh"&&(O=_.some(H=>H.n===4&&ti(H.dir,J.normal))?"h":"d"));B({kind:"sigma",normal:J.normal,label:en(nt,O),op:{type:"refl",normal:J.normal}})}}let z={E:0,C:1,S:2,sigma:3,i:4};N.sort((Y,J)=>z[Y.kind]-z[J.kind]||(J.n||0)-(Y.n||0)),N.forEach((Y,J)=>{Y.id=`${Y.kind}${J}`});let q=[];for(let Y of N){let J=q.find(nt=>nt.key===Y.typeKey);J||(J={key:Y.typeKey,kind:Y.kind,label:Y.label,members:[],n:Y.n,implied:!1},q.push(J)),J.members.push(Y),Y.implied&&(J.implied=!0)}for(let Y of q)Y.count=Y.members.filter(J=>!J.hidden).length,Y.infinite=Y.members.some(J=>J.infinite)||Y.kind==="C"&&Y.n===1/0;let Z="\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9";function rt(Y){let J=Y==="fa",nt=(Ht,$t)=>J?$t:Ht,O=Ht=>J?String(Ht).replace(/\d/g,$t=>Z[$t]):String(Ht),H=[],at=Ht=>Ht.map($t=>$t.id),ut=Ht=>N.filter($t=>$t.kind===Ht).map($t=>$t.id),ct=Ht=>N.filter($t=>$t.typeKey===Ht).map($t=>$t.id),bt=(Ht,$t,qt,ne=[])=>H.push({type:"yn",q:Ht,a:$t,why:qt,show:ne}),Lt=(Ht,$t=[])=>H.push({type:"info",text:Ht,show:$t}),At=Ht=>`C<sub>${Ht}</sub>`,kt=(Ht,$t,qt)=>J?`${O(Ht)} ${qt}`:`${Ht} ${$t}${Ht===1?"":"s"}`,ee=nt("Is there a horizontal mirror plane \u03C3<sub>h</sub> (perpendicular to the principal axis)?","\u0622\u06CC\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC (\u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC) \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),Gt=nt("No \u03C3<sub>h</sub>.","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),he=nt("Is there a centre of inversion?","\u0622\u06CC\u0627 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F");if(f)bt(nt("Is the molecule linear?","\u0622\u06CC\u0627 \u0645\u0648\u0644\u06A9\u0648\u0644 \u062E\u0637\u06CC \u0627\u0633\u062A\u061F"),!0,nt("Every atom lies on one line. That line is a C<sub>\u221E</sub> axis: any rotation about it leaves the molecule unchanged.","\u0647\u0645\u0647\u0654 \u0627\u062A\u0645\u200C\u0647\u0627 \u0631\u0648\u06CC \u06CC\u06A9 \u062E\u0637 \u0642\u0631\u0627\u0631 \u062F\u0627\u0631\u0646\u062F. \u0627\u06CC\u0646 \u062E\u0637 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u221E \u0627\u0633\u062A: \u0647\u0631 \u0686\u0631\u062E\u0634\u06CC \u0628\u0647 \u062F\u0648\u0631 \u0622\u0646\u060C \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0628\u062F\u0648\u0646 \u062A\u063A\u06CC\u06CC\u0631 \u0645\u06CC\u200C\u06AF\u0630\u0627\u0631\u062F."),ct("C\u221E")),bt(he,l,l?nt("Moving every atom through the midpoint to the opposite side gives the same arrangement, so i is present.","\u0627\u06AF\u0631 \u0647\u0631 \u0627\u062A\u0645 \u0631\u0627 \u0627\u0632 \u0648\u0633\u0637 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0647 \u0633\u0645\u062A \u0645\u0642\u0627\u0628\u0644 \u0628\u0628\u0631\u06CC\u0645\u060C \u0647\u0645\u0627\u0646 \u0622\u0631\u0627\u06CC\u0634 \u0628\u0647 \u062F\u0633\u062A \u0645\u06CC\u200C\u0622\u06CC\u062F\u061B \u067E\u0633 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F."):nt("The two ends are different, so inversion would swap unlike atoms. There is no i.","\u062F\u0648 \u0633\u0631 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0627 \u0647\u0645 \u0641\u0631\u0642 \u062F\u0627\u0631\u0646\u062F \u0648 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u062A\u0645\u200C\u0647\u0627\u06CC \u0646\u0627\u0647\u0645\u0627\u0646\u0646\u062F \u0631\u0627 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F. \u067E\u0633 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),l?ct("i"):[]);else if(bt(nt("Is the molecule linear?","\u0622\u06CC\u0627 \u0645\u0648\u0644\u06A9\u0648\u0644 \u062E\u0637\u06CC \u0627\u0633\u062A\u061F"),!1,nt("The atoms do not all lie on a single line.","\u0627\u062A\u0645\u200C\u0647\u0627 \u0647\u0645\u06AF\u06CC \u0631\u0648\u06CC \u06CC\u06A9 \u062E\u0637 \u0646\u06CC\u0633\u062A\u0646\u062F."),[]),d){let Ht=m.reduce((qt,ne)=>(qt[ne.n]=(qt[ne.n]||0)+1,qt),{}),$t=Object.keys(Ht).sort((qt,ne)=>ne-qt).map(qt=>`${O(Ht[qt])} \xD7 ${At(qt)}`).join(nt(", ","\u060C "));bt(nt("Are there two or more C<sub>n</sub> axes with n \u2265 3?","\u0622\u06CC\u0627 \u062F\u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n \u06CC\u0627 \u0628\u06CC\u0634\u062A\u0631 \u0628\u0627 n \u2265 \u06F3 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),!0,nt(`Yes: ${$t}. Several high-order axes at once mark a cubic or icosahedral group.`,`\u0628\u0644\u0647: ${$t}. \u0648\u062C\u0648\u062F \u0647\u0645\u200C\u0632\u0645\u0627\u0646 \u0686\u0646\u062F \u0645\u062D\u0648\u0631 \u0628\u0627 \u0645\u0631\u062A\u0628\u0647\u0654 \u0628\u0627\u0644\u0627 \u0646\u0634\u0627\u0646\u0647\u0654 \u06AF\u0631\u0648\u0647 \u0645\u06A9\u0639\u0628\u06CC \u06CC\u0627 \u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC \u0627\u0633\u062A.`),m.map(qt=>{var ne;return(ne=N.find(L=>L.kind==="C"&&L.dir===qt.dir))==null?void 0:ne.id}).filter(Boolean)),E(5)?bt(nt("Is there a C<sub>5</sub> axis?","\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),!0,nt(`${kt(E(5),"C<sub>5</sub> axis","")} found: the icosahedral family (I or I<sub>h</sub>).`.replace("axiss","axes"),`${O(E(5))} \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5 \u06CC\u0627\u0641\u062A \u0634\u062F: \u062E\u0627\u0646\u0648\u0627\u062F\u0647\u0654 \u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC (I \u06CC\u0627 I<sub>h</sub>).`),ct("C5")):(bt(nt("Is there a C<sub>5</sub> axis?","\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),!1,nt("No fivefold axis, so it is not icosahedral.","\u0645\u062D\u0648\u0631 \u067E\u0646\u062C\u200C\u06AF\u0627\u0646\u0647 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F\u061B \u067E\u0633 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC \u0646\u06CC\u0633\u062A."),[]),E(4)?bt(nt("Is there a C<sub>4</sub> axis?","\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),!0,nt(`${E(4)} C<sub>4</sub> axes found: the octahedral family (O or O<sub>h</sub>).`,`${O(E(4))} \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u06CC\u0627\u0641\u062A \u0634\u062F: \u062E\u0627\u0646\u0648\u0627\u062F\u0647\u0654 \u0647\u0634\u062A\u200C\u0648\u062C\u0647\u06CC (O \u06CC\u0627 O<sub>h</sub>).`),ct("C4")):bt(nt("Is there a C<sub>4</sub> axis?","\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),!1,nt("No fourfold axis, so it is not octahedral. Only C<sub>3</sub> and C<sub>2</sub> axes remain: the tetrahedral family (T, T<sub>d</sub>, T<sub>h</sub>).","\u0645\u062D\u0648\u0631 \u0686\u0647\u0627\u0631\u06AF\u0627\u0646\u0647 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F\u061B \u067E\u0633 \u0647\u0634\u062A\u200C\u0648\u062C\u0647\u06CC \u0646\u06CC\u0633\u062A. \u0641\u0642\u0637 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0648 \u06F2 \u0628\u0627\u0642\u06CC \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F: \u062E\u0627\u0646\u0648\u0627\u062F\u0647\u0654 \u0686\u0647\u0627\u0631\u0648\u062C\u0647\u06CC (T\u060C T<sub>d</sub>\u060C T<sub>h</sub>)."),[])),bt(he,l,l?nt("Yes, i is present.","\u0628\u0644\u0647\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F."):nt("No inversion centre.","\u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),l?ct("i"):[]),!E(5)&&!E(4)&&!l&&bt(nt("Are there any mirror planes?","\u0622\u06CC\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),p.length>0,p.length?nt(`${p.length} mirror planes found (\u03C3<sub>d</sub>), each containing a C<sub>2</sub> axis.`,`${O(p.length)} \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u06CC\u0627\u0641\u062A \u0634\u062F \u06A9\u0647 \u0647\u0631 \u06A9\u062F\u0627\u0645 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F.`):nt("No mirror planes: the pure rotation group T.","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u062F\u0648\u0631\u0627\u0646\u06CC \u062E\u0627\u0644\u0635 T."),ut("sigma"))}else if(bt(nt("Is there a rotation axis C<sub>n</sub> with n \u2265 2?","\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 (\u0645\u0631\u062A\u0628\u0647\u0654 n \u0628\u0627 n \u2265 \u06F2) \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),_.length>0,_.length?nt(`Yes. The highest order found is n = ${b}.`,`\u0628\u0644\u0647. \u0628\u0627\u0644\u0627\u062A\u0631\u06CC\u0646 \u0645\u0631\u062A\u0628\u0647\u0654 \u06CC\u0627\u0641\u062A\u200C\u0634\u062F\u0647 n = ${O(b)} \u0627\u0633\u062A.`):nt("No proper rotation axis exists.","\u0647\u06CC\u0686 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),_.length?at(N.filter(Ht=>Ht.kind==="C")):[]),!_.length)bt(nt("Is there a mirror plane \u03C3?","\u0622\u06CC\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F"),p.length>0,p.length?nt("One mirror plane maps the molecule onto itself: point group C<sub>s</sub>.","\u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0628\u0631 \u062E\u0648\u062F\u0634 \u0645\u06CC\u200C\u0646\u06AF\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>s</sub>."):nt("No mirror plane.","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),ut("sigma")),p.length||bt(he,l,l?nt("Yes, i is present: point group C<sub>i</sub>.","\u0628\u0644\u0647\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>i</sub>."):nt("Nothing at all except the identity: point group C<sub>1</sub>.","\u062C\u0632 \u06CC\u06A9\u0633\u0627\u0646\u06CC \u0647\u06CC\u0686 \u0639\u0646\u0635\u0631\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>1</sub>."),l?ct("i"):[]);else{let Ht=N.find(jt=>jt.principal),$t=E(b)>1?nt(` (there are ${E(b)} equal-order axes, so pick the one that is also an S<sub>4</sub> axis if any)`,` (${O(E(b))} \u0645\u062D\u0648\u0631 \u0647\u0645\u200C\u0645\u0631\u062A\u0628\u0647 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061B \u0627\u06AF\u0631 \u06CC\u06A9\u06CC \u0627\u0632 \u0622\u0646\u200C\u0647\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0647\u0645 \u0647\u0633\u062A\u060C \u0647\u0645\u0627\u0646 \u0631\u0627 \u0628\u0631\u06AF\u0632\u06CC\u0646\u06CC\u062F)`):"";Lt(nt(`The <b>principal axis</b> is the C<sub>n</sub> of highest order: C<sub>${y}</sub>${$t}. Treat it as the vertical z axis.`,`<b>\u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC</b> \u0647\u0645\u0627\u0646 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0628\u0627 \u0628\u0627\u0644\u0627\u062A\u0631\u06CC\u0646 \u0645\u0631\u062A\u0628\u0647 \u0627\u0633\u062A: \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 ${O(y)}${$t}. \u0622\u0646 \u0631\u0627 \u0645\u062D\u0648\u0631 \u0639\u0645\u0648\u062F\u06CC z \u062F\u0631 \u0646\u0638\u0631 \u0628\u06AF\u06CC\u0631\u06CC\u062F.`),Ht?[Ht.id]:[]);let qt=N.filter(jt=>jt.kind==="C"&&!jt.principal&&A&&Vi(jt.dir,A.dir)).map(jt=>jt.id);bt(nt(`Are there ${y} C<sub>2</sub> axes perpendicular to the principal axis?`,`\u0622\u06CC\u0627 ${O(y)} \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F`),S.length===y,S.length===y?nt(`Yes, ${S.length} perpendicular C<sub>2</sub> axes: a dihedral group (D).`,`\u0628\u0644\u0647\u060C ${O(S.length)} \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F\u06CC: \u06CC\u06A9 \u06AF\u0631\u0648\u0647 \u062F\u0648\u0648\u062C\u0647\u06CC (D).`):nt(`Found ${S.length}; ${y} would be needed. Not a dihedral group: look at the C family.`,`${O(S.length)} \u0645\u062D\u0648\u0631 \u06CC\u0627\u0641\u062A \u0634\u062F\u060C \u0627\u0645\u0627 ${O(y)} \u0645\u062D\u0648\u0631 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A. \u06AF\u0631\u0648\u0647 \u062F\u0648\u0648\u062C\u0647\u06CC \u0646\u06CC\u0633\u062A\u061B \u062E\u0627\u0646\u0648\u0627\u062F\u0647\u0654 \u06AF\u0631\u0648\u0647\u200C\u0647\u0627\u06CC C \u0631\u0627 \u0628\u0631\u0631\u0633\u06CC \u06A9\u0646\u06CC\u062F.`),qt);let ne=N.filter(jt=>jt.kind==="sigma"&&A&&ti(jt.normal,A.dir)).map(jt=>jt.id),L=N.filter(jt=>jt.kind==="sigma"&&A&&Vi(jt.normal,A.dir)).map(jt=>jt.id);if(S.length===y)bt(ee,M.length>0,M.length?nt(`Yes: point group D<sub>${y}h</sub>.`,`\u0628\u0644\u0647: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC D<sub>${y}h</sub>.`):Gt,ne),M.length||bt(nt(`Are there ${y} vertical planes \u03C3<sub>d</sub> that bisect the C<sub>2</sub> axes?`,`\u0622\u06CC\u0627 ${O(y)} \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F \u06A9\u0647 \u0632\u0627\u0648\u06CC\u0647\u0654 \u0645\u06CC\u0627\u0646 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0631\u0627 \u0646\u0635\u0641 \u0645\u06CC\u200C\u06A9\u0646\u062F\u061F`),C.length===y,C.length===y?nt(`Yes, ${y} \u03C3<sub>d</sub> planes: point group D<sub>${y}d</sub>.`,`\u0628\u0644\u0647\u060C ${O(y)} \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC D<sub>${y}d</sub>.`):nt(`No vertical planes: point group D<sub>${y}</sub>.`,`\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC D<sub>${y}</sub>.`),L);else if(bt(ee,M.length>0,M.length?nt(`Yes: point group C<sub>${y}h</sub>.`,`\u0628\u0644\u0647: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>${y}h</sub>.`):Gt,ne),!M.length&&(bt(nt("Are there vertical mirror planes \u03C3<sub>v</sub> containing the principal axis?","\u0622\u06CC\u0627 \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0634\u0627\u0645\u0644 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u0646\u062F\u061F"),C.length>0,C.length?nt(`Yes, ${kt(C.length,"\u03C3<sub>v</sub> plane")}: point group C<sub>${y}v</sub>.`,`\u0628\u0644\u0647\u060C ${O(C.length)} \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>${y}v</sub>.`):nt("No vertical planes.","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F."),L),!C.length)){let jt=N.filter(ie=>ie.kind==="S").map(ie=>ie.id);bt(nt(`Is there an improper axis S<sub>${2*y}</sub> along the principal axis?`,`\u0622\u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 ${O(2*y)} \u062F\u0631 \u0627\u0645\u062A\u062F\u0627\u062F \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061F`),A.sn===2*y,A.sn===2*y?nt(`Yes: rotating by ${360/(2*y)}\xB0 and reflecting is a symmetry. Point group S<sub>${2*y}</sub>.`,`\u0628\u0644\u0647: \u0686\u0631\u062E\u0634 ${O(360/(2*y))} \u062F\u0631\u062C\u0647 \u0648 \u0633\u067E\u0633 \u0628\u0627\u0632\u062A\u0627\u0628 \u06CC\u06A9 \u0639\u0645\u0644\u06CC\u0627\u062A \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A. \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC S<sub>${2*y}</sub>.`):nt(`No improper axis: point group C<sub>${y}</sub>.`,`\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F: \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC C<sub>${y}</sub>.`),jt)}}return H}let $={en:rt("en"),fa:rt("fa")},K=p.length>0||l||h.some(Y=>Y.sn)||f,st=!f&&!K,Tt=/^(C1|Cs|C\d+|C\d+v|C∞v)$/.test(x);return{linear:f,cubic:d,group:x,order:Pd(x),elements:N,types:q,steps:$,counts:{axes:_.length,planes:p.length,inv:l},chiral:st,polar:Tt,principalId:((ht=N.find(Y=>Y.principal))==null?void 0:ht.id)||null}}var di={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},fi={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},yh=0,Ml=1,vh=2;var hr=1,bh=2,As=3,pi=0,Je=1,Ke=2,Dn=0,Cs=1,Tl=2,El=3,wl=4,Sh=5;var Ii=100,Mh=101,Th=102,Eh=103,wh=104,Ah=200,Ch=201,Rh=202,Ph=203,Al=204,Cl=205,Ih=206,Lh=207,Dh=208,Nh=209,Uh=210,Fh=211,Oh=212,Bh=213,kh=214,ea=0,na=1,ia=2,ls=3,sa=4,ra=5,aa=6,oa=7,Rl=0,zh=1,Hh=2,Mn=0,Pl=1,Il=2,Ll=3,Dl=4,Nl=5,Ul=6,Fl=7;var Ol=300,mi=301,Li=302,Ua=303,Fa=304,ur=306,la=1e3,In=1001,ca=1002,Ne=1003,Vh=1004;var dr=1005;var Fe=1006,Oa=1007;var gi=1008;var Qe=1009,Bl=1010,kl=1011,Rs=1012,Ba=1013,Tn=1014,En=1015,wn=1016,ka=1017,za=1018,Ps=1020,zl=35902,Hl=35899,Vl=1021,Gl=1022,fn=1023,Ln=1026,_i=1027,Wl=1028,Ha=1029,xi=1030,Va=1031;var Ga=1033,fr=33776,pr=33777,mr=33778,gr=33779,Wa=35840,Xa=35841,$a=35842,qa=35843,Ya=36196,Za=37492,Ja=37496,Ka=37488,ja=37489,_r=37490,Qa=37491,to=37808,eo=37809,no=37810,io=37811,so=37812,ro=37813,ao=37814,oo=37815,lo=37816,co=37817,ho=37818,uo=37819,fo=37820,po=37821,mo=36492,go=36494,_o=36495,xo=36283,yo=36284,xr=36285,vo=36286;var Xs=2300,ha=2301,Qr=2302,gl=2303,_l=2400,xl=2401,yl=2402;var Gh=3200;var bo=0,Wh=1,Zn="",Ge="srgb",$s="srgb-linear",qs="linear",oe="srgb";var ta=7680;var Xh=519,$h=512,qh=513,Yh=514,So=515,Zh=516,Jh=517,Mo=518,Kh=519,Xl=35044;var $l="300 es",bn=2e3,cs=2001;function Id(i){for(let t=i.length-1;t>=0;--t)if(i[t]>=65535)return!0;return!1}function Ld(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function Ys(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function jh(){let i=Ys("canvas");return i.style.display="block",i}var Zc={},hs=null;function Zs(...i){let t="THREE."+i.shift();hs?hs("log",t,...i):console.log(t,...i)}function Qh(i){let t=i[0];if(typeof t=="string"&&t.startsWith("TSL:")){let e=i[1];e&&e.isStackTrace?i[0]+=" "+e.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function Bt(...i){i=Qh(i);let t="THREE."+i.shift();if(hs)hs("warn",t,...i);else{let e=i[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...i)}}function zt(...i){i=Qh(i);let t="THREE."+i.shift();if(hs)hs("error",t,...i);else{let e=i[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...i)}}function Ci(...i){let t=i.join(" ");t in Zc||(Zc[t]=!0,Bt(...i))}function tu(i,t,e){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(t,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,e);break;default:n()}}setTimeout(r,e)})}var eu={[ea]:na,[ia]:aa,[sa]:oa,[ls]:ra,[na]:ea,[aa]:ia,[oa]:sa,[ra]:ls},Sn=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){let n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){let n=this._listeners;if(n===void 0)return;let s=n[t];if(s!==void 0){let r=s.indexOf(e);r!==-1&&s.splice(r,1)}}dispatchEvent(t){let e=this._listeners;if(e===void 0)return;let n=e[t.type];if(n!==void 0){t.target=this;let s=n.slice(0);for(let r=0,a=s.length;r<a;r++)s[r].call(this,t);t.target=null}}},He=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Jc=1234567,Gs=Math.PI/180,us=180/Math.PI;function Xn(){let i=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(He[i&255]+He[i>>8&255]+He[i>>16&255]+He[i>>24&255]+"-"+He[t&255]+He[t>>8&255]+"-"+He[t>>16&15|64]+He[t>>24&255]+"-"+He[e&63|128]+He[e>>8&255]+"-"+He[e>>16&255]+He[e>>24&255]+He[n&255]+He[n>>8&255]+He[n>>16&255]+He[n>>24&255]).toLowerCase()}function Jt(i,t,e){return Math.max(t,Math.min(e,i))}function ql(i,t){return(i%t+t)%t}function Dd(i,t,e,n,s){return n+(i-t)*(s-n)/(e-t)}function Nd(i,t,e){return i!==t?(e-i)/(t-i):0}function Ws(i,t,e){return(1-e)*i+e*t}function Ud(i,t,e,n){return Ws(i,t,1-Math.exp(-e*n))}function Fd(i,t=1){return t-Math.abs(ql(i,t*2)-t)}function Od(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*(3-2*i))}function Bd(i,t,e){return i<=t?0:i>=e?1:(i=(i-t)/(e-t),i*i*i*(i*(i*6-15)+10))}function kd(i,t){return i+Math.floor(Math.random()*(t-i+1))}function zd(i,t){return i+Math.random()*(t-i)}function Hd(i){return i*(.5-Math.random())}function Vd(i){i!==void 0&&(Jc=i);let t=Jc+=1831565813;return t=Math.imul(t^t>>>15,t|1),t^=t+Math.imul(t^t>>>7,t|61),((t^t>>>14)>>>0)/4294967296}function Gd(i){return i*Gs}function Wd(i){return i*us}function Xd(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function $d(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function qd(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function Yd(i,t,e,n,s){let r=Math.cos,a=Math.sin,o=r(e/2),l=a(e/2),c=r((t+n)/2),u=a((t+n)/2),f=r((t-n)/2),h=a((t-n)/2),p=r((n-t)/2),_=a((n-t)/2);switch(s){case"XYX":i.set(o*u,l*f,l*h,o*c);break;case"YZY":i.set(l*h,o*u,l*f,o*c);break;case"ZXZ":i.set(l*f,l*h,o*u,o*c);break;case"XZX":i.set(o*u,l*_,l*p,o*c);break;case"YXY":i.set(l*p,o*u,l*_,o*c);break;case"ZYZ":i.set(l*_,l*p,o*u,o*c);break;default:Bt("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function vn(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:case Uint8ClampedArray:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function le(i,t){switch(t.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}var Yl={DEG2RAD:Gs,RAD2DEG:us,generateUUID:Xn,clamp:Jt,euclideanModulo:ql,mapLinear:Dd,inverseLerp:Nd,lerp:Ws,damp:Ud,pingpong:Fd,smoothstep:Od,smootherstep:Bd,randInt:kd,randFloat:zd,randFloatSpread:Hd,seededRandom:Vd,degToRad:Gd,radToDeg:Wd,isPowerOfTwo:Xd,ceilPowerOfTwo:$d,floorPowerOfTwo:qd,setQuaternionFromProperEuler:Yd,normalize:le,denormalize:vn},Ql=class Ql{constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,s=t.elements;return this.x=s[0]*e+s[3]*n+s[6],this.y=s[1]*e+s[4]*n+s[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),s=Math.sin(e),r=this.x-t.x,a=this.y-t.y;return this.x=r*n-a*s+t.x,this.y=r*s+a*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Ql.prototype.isVector2=!0;var Dt=Ql,Oe=class{constructor(t=0,e=0,n=0,s=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=s}static slerpFlat(t,e,n,s,r,a,o){let l=n[s+0],c=n[s+1],u=n[s+2],f=n[s+3],h=r[a+0],p=r[a+1],_=r[a+2],b=r[a+3];if(f!==b||l!==h||c!==p||u!==_){let m=l*h+c*p+u*_+f*b;m<0&&(h=-h,p=-p,_=-_,b=-b,m=-m);let d=1-o;if(m<.9995){let E=Math.acos(m),A=Math.sin(E);d=Math.sin(d*E)/A,o=Math.sin(o*E)/A,l=l*d+h*o,c=c*d+p*o,u=u*d+_*o,f=f*d+b*o}else{l=l*d+h*o,c=c*d+p*o,u=u*d+_*o,f=f*d+b*o;let E=1/Math.sqrt(l*l+c*c+u*u+f*f);l*=E,c*=E,u*=E,f*=E}}t[e]=l,t[e+1]=c,t[e+2]=u,t[e+3]=f}static multiplyQuaternionsFlat(t,e,n,s,r,a){let o=n[s],l=n[s+1],c=n[s+2],u=n[s+3],f=r[a],h=r[a+1],p=r[a+2],_=r[a+3];return t[e]=o*_+u*f+l*p-c*h,t[e+1]=l*_+u*h+c*f-o*p,t[e+2]=c*_+u*p+o*h-l*f,t[e+3]=u*_-o*f-l*h-c*p,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,s){return this._x=t,this._y=e,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,s=t._y,r=t._z,a=t._order,o=Math.cos,l=Math.sin,c=o(n/2),u=o(s/2),f=o(r/2),h=l(n/2),p=l(s/2),_=l(r/2);switch(a){case"XYZ":this._x=h*u*f+c*p*_,this._y=c*p*f-h*u*_,this._z=c*u*_+h*p*f,this._w=c*u*f-h*p*_;break;case"YXZ":this._x=h*u*f+c*p*_,this._y=c*p*f-h*u*_,this._z=c*u*_-h*p*f,this._w=c*u*f+h*p*_;break;case"ZXY":this._x=h*u*f-c*p*_,this._y=c*p*f+h*u*_,this._z=c*u*_+h*p*f,this._w=c*u*f-h*p*_;break;case"ZYX":this._x=h*u*f-c*p*_,this._y=c*p*f+h*u*_,this._z=c*u*_-h*p*f,this._w=c*u*f+h*p*_;break;case"YZX":this._x=h*u*f+c*p*_,this._y=c*p*f+h*u*_,this._z=c*u*_-h*p*f,this._w=c*u*f-h*p*_;break;case"XZY":this._x=h*u*f-c*p*_,this._y=c*p*f-h*u*_,this._z=c*u*_+h*p*f,this._w=c*u*f+h*p*_;break;default:Bt("Quaternion: .setFromEuler() encountered an unknown order: "+a)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,s=Math.sin(n);return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],s=e[4],r=e[8],a=e[1],o=e[5],l=e[9],c=e[2],u=e[6],f=e[10],h=n+o+f;if(h>0){let p=.5/Math.sqrt(h+1);this._w=.25/p,this._x=(u-l)*p,this._y=(r-c)*p,this._z=(a-s)*p}else if(n>o&&n>f){let p=2*Math.sqrt(1+n-o-f);this._w=(u-l)/p,this._x=.25*p,this._y=(s+a)/p,this._z=(r+c)/p}else if(o>f){let p=2*Math.sqrt(1+o-n-f);this._w=(r-c)/p,this._x=(s+a)/p,this._y=.25*p,this._z=(l+u)/p}else{let p=2*Math.sqrt(1+f-n-o);this._w=(a-s)/p,this._x=(r+c)/p,this._y=(l+u)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(Jt(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let s=Math.min(1,e/n);return this.slerp(t,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,s=t._y,r=t._z,a=t._w,o=e._x,l=e._y,c=e._z,u=e._w;return this._x=n*u+a*o+s*c-r*l,this._y=s*u+a*l+r*o-n*c,this._z=r*u+a*c+n*l-s*o,this._w=a*u-n*o-s*l-r*c,this._onChangeCallback(),this}slerp(t,e){let n=t._x,s=t._y,r=t._z,a=t._w,o=this.dot(t);o<0&&(n=-n,s=-s,r=-r,a=-a,o=-o);let l=1-e;if(o<.9995){let c=Math.acos(o),u=Math.sin(c);l=Math.sin(l*c)/u,e=Math.sin(e*c)/u,this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this._onChangeCallback()}else this._x=this._x*l+n*e,this._y=this._y*l+s*e,this._z=this._z*l+r*e,this._w=this._w*l+a*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},tc=class tc{constructor(t=0,e=0,n=0){this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Kc.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Kc.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*s,this.y=r[1]*e+r[4]*n+r[7]*s,this.z=r[2]*e+r[5]*n+r[8]*s,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=t.elements,a=1/(r[3]*e+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*s+r[12])*a,this.y=(r[1]*e+r[5]*n+r[9]*s+r[13])*a,this.z=(r[2]*e+r[6]*n+r[10]*s+r[14])*a,this}applyQuaternion(t){let e=this.x,n=this.y,s=this.z,r=t.x,a=t.y,o=t.z,l=t.w,c=2*(a*s-o*n),u=2*(o*e-r*s),f=2*(r*n-a*e);return this.x=e+l*c+a*f-o*u,this.y=n+l*u+o*c-r*f,this.z=s+l*f+r*u-a*c,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,s=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*s,this.y=r[1]*e+r[5]*n+r[9]*s,this.z=r[2]*e+r[6]*n+r[10]*s,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this.z=Jt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this.z=Jt(this.z,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,s=t.y,r=t.z,a=e.x,o=e.y,l=e.z;return this.x=s*l-r*o,this.y=r*a-n*l,this.z=n*o-s*a,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return Yo.copy(this).projectOnVector(t),this.sub(Yo)}reflect(t){return this.sub(Yo.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(Jt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,s=this.z-t.z;return e*e+n*n+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let s=Math.sin(e)*t;return this.x=s*Math.sin(n),this.y=Math.cos(e)*t,this.z=s*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=s,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};tc.prototype.isVector3=!0;var U=tc,Yo=new U,Kc=new Oe,ec=class ec{constructor(t,e,n,s,r,a,o,l,c){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c)}set(t,e,n,s,r,a,o,l,c){let u=this.elements;return u[0]=t,u[1]=s,u[2]=o,u[3]=e,u[4]=r,u[5]=l,u[6]=n,u[7]=a,u[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[3],l=n[6],c=n[1],u=n[4],f=n[7],h=n[2],p=n[5],_=n[8],b=s[0],m=s[3],d=s[6],E=s[1],A=s[4],y=s[7],S=s[2],M=s[5],C=s[8];return r[0]=a*b+o*E+l*S,r[3]=a*m+o*A+l*M,r[6]=a*d+o*y+l*C,r[1]=c*b+u*E+f*S,r[4]=c*m+u*A+f*M,r[7]=c*d+u*y+f*C,r[2]=h*b+p*E+_*S,r[5]=h*m+p*A+_*M,r[8]=h*d+p*y+_*C,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],u=t[8];return e*a*u-e*o*c-n*r*u+n*o*l+s*r*c-s*a*l}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],u=t[8],f=u*a-o*c,h=o*l-u*r,p=c*r-a*l,_=e*f+n*h+s*p;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);let b=1/_;return t[0]=f*b,t[1]=(s*c-u*n)*b,t[2]=(o*n-s*a)*b,t[3]=h*b,t[4]=(u*e-s*l)*b,t[5]=(s*r-o*e)*b,t[6]=p*b,t[7]=(n*l-c*e)*b,t[8]=(a*e-n*r)*b,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,s,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*a+c*o)+a+t,-s*c,s*l,-s*(-c*a+l*o)+o+e,0,0,1),this}scale(t,e){return Ci("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(Zo.makeScale(t,e)),this}rotate(t){return Ci("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(Zo.makeRotation(-t)),this}translate(t,e){return Ci("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(Zo.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<9;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}};ec.prototype.isMatrix3=!0;var Vt=ec,Zo=new Vt,jc=new Vt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Qc=new Vt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Zd(){let i={enabled:!0,workingColorSpace:$s,spaces:{},convert:function(s,r,a){return this.enabled===!1||r===a||!r||!a||(this.spaces[r].transfer===oe&&(s.r=$n(s.r),s.g=$n(s.g),s.b=$n(s.b)),this.spaces[r].primaries!==this.spaces[a].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[a].fromXYZ)),this.spaces[a].transfer===oe&&(s.r=os(s.r),s.g=os(s.g),s.b=os(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Zn?qs:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,a){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[a].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return Ci("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return Ci("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[$s]:{primaries:t,whitePoint:n,transfer:qs,toXYZ:jc,fromXYZ:Qc,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Ge},outputColorSpaceConfig:{drawingBufferColorSpace:Ge}},[Ge]:{primaries:t,whitePoint:n,transfer:oe,toXYZ:jc,fromXYZ:Qc,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Ge}}}),i}var Qt=Zd();function $n(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function os(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var Wi,ua=class{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{Wi===void 0&&(Wi=Ys("canvas")),Wi.width=t.width,Wi.height=t.height;let s=Wi.getContext("2d");t instanceof ImageData?s.putImageData(t,0,0):s.drawImage(t,0,0,t.width,t.height),n=Wi}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Ys("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let s=n.getImageData(0,0,t.width,t.height),r=s.data;for(let a=0;a<r.length;a++)r[a]=$n(r[a]/255)*255;return n.putImageData(s,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor($n(e[n]/255)*255):e[n]=$n(e[n]);return{data:e,width:t.width,height:t.height}}else return Bt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Jd=0,ds=class{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Jd++}),this.uuid=Xn(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){let e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame<"u"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let a=0,o=s.length;a<o;a++)s[a].isDataTexture?r.push(Jo(s[a].image)):r.push(Jo(s[a]))}else r=Jo(s);n.url=r}return e||(t.images[this.uuid]=n),n}};function Jo(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?ua.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(Bt("Texture: Unable to serialize Texture."),{})}var Kd=0,Ko=new U,Ye=class i extends Sn{constructor(t=i.DEFAULT_IMAGE,e=i.DEFAULT_MAPPING,n=In,s=In,r=Fe,a=gi,o=fn,l=Qe,c=i.DEFAULT_ANISOTROPY,u=Zn){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Kd++}),this.uuid=Xn(),this.name="",this.source=new ds(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Dt(0,0),this.repeat=new Dt(1,1),this.center=new Dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Vt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Ko).x}get height(){return this.source.getSize(Ko).y}get depth(){return this.source.getSize(Ko).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(let e in t){let n=t[e];if(n===void 0){Bt(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){Bt(`Texture.setValues(): property '${e}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==Ol)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case la:t.x=t.x-Math.floor(t.x);break;case In:t.x=t.x<0?0:1;break;case ca:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case la:t.y=t.y-Math.floor(t.y);break;case In:t.y=t.y<0?0:1;break;case ca:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};Ye.DEFAULT_IMAGE=null;Ye.DEFAULT_MAPPING=Ol;Ye.DEFAULT_ANISOTROPY=1;var nc=class nc{constructor(t=0,e=0,n=0,s=1){this.x=t,this.y=e,this.z=n,this.w=s}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,s){return this.x=t,this.y=e,this.z=n,this.w=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,s=this.z,r=this.w,a=t.elements;return this.x=a[0]*e+a[4]*n+a[8]*s+a[12]*r,this.y=a[1]*e+a[5]*n+a[9]*s+a[13]*r,this.z=a[2]*e+a[6]*n+a[10]*s+a[14]*r,this.w=a[3]*e+a[7]*n+a[11]*s+a[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,s,r,l=t.elements,c=l[0],u=l[4],f=l[8],h=l[1],p=l[5],_=l[9],b=l[2],m=l[6],d=l[10];if(Math.abs(u-h)<.01&&Math.abs(f-b)<.01&&Math.abs(_-m)<.01){if(Math.abs(u+h)<.1&&Math.abs(f+b)<.1&&Math.abs(_+m)<.1&&Math.abs(c+p+d-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let A=(c+1)/2,y=(p+1)/2,S=(d+1)/2,M=(u+h)/4,C=(f+b)/4,x=(_+m)/4;return A>y&&A>S?A<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(A),s=M/n,r=C/n):y>S?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=M/s,r=x/s):S<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(S),n=C/r,s=x/r),this.set(n,s,r,e),this}let E=Math.sqrt((m-_)*(m-_)+(f-b)*(f-b)+(h-u)*(h-u));return Math.abs(E)<.001&&(E=1),this.x=(m-_)/E,this.y=(f-b)/E,this.z=(h-u)/E,this.w=Math.acos((c+p+d-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=Jt(this.x,t.x,e.x),this.y=Jt(this.y,t.y,e.y),this.z=Jt(this.z,t.z,e.z),this.w=Jt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=Jt(this.x,t,e),this.y=Jt(this.y,t,e),this.z=Jt(this.z,t,e),this.w=Jt(this.w,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(Jt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};nc.prototype.isVector4=!0;var be=nc,da=class extends Sn{constructor(t=1,e=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Fe,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=n.depth,this.scissor=new be(0,0,t,e),this.scissorTest=!1,this.viewport=new be(0,0,t,e),this.textures=[];let s={width:t,height:e,depth:n.depth},r=new Ye(s),a=n.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0,this.textures[o].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(t={}){let e={minFilter:Fe,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(e.mapping=t.mapping),t.wrapS!==void 0&&(e.wrapS=t.wrapS),t.wrapT!==void 0&&(e.wrapT=t.wrapT),t.wrapR!==void 0&&(e.wrapR=t.wrapR),t.magFilter!==void 0&&(e.magFilter=t.magFilter),t.minFilter!==void 0&&(e.minFilter=t.minFilter),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.anisotropy!==void 0&&(e.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(e.internalFormat=t.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(e)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),t!==null&&t.renderTarget===null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,e,n=1){if(this.width!==t||this.height!==e||this.depth!==n){this.width=t,this.height=e,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let e=0,n=t.textures.length;e<n;e++){this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;let s=Object.assign({},t.textures[e].image);this.textures[e].source=new ds(s)}if(this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveColorBuffer=t.resolveColorBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,this.storeMultisampledColorBuffer=t.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=t.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=t.storeMultisampledStencilBuffer,t.depthTexture!==null)if(t.depthTexture.renderTarget===t){let e=t.depthTexture.clone();e.renderTarget=null,this.depthTexture=e}else this.depthTexture=t.depthTexture;return this.samples=t.samples,this.multiview=t.multiview,this.useArrayDepthTexture=t.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}},je=class extends da{constructor(t=1,e=1,n={}){super(t,e,n),this.isWebGLRenderTarget=!0}},Js=class extends Ye{constructor(t=null,e=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ne,this.minFilter=Ne,this.wrapR=In,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}};var fa=class extends Ye{constructor(t=null,e=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:n,depth:s},this.magFilter=Ne,this.minFilter=Ne,this.wrapR=In,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(t){return super.copy(t),this.wrapR=t.wrapR,this}};var Na=class Na{constructor(t,e,n,s,r,a,o,l,c,u,f,h,p,_,b,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,s,r,a,o,l,c,u,f,h,p,_,b,m)}set(t,e,n,s,r,a,o,l,c,u,f,h,p,_,b,m){let d=this.elements;return d[0]=t,d[4]=e,d[8]=n,d[12]=s,d[1]=r,d[5]=a,d[9]=o,d[13]=l,d[2]=c,d[6]=u,d[10]=f,d[14]=h,d[3]=p,d[7]=_,d[11]=b,d[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Na().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),n.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();let e=this.elements,n=t.elements,s=1/Xi.setFromMatrixColumn(t,0).length(),r=1/Xi.setFromMatrixColumn(t,1).length(),a=1/Xi.setFromMatrixColumn(t,2).length();return e[0]=n[0]*s,e[1]=n[1]*s,e[2]=n[2]*s,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*a,e[9]=n[9]*a,e[10]=n[10]*a,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,s=t.y,r=t.z,a=Math.cos(n),o=Math.sin(n),l=Math.cos(s),c=Math.sin(s),u=Math.cos(r),f=Math.sin(r);if(t.order==="XYZ"){let h=a*u,p=a*f,_=o*u,b=o*f;e[0]=l*u,e[4]=-l*f,e[8]=c,e[1]=p+_*c,e[5]=h-b*c,e[9]=-o*l,e[2]=b-h*c,e[6]=_+p*c,e[10]=a*l}else if(t.order==="YXZ"){let h=l*u,p=l*f,_=c*u,b=c*f;e[0]=h+b*o,e[4]=_*o-p,e[8]=a*c,e[1]=a*f,e[5]=a*u,e[9]=-o,e[2]=p*o-_,e[6]=b+h*o,e[10]=a*l}else if(t.order==="ZXY"){let h=l*u,p=l*f,_=c*u,b=c*f;e[0]=h-b*o,e[4]=-a*f,e[8]=_+p*o,e[1]=p+_*o,e[5]=a*u,e[9]=b-h*o,e[2]=-a*c,e[6]=o,e[10]=a*l}else if(t.order==="ZYX"){let h=a*u,p=a*f,_=o*u,b=o*f;e[0]=l*u,e[4]=_*c-p,e[8]=h*c+b,e[1]=l*f,e[5]=b*c+h,e[9]=p*c-_,e[2]=-c,e[6]=o*l,e[10]=a*l}else if(t.order==="YZX"){let h=a*l,p=a*c,_=o*l,b=o*c;e[0]=l*u,e[4]=b-h*f,e[8]=_*f+p,e[1]=f,e[5]=a*u,e[9]=-o*u,e[2]=-c*u,e[6]=p*f+_,e[10]=h-b*f}else if(t.order==="XZY"){let h=a*l,p=a*c,_=o*l,b=o*c;e[0]=l*u,e[4]=-f,e[8]=c*u,e[1]=h*f+b,e[5]=a*u,e[9]=p*f-_,e[2]=_*f-p,e[6]=o*u,e[10]=b*f+h}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose(jd,t,Qd)}lookAt(t,e,n){let s=this.elements;return nn.subVectors(t,e),nn.lengthSq()===0&&(nn.z=1),nn.normalize(),ei.crossVectors(n,nn),ei.lengthSq()===0&&(Math.abs(n.z)===1?nn.x+=1e-4:nn.z+=1e-4,nn.normalize(),ei.crossVectors(n,nn)),ei.normalize(),Ir.crossVectors(nn,ei),s[0]=ei.x,s[4]=Ir.x,s[8]=nn.x,s[1]=ei.y,s[5]=Ir.y,s[9]=nn.y,s[2]=ei.z,s[6]=Ir.z,s[10]=nn.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,s=e.elements,r=this.elements,a=n[0],o=n[4],l=n[8],c=n[12],u=n[1],f=n[5],h=n[9],p=n[13],_=n[2],b=n[6],m=n[10],d=n[14],E=n[3],A=n[7],y=n[11],S=n[15],M=s[0],C=s[4],x=s[8],T=s[12],P=s[1],F=s[5],N=s[9],B=s[13],R=s[2],z=s[6],q=s[10],Z=s[14],rt=s[3],$=s[7],K=s[11],st=s[15];return r[0]=a*M+o*P+l*R+c*rt,r[4]=a*C+o*F+l*z+c*$,r[8]=a*x+o*N+l*q+c*K,r[12]=a*T+o*B+l*Z+c*st,r[1]=u*M+f*P+h*R+p*rt,r[5]=u*C+f*F+h*z+p*$,r[9]=u*x+f*N+h*q+p*K,r[13]=u*T+f*B+h*Z+p*st,r[2]=_*M+b*P+m*R+d*rt,r[6]=_*C+b*F+m*z+d*$,r[10]=_*x+b*N+m*q+d*K,r[14]=_*T+b*B+m*Z+d*st,r[3]=E*M+A*P+y*R+S*rt,r[7]=E*C+A*F+y*z+S*$,r[11]=E*x+A*N+y*q+S*K,r[15]=E*T+A*B+y*Z+S*st,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[12],a=t[1],o=t[5],l=t[9],c=t[13],u=t[2],f=t[6],h=t[10],p=t[14],_=t[3],b=t[7],m=t[11],d=t[15],E=l*p-c*h,A=o*p-c*f,y=o*h-l*f,S=a*p-c*u,M=a*h-l*u,C=a*f-o*u;return e*(b*E-m*A+d*y)-n*(_*E-m*S+d*M)+s*(_*A-b*S+d*C)-r*(_*y-b*M+m*C)}determinantAffine(){let t=this.elements,e=t[0],n=t[4],s=t[8],r=t[1],a=t[5],o=t[9],l=t[2],c=t[6],u=t[10];return e*(a*u-o*c)-n*(r*u-o*l)+s*(r*c-a*l)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let s=this.elements;return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],s=t[2],r=t[3],a=t[4],o=t[5],l=t[6],c=t[7],u=t[8],f=t[9],h=t[10],p=t[11],_=t[12],b=t[13],m=t[14],d=t[15],E=e*o-n*a,A=e*l-s*a,y=e*c-r*a,S=n*l-s*o,M=n*c-r*o,C=s*c-r*l,x=u*b-f*_,T=u*m-h*_,P=u*d-p*_,F=f*m-h*b,N=f*d-p*b,B=h*d-p*m,R=E*B-A*N+y*F+S*P-M*T+C*x;if(R===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let z=1/R;return t[0]=(o*B-l*N+c*F)*z,t[1]=(s*N-n*B-r*F)*z,t[2]=(b*C-m*M+d*S)*z,t[3]=(h*M-f*C-p*S)*z,t[4]=(l*P-a*B-c*T)*z,t[5]=(e*B-s*P+r*T)*z,t[6]=(m*y-_*C-d*A)*z,t[7]=(u*C-h*y+p*A)*z,t[8]=(a*N-o*P+c*x)*z,t[9]=(n*P-e*N-r*x)*z,t[10]=(_*M-b*y+d*E)*z,t[11]=(f*y-u*M-p*E)*z,t[12]=(o*T-a*F-l*x)*z,t[13]=(e*F-n*T+s*x)*z,t[14]=(b*A-_*S-m*E)*z,t[15]=(u*S-f*A+h*E)*z,this}scale(t){let e=this.elements,n=t.x,s=t.y,r=t.z;return e[0]*=n,e[4]*=s,e[8]*=r,e[1]*=n,e[5]*=s,e[9]*=r,e[2]*=n,e[6]*=s,e[10]*=r,e[3]*=n,e[7]*=s,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],s=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,s))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),s=Math.sin(e),r=1-n,a=t.x,o=t.y,l=t.z,c=r*a,u=r*o;return this.set(c*a+n,c*o-s*l,c*l+s*o,0,c*o+s*l,u*o+n,u*l-s*a,0,c*l-s*o,u*l+s*a,r*l*l+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,s,r,a){return this.set(1,n,r,0,t,1,a,0,e,s,1,0,0,0,0,1),this}compose(t,e,n){let s=this.elements,r=e._x,a=e._y,o=e._z,l=e._w,c=r+r,u=a+a,f=o+o,h=r*c,p=r*u,_=r*f,b=a*u,m=a*f,d=o*f,E=l*c,A=l*u,y=l*f,S=n.x,M=n.y,C=n.z;return s[0]=(1-(b+d))*S,s[1]=(p+y)*S,s[2]=(_-A)*S,s[3]=0,s[4]=(p-y)*M,s[5]=(1-(h+d))*M,s[6]=(m+E)*M,s[7]=0,s[8]=(_+A)*C,s[9]=(m-E)*C,s[10]=(1-(h+b))*C,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this}decompose(t,e,n){let s=this.elements;t.x=s[12],t.y=s[13],t.z=s[14];let r=this.determinantAffine();if(r===0)return n.set(1,1,1),e.identity(),this;let a=Xi.set(s[0],s[1],s[2]).length(),o=Xi.set(s[4],s[5],s[6]).length(),l=Xi.set(s[8],s[9],s[10]).length();r<0&&(a=-a),_n.copy(this);let c=1/a,u=1/o,f=1/l;return _n.elements[0]*=c,_n.elements[1]*=c,_n.elements[2]*=c,_n.elements[4]*=u,_n.elements[5]*=u,_n.elements[6]*=u,_n.elements[8]*=f,_n.elements[9]*=f,_n.elements[10]*=f,e.setFromRotationMatrix(_n),n.x=a,n.y=o,n.z=l,this}makePerspective(t,e,n,s,r,a,o=bn,l=!1){let c=this.elements,u=2*r/(e-t),f=2*r/(n-s),h=(e+t)/(e-t),p=(n+s)/(n-s),_,b;if(l)_=r/(a-r),b=a*r/(a-r);else if(o===bn)_=-(a+r)/(a-r),b=-2*a*r/(a-r);else if(o===cs)_=-a/(a-r),b=-a*r/(a-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=u,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=f,c[9]=p,c[13]=0,c[2]=0,c[6]=0,c[10]=_,c[14]=b,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(t,e,n,s,r,a,o=bn,l=!1){let c=this.elements,u=2/(e-t),f=2/(n-s),h=-(e+t)/(e-t),p=-(n+s)/(n-s),_,b;if(l)_=1/(a-r),b=a/(a-r);else if(o===bn)_=-2/(a-r),b=-(a+r)/(a-r);else if(o===cs)_=-1/(a-r),b=-r/(a-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=u,c[4]=0,c[8]=0,c[12]=h,c[1]=0,c[5]=f,c[9]=0,c[13]=p,c[2]=0,c[6]=0,c[10]=_,c[14]=b,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let s=0;s<16;s++)if(e[s]!==n[s])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}};Na.prototype.isMatrix4=!0;var ye=Na,Xi=new U,_n=new ye,jd=new U(0,0,0),Qd=new U(1,1,1),ei=new U,Ir=new U,nn=new U,th=new ye,eh=new Oe,qn=class i{constructor(t=0,e=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=s}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,s=this._order){return this._x=t,this._y=e,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let s=t.elements,r=s[0],a=s[4],o=s[8],l=s[1],c=s[5],u=s[9],f=s[2],h=s[6],p=s[10];switch(e){case"XYZ":this._y=Math.asin(Jt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-u,p),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(h,c),this._z=0);break;case"YXZ":this._x=Math.asin(-Jt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-f,r),this._z=0);break;case"ZXY":this._x=Math.asin(Jt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-f,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-Jt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(h,p),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(Jt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-u,c),this._y=Math.atan2(-f,r)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-Jt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-u,p),this._y=0);break;default:Bt("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return th.makeRotationFromQuaternion(t),this.setFromRotationMatrix(th,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return eh.setFromEuler(this),this.setFromQuaternion(eh,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};qn.DEFAULT_ORDER="XYZ";var Ks=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},tf=0,nh=new U,$i=new Oe,kn=new ye,Lr=new U,Fs=new U,ef=new U,nf=new Oe,ih=new U(1,0,0),sh=new U(0,1,0),rh=new U(0,0,1),ah={type:"added"},sf={type:"removed"},qi={type:"childadded",child:null},jo={type:"childremoved",child:null},Be=class i extends Sn{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:tf++}),this.uuid=Xn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let t=new U,e=new qn,n=new Oe,s=new U(1,1,1);function r(){n.setFromEuler(e,!1)}function a(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new ye},normalMatrix:{value:new Vt}}),this.matrix=new ye,this.matrixWorld=new ye,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ks,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return $i.setFromAxisAngle(t,e),this.quaternion.multiply($i),this}rotateOnWorldAxis(t,e){return $i.setFromAxisAngle(t,e),this.quaternion.premultiply($i),this}rotateX(t){return this.rotateOnAxis(ih,t)}rotateY(t){return this.rotateOnAxis(sh,t)}rotateZ(t){return this.rotateOnAxis(rh,t)}translateOnAxis(t,e){return nh.copy(t).applyQuaternion(this.quaternion),this.position.add(nh.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(ih,t)}translateY(t){return this.translateOnAxis(sh,t)}translateZ(t){return this.translateOnAxis(rh,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(kn.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?Lr.copy(t):Lr.set(t,e,n);let s=this.parent;this.updateWorldMatrix(!0,!1),Fs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?kn.lookAt(Fs,Lr,this.up):kn.lookAt(Lr,Fs,this.up),this.quaternion.setFromRotationMatrix(kn),s&&(kn.extractRotation(s.matrixWorld),$i.setFromRotationMatrix(kn),this.quaternion.premultiply($i.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(zt("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(ah),qi.child=t,this.dispatchEvent(qi),qi.child=null):zt("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(sf),jo.child=t,this.dispatchEvent(jo),jo.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),kn.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),kn.multiply(t.parent.matrixWorld)),t.applyMatrix4(kn),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(ah),qi.child=t,this.dispatchEvent(qi),qi.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,s=this.children.length;n<s;n++){let a=this.children[n].getObjectByProperty(t,e);if(a!==void 0)return a}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let s=this.children;for(let r=0,a=s.length;r<a;r++)s[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fs,t,ef),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Fs,nf,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(t){t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let t=this.pivot;if(t!==null){let e=t.x,n=t.y,s=t.z,r=this.matrix.elements;r[12]+=e-r[0]*e-r[4]*n-r[8]*s,r[13]+=n-r[1]*e-r[5]*n-r[9]*s,r[14]+=s-r[2]*e-r[6]*n-r[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,s=e.length;n<s;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e,n=!1){let s=this.parent;if(t===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),e===!0){let r=this.children;for(let a=0,o=r.length;a<o;a++)r[a].updateWorldMatrix(!1,!0,n)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(o=>({...o})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(t),s.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(t)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,u=l.length;c<u;c++){let f=l[c];r(t.shapes,f)}else r(t.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(t.materials,this.material[l]));s.material=o}else s.material=r(t.materials,this.material);if(this.children.length>0){s.children=[];for(let o=0;o<this.children.length;o++)s.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){s.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];s.animations.push(r(t.animations,l))}}if(e){let o=a(t.geometries),l=a(t.materials),c=a(t.textures),u=a(t.images),f=a(t.shapes),h=a(t.skeletons),p=a(t.animations),_=a(t.nodes);o.length>0&&(n.geometries=o),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),u.length>0&&(n.images=u),f.length>0&&(n.shapes=f),h.length>0&&(n.skeletons=h),p.length>0&&(n.animations=p),_.length>0&&(n.nodes=_)}return n.object=s,n;function a(o){let l=[];for(let c in o){let u=o[c];delete u.metadata,l.push(u)}return l}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let s=t.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}};Be.DEFAULT_UP=new U(0,1,0);Be.DEFAULT_MATRIX_AUTO_UPDATE=!0;Be.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var dn=class extends Be{constructor(){super(),this.isGroup=!0,this.type="Group"}},rf={type:"move"},fs=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new dn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new dn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new U,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new U),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new dn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new U,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new U,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){let e=this._hand;if(e)for(let n of t.hand.values())this._getHandJoint(e,n)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,e,n){let s=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(t&&e.session.visibilityState!=="visible-blurred"){if(c&&t.hand){a=!0;for(let b of t.hand.values()){let m=e.getJointPose(b,n),d=this._getHandJoint(c,b);m!==null&&(d.matrix.fromArray(m.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,d.jointRadius=m.radius),d.visible=m!==null}let u=c.joints["index-finger-tip"],f=c.joints["thumb-tip"],h=u.position.distanceTo(f.position),p=.02,_=.005;c.inputState.pinching&&h>p+_?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!c.inputState.pinching&&h<=p-_&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else l!==null&&t.gripSpace&&(r=e.getPose(t.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:t,target:this})));o!==null&&(s=e.getPose(t.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(o.matrix.fromArray(s.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,s.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(s.linearVelocity)):o.hasLinearVelocity=!1,s.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(s.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(rf)))}return o!==null&&(o.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(t,e){if(t.joints[e.jointName]===void 0){let n=new dn;n.matrixAutoUpdate=!1,n.visible=!1,t.joints[e.jointName]=n,t.add(n)}return t.joints[e.jointName]}},nu={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ni={h:0,s:0,l:0},Dr={h:0,s:0,l:0};function Qo(i,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?i+(t-i)*6*e:e<1/2?t:e<2/3?i+(t-i)*6*(2/3-e):i}var Xt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let s=t;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Ge){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Qt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,s=Qt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Qt.colorSpaceToWorking(this,s),this}setHSL(t,e,n,s=Qt.workingColorSpace){if(t=ql(t,1),e=Jt(e,0,1),n=Jt(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,a=2*n-r;this.r=Qo(a,r,t+1/3),this.g=Qo(a,r,t),this.b=Qo(a,r,t-1/3)}return Qt.colorSpaceToWorking(this,s),this}setStyle(t,e=Ge){function n(r){r!==void 0&&parseFloat(r)<1&&Bt("Color: Alpha component of "+t+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,a=s[1],o=s[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:Bt("Color: Unknown color model "+t)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=s[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(a===6)return this.setHex(parseInt(r,16),e);Bt("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Ge){let n=nu[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Bt("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=$n(t.r),this.g=$n(t.g),this.b=$n(t.b),this}copyLinearToSRGB(t){return this.r=os(t.r),this.g=os(t.g),this.b=os(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Ge){return Qt.workingToColorSpace(Ve.copy(this),t),Math.round(Jt(Ve.r*255,0,255))*65536+Math.round(Jt(Ve.g*255,0,255))*256+Math.round(Jt(Ve.b*255,0,255))}getHexString(t=Ge){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Qt.workingColorSpace){Qt.workingToColorSpace(Ve.copy(this),e);let n=Ve.r,s=Ve.g,r=Ve.b,a=Math.max(n,s,r),o=Math.min(n,s,r),l,c,u=(o+a)/2;if(o===a)l=0,c=0;else{let f=a-o;switch(c=u<=.5?f/(a+o):f/(2-a-o),a){case n:l=(s-r)/f+(s<r?6:0);break;case s:l=(r-n)/f+2;break;case r:l=(n-s)/f+4;break}l/=6}return t.h=l,t.s=c,t.l=u,t}getRGB(t,e=Qt.workingColorSpace){return Qt.workingToColorSpace(Ve.copy(this),e),t.r=Ve.r,t.g=Ve.g,t.b=Ve.b,t}getStyle(t=Ge){Qt.workingToColorSpace(Ve.copy(this),t);let e=Ve.r,n=Ve.g,s=Ve.b;return t!==Ge?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(t,e,n){return this.getHSL(ni),this.setHSL(ni.h+t,ni.s+e,ni.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(ni),t.getHSL(Dr);let n=Ws(ni.h,Dr.h,e),s=Ws(ni.s,Dr.s,e),r=Ws(ni.l,Dr.l,e);return this.setHSL(n,s,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,s=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*s,this.g=r[1]*e+r[4]*n+r[7]*s,this.b=r[2]*e+r[5]*n+r[8]*s,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Ve=new Xt;Xt.NAMES=nu;var js=class extends Be{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new qn,this.environmentIntensity=1,this.environmentRotation=new qn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,e){return super.copy(t,e),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){let e=super.toJSON(t);return this.fog!==null&&(e.object.fog=this.fog.toJSON()),e.object.backgroundBlurriness=this.backgroundBlurriness,e.object.backgroundIntensity=this.backgroundIntensity,e.object.backgroundRotation=this.backgroundRotation.toArray(),e.object.environmentIntensity=this.environmentIntensity,e.object.environmentRotation=this.environmentRotation.toArray(),e}},xn=new U,zn=new U,tl=new U,Hn=new U,Yi=new U,Zi=new U,oh=new U,el=new U,nl=new U,il=new U,sl=new be,rl=new be,al=new be,Wn=class i{constructor(t=new U,e=new U,n=new U){this.a=t,this.b=e,this.c=n}static getNormal(t,e,n,s){s.subVectors(n,e),xn.subVectors(t,e),s.cross(xn);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(t,e,n,s,r){xn.subVectors(s,e),zn.subVectors(n,e),tl.subVectors(t,e);let a=xn.dot(xn),o=xn.dot(zn),l=xn.dot(tl),c=zn.dot(zn),u=zn.dot(tl),f=a*c-o*o;if(f===0)return r.set(0,0,0),null;let h=1/f,p=(c*l-o*u)*h,_=(a*u-o*l)*h;return r.set(1-p-_,_,p)}static containsPoint(t,e,n,s){return this.getBarycoord(t,e,n,s,Hn)===null?!1:Hn.x>=0&&Hn.y>=0&&Hn.x+Hn.y<=1}static getInterpolation(t,e,n,s,r,a,o,l){return this.getBarycoord(t,e,n,s,Hn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Hn.x),l.addScaledVector(a,Hn.y),l.addScaledVector(o,Hn.z),l)}static getInterpolatedAttribute(t,e,n,s,r,a){return sl.setScalar(0),rl.setScalar(0),al.setScalar(0),sl.fromBufferAttribute(t,e),rl.fromBufferAttribute(t,n),al.fromBufferAttribute(t,s),a.setScalar(0),a.addScaledVector(sl,r.x),a.addScaledVector(rl,r.y),a.addScaledVector(al,r.z),a}static isFrontFacing(t,e,n,s){return xn.subVectors(n,e),zn.subVectors(t,e),xn.cross(zn).dot(s)<0}set(t,e,n){return this.a.copy(t),this.b.copy(e),this.c.copy(n),this}setFromPointsAndIndices(t,e,n,s){return this.a.copy(t[e]),this.b.copy(t[n]),this.c.copy(t[s]),this}setFromAttributeAndIndices(t,e,n,s){return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,n),this.c.fromBufferAttribute(t,s),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return xn.subVectors(this.c,this.b),zn.subVectors(this.a,this.b),xn.cross(zn).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return i.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,e){return i.getBarycoord(t,this.a,this.b,this.c,e)}getInterpolation(t,e,n,s,r){return i.getInterpolation(t,this.a,this.b,this.c,e,n,s,r)}containsPoint(t){return i.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return i.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,e){let n=this.a,s=this.b,r=this.c,a,o;Yi.subVectors(s,n),Zi.subVectors(r,n),el.subVectors(t,n);let l=Yi.dot(el),c=Zi.dot(el);if(l<=0&&c<=0)return e.copy(n);nl.subVectors(t,s);let u=Yi.dot(nl),f=Zi.dot(nl);if(u>=0&&f<=u)return e.copy(s);let h=l*f-u*c;if(h<=0&&l>=0&&u<=0)return a=l/(l-u),e.copy(n).addScaledVector(Yi,a);il.subVectors(t,r);let p=Yi.dot(il),_=Zi.dot(il);if(_>=0&&p<=_)return e.copy(r);let b=p*c-l*_;if(b<=0&&c>=0&&_<=0)return o=c/(c-_),e.copy(n).addScaledVector(Zi,o);let m=u*_-p*f;if(m<=0&&f-u>=0&&p-_>=0)return oh.subVectors(r,s),o=(f-u)/(f-u+(p-_)),e.copy(s).addScaledVector(oh,o);let d=1/(m+b+h);return a=b*d,o=h*d,e.copy(n).addScaledVector(Yi,a).addScaledVector(Zi,o)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}},ai=class{constructor(t=new U(1/0,1/0,1/0),e=new U(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(yn.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(yn.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=yn.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)t.isMesh===!0?t.getVertexPosition(a,yn):yn.fromBufferAttribute(r,a),yn.applyMatrix4(t.matrixWorld),this.expandByPoint(yn);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Nr.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Nr.copy(n.boundingBox)),Nr.applyMatrix4(t.matrixWorld),this.union(Nr)}let s=t.children;for(let r=0,a=s.length;r<a;r++)this.expandByObject(s[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,yn),yn.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Os),Ur.subVectors(this.max,Os),Ji.subVectors(t.a,Os),Ki.subVectors(t.b,Os),ji.subVectors(t.c,Os),ii.subVectors(Ki,Ji),si.subVectors(ji,Ki),Ti.subVectors(Ji,ji);let e=[0,-ii.z,ii.y,0,-si.z,si.y,0,-Ti.z,Ti.y,ii.z,0,-ii.x,si.z,0,-si.x,Ti.z,0,-Ti.x,-ii.y,ii.x,0,-si.y,si.x,0,-Ti.y,Ti.x,0];return!ol(e,Ji,Ki,ji,Ur)||(e=[1,0,0,0,1,0,0,0,1],!ol(e,Ji,Ki,ji,Ur))?!1:(Fr.crossVectors(ii,si),e=[Fr.x,Fr.y,Fr.z],ol(e,Ji,Ki,ji,Ur))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,yn).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(yn).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Vn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Vn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Vn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Vn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Vn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Vn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Vn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Vn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Vn),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}},Vn=[new U,new U,new U,new U,new U,new U,new U,new U],yn=new U,Nr=new ai,Ji=new U,Ki=new U,ji=new U,ii=new U,si=new U,Ti=new U,Os=new U,Ur=new U,Fr=new U,Ei=new U;function ol(i,t,e,n,s){for(let r=0,a=i.length-3;r<=a;r+=3){Ei.fromArray(i,r);let o=s.x*Math.abs(Ei.x)+s.y*Math.abs(Ei.y)+s.z*Math.abs(Ei.z),l=t.dot(Ei),c=e.dot(Ei),u=n.dot(Ei);if(Math.max(-Math.max(l,c,u),Math.min(l,c,u))>o)return!1}return!0}var Ce=new U,Or=new Dt,af=0,an=class extends Sn{constructor(t,e,n=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:af++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Xl,this.updateRanges=[],this.gpuType=En,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[t+s]=e.array[n+s];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Or.fromBufferAttribute(this,e),Or.applyMatrix3(t),this.setXY(e,Or.x,Or.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)Ce.fromBufferAttribute(this,e),Ce.applyMatrix3(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)Ce.fromBufferAttribute(this,e),Ce.applyMatrix4(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)Ce.fromBufferAttribute(this,e),Ce.applyNormalMatrix(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)Ce.fromBufferAttribute(this,e),Ce.transformDirection(t),this.setXYZ(e,Ce.x,Ce.y,Ce.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=vn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=le(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=vn(e,this.array)),e}setX(t,e){return this.normalized&&(e=le(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=vn(e,this.array)),e}setY(t,e){return this.normalized&&(e=le(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=vn(e,this.array)),e}setZ(t,e){return this.normalized&&(e=le(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=vn(e,this.array)),e}setW(t,e){return this.normalized&&(e=le(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=le(e,this.array),n=le(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,s){return t*=this.itemSize,this.normalized&&(e=le(e,this.array),n=le(n,this.array),s=le(s,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t*=this.itemSize,this.normalized&&(e=le(e,this.array),n=le(n,this.array),s=le(s,this.array),r=le(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=s,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}};var Qs=class extends an{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var tr=class extends an{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var ve=class extends an{constructor(t,e,n){super(new Float32Array(t),e,n)}},of=new ai,Bs=new U,ll=new U,ps=class{constructor(t=new U,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):of.setFromPoints(t).getCenter(n);let s=0;for(let r=0,a=t.length;r<a;r++)s=Math.max(s,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(s),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;Bs.subVectors(t,this.center);let e=Bs.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),s=(n-this.radius)*.5;this.center.addScaledVector(Bs,s/n),this.radius+=s}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(ll.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(Bs.copy(t.center).add(ll)),this.expandByPoint(Bs.copy(t.center).sub(ll))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}},lf=0,un=new ye,cl=new Be,Qi=new U,sn=new ai,ks=new ai,De=new U,Ze=class i extends Sn{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:lf++}),this.uuid=Xn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(Id(t)?tr:Qs)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new Vt().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(t),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return un.makeRotationFromQuaternion(t),this.applyMatrix4(un),this}rotateX(t){return un.makeRotationX(t),this.applyMatrix4(un),this}rotateY(t){return un.makeRotationY(t),this.applyMatrix4(un),this}rotateZ(t){return un.makeRotationZ(t),this.applyMatrix4(un),this}translate(t,e,n){return un.makeTranslation(t,e,n),this.applyMatrix4(un),this}scale(t,e,n){return un.makeScale(t,e,n),this.applyMatrix4(un),this}lookAt(t){return cl.lookAt(t),cl.updateMatrix(),this.applyMatrix4(cl.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Qi).negate(),this.translate(Qi.x,Qi.y,Qi.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let s=0,r=t.length;s<r;s++){let a=t[s];n.push(a.x,a.y,a.z||0)}this.setAttribute("position",new ve(n,3))}else{let n=Math.min(t.length,e.count);for(let s=0;s<n;s++){let r=t[s];e.setXYZ(s,r.x,r.y,r.z||0)}t.length>e.count&&Bt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ai);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){zt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new U(-1/0,-1/0,-1/0),new U(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,s=e.length;n<s;n++){let r=e[n];sn.setFromBufferAttribute(r),this.morphTargetsRelative?(De.addVectors(this.boundingBox.min,sn.min),this.boundingBox.expandByPoint(De),De.addVectors(this.boundingBox.max,sn.max),this.boundingBox.expandByPoint(De)):(this.boundingBox.expandByPoint(sn.min),this.boundingBox.expandByPoint(sn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&zt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ps);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){zt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new U,1/0);return}if(t){let n=this.boundingSphere.center;if(sn.setFromBufferAttribute(t),e)for(let r=0,a=e.length;r<a;r++){let o=e[r];ks.setFromBufferAttribute(o),this.morphTargetsRelative?(De.addVectors(sn.min,ks.min),sn.expandByPoint(De),De.addVectors(sn.max,ks.max),sn.expandByPoint(De)):(sn.expandByPoint(ks.min),sn.expandByPoint(ks.max))}sn.getCenter(n);let s=0;for(let r=0,a=t.count;r<a;r++)De.fromBufferAttribute(t,r),s=Math.max(s,n.distanceToSquared(De));if(e)for(let r=0,a=e.length;r<a;r++){let o=e[r],l=this.morphTargetsRelative;for(let c=0,u=o.count;c<u;c++)De.fromBufferAttribute(o,c),l&&(Qi.fromBufferAttribute(t,c),De.add(Qi)),s=Math.max(s,n.distanceToSquared(De))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&zt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){zt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,s=e.normal,r=e.uv,a=this.getAttribute("tangent");(a===void 0||a.count!==n.count)&&(a=new an(new Float32Array(4*n.count),4),this.setAttribute("tangent",a));let o=[],l=[];for(let x=0;x<n.count;x++)o[x]=new U,l[x]=new U;let c=new U,u=new U,f=new U,h=new Dt,p=new Dt,_=new Dt,b=new U,m=new U;function d(x,T,P){c.fromBufferAttribute(n,x),u.fromBufferAttribute(n,T),f.fromBufferAttribute(n,P),h.fromBufferAttribute(r,x),p.fromBufferAttribute(r,T),_.fromBufferAttribute(r,P),u.sub(c),f.sub(c),p.sub(h),_.sub(h);let F=1/(p.x*_.y-_.x*p.y);isFinite(F)&&(b.copy(u).multiplyScalar(_.y).addScaledVector(f,-p.y).multiplyScalar(F),m.copy(f).multiplyScalar(p.x).addScaledVector(u,-_.x).multiplyScalar(F),o[x].add(b),o[T].add(b),o[P].add(b),l[x].add(m),l[T].add(m),l[P].add(m))}let E=this.groups;E.length===0&&(E=[{start:0,count:t.count}]);for(let x=0,T=E.length;x<T;++x){let P=E[x],F=P.start,N=P.count;for(let B=F,R=F+N;B<R;B+=3)d(t.getX(B+0),t.getX(B+1),t.getX(B+2))}let A=new U,y=new U,S=new U,M=new U;function C(x){S.fromBufferAttribute(s,x),M.copy(S);let T=o[x];A.copy(T),A.sub(S.multiplyScalar(S.dot(T))).normalize(),y.crossVectors(M,T);let F=y.dot(l[x])<0?-1:1;a.setXYZW(x,A.x,A.y,A.z,F)}for(let x=0,T=E.length;x<T;++x){let P=E[x],F=P.start,N=P.count;for(let B=F,R=F+N;B<R;B+=3)C(t.getX(B+0)),C(t.getX(B+1)),C(t.getX(B+2))}this._transformed=!0}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==e.count)n=new an(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let h=0,p=n.count;h<p;h++)n.setXYZ(h,0,0,0);let s=new U,r=new U,a=new U,o=new U,l=new U,c=new U,u=new U,f=new U;if(t)for(let h=0,p=t.count;h<p;h+=3){let _=t.getX(h+0),b=t.getX(h+1),m=t.getX(h+2);s.fromBufferAttribute(e,_),r.fromBufferAttribute(e,b),a.fromBufferAttribute(e,m),u.subVectors(a,r),f.subVectors(s,r),u.cross(f),o.fromBufferAttribute(n,_),l.fromBufferAttribute(n,b),c.fromBufferAttribute(n,m),o.add(u),l.add(u),c.add(u),n.setXYZ(_,o.x,o.y,o.z),n.setXYZ(b,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let h=0,p=e.count;h<p;h+=3)s.fromBufferAttribute(e,h+0),r.fromBufferAttribute(e,h+1),a.fromBufferAttribute(e,h+2),u.subVectors(a,r),f.subVectors(s,r),u.cross(f),n.setXYZ(h+0,u.x,u.y,u.z),n.setXYZ(h+1,u.x,u.y,u.z),n.setXYZ(h+2,u.x,u.y,u.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)De.fromBufferAttribute(t,e),De.normalize(),t.setXYZ(e,De.x,De.y,De.z)}toNonIndexed(){function t(o,l){let c=o.array,u=o.itemSize,f=o.normalized,h=new c.constructor(l.length*u),p=0,_=0;for(let b=0,m=l.length;b<m;b++){o.isInterleavedBufferAttribute?p=l[b]*o.data.stride+o.offset:p=l[b]*u;for(let d=0;d<u;d++)h[_++]=c[p++]}return new an(h,u,f)}if(this.index===null)return Bt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new i,n=this.index.array,s=this.attributes;for(let o in s){let l=s[o],c=t(l,n);e.setAttribute(o,c)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let u=0,f=c.length;u<f;u++){let h=c[u],p=t(h,n);l.push(p)}e.morphAttributes[o]=l}e.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];e.addGroup(c.start,c.count,c.materialIndex)}return e}toJSON(){let t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(t[c]=l[c]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let l in n){let c=n[l];t.data.attributes[l]=c.toJSON(t.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],u=[];for(let f=0,h=c.length;f<h;f++){let p=c[f];u.push(p.toJSON(t.data))}u.length>0&&(s[l]=u,r=!0)}r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(t.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone());let s=t.attributes;for(let c in s){let u=s[c];this.setAttribute(c,u.clone(e))}let r=t.morphAttributes;for(let c in r){let u=[],f=r[c];for(let h=0,p=f.length;h<p;h++)u.push(f[h].clone(e));this.morphAttributes[c]=u}this.morphTargetsRelative=t.morphTargetsRelative;let a=t.groups;for(let c=0,u=a.length;c<u;c++){let f=a[c];this.addGroup(f.start,f.count,f.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=t.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}},pa=class{constructor(t,e){this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=t!==void 0?t.length/e:0,this.usage=Xl,this.updateRanges=[],this.version=0,this.uuid=Xn()}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this}copyAt(t,e,n){t*=this.stride,n*=e.stride;for(let s=0,r=this.stride;s<r;s++)this.array[t+s]=e.array[n+s];return this}set(t,e=0){return this.array.set(t,e),this}clone(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Xn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(e,this.stride);return n.setUsage(this.usage),n}onUpload(t){return this.onUploadCallback=t,this}toJSON(t){t.arrayBuffers===void 0&&(t.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Xn()),t.arrayBuffers[this.array.buffer._uuid]===void 0&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));let e={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return e.usage=this.usage,e}},qe=new U,er=class i{constructor(t,e,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(t){this.data.needsUpdate=t}applyMatrix4(t){for(let e=0,n=this.data.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyMatrix4(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.applyNormalMatrix(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)qe.fromBufferAttribute(this,e),qe.transformDirection(t),this.setXYZ(e,qe.x,qe.y,qe.z);return this}getComponent(t,e){let n=this.array[t*this.data.stride+this.offset+e];return this.normalized&&(n=vn(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=le(n,this.array)),this.data.array[t*this.data.stride+this.offset+e]=n,this}setX(t,e){return this.normalized&&(e=le(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this}setY(t,e){return this.normalized&&(e=le(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this}setZ(t,e){return this.normalized&&(e=le(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this}setW(t,e){return this.normalized&&(e=le(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this}getX(t){let e=this.data.array[t*this.data.stride+this.offset];return this.normalized&&(e=vn(e,this.array)),e}getY(t){let e=this.data.array[t*this.data.stride+this.offset+1];return this.normalized&&(e=vn(e,this.array)),e}getZ(t){let e=this.data.array[t*this.data.stride+this.offset+2];return this.normalized&&(e=vn(e,this.array)),e}getW(t){let e=this.data.array[t*this.data.stride+this.offset+3];return this.normalized&&(e=vn(e,this.array)),e}setXY(t,e,n){return t=t*this.data.stride+this.offset,this.normalized&&(e=le(e,this.array),n=le(n,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this}setXYZ(t,e,n,s){return t=t*this.data.stride+this.offset,this.normalized&&(e=le(e,this.array),n=le(n,this.array),s=le(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this}setXYZW(t,e,n,s,r){return t=t*this.data.stride+this.offset,this.normalized&&(e=le(e,this.array),n=le(n,this.array),s=le(s,this.array),r=le(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=n,this.data.array[t+2]=s,this.data.array[t+3]=r,this}clone(t){if(t===void 0){Zs("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return new an(new this.array.constructor(e),this.itemSize,this.normalized)}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new i(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(t){if(t===void 0){Zs("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let e=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)e.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:e,normalized:this.normalized}}else return t.interleavedBuffers===void 0&&(t.interleavedBuffers={}),t.interleavedBuffers[this.data.uuid]===void 0&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},hl=new U,cf=new U,hf=new Vt,rn=class{constructor(t=new U(1,0,0),e=0){this.isPlane=!0,this.normal=t,this.constant=e}set(t,e){return this.normal.copy(t),this.constant=e,this}setComponents(t,e,n,s){return this.normal.set(t,e,n),this.constant=s,this}setFromNormalAndCoplanarPoint(t,e){return this.normal.copy(t),this.constant=-e.dot(this.normal),this}setFromCoplanarPoints(t,e,n){let s=hl.subVectors(n,e).cross(cf.subVectors(t,e)).normalize();return this.setFromNormalAndCoplanarPoint(s,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){let t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,e){return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,e,n=!0){let s=t.delta(hl),r=this.normal.dot(s);if(r===0)return this.distanceToPoint(t.start)===0?e.copy(t.start):null;let a=-(t.start.dot(this.normal)+this.constant)/r;return n===!0&&(a<0||a>1)?null:e.copy(t.start).addScaledVector(s,a)}intersectsLine(t){let e=this.distanceToPoint(t.start),n=this.distanceToPoint(t.end);return e<0&&n>0||n<0&&e>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,e){let n=e||hf.getNormalMatrix(t),s=this.coplanarPoint(hl).applyMatrix4(t),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(t){return this.normal.fromArray(t.normal),this.constant=t.constant,this}},uf=0,Yn=class extends Sn{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:uf++}),this.uuid=Xn(),this.name="",this.type="Material",this.blending=Cs,this.side=pi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Al,this.blendDst=Cl,this.blendEquation=Ii,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Xt(0,0,0),this.blendAlpha=0,this.depthFunc=ls,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Xh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ta,this.stencilZFail=ta,this.stencilZPass=ta,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(let e in t){let n=t[e];if(n===void 0){Bt(`Material: parameter '${e}' has value of undefined.`);continue}let s=this[e];if(s===void 0){Bt(`Material: '${e}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";e&&(t={textures:{},images:{}});let n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(t).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(t).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(t).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(t).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(t).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(e){let r=s(t.textures),a=s(t.images);r.length>0&&(n.textures=r),a.length>0&&(n.images=a)}return n}fromJSON(t,e){if(t.uuid!==void 0&&(this.uuid=t.uuid),t.name!==void 0&&(this.name=t.name),t.color!==void 0&&this.color!==void 0&&this.color.setHex(t.color),t.roughness!==void 0&&(this.roughness=t.roughness),t.metalness!==void 0&&(this.metalness=t.metalness),t.sheen!==void 0&&(this.sheen=t.sheen),t.sheenColor!==void 0&&(this.sheenColor=new Xt().setHex(t.sheenColor)),t.sheenRoughness!==void 0&&(this.sheenRoughness=t.sheenRoughness),t.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(t.emissive),t.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(t.specular),t.specularIntensity!==void 0&&(this.specularIntensity=t.specularIntensity),t.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(t.specularColor),t.shininess!==void 0&&(this.shininess=t.shininess),t.clearcoat!==void 0&&(this.clearcoat=t.clearcoat),t.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=t.clearcoatRoughness),t.dispersion!==void 0&&(this.dispersion=t.dispersion),t.retroreflectivity!==void 0&&(this.retroreflectivity=t.retroreflectivity),t.iridescence!==void 0&&(this.iridescence=t.iridescence),t.iridescenceIOR!==void 0&&(this.iridescenceIOR=t.iridescenceIOR),t.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=t.iridescenceThicknessRange),t.transmission!==void 0&&(this.transmission=t.transmission),t.thickness!==void 0&&(this.thickness=t.thickness),t.attenuationDistance!==void 0&&(this.attenuationDistance=t.attenuationDistance),t.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(t.attenuationColor),t.anisotropy!==void 0&&(this.anisotropy=t.anisotropy),t.anisotropyRotation!==void 0&&(this.anisotropyRotation=t.anisotropyRotation),t.fog!==void 0&&(this.fog=t.fog),t.flatShading!==void 0&&(this.flatShading=t.flatShading),t.blending!==void 0&&(this.blending=t.blending),t.combine!==void 0&&(this.combine=t.combine),t.side!==void 0&&(this.side=t.side),t.shadowSide!==void 0&&(this.shadowSide=t.shadowSide),t.opacity!==void 0&&(this.opacity=t.opacity),t.transparent!==void 0&&(this.transparent=t.transparent),t.alphaTest!==void 0&&(this.alphaTest=t.alphaTest),t.alphaHash!==void 0&&(this.alphaHash=t.alphaHash),t.depthFunc!==void 0&&(this.depthFunc=t.depthFunc),t.depthTest!==void 0&&(this.depthTest=t.depthTest),t.depthWrite!==void 0&&(this.depthWrite=t.depthWrite),t.colorWrite!==void 0&&(this.colorWrite=t.colorWrite),t.clippingPlanes!==void 0&&(this.clippingPlanes=t.clippingPlanes.map(n=>new rn().fromJSON(n))),t.clipIntersection!==void 0&&(this.clipIntersection=t.clipIntersection),t.clipShadows!==void 0&&(this.clipShadows=t.clipShadows),t.depthPacking!==void 0&&(this.depthPacking=t.depthPacking),t.blendSrc!==void 0&&(this.blendSrc=t.blendSrc),t.blendDst!==void 0&&(this.blendDst=t.blendDst),t.blendEquation!==void 0&&(this.blendEquation=t.blendEquation),t.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=t.blendSrcAlpha),t.blendDstAlpha!==void 0&&(this.blendDstAlpha=t.blendDstAlpha),t.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=t.blendEquationAlpha),t.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(t.blendColor),t.blendAlpha!==void 0&&(this.blendAlpha=t.blendAlpha),t.stencilWriteMask!==void 0&&(this.stencilWriteMask=t.stencilWriteMask),t.stencilFunc!==void 0&&(this.stencilFunc=t.stencilFunc),t.stencilRef!==void 0&&(this.stencilRef=t.stencilRef),t.stencilFuncMask!==void 0&&(this.stencilFuncMask=t.stencilFuncMask),t.stencilFail!==void 0&&(this.stencilFail=t.stencilFail),t.stencilZFail!==void 0&&(this.stencilZFail=t.stencilZFail),t.stencilZPass!==void 0&&(this.stencilZPass=t.stencilZPass),t.stencilWrite!==void 0&&(this.stencilWrite=t.stencilWrite),t.wireframe!==void 0&&(this.wireframe=t.wireframe),t.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=t.wireframeLinewidth),t.wireframeLinecap!==void 0&&(this.wireframeLinecap=t.wireframeLinecap),t.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=t.wireframeLinejoin),t.rotation!==void 0&&(this.rotation=t.rotation),t.linewidth!==void 0&&(this.linewidth=t.linewidth),t.linecap!==void 0&&(this.linecap=t.linecap),t.linejoin!==void 0&&(this.linejoin=t.linejoin),t.dashSize!==void 0&&(this.dashSize=t.dashSize),t.gapSize!==void 0&&(this.gapSize=t.gapSize),t.scale!==void 0&&(this.scale=t.scale),t.polygonOffset!==void 0&&(this.polygonOffset=t.polygonOffset),t.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=t.polygonOffsetFactor),t.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=t.polygonOffsetUnits),t.dithering!==void 0&&(this.dithering=t.dithering),t.alphaToCoverage!==void 0&&(this.alphaToCoverage=t.alphaToCoverage),t.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=t.premultipliedAlpha),t.forceSinglePass!==void 0&&(this.forceSinglePass=t.forceSinglePass),t.allowOverride!==void 0&&(this.allowOverride=t.allowOverride),t.visible!==void 0&&(this.visible=t.visible),t.toneMapped!==void 0&&(this.toneMapped=t.toneMapped),t.userData!==void 0&&(this.userData=t.userData),t.vertexColors!==void 0&&(typeof t.vertexColors=="number"?this.vertexColors=t.vertexColors>0:this.vertexColors=t.vertexColors),t.size!==void 0&&(this.size=t.size),t.sizeAttenuation!==void 0&&(this.sizeAttenuation=t.sizeAttenuation),t.map!==void 0&&(this.map=e[t.map]||null),t.matcap!==void 0&&(this.matcap=e[t.matcap]||null),t.alphaMap!==void 0&&(this.alphaMap=e[t.alphaMap]||null),t.bumpMap!==void 0&&(this.bumpMap=e[t.bumpMap]||null),t.bumpScale!==void 0&&(this.bumpScale=t.bumpScale),t.normalMap!==void 0&&(this.normalMap=e[t.normalMap]||null),t.normalMapType!==void 0&&(this.normalMapType=t.normalMapType),t.normalScale!==void 0){let n=t.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new Dt().fromArray(n)}return t.displacementMap!==void 0&&(this.displacementMap=e[t.displacementMap]||null),t.displacementScale!==void 0&&(this.displacementScale=t.displacementScale),t.displacementBias!==void 0&&(this.displacementBias=t.displacementBias),t.roughnessMap!==void 0&&(this.roughnessMap=e[t.roughnessMap]||null),t.metalnessMap!==void 0&&(this.metalnessMap=e[t.metalnessMap]||null),t.emissiveMap!==void 0&&(this.emissiveMap=e[t.emissiveMap]||null),t.emissiveIntensity!==void 0&&(this.emissiveIntensity=t.emissiveIntensity),t.specularMap!==void 0&&(this.specularMap=e[t.specularMap]||null),t.specularIntensityMap!==void 0&&(this.specularIntensityMap=e[t.specularIntensityMap]||null),t.specularColorMap!==void 0&&(this.specularColorMap=e[t.specularColorMap]||null),t.envMap!==void 0&&(this.envMap=e[t.envMap]||null),t.envMapRotation!==void 0&&this.envMapRotation.fromArray(t.envMapRotation),t.envMapIntensity!==void 0&&(this.envMapIntensity=t.envMapIntensity),t.reflectivity!==void 0&&(this.reflectivity=t.reflectivity),t.refractionRatio!==void 0&&(this.refractionRatio=t.refractionRatio),t.lightMap!==void 0&&(this.lightMap=e[t.lightMap]||null),t.lightMapIntensity!==void 0&&(this.lightMapIntensity=t.lightMapIntensity),t.aoMap!==void 0&&(this.aoMap=e[t.aoMap]||null),t.aoMapIntensity!==void 0&&(this.aoMapIntensity=t.aoMapIntensity),t.gradientMap!==void 0&&(this.gradientMap=e[t.gradientMap]||null),t.clearcoatMap!==void 0&&(this.clearcoatMap=e[t.clearcoatMap]||null),t.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=e[t.clearcoatRoughnessMap]||null),t.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=e[t.clearcoatNormalMap]||null),t.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new Dt().fromArray(t.clearcoatNormalScale)),t.iridescenceMap!==void 0&&(this.iridescenceMap=e[t.iridescenceMap]||null),t.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=e[t.iridescenceThicknessMap]||null),t.transmissionMap!==void 0&&(this.transmissionMap=e[t.transmissionMap]||null),t.thicknessMap!==void 0&&(this.thicknessMap=e[t.thicknessMap]||null),t.anisotropyMap!==void 0&&(this.anisotropyMap=e[t.anisotropyMap]||null),t.sheenColorMap!==void 0&&(this.sheenColorMap=e[t.sheenColorMap]||null),t.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=e[t.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;let e=t.clippingPlanes,n=null;if(e!==null){let s=e.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=e[r].clone()}return this.clippingPlanes=n,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}},Ri=class extends Yn{constructor(t){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Xt(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}},ts,zs=new U,es=new U,ns=new U,is=new Dt,Hs=new Dt,iu=new ye,Br=new U,Vs=new U,kr=new U,lh=new Dt,ul=new Dt,ch=new Dt,ms=class extends Be{constructor(t=new Ri){if(super(),this.isSprite=!0,this.type="Sprite",ts===void 0){ts=new Ze;let e=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new pa(e,5);ts.setIndex([0,1,2,0,2,3]),ts.setAttribute("position",new er(n,3,0,!1)),ts.setAttribute("uv",new er(n,2,3,!1))}this.geometry=ts,this.material=t,this.center=new Dt(.5,.5),this.count=1}intersectsFrustum(t){return t.intersectsSprite(this)}raycast(t,e){t.camera===null&&zt('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),es.setFromMatrixScale(this.matrixWorld),iu.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),ns.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&es.multiplyScalar(-ns.z);let n=this.material.rotation,s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));let a=this.center;zr(Br.set(-.5,-.5,0),ns,a,es,s,r),zr(Vs.set(.5,-.5,0),ns,a,es,s,r),zr(kr.set(.5,.5,0),ns,a,es,s,r),lh.set(0,0),ul.set(1,0),ch.set(1,1);let o=t.ray.intersectTriangle(Br,Vs,kr,!1,zs);if(o===null&&(zr(Vs.set(-.5,.5,0),ns,a,es,s,r),ul.set(0,1),o=t.ray.intersectTriangle(Br,kr,Vs,!1,zs),o===null))return;let l=t.ray.origin.distanceTo(zs);l<t.near||l>t.far||e.push({distance:l,point:zs.clone(),uv:Wn.getInterpolation(zs,Br,Vs,kr,lh,ul,ch,new Dt),face:null,object:this})}copy(t,e){return super.copy(t,e),t.center!==void 0&&this.center.copy(t.center),this.material=t.material,this}};function zr(i,t,e,n,s,r){is.subVectors(i,e).addScalar(.5).multiply(n),s!==void 0?(Hs.x=r*is.x-s*is.y,Hs.y=s*is.x+r*is.y):Hs.copy(is),i.copy(t),i.x+=Hs.x,i.y+=Hs.y,i.applyMatrix4(iu)}var Gn=new U,dl=new U,Hr=new U,Vr=new U,gs=class{constructor(t=new U,e=new U(0,0,-1)){this.origin=t,this.direction=e}set(t,e){return this.origin.copy(t),this.direction.copy(e),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,e){return e.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Gn)),this}closestPointToPoint(t,e){e.subVectors(t,this.origin);let n=e.dot(this.direction);return n<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){let e=Gn.subVectors(t,this.origin).dot(this.direction);return e<0?this.origin.distanceToSquared(t):(Gn.copy(this.origin).addScaledVector(this.direction,e),Gn.distanceToSquared(t))}distanceSqToSegment(t,e,n,s){dl.copy(t).add(e).multiplyScalar(.5),Hr.copy(e).sub(t).normalize(),Vr.copy(this.origin).sub(dl);let r=t.distanceTo(e)*.5,a=-this.direction.dot(Hr),o=Vr.dot(this.direction),l=-Vr.dot(Hr),c=Vr.lengthSq(),u=Math.abs(1-a*a),f,h,p,_;if(u>0)if(f=a*l-o,h=a*o-l,_=r*u,f>=0)if(h>=-_)if(h<=_){let b=1/u;f*=b,h*=b,p=f*(f+a*h+2*o)+h*(a*f+h+2*l)+c}else h=r,f=Math.max(0,-(a*h+o)),p=-f*f+h*(h+2*l)+c;else h=-r,f=Math.max(0,-(a*h+o)),p=-f*f+h*(h+2*l)+c;else h<=-_?(f=Math.max(0,-(-a*r+o)),h=f>0?-r:Math.min(Math.max(-r,-l),r),p=-f*f+h*(h+2*l)+c):h<=_?(f=0,h=Math.min(Math.max(-r,-l),r),p=h*(h+2*l)+c):(f=Math.max(0,-(a*r+o)),h=f>0?r:Math.min(Math.max(-r,-l),r),p=-f*f+h*(h+2*l)+c);else h=a>0?-r:r,f=Math.max(0,-(a*h+o)),p=-f*f+h*(h+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,f),s&&s.copy(dl).addScaledVector(Hr,h),p}intersectSphere(t,e){if(t.radius<0)return null;Gn.subVectors(t.center,this.origin);let n=Gn.dot(this.direction),s=Gn.dot(Gn)-n*n,r=t.radius*t.radius;if(s>r)return null;let a=Math.sqrt(r-s),o=n-a,l=n+a;return l<0?null:o<0?this.at(l,e):this.at(o,e)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){let e=t.normal.dot(this.direction);if(e===0)return t.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(t.normal)+t.constant)/e;return n>=0?n:null}intersectPlane(t,e){let n=this.distanceToPlane(t);return n===null?null:this.at(n,e)}intersectsPlane(t){let e=t.distanceToPoint(this.origin);return e===0||t.normal.dot(this.direction)*e<0}intersectBox(t,e){let n,s,r,a,o,l,c=1/this.direction.x,u=1/this.direction.y,f=1/this.direction.z,h=this.origin;return c>=0?(n=(t.min.x-h.x)*c,s=(t.max.x-h.x)*c):(n=(t.max.x-h.x)*c,s=(t.min.x-h.x)*c),u>=0?(r=(t.min.y-h.y)*u,a=(t.max.y-h.y)*u):(r=(t.max.y-h.y)*u,a=(t.min.y-h.y)*u),n>a||r>s||((r>n||isNaN(n))&&(n=r),(a<s||isNaN(s))&&(s=a),f>=0?(o=(t.min.z-h.z)*f,l=(t.max.z-h.z)*f):(o=(t.max.z-h.z)*f,l=(t.min.z-h.z)*f),n>l||o>s)||((o>n||n!==n)&&(n=o),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,e)}intersectsBox(t){return this.intersectBox(t,Gn)!==null}intersectTriangle(t,e,n,s,r){let a=this.origin,o=this.direction,l=o.x,c=o.y,u=o.z,f=t.x-a.x,h=t.y-a.y,p=t.z-a.z,_=e.x-a.x,b=e.y-a.y,m=e.z-a.z,d=n.x-a.x,E=n.y-a.y,A=n.z-a.z,y=Math.abs(l),S=Math.abs(c),M=Math.abs(u),C,x,T,P,F,N,B,R,z,q,Z,rt;if(y>=S&&y>=M?(T=l,N=f,z=_,rt=d,l>=0?(C=c,x=u,P=h,F=p,B=b,R=m,q=E,Z=A):(C=u,x=c,P=p,F=h,B=m,R=b,q=A,Z=E)):S>=M?(T=c,N=h,z=b,rt=E,c>=0?(C=u,x=l,P=p,F=f,B=m,R=_,q=A,Z=d):(C=l,x=u,P=f,F=p,B=_,R=m,q=d,Z=A)):(T=u,N=p,z=m,rt=A,u>=0?(C=l,x=c,P=f,F=h,B=_,R=b,q=d,Z=E):(C=c,x=l,P=h,F=f,B=b,R=_,q=E,Z=d)),T===0)return null;let $=C/T,K=x/T,st=1/T,Tt=P-$*N,ht=F-K*N,Y=B-$*z,J=R-K*z,nt=q-$*rt,O=Z-K*rt,H=nt*J-O*Y,at=Tt*O-ht*nt,ut=Y*ht-J*Tt;if(s){if(H<0||at<0||ut<0)return null}else if((H<0||at<0||ut<0)&&(H>0||at>0||ut>0))return null;let ct=H+at+ut;if(ct===0)return null;let bt=st*(H*N+at*z+ut*rt);return(ct>0?bt<0:bt>0)?null:this.at(bt/ct,r)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Pi=class extends Yn{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Xt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new qn,this.combine=Rl,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}},hh=new ye,wi=new gs,Gr=new ps,uh=new U,Wr=new U,Xr=new U,$r=new U,fl=new U,qr=new U,dh=new U,Yr=new U,Me=class extends Be{constructor(t=new Ze,e=new Pi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,e){return super.copy(t,e),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,n=Object.keys(e);if(n.length>0){let s=e[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,a=s.length;r<a;r++){let o=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=r}}}}getVertexPosition(t,e){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,a=n.morphTargetsRelative;e.fromBufferAttribute(s,t);let o=this.morphTargetInfluences;if(r&&o){qr.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let u=o[l],f=r[l];u!==0&&(fl.fromBufferAttribute(f,t),a?qr.addScaledVector(fl,u):qr.addScaledVector(fl.sub(e),u))}e.add(qr)}return e}intersectsFrustum(t){return t.intersectsObject(this)}raycast(t,e){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Gr.copy(n.boundingSphere),Gr.applyMatrix4(r),wi.copy(t.ray).recast(t.near),!(Gr.containsPoint(wi.origin)===!1&&(wi.intersectSphere(Gr,uh)===null||wi.origin.distanceToSquared(uh)>(t.far-t.near)**2))&&(hh.copy(r).invert(),wi.copy(t.ray).applyMatrix4(hh),!(n.boundingBox!==null&&wi.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(t,e,wi)))}_computeIntersections(t,e,n){let s,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,u=r.attributes.uv1,f=r.attributes.normal,h=r.groups,p=r.drawRange;if(o!==null)if(Array.isArray(a))for(let _=0,b=h.length;_<b;_++){let m=h[_],d=a[m.materialIndex],E=Math.max(m.start,p.start),A=Math.min(o.count,Math.min(m.start+m.count,p.start+p.count));for(let y=E,S=A;y<S;y+=3){let M=o.getX(y),C=o.getX(y+1),x=o.getX(y+2);s=Zr(this,d,t,n,c,u,f,M,C,x),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let _=Math.max(0,p.start),b=Math.min(o.count,p.start+p.count);for(let m=_,d=b;m<d;m+=3){let E=o.getX(m),A=o.getX(m+1),y=o.getX(m+2);s=Zr(this,a,t,n,c,u,f,E,A,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}else if(l!==void 0)if(Array.isArray(a))for(let _=0,b=h.length;_<b;_++){let m=h[_],d=a[m.materialIndex],E=Math.max(m.start,p.start),A=Math.min(l.count,Math.min(m.start+m.count,p.start+p.count));for(let y=E,S=A;y<S;y+=3){let M=y,C=y+1,x=y+2;s=Zr(this,d,t,n,c,u,f,M,C,x),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=m.materialIndex,e.push(s))}}else{let _=Math.max(0,p.start),b=Math.min(l.count,p.start+p.count);for(let m=_,d=b;m<d;m+=3){let E=m,A=m+1,y=m+2;s=Zr(this,a,t,n,c,u,f,E,A,y),s&&(s.faceIndex=Math.floor(m/3),e.push(s))}}}};function df(i,t,e,n,s,r,a,o){let l;if(t.side===Je?l=n.intersectTriangle(a,r,s,!0,o):l=n.intersectTriangle(s,r,a,t.side===pi,o),l===null)return null;Yr.copy(o),Yr.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(Yr);return c<e.near||c>e.far?null:{distance:c,point:Yr.clone(),object:i}}function Zr(i,t,e,n,s,r,a,o,l,c){i.getVertexPosition(o,Wr),i.getVertexPosition(l,Xr),i.getVertexPosition(c,$r);let u=df(i,t,e,n,Wr,Xr,$r,dh);if(u){let f=new U;Wn.getBarycoord(dh,Wr,Xr,$r,f),s&&(u.uv=Wn.getInterpolatedAttribute(s,o,l,c,f,new Dt)),r&&(u.uv1=Wn.getInterpolatedAttribute(r,o,l,c,f,new Dt)),a&&(u.normal=Wn.getInterpolatedAttribute(a,o,l,c,f,new U),u.normal.dot(n.direction)>0&&u.normal.multiplyScalar(-1));let h={a:o,b:l,c,normal:new U,materialIndex:0};Wn.getNormal(Wr,Xr,$r,h.normal),u.face=h,u.barycoord=f}return u}var ma=class extends Ye{constructor(t=null,e=1,n=1,s,r,a,o,l,c=Ne,u=Ne,f,h){super(null,a,o,l,c,u,s,r,f,h),this.isDataTexture=!0,this.image={data:t,width:e,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Ai=new ps,ff=new Dt(.5,.5),Jr=new U,_s=class{constructor(t=new rn,e=new rn,n=new rn,s=new rn,r=new rn,a=new rn){this.planes=[t,e,n,s,r,a]}set(t,e,n,s,r,a){let o=this.planes;return o[0].copy(t),o[1].copy(e),o[2].copy(n),o[3].copy(s),o[4].copy(r),o[5].copy(a),this}copy(t){let e=this.planes;for(let n=0;n<6;n++)e[n].copy(t.planes[n]);return this}setFromProjectionMatrix(t,e=bn,n=!1){let s=this.planes,r=t.elements,a=r[0],o=r[1],l=r[2],c=r[3],u=r[4],f=r[5],h=r[6],p=r[7],_=r[8],b=r[9],m=r[10],d=r[11],E=r[12],A=r[13],y=r[14],S=r[15];if(s[0].setComponents(c-a,p-u,d-_,S-E).normalize(),s[1].setComponents(c+a,p+u,d+_,S+E).normalize(),s[2].setComponents(c+o,p+f,d+b,S+A).normalize(),s[3].setComponents(c-o,p-f,d-b,S-A).normalize(),n)s[4].setComponents(l,h,m,y).normalize(),s[5].setComponents(c-l,p-h,d-m,S-y).normalize();else if(s[4].setComponents(c-l,p-h,d-m,S-y).normalize(),e===bn)s[5].setComponents(c+l,p+h,d+m,S+y).normalize();else if(e===cs)s[5].setComponents(l,h,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ai.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{let e=t.geometry;e.boundingSphere===null&&e.computeBoundingSphere(),Ai.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ai)}intersectsSprite(t){Ai.center.set(0,0,0);let e=ff.distanceTo(t.center);return Ai.radius=.7071067811865476+e,Ai.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ai)}intersectsSphere(t){let e=this.planes,n=t.center,s=-t.radius;for(let r=0;r<6;r++)if(e[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(t){let e=this.planes;for(let n=0;n<6;n++){let s=e[n];if(Jr.x=s.normal.x>0?t.max.x:t.min.x,Jr.y=s.normal.y>0?t.max.y:t.min.y,Jr.z=s.normal.z>0?t.max.z:t.min.z,s.distanceToPoint(Jr)<0)return!1}return!0}containsPoint(t){let e=this.planes;for(let n=0;n<6;n++)if(e[n].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};var nr=class extends Ye{constructor(t=[],e=mi,n,s,r,a,o,l,c,u){super(t,e,n,s,r,a,o,l,c,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}},xs=class extends Ye{constructor(t,e,n,s,r,a,o,l,c){super(t,e,n,s,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}};var oi=class extends Ye{constructor(t,e,n=Tn,s,r,a,o=Ne,l=Ne,c,u=Ln,f=1){if(u!==Ln&&u!==_i)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let h={width:t,height:e,depth:f};super(h,s,r,a,o,l,u,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new ds(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){let e=super.toJSON(t);return e.compareFunction=this.compareFunction,e}},ga=class extends oi{constructor(t,e=Tn,n=mi,s,r,a=Ne,o=Ne,l,c=Ln){let u={width:t,height:t,depth:1},f=[u,u,u,u,u,u];super(t,t,e,n,s,r,a,o,l,c),this.image=f,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}},ir=class extends Ye{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}},ys=class i extends Ze{constructor(t=1,e=1,n=1,s=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:n,widthSegments:s,heightSegments:r,depthSegments:a};let o=this;s=Math.floor(s),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],u=[],f=[],h=0,p=0;_("z","y","x",-1,-1,n,e,t,a,r,0),_("z","y","x",1,-1,n,e,-t,a,r,1),_("x","z","y",1,1,t,n,e,s,a,2),_("x","z","y",1,-1,t,n,-e,s,a,3),_("x","y","z",1,-1,t,e,n,s,r,4),_("x","y","z",-1,-1,t,e,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new ve(c,3)),this.setAttribute("normal",new ve(u,3)),this.setAttribute("uv",new ve(f,2));function _(b,m,d,E,A,y,S,M,C,x,T){let P=y/C,F=S/x,N=y/2,B=S/2,R=M/2,z=C+1,q=x+1,Z=0,rt=0,$=new U;for(let K=0;K<q;K++){let st=K*F-B;for(let Tt=0;Tt<z;Tt++){let ht=Tt*P-N;$[b]=ht*E,$[m]=st*A,$[d]=R,c.push($.x,$.y,$.z),$[b]=0,$[m]=0,$[d]=M>0?1:-1,u.push($.x,$.y,$.z),f.push(Tt/C),f.push(1-K/x),Z+=1}}for(let K=0;K<x;K++)for(let st=0;st<C;st++){let Tt=h+st+z*K,ht=h+st+z*(K+1),Y=h+(st+1)+z*(K+1),J=h+(st+1)+z*K;l.push(Tt,ht,J),l.push(ht,Y,J),rt+=6}o.addGroup(p,rt,T),p+=rt,h+=Z}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}};var vs=class i extends Ze{constructor(t=1,e=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:n,thetaLength:s},e=Math.max(3,e);let r=[],a=[],o=[],l=[],c=new U,u=new Dt;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let f=0,h=3;f<=e;f++,h+=3){let p=n+f/e*s;c.x=t*Math.cos(p),c.y=t*Math.sin(p),a.push(c.x,c.y,c.z),o.push(0,0,1),u.x=(a[h]/t+1)/2,u.y=(a[h+1]/t+1)/2,l.push(u.x,u.y)}for(let f=1;f<=e;f++)r.push(f,f+1,0);this.setIndex(r),this.setAttribute("position",new ve(a,3)),this.setAttribute("normal",new ve(o,3)),this.setAttribute("uv",new ve(l,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.segments,t.thetaStart,t.thetaLength)}},li=class i extends Ze{constructor(t=1,e=1,n=1,s=32,r=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:n,radialSegments:s,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let u=[],f=[],h=[],p=[],_=0,b=[],m=n/2,d=0;E(),a===!1&&(t>0&&A(!0),e>0&&A(!1)),this.setIndex(u),this.setAttribute("position",new ve(f,3)),this.setAttribute("normal",new ve(h,3)),this.setAttribute("uv",new ve(p,2));function E(){let y=new U,S=new U,M=0,C=(e-t)/n;for(let x=0;x<=r;x++){let T=[],P=x/r,F=P*(e-t)+t;for(let N=0;N<=s;N++){let B=N/s,R=B*l+o,z=Math.sin(R),q=Math.cos(R);S.x=F*z,S.y=-P*n+m,S.z=F*q,f.push(S.x,S.y,S.z),y.set(z,C,q).normalize(),h.push(y.x,y.y,y.z),p.push(B,1-P),T.push(_++)}b.push(T)}for(let x=0;x<s;x++)for(let T=0;T<r;T++){let P=b[T][x],F=b[T+1][x],N=b[T+1][x+1],B=b[T][x+1];(t>0||T!==0)&&(u.push(P,F,B),M+=3),(e>0||T!==r-1)&&(u.push(F,N,B),M+=3)}c.addGroup(d,M,0),d+=M}function A(y){let S=_,M=new Dt,C=new U,x=0,T=y===!0?t:e,P=y===!0?1:-1;for(let N=1;N<=s;N++)f.push(0,m*P,0),h.push(0,P,0),p.push(.5,.5),_++;let F=_;for(let N=0;N<=s;N++){let R=N/s*l+o,z=Math.cos(R),q=Math.sin(R);C.x=T*q,C.y=m*P,C.z=T*z,f.push(C.x,C.y,C.z),h.push(0,P,0),M.x=z*.5+.5,M.y=q*.5*P+.5,p.push(M.x,M.y),_++}for(let N=0;N<s;N++){let B=S+N,R=F+N;y===!0?u.push(R,R+1,B):u.push(R+1,R,B),x+=3}c.addGroup(d,x,y===!0?1:2),d+=x}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}};var sr=class i extends Ze{constructor(t=1,e=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:n,heightSegments:s};let r=t/2,a=e/2,o=Math.floor(n),l=Math.floor(s),c=o+1,u=l+1,f=t/o,h=e/l,p=[],_=[],b=[],m=[];for(let d=0;d<u;d++){let E=d*h-a;for(let A=0;A<c;A++){let y=A*f-r;_.push(y,-E,0),b.push(0,0,1),m.push(A/o),m.push(1-d/l)}}for(let d=0;d<l;d++)for(let E=0;E<o;E++){let A=E+c*d,y=E+c*(d+1),S=E+1+c*(d+1),M=E+1+c*d;p.push(A,y,M),p.push(y,S,M)}this.setIndex(p),this.setAttribute("position",new ve(_,3)),this.setAttribute("normal",new ve(b,3)),this.setAttribute("uv",new ve(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.width,t.height,t.widthSegments,t.heightSegments)}},bs=class i extends Ze{constructor(t=.5,e=1,n=32,s=1,r=0,a=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:a},n=Math.max(3,n),s=Math.max(1,s);let o=[],l=[],c=[],u=[],f=t,h=(e-t)/s,p=new U,_=new Dt;for(let b=0;b<=s;b++){for(let m=0;m<=n;m++){let d=r+m/n*a;p.x=f*Math.cos(d),p.y=f*Math.sin(d),l.push(p.x,p.y,p.z),c.push(0,0,1),_.x=(p.x/e+1)/2,_.y=(p.y/e+1)/2,u.push(_.x,_.y)}f+=h}for(let b=0;b<s;b++){let m=b*(n+1);for(let d=0;d<n;d++){let E=d+m,A=E,y=E+n+1,S=E+n+2,M=E+1;o.push(A,y,M),o.push(y,S,M)}}this.setIndex(o),this.setAttribute("position",new ve(l,3)),this.setAttribute("normal",new ve(c,3)),this.setAttribute("uv",new ve(u,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)}};var Ss=class i extends Ze{constructor(t=1,e=32,n=16,s=0,r=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:n,phiStart:s,phiLength:r,thetaStart:a,thetaLength:o},e=Math.max(3,Math.floor(e)),n=Math.max(2,Math.floor(n));let l=Math.min(a+o,Math.PI),c=0,u=[],f=new U,h=new U,p=[],_=[],b=[],m=[];for(let d=0;d<=n;d++){let E=[],A=d/n,y=a+A*o,S=t*Math.cos(y),M=Math.sqrt(t*t-S*S),C=0;d===0&&a===0?C=.5/e:d===n&&l===Math.PI&&(C=-.5/e);for(let x=0;x<=e;x++){let T=x/e,P=s+T*r;f.x=-M*Math.cos(P),f.y=S,f.z=M*Math.sin(P),_.push(f.x,f.y,f.z),h.copy(f).normalize(),b.push(h.x,h.y,h.z),m.push(T+C,1-A),E.push(c++)}u.push(E)}for(let d=0;d<n;d++)for(let E=0;E<e;E++){let A=u[d][E+1],y=u[d][E],S=u[d+1][E],M=u[d+1][E+1];(d!==0||a>0)&&p.push(A,y,M),(d!==n-1||l<Math.PI)&&p.push(y,S,M)}this.setIndex(p),this.setAttribute("position",new ve(_,3)),this.setAttribute("normal",new ve(b,3)),this.setAttribute("uv",new ve(m,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new i(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}};function Di(i){let t={};for(let e in i){t[e]={};for(let n in i[e]){let s=i[e][n];if(fh(s))s.isRenderTargetTexture?(Bt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=s.clone();else if(Array.isArray(s))if(fh(s[0])){let r=[];for(let a=0,o=s.length;a<o;a++)r[a]=s[a].clone();t[e][n]=r}else t[e][n]=s.slice();else t[e][n]=s}}return t}function Xe(i){let t={};for(let e=0;e<i.length;e++){let n=Di(i[e]);for(let s in n)t[s]=n[s]}return t}function fh(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function pf(i){let t=[];for(let e=0;e<i.length;e++)t.push(i[e].clone());return t}function Zl(i){let t=i.getRenderTarget();return t===null?i.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Qt.workingColorSpace}var su={clone:Di,merge:Xe},mf=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,gf=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,on=class extends Yn{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=mf,this.fragmentShader=gf,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=Di(t.uniforms),this.uniformsGroups=pf(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){let e=super.toJSON(t);e.glslVersion=this.glslVersion,e.uniforms={};for(let s in this.uniforms){let a=this.uniforms[s].value;a&&a.isTexture?e.uniforms[s]={type:"t",value:a.toJSON(t).uuid}:a&&a.isColor?e.uniforms[s]={type:"c",value:a.getHex()}:a&&a.isVector2?e.uniforms[s]={type:"v2",value:a.toArray()}:a&&a.isVector3?e.uniforms[s]={type:"v3",value:a.toArray()}:a&&a.isVector4?e.uniforms[s]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?e.uniforms[s]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?e.uniforms[s]={type:"m4",value:a.toArray()}:e.uniforms[s]={value:a}}Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(e.extensions=n),e}fromJSON(t,e){if(super.fromJSON(t,e),t.uniforms!==void 0)for(let n in t.uniforms){let s=t.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=e[s.value]||null;break;case"c":this.uniforms[n].value=new Xt().setHex(s.value);break;case"v2":this.uniforms[n].value=new Dt().fromArray(s.value);break;case"v3":this.uniforms[n].value=new U().fromArray(s.value);break;case"v4":this.uniforms[n].value=new be().fromArray(s.value);break;case"m3":this.uniforms[n].value=new Vt().fromArray(s.value);break;case"m4":this.uniforms[n].value=new ye().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(t.defines!==void 0&&(this.defines=t.defines),t.vertexShader!==void 0&&(this.vertexShader=t.vertexShader),t.fragmentShader!==void 0&&(this.fragmentShader=t.fragmentShader),t.glslVersion!==void 0&&(this.glslVersion=t.glslVersion),t.extensions!==void 0)for(let n in t.extensions)this.extensions[n]=t.extensions[n];return t.lights!==void 0&&(this.lights=t.lights),t.clipping!==void 0&&(this.clipping=t.clipping),this}},_a=class extends on{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},xa=class extends Yn{constructor(t){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Xt(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Xt(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=bo,this.normalScale=new Dt(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new qn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}},Ms=class extends xa{constructor(t){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new Dt(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return Jt(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(e){this.ior=(1+.4*e)/(1-.4*e)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Xt(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Xt(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Xt(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(t)}get anisotropy(){return this._anisotropy}set anisotropy(t){this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t}get clearcoat(){return this._clearcoat}set clearcoat(t){this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t}get iridescence(){return this._iridescence}set iridescence(t){this._iridescence>0!=t>0&&this.version++,this._iridescence=t}get dispersion(){return this._dispersion}set dispersion(t){this._dispersion>0!=t>0&&this.version++,this._dispersion=t}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(t){this._retroreflectivity>0!=t>0&&this.version++,this._retroreflectivity=t}get sheen(){return this._sheen}set sheen(t){this._sheen>0!=t>0&&this.version++,this._sheen=t}get transmission(){return this._transmission}set transmission(t){this._transmission>0!=t>0&&this.version++,this._transmission=t}copy(t){return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.retroreflectivity=t.retroreflectivity,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this}};var ya=class extends Yn{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Gh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}},va=class extends Yn{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}};function ss(i,t){return!i||i.constructor===t?i:typeof t.BYTES_PER_ELEMENT=="number"?new t(i):Array.prototype.slice.call(i)}function pl(i){return i!==void 0&&i.inTangents!==void 0&&i.outTangents!==void 0}var ci=class{constructor(t,e,n,s){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,s=e[n],r=e[n-1];n:{t:{let a;e:{i:if(!(t<s)){for(let o=n+2;;){if(s===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=s,s=e[++n],t<s)break t}a=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=e[--n-1],t>=r)break t}a=n,n=0;break e}break n}for(;n<a;){let o=n+a>>>1;t<e[o]?a=o:n=o+1}if(s=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,t,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=t*s;for(let a=0;a!==s;++a)e[a]=n[r+a];return e}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}},ba=class extends ci{constructor(t,e,n,s){super(t,e,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:_l,endingEnd:_l}}intervalChanged_(t,e,n){let s=this.parameterPositions,r=t-2,a=t+1,o=s[r],l=s[a];if(o===void 0)switch(this.getSettings_().endingStart){case xl:r=t,o=2*e-n;break;case yl:r=s.length-2,o=e+s[r]-s[r+1];break;default:r=t,o=n}if(l===void 0)switch(this.getSettings_().endingEnd){case xl:a=t,l=2*n-e;break;case yl:a=1,l=n+s[1]-s[0];break;default:a=t-1,l=e}let c=(n-e)*.5,u=this.valueSize;this._weightPrev=c/(e-o),this._weightNext=c/(l-n),this._offsetPrev=r*u,this._offsetNext=a*u}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,u=this._offsetPrev,f=this._offsetNext,h=this._weightPrev,p=this._weightNext,_=(n-e)/(s-e),b=_*_,m=b*_,d=-h*m+2*h*b-h*_,E=(1+h)*m+(-1.5-2*h)*b+(-.5+h)*_+1,A=(-1-p)*m+(1.5+p)*b+.5*_,y=p*m-p*b;for(let S=0;S!==o;++S)r[S]=d*a[u+S]+E*a[c+S]+A*a[l+S]+y*a[f+S];return r}},Sa=class extends ci{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,u=(n-e)/(s-e),f=1-u;for(let h=0;h!==o;++h)r[h]=a[c+h]*f+a[l+h]*u;return r}},Ma=class extends ci{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t){return this.copySampleValue_(t-1)}},Ta=class extends ci{interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=t*o,c=l-o,u=this.inTangents,f=this.outTangents;if(!u||!f){let _=(n-e)/(s-e),b=1-_;for(let m=0;m!==o;++m)r[m]=a[c+m]*b+a[l+m]*_;return r}let h=o*2,p=t-1;for(let _=0;_!==o;++_){let b=a[c+_],m=a[l+_],d=p*h+_*2,E=f[d],A=f[d+1],y=t*h+_*2,S=u[y],M=u[y+1],C=xf(n,e,E,S,s);r[_]=ru(C,b,A,M,m)}return r}};function ru(i,t,e,n,s){let r=1-i;return r*r*r*t+3*r*r*i*e+3*r*i*i*n+i*i*i*s}function _f(i,t,e,n,s){let r=1-i;return 3*r*r*(e-t)+6*r*i*(n-e)+3*i*i*(s-n)}function xf(i,t,e,n,s){let r=(i-t)/(s-t);for(let a=0;a<8;a++){let o=ru(r,t,e,n,s)-i;if(Math.abs(o)<1e-10)break;let l=_f(r,t,e,n,s);if(Math.abs(l)<1e-10)break;r=Math.max(0,Math.min(1,r-o/l))}return r}var ln=class{constructor(t,e,n,s){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=ss(e,this.TimeBufferType),this.values=ss(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:ss(t.times,Array),values:ss(t.values,Array)};let s=t.getInterpolation();s!==t.DefaultInterpolation&&(n.interpolation=s),pl(t.settings)&&(n.settings={inTangents:ss(t.settings.inTangents,Array),outTangents:ss(t.settings.outTangents,Array)})}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Ma(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Sa(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new ba(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodBezier(t){let e=new Ta(this.times,this.values,this.getValueSize(),t);return this.settings&&(e.inTangents=this.settings.inTangents,e.outTangents=this.settings.outTangents),e}setInterpolation(t){let e;switch(t){case Xs:e=this.InterpolantFactoryMethodDiscrete;break;case ha:e=this.InterpolantFactoryMethodLinear;break;case Qr:e=this.InterpolantFactoryMethodSmooth;break;case gl:e=this.InterpolantFactoryMethodBezier;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return Bt("KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Xs;case this.InterpolantFactoryMethodLinear:return ha;case this.InterpolantFactoryMethodSmooth:return Qr;case this.InterpolantFactoryMethodBezier:return gl}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,s=e.length;n!==s;++n)e[n]*=t;pl(this.settings)&&(ph(this.settings.inTangents,t),ph(this.settings.outTangents,t))}return this}trim(t,e){let n=this.times,s=n.length,r=0,a=s-1;for(;r!==s&&n[r]<t;)++r;for(;a!==-1&&n[a]>e;)--a;if(++a,r!==0||a!==s){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=n.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(zt("KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,s=this.values,r=n.length;r===0&&(zt("KeyframeTrack: Track is empty.",this),t=!1);let a=null;for(let o=0;o!==r;o++){let l=n[o];if(typeof l=="number"&&isNaN(l)){zt("KeyframeTrack: Time is not a valid number.",this,o,l),t=!1;break}if(a!==null&&a>l){zt("KeyframeTrack: Out of order keys.",this,o,l,a),t=!1;break}a=l}if(s!==void 0&&Ld(s))for(let o=0,l=s.length;o!==l;++o){let c=s[o];if(isNaN(c)){zt("KeyframeTrack: Value is not a valid number.",this,o,c),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===Qr,r=t.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=t[o],u=t[o+1];if(c!==u&&(o!==1||c!==t[0]))if(s)l=!0;else{let f=o*n,h=f-n,p=f+n;for(let _=0;_!==n;++_){let b=e[f+_];if(b!==e[h+_]||b!==e[p+_]){l=!0;break}}}if(l){if(o!==a){t[a]=t[o];let f=o*n,h=a*n;for(let p=0;p!==n;++p)e[h+p]=e[f+p]}++a}}if(r>0){t[a]=t[r];for(let o=r*n,l=a*n,c=0;c!==n;++c)e[l+c]=e[o+c];++a}return a!==t.length?(this.times=t.slice(0,a),this.values=e.slice(0,a*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,s=new n(this.name,t,e);return s.createInterpolant=this.createInterpolant,pl(this.settings)&&(s.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),s}};function ph(i,t){for(let e=0,n=i.length;e!==n;e+=2)i[e]*=t}ln.prototype.ValueTypeName="";ln.prototype.TimeBufferType=Float32Array;ln.prototype.ValueBufferType=Float32Array;ln.prototype.DefaultInterpolation=ha;var hi=class extends ln{constructor(t,e,n){super(t,e,n)}};hi.prototype.ValueTypeName="bool";hi.prototype.ValueBufferType=Array;hi.prototype.DefaultInterpolation=Xs;hi.prototype.InterpolantFactoryMethodLinear=void 0;hi.prototype.InterpolantFactoryMethodSmooth=void 0;var Ea=class extends ln{constructor(t,e,n,s){super(t,e,n,s)}};Ea.prototype.ValueTypeName="color";var wa=class extends ln{constructor(t,e,n,s){super(t,e,n,s)}};wa.prototype.ValueTypeName="number";var Aa=class extends ci{constructor(t,e,n,s){super(t,e,n,s)}interpolate_(t,e,n,s){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(n-e)/(s-e),c=t*o;for(let u=c+o;c!==u;c+=4)Oe.slerpFlat(r,0,a,c-o,a,c,l);return r}},rr=class extends ln{constructor(t,e,n,s){super(t,e,n,s)}InterpolantFactoryMethodLinear(t){return new Aa(this.times,this.values,this.getValueSize(),t)}};rr.prototype.ValueTypeName="quaternion";rr.prototype.InterpolantFactoryMethodSmooth=void 0;var ui=class extends ln{constructor(t,e,n){super(t,e,n)}};ui.prototype.ValueTypeName="string";ui.prototype.ValueBufferType=Array;ui.prototype.DefaultInterpolation=Xs;ui.prototype.InterpolantFactoryMethodLinear=void 0;ui.prototype.InterpolantFactoryMethodSmooth=void 0;var Ca=class extends ln{constructor(t,e,n,s){super(t,e,n,s)}};Ca.prototype.ValueTypeName="vector";var Ra=class{constructor(t,e,n){let s=this,r=!1,a=0,o=0,l,c=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this._abortController=null,this.itemStart=function(u){o++,r===!1&&s.onStart!==void 0&&s.onStart(u,a,o),r=!0},this.itemEnd=function(u){a++,s.onProgress!==void 0&&s.onProgress(u,a,o),a===o&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(u){s.onError!==void 0&&s.onError(u)},this.resolveURL=function(u){return u=u.normalize("NFC"),l?l(u):u},this.setURLModifier=function(u){return l=u,this},this.addHandler=function(u,f){return c.push(u,f),this},this.removeHandler=function(u){let f=c.indexOf(u);return f!==-1&&c.splice(f,2),this},this.getHandler=function(u){for(let f=0,h=c.length;f<h;f+=2){let p=c[f],_=c[f+1];if(p.global&&(p.lastIndex=0),p.test(u))return _}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}},au=new Ra,Pa=class{constructor(t){this.manager=t!==void 0?t:au,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(t,e){let n=this;return new Promise(function(s,r){n.load(t,s,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}abort(){return this}};Pa.DEFAULT_MATERIAL_NAME="__DEFAULT";var ar=class extends Be{constructor(t,e=1){super(),this.isLight=!0,this.type="Light",this.color=new Xt(t),this.intensity=e}copy(t,e){return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){let e=super.toJSON(t);return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e}},or=class extends ar{constructor(t,e,n){super(t,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Be.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Xt(e)}copy(t,e){return super.copy(t,e),this.groundColor.copy(t.groundColor),this}toJSON(t){let e=super.toJSON(t);return e.object.groundColor=this.groundColor.getHex(),e}},ml=new ye,mh=new U,gh=new U,Ia=class{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Dt(512,512),this.mapType=Qe,this.map=null,this.mapPass=null,this.matrix=new ye,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new _s,this._frameExtents=new Dt(1,1),this._viewportCount=1,this._viewports=[new be(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(t){let e=this.camera;mh.setFromMatrixPosition(t.matrixWorld),e.position.copy(mh),gh.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(gh),e.updateMatrixWorld(),this._updateMatrix(e,this.matrix,this._frustum)}_updateMatrix(t,e,n,s){ml.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),n.setFromProjectionMatrix(ml,t.coordinateSystem,t.reversedDepth);let r=this._frameExtents,a=s?s.z/r.x:1,o=s?s.w/r.y:1,l=s?s.x/r.x:0,c=s?s.y/r.y:0;t.coordinateSystem===cs||t.reversedDepth?e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):e.set(.5*a,0,0,.5*a+l,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),e.multiply(ml)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let t={};return t.intensity=this.intensity,t.bias=this.bias,t.normalBias=this.normalBias,t.radius=this.radius,t.blurSamples=this.blurSamples,t.mapSize=this.mapSize.toArray(),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}},Kr=new U,jr=new Oe,Pn=new U,lr=class extends Be{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ye,this.projectionMatrix=new ye,this.projectionMatrixInverse=new ye,this.coordinateSystem=bn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,e){return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Kr,jr,Pn),Pn.x===1&&Pn.y===1&&Pn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Kr,jr,Pn.set(1,1,1)).invert()}updateWorldMatrix(t,e,n=!1){super.updateWorldMatrix(t,e,n),this.matrixWorld.decompose(Kr,jr,Pn),Pn.x===1&&Pn.y===1&&Pn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Kr,jr,Pn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},ri=new U,_h=new Dt,xh=new Dt,We=class extends lr{constructor(t=50,e=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){let e=.5*this.getFilmHeight()/t;this.fov=us*2*Math.atan(e),this.updateProjectionMatrix()}getFocalLength(){let t=Math.tan(Gs*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return us*2*Math.atan(Math.tan(Gs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,e,n){ri.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(ri.x,ri.y).multiplyScalar(-t/ri.z),ri.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(ri.x,ri.y).multiplyScalar(-t/ri.z)}getViewSize(t,e){return this.getViewBounds(t,_h,xh),e.subVectors(xh,_h)}setViewOffset(t,e,n,s,r,a){this.aspect=t/e,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=this.near,e=t*Math.tan(Gs*.5*this.fov)/this.zoom,n=2*e,s=this.aspect*n,r=-.5*s,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*s/l,e-=a.offsetY*n/c,s*=a.width/l,n*=a.height/c}let o=this.filmOffset;o!==0&&(r+=t*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-n,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,this.view!==null&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e}};var Ts=class extends lr{constructor(t=-1,e=1,n=1,s=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=n,this.bottom=s,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(t,e){return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,e,n,s,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-t,a=n+t,o=s+e,l=s-e;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=u*this.view.offsetY,l=o-u*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){let e=super.toJSON(t);return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,this.view!==null&&(e.object.view=Object.assign({},this.view)),e}},vl=class extends Ia{constructor(){super(new Ts(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Es=class extends ar{constructor(t,e){super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Be.DEFAULT_UP),this.updateMatrix(),this.target=new Be,this.shadow=new vl}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){let e=super.toJSON(t);return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e}};var rs=-90,as=1,La=class extends Be{constructor(t,e,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new We(rs,as,t,e);s.layers=this.layers,this.add(s);let r=new We(rs,as,t,e);r.layers=this.layers,this.add(r);let a=new We(rs,as,t,e);a.layers=this.layers,this.add(a);let o=new We(rs,as,t,e);o.layers=this.layers,this.add(o);let l=new We(rs,as,t,e);l.layers=this.layers,this.add(l);let c=new We(rs,as,t,e);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let t=this.coordinateSystem,e=this.children.concat(),[n,s,r,a,o,l]=e;for(let c of e)this.remove(c);if(t===bn)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(t===cs)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(let c of e)this.add(c),c.updateMatrixWorld()}update(t,e){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,u]=this.children,f=t.getRenderTarget(),h=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),_=t.xr.enabled;t.xr.enabled=!1;let b=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let m=!1;t.isWebGLRenderer===!0?m=t.state.buffers.depth.getReversed():m=t.reversedDepthBuffer,t.setRenderTarget(n,0,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,r),t.setRenderTarget(n,1,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,a),t.setRenderTarget(n,2,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,o),t.setRenderTarget(n,3,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,l),t.setRenderTarget(n,4,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,c),n.texture.generateMipmaps=b,t.setRenderTarget(n,5,s),m&&t.autoClear===!1&&t.clearDepth(),t.render(e,u),t.setRenderTarget(f,h,p),t.xr.enabled=_,n.texture.needsPMREMUpdate=!0}},Da=class extends We{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}};var Jl="\\[\\]\\.:\\/",yf=new RegExp("["+Jl+"]","g"),Kl="[^"+Jl+"]",vf="[^"+Jl.replace("\\.","")+"]",bf=/((?:WC+[\/:])*)/.source.replace("WC",Kl),Sf=/(WCOD+)?/.source.replace("WCOD",vf),Mf=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",Kl),Tf=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",Kl),Ef=new RegExp("^"+bf+Sf+Mf+Tf+"$"),wf=["material","materials","bones","map"],bl=class{constructor(t,e,n){let s=n||xe.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,s)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},xe=class i{constructor(t,e,n){this.path=e,this.parsedPath=n||i.parseTrackName(e),this.node=i.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new i.Composite(t,e,n):new i(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(yf,"")}static parseTrackName(t){let e=Ef.exec(t);if(e===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);wf.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===e||o.uuid===e)return o;let l=n(o.children);if(l)return l}return null},s=n(t.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)t[e++]=n[s]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,s=e.propertyName,r=e.propertyIndex;if(t||(t=i.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){Bt("PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=e.objectIndex;switch(n){case"materials":if(!t.material){zt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){zt("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){zt("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let u=0;u<t.length;u++)if(t[u].name===c){c=u;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){zt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){zt("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){zt("PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(c!==void 0){if(t[c]===void 0){zt("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[c]}}let a=t[s];if(a===void 0){let c=e.nodeName;zt("PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?o=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!t.geometry){zt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){zt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};xe.Composite=bl;xe.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};xe.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};xe.prototype.GetterByBindingType=[xe.prototype._getValue_direct,xe.prototype._getValue_array,xe.prototype._getValue_arrayElement,xe.prototype._getValue_toArray];xe.prototype.SetterByBindingTypeAndVersioning=[[xe.prototype._setValue_direct,xe.prototype._setValue_direct_setNeedsUpdate,xe.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[xe.prototype._setValue_array,xe.prototype._setValue_array_setNeedsUpdate,xe.prototype._setValue_array_setMatrixWorldNeedsUpdate],[xe.prototype._setValue_arrayElement,xe.prototype._setValue_arrayElement_setNeedsUpdate,xe.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[xe.prototype._setValue_fromArray,xe.prototype._setValue_fromArray_setNeedsUpdate,xe.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var ux=new Float32Array(1);var ws=class{constructor(t=1,e=0,n=0){this.radius=t,this.phi=e,this.theta=n}set(t,e,n){return this.radius=t,this.phi=e,this.theta=n,this}copy(t){return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this}makeSafe(){return this.phi=Jt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(t){return this.setFromCartesianCoords(t.x,t.y,t.z)}setFromCartesianCoords(t,e,n){return this.radius=Math.sqrt(t*t+e*e+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,n),this.phi=Math.acos(Jt(e/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};var ic=class ic{constructor(t,e,n,s){this.elements=[1,0,0,1],t!==void 0&&this.set(t,e,n,s)}identity(){return this.set(1,0,0,1),this}fromArray(t,e=0){for(let n=0;n<4;n++)this.elements[n]=t[n+e];return this}set(t,e,n,s){let r=this.elements;return r[0]=t,r[2]=e,r[1]=n,r[3]=s,this}};ic.prototype.isMatrix2=!0;var Sl=ic;var cr=class extends Sn{constructor(t,e=null){super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(t){this.domElement!==null&&this.disconnect(),this.domElement=t}disconnect(){}dispose(){}update(){}};function jl(i,t,e,n){let s=Af(n);switch(e){case Vl:return i*t;case Wl:return i*t/s.components*s.byteLength;case Ha:return i*t/s.components*s.byteLength;case xi:return i*t*2/s.components*s.byteLength;case Va:return i*t*2/s.components*s.byteLength;case Gl:return i*t*3/s.components*s.byteLength;case fn:return i*t*4/s.components*s.byteLength;case Ga:return i*t*4/s.components*s.byteLength;case fr:case pr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case mr:case gr:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case Xa:case qa:return Math.max(i,16)*Math.max(t,8)/4;case Wa:case $a:return Math.max(i,8)*Math.max(t,8)/2;case Ya:case Za:case Ka:case ja:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*8;case Ja:case _r:case Qa:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case to:return Math.floor((i+3)/4)*Math.floor((t+3)/4)*16;case eo:return Math.floor((i+4)/5)*Math.floor((t+3)/4)*16;case no:return Math.floor((i+4)/5)*Math.floor((t+4)/5)*16;case io:return Math.floor((i+5)/6)*Math.floor((t+4)/5)*16;case so:return Math.floor((i+5)/6)*Math.floor((t+5)/6)*16;case ro:return Math.floor((i+7)/8)*Math.floor((t+4)/5)*16;case ao:return Math.floor((i+7)/8)*Math.floor((t+5)/6)*16;case oo:return Math.floor((i+7)/8)*Math.floor((t+7)/8)*16;case lo:return Math.floor((i+9)/10)*Math.floor((t+4)/5)*16;case co:return Math.floor((i+9)/10)*Math.floor((t+5)/6)*16;case ho:return Math.floor((i+9)/10)*Math.floor((t+7)/8)*16;case uo:return Math.floor((i+9)/10)*Math.floor((t+9)/10)*16;case fo:return Math.floor((i+11)/12)*Math.floor((t+9)/10)*16;case po:return Math.floor((i+11)/12)*Math.floor((t+11)/12)*16;case mo:case go:case _o:return Math.ceil(i/4)*Math.ceil(t/4)*16;case xo:case yo:return Math.ceil(i/4)*Math.ceil(t/4)*8;case xr:case vo:return Math.ceil(i/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${e} format.`)}function Af(i){switch(i){case Qe:case Bl:return{byteLength:1,components:1};case Rs:case kl:case wn:return{byteLength:2,components:1};case ka:case za:return{byteLength:2,components:4};case Tn:case Ba:case En:return{byteLength:4,components:1};case zl:case Hl:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"186"}}));typeof window<"u"&&(window.__THREE__?Bt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="186");function Cu(){let i=null,t=!1,e=null,n=null;function s(r,a){n=i.requestAnimationFrame(s),e(r,a)}return{start:function(){t!==!0&&e!==null&&i!==null&&(n=i.requestAnimationFrame(s),t=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),t=!1},setAnimationLoop:function(r){e=r},setContext:function(r){i=r}}}function Rf(i){let t=new WeakMap;function e(o,l){let c=o.array,u=o.usage,f=c.byteLength,h=i.createBuffer();i.bindBuffer(l,h),i.bufferData(l,c,u),o.onUploadCallback();let p;if(c instanceof Float32Array)p=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)p=i.HALF_FLOAT;else if(c instanceof Uint16Array)o.isFloat16BufferAttribute?p=i.HALF_FLOAT:p=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)p=i.SHORT;else if(c instanceof Uint32Array)p=i.UNSIGNED_INT;else if(c instanceof Int32Array)p=i.INT;else if(c instanceof Int8Array)p=i.BYTE;else if(c instanceof Uint8Array)p=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)p=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:h,type:p,bytesPerElement:c.BYTES_PER_ELEMENT,version:o.version,size:f}}function n(o,l,c){let u=l.array,f=l.updateRanges;if(i.bindBuffer(c,o),f.length===0)i.bufferSubData(c,0,u);else{f.sort((p,_)=>p.start-_.start);let h=0;for(let p=1;p<f.length;p++){let _=f[h],b=f[p];b.start<=_.start+_.count+1?_.count=Math.max(_.count,b.start+b.count-_.start):(++h,f[h]=b)}f.length=h+1;for(let p=0,_=f.length;p<_;p++){let b=f[p];i.bufferSubData(c,b.start*u.BYTES_PER_ELEMENT,u,b.start,b.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(o){return o.isInterleavedBufferAttribute&&(o=o.data),t.get(o)}function r(o){o.isInterleavedBufferAttribute&&(o=o.data);let l=t.get(o);l&&(i.deleteBuffer(l.buffer),t.delete(o))}function a(o,l){if(o.isInterleavedBufferAttribute&&(o=o.data),o.isGLBufferAttribute){let u=t.get(o);(!u||u.version<o.version)&&t.set(o,{buffer:o.buffer,type:o.type,bytesPerElement:o.elementSize,version:o.version});return}let c=t.get(o);if(c===void 0)t.set(o,e(o,l));else if(c.version<o.version){if(c.size!==o.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,o,l),c.version=o.version}}return{get:s,remove:r,update:a}}var Pf=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,If=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Lf=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Df=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Nf=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Uf=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ff=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Of=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Bf=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,kf=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,zf=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Hf=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Vf=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Gf=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Wf=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Xf=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,$f=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,qf=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Yf=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Zf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Jf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Kf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,jf=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Qf=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,tp=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,ep=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,np=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,ip=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,sp=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,rp=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,ap="gl_FragColor = linearToOutputTexel( gl_FragColor );",op=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,lp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,cp=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,hp=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,up=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,dp=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fp=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,pp=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,mp=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,gp=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,_p=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,xp=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,yp=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,vp=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,bp=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Sp=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Mp=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Tp=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Ep=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,wp=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Ap=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Cp=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Rp=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Pp=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Ip=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Lp=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Dp=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Np=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Up=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Fp=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Op=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Bp=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,kp=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,zp=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Hp=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Vp=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Gp=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Wp=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Xp=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,$p=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,qp=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Yp=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Zp=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Jp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Kp=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,jp=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,Qp=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,tm=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,em=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,nm=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,im=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,sm=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,rm=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,am=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,om=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,lm=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,cm=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,hm=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,um=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,dm=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,fm=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,pm=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,mm=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,gm=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,_m=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,xm=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ym=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,vm=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,bm=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Sm=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Mm=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Tm=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Em=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,wm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Am=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Cm=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Rm=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,Pm=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Im=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Lm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Dm=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Nm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Um=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Fm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Om=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Bm=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,km=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,zm=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Hm=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Vm=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Gm=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Wm=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Xm=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$m=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,qm=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ym=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Zm=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jm=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Km=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,jm=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Qm=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tg=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,eg=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ng=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ig=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sg=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,rg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ag=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,og=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,lg=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,cg=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Zt={alphahash_fragment:Pf,alphahash_pars_fragment:If,alphamap_fragment:Lf,alphamap_pars_fragment:Df,alphatest_fragment:Nf,alphatest_pars_fragment:Uf,aomap_fragment:Ff,aomap_pars_fragment:Of,batching_pars_vertex:Bf,batching_vertex:kf,begin_vertex:zf,beginnormal_vertex:Hf,bsdfs:Vf,iridescence_fragment:Gf,bumpmap_pars_fragment:Wf,clipping_planes_fragment:Xf,clipping_planes_pars_fragment:$f,clipping_planes_pars_vertex:qf,clipping_planes_vertex:Yf,color_fragment:Zf,color_pars_fragment:Jf,color_pars_vertex:Kf,color_vertex:jf,common:Qf,cube_uv_reflection_fragment:tp,defaultnormal_vertex:ep,displacementmap_pars_vertex:np,displacementmap_vertex:ip,emissivemap_fragment:sp,emissivemap_pars_fragment:rp,colorspace_fragment:ap,colorspace_pars_fragment:op,envmap_fragment:lp,envmap_common_pars_fragment:cp,envmap_pars_fragment:hp,envmap_pars_vertex:up,envmap_physical_pars_fragment:Sp,envmap_vertex:dp,fog_vertex:fp,fog_pars_vertex:pp,fog_fragment:mp,fog_pars_fragment:gp,gradientmap_pars_fragment:_p,lightmap_pars_fragment:xp,lights_lambert_fragment:yp,lights_lambert_pars_fragment:vp,lights_pars_begin:bp,lights_toon_fragment:Mp,lights_toon_pars_fragment:Tp,lights_phong_fragment:Ep,lights_phong_pars_fragment:wp,lights_physical_fragment:Ap,lights_physical_pars_fragment:Cp,lights_fragment_begin:Rp,lights_fragment_maps:Pp,lights_fragment_end:Ip,lightprobes_pars_fragment:Lp,logdepthbuf_fragment:Dp,logdepthbuf_pars_fragment:Np,logdepthbuf_pars_vertex:Up,logdepthbuf_vertex:Fp,map_fragment:Op,map_pars_fragment:Bp,map_particle_fragment:kp,map_particle_pars_fragment:zp,metalnessmap_fragment:Hp,metalnessmap_pars_fragment:Vp,morphinstance_vertex:Gp,morphcolor_vertex:Wp,morphnormal_vertex:Xp,morphtarget_pars_vertex:$p,morphtarget_vertex:qp,normal_fragment_begin:Yp,normal_fragment_maps:Zp,normal_pars_fragment:Jp,normal_pars_vertex:Kp,normal_vertex:jp,normalmap_pars_fragment:Qp,clearcoat_normal_fragment_begin:tm,clearcoat_normal_fragment_maps:em,clearcoat_pars_fragment:nm,iridescence_pars_fragment:im,opaque_fragment:sm,packing:rm,premultiplied_alpha_fragment:am,project_vertex:om,dithering_fragment:lm,dithering_pars_fragment:cm,roughnessmap_fragment:hm,roughnessmap_pars_fragment:um,shadowmap_pars_fragment:dm,shadowmap_pars_vertex:fm,shadowmap_vertex:pm,shadowmask_pars_fragment:mm,skinbase_vertex:gm,skinning_pars_vertex:_m,skinning_vertex:xm,skinnormal_vertex:ym,specularmap_fragment:vm,specularmap_pars_fragment:bm,tonemapping_fragment:Sm,tonemapping_pars_fragment:Mm,transmission_fragment:Tm,transmission_pars_fragment:Em,uv_pars_fragment:wm,uv_pars_vertex:Am,uv_vertex:Cm,worldpos_vertex:Rm,background_vert:Pm,background_frag:Im,backgroundCube_vert:Lm,backgroundCube_frag:Dm,cube_vert:Nm,cube_frag:Um,depth_vert:Fm,depth_frag:Om,distance_vert:Bm,distance_frag:km,equirect_vert:zm,equirect_frag:Hm,linedashed_vert:Vm,linedashed_frag:Gm,meshbasic_vert:Wm,meshbasic_frag:Xm,meshlambert_vert:$m,meshlambert_frag:qm,meshmatcap_vert:Ym,meshmatcap_frag:Zm,meshnormal_vert:Jm,meshnormal_frag:Km,meshphong_vert:jm,meshphong_frag:Qm,meshphysical_vert:tg,meshphysical_frag:eg,meshtoon_vert:ng,meshtoon_frag:ig,points_vert:sg,points_frag:rg,shadow_vert:ag,shadow_frag:og,sprite_vert:lg,sprite_frag:cg},yt={common:{diffuse:{value:new Xt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Vt},alphaMap:{value:null},alphaMapTransform:{value:new Vt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Vt}},envmap:{envMap:{value:null},envMapRotation:{value:new Vt},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Vt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Vt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Vt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Vt},normalScale:{value:new Dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Vt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Vt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Vt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Vt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Xt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new U},probesMax:{value:new U},probesResolution:{value:new U}},points:{diffuse:{value:new Xt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Vt},alphaTest:{value:0},uvTransform:{value:new Vt}},sprite:{diffuse:{value:new Xt(16777215)},opacity:{value:1},center:{value:new Dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Vt},alphaMap:{value:null},alphaMapTransform:{value:new Vt},alphaTest:{value:0}}},Un={basic:{uniforms:Xe([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.fog]),vertexShader:Zt.meshbasic_vert,fragmentShader:Zt.meshbasic_frag},lambert:{uniforms:Xe([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)},envMapIntensity:{value:1}}]),vertexShader:Zt.meshlambert_vert,fragmentShader:Zt.meshlambert_frag},phong:{uniforms:Xe([yt.common,yt.specularmap,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)},specular:{value:new Xt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Zt.meshphong_vert,fragmentShader:Zt.meshphong_frag},standard:{uniforms:Xe([yt.common,yt.envmap,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.roughnessmap,yt.metalnessmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Zt.meshphysical_vert,fragmentShader:Zt.meshphysical_frag},toon:{uniforms:Xe([yt.common,yt.aomap,yt.lightmap,yt.emissivemap,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.gradientmap,yt.fog,yt.lights,{emissive:{value:new Xt(0)}}]),vertexShader:Zt.meshtoon_vert,fragmentShader:Zt.meshtoon_frag},matcap:{uniforms:Xe([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,yt.fog,{matcap:{value:null}}]),vertexShader:Zt.meshmatcap_vert,fragmentShader:Zt.meshmatcap_frag},points:{uniforms:Xe([yt.points,yt.fog]),vertexShader:Zt.points_vert,fragmentShader:Zt.points_frag},dashed:{uniforms:Xe([yt.common,yt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Zt.linedashed_vert,fragmentShader:Zt.linedashed_frag},depth:{uniforms:Xe([yt.common,yt.displacementmap]),vertexShader:Zt.depth_vert,fragmentShader:Zt.depth_frag},normal:{uniforms:Xe([yt.common,yt.bumpmap,yt.normalmap,yt.displacementmap,{opacity:{value:1}}]),vertexShader:Zt.meshnormal_vert,fragmentShader:Zt.meshnormal_frag},sprite:{uniforms:Xe([yt.sprite,yt.fog]),vertexShader:Zt.sprite_vert,fragmentShader:Zt.sprite_frag},background:{uniforms:{uvTransform:{value:new Vt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Zt.background_vert,fragmentShader:Zt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Vt}},vertexShader:Zt.backgroundCube_vert,fragmentShader:Zt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Zt.cube_vert,fragmentShader:Zt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Zt.equirect_vert,fragmentShader:Zt.equirect_frag},distance:{uniforms:Xe([yt.common,yt.displacementmap,{referencePosition:{value:new U},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Zt.distance_vert,fragmentShader:Zt.distance_frag},shadow:{uniforms:Xe([yt.lights,yt.fog,{color:{value:new Xt(0)},opacity:{value:1}}]),vertexShader:Zt.shadow_vert,fragmentShader:Zt.shadow_frag}};Un.physical={uniforms:Xe([Un.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Vt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Vt},clearcoatNormalScale:{value:new Dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Vt},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Vt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Vt},sheen:{value:0},sheenColor:{value:new Xt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Vt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Vt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Vt},transmissionSamplerSize:{value:new Dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Vt},attenuationDistance:{value:0},attenuationColor:{value:new Xt(0)},specularColor:{value:new Xt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Vt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Vt},anisotropyVector:{value:new Dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Vt}}]),vertexShader:Zt.meshphysical_vert,fragmentShader:Zt.meshphysical_frag};var To={r:0,b:0,g:0},hg=new ye,Ru=new Vt;Ru.set(-1,0,0,0,1,0,0,0,1);function ug(i,t,e,n,s,r){let a=new Xt(0),o=s===!0?0:1,l,c,u=null,f=0,h=null;function p(E){let A=E.isScene===!0?E.background:null;if(A&&A.isTexture){let y=E.backgroundBlurriness>0;A=t.get(A,y)}return A}function _(E){let A=!1,y=p(E);y===null?m(a,o):y&&y.isColor&&(m(y,1),A=!0);let S=i.xr.getEnvironmentBlendMode();S==="additive"?e.buffers.color.setClear(0,0,0,1,r):S==="alpha-blend"&&e.buffers.color.setClear(0,0,0,0,r),(i.autoClear||A)&&(e.buffers.depth.setTest(!0),e.buffers.depth.setMask(!0),e.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function b(E,A){let y=p(A);y&&(y.isCubeTexture||y.mapping===ur)?(c===void 0&&(c=new Me(new ys(1,1,1),new on({name:"BackgroundCubeMaterial",uniforms:Di(Un.backgroundCube.uniforms),vertexShader:Un.backgroundCube.vertexShader,fragmentShader:Un.backgroundCube.fragmentShader,side:Je,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(S,M,C){this.matrixWorld.copyPosition(C.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=A.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(hg.makeRotationFromEuler(A.backgroundRotation)).transpose(),y.isCubeTexture&&y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Ru),c.material.toneMapped=Qt.getTransfer(y.colorSpace)!==oe,(u!==y||f!==y.version||h!==i.toneMapping)&&(c.material.needsUpdate=!0,u=y,f=y.version,h=i.toneMapping),c.layers.enableAll(),E.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new Me(new sr(2,2),new on({name:"BackgroundMaterial",uniforms:Di(Un.background.uniforms),vertexShader:Un.background.vertexShader,fragmentShader:Un.background.fragmentShader,side:pi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,l.material.toneMapped=Qt.getTransfer(y.colorSpace)!==oe,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||f!==y.version||h!==i.toneMapping)&&(l.material.needsUpdate=!0,u=y,f=y.version,h=i.toneMapping),l.layers.enableAll(),E.unshift(l,l.geometry,l.material,0,0,null))}function m(E,A){E.getRGB(To,Zl(i)),e.buffers.color.setClear(To.r,To.g,To.b,A,r)}function d(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return a},setClearColor:function(E,A=1){a.set(E),o=A,m(a,o)},getClearAlpha:function(){return o},setClearAlpha:function(E){o=E,m(a,o)},render:_,addToRenderList:b,dispose:d}}function dg(i,t){let e=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=h(null),r=s,a=!1;function o(F,N,B,R,z){let q=!1,Z=f(F,R,B,N);r!==Z&&(r=Z,c(r.object)),q=p(F,R,B,z),q&&_(F,R,B,z),z!==null&&t.update(z,i.ELEMENT_ARRAY_BUFFER),(q||a)&&(a=!1,y(F,N,B,R),z!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,t.get(z).buffer))}function l(){return i.createVertexArray()}function c(F){return i.bindVertexArray(F)}function u(F){return i.deleteVertexArray(F)}function f(F,N,B,R){let z=R.wireframe===!0,q=n[N.id];q===void 0&&(q={},n[N.id]=q);let Z=F.isInstancedMesh===!0?F.id:0,rt=q[Z];rt===void 0&&(rt={},q[Z]=rt);let $=rt[B.id];$===void 0&&($={},rt[B.id]=$);let K=$[z];return K===void 0&&(K=h(l()),$[z]=K),K}function h(F){let N=[],B=[],R=[];for(let z=0;z<e;z++)N[z]=0,B[z]=0,R[z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:N,enabledAttributes:B,attributeDivisors:R,object:F,attributes:{},index:null}}function p(F,N,B,R){let z=r.attributes,q=N.attributes,Z=0,rt=B.getAttributes();for(let $ in rt)if(rt[$].location>=0){let st=z[$],Tt=q[$];if(Tt===void 0&&($==="instanceMatrix"&&F.instanceMatrix&&(Tt=F.instanceMatrix),$==="instanceColor"&&F.instanceColor&&(Tt=F.instanceColor)),st===void 0||st.attribute!==Tt||Tt&&st.data!==Tt.data)return!0;Z++}return r.attributesNum!==Z||r.index!==R}function _(F,N,B,R){let z={},q=N.attributes,Z=0,rt=B.getAttributes();for(let $ in rt)if(rt[$].location>=0){let st=q[$];st===void 0&&($==="instanceMatrix"&&F.instanceMatrix&&(st=F.instanceMatrix),$==="instanceColor"&&F.instanceColor&&(st=F.instanceColor));let Tt={};Tt.attribute=st,st&&st.data&&(Tt.data=st.data),z[$]=Tt,Z++}r.attributes=z,r.attributesNum=Z,r.index=R}function b(){let F=r.newAttributes;for(let N=0,B=F.length;N<B;N++)F[N]=0}function m(F){d(F,0)}function d(F,N){let B=r.newAttributes,R=r.enabledAttributes,z=r.attributeDivisors;B[F]=1,R[F]===0&&(i.enableVertexAttribArray(F),R[F]=1),z[F]!==N&&(i.vertexAttribDivisor(F,N),z[F]=N)}function E(){let F=r.newAttributes,N=r.enabledAttributes;for(let B=0,R=N.length;B<R;B++)N[B]!==F[B]&&(i.disableVertexAttribArray(B),N[B]=0)}function A(F,N,B,R,z,q,Z){Z===!0?i.vertexAttribIPointer(F,N,B,z,q):i.vertexAttribPointer(F,N,B,R,z,q)}function y(F,N,B,R){b();let z=R.attributes,q=B.getAttributes(),Z=N.defaultAttributeValues;for(let rt in q){let $=q[rt];if($.location>=0){let K=z[rt];if(K===void 0&&(rt==="instanceMatrix"&&F.instanceMatrix&&(K=F.instanceMatrix),rt==="instanceColor"&&F.instanceColor&&(K=F.instanceColor)),K!==void 0){let st=K.normalized,Tt=K.itemSize,ht=t.get(K);if(ht===void 0)continue;let Y=ht.buffer,J=ht.type,nt=ht.bytesPerElement,O=J===i.INT||J===i.UNSIGNED_INT||K.gpuType===Ba;if(K.isInterleavedBufferAttribute){let H=K.data,at=H.stride,ut=K.offset;if(H.isInstancedInterleavedBuffer){for(let ct=0;ct<$.locationSize;ct++)d($.location+ct,H.meshPerAttribute);F.isInstancedMesh!==!0&&R._maxInstanceCount===void 0&&(R._maxInstanceCount=H.meshPerAttribute*H.count)}else for(let ct=0;ct<$.locationSize;ct++)m($.location+ct);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let ct=0;ct<$.locationSize;ct++)A($.location+ct,Tt/$.locationSize,J,st,at*nt,(ut+Tt/$.locationSize*ct)*nt,O)}else{if(K.isInstancedBufferAttribute){for(let H=0;H<$.locationSize;H++)d($.location+H,K.meshPerAttribute);F.isInstancedMesh!==!0&&R._maxInstanceCount===void 0&&(R._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let H=0;H<$.locationSize;H++)m($.location+H);i.bindBuffer(i.ARRAY_BUFFER,Y);for(let H=0;H<$.locationSize;H++)A($.location+H,Tt/$.locationSize,J,st,Tt*nt,Tt/$.locationSize*H*nt,O)}}else if(Z!==void 0){let st=Z[rt];if(st!==void 0)switch(st.length){case 2:i.vertexAttrib2fv($.location,st);break;case 3:i.vertexAttrib3fv($.location,st);break;case 4:i.vertexAttrib4fv($.location,st);break;default:i.vertexAttrib1fv($.location,st)}}}}E()}function S(){T();for(let F in n){let N=n[F];for(let B in N){let R=N[B];for(let z in R){let q=R[z];for(let Z in q)u(q[Z].object),delete q[Z];delete R[z]}}delete n[F]}}function M(F){if(n[F.id]===void 0)return;let N=n[F.id];for(let B in N){let R=N[B];for(let z in R){let q=R[z];for(let Z in q)u(q[Z].object),delete q[Z];delete R[z]}}delete n[F.id]}function C(F){for(let N in n){let B=n[N];for(let R in B){let z=B[R];if(z[F.id]===void 0)continue;let q=z[F.id];for(let Z in q)u(q[Z].object),delete q[Z];delete z[F.id]}}}function x(F){for(let N in n){let B=n[N],R=F.isInstancedMesh===!0?F.id:0,z=B[R];if(z!==void 0){for(let q in z){let Z=z[q];for(let rt in Z)u(Z[rt].object),delete Z[rt];delete z[q]}delete B[R],Object.keys(B).length===0&&delete n[N]}}}function T(){P(),a=!0,r!==s&&(r=s,c(r.object))}function P(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:o,reset:T,resetDefaultState:P,dispose:S,releaseStatesOfGeometry:M,releaseStatesOfObject:x,releaseStatesOfProgram:C,initAttributes:b,enableAttribute:m,disableUnusedAttributes:E}}function fg(i,t,e){let n;function s(l){n=l}function r(l,c){i.drawArrays(n,l,c),e.update(c,n,1)}function a(l,c,u){u!==0&&(i.drawArraysInstanced(n,l,c,u),e.update(c,n,u))}function o(l,c,u){if(u===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,u);let h=0;for(let p=0;p<u;p++)h+=c[p];e.update(h,n,1)}this.setMode=s,this.render=r,this.renderInstances=a,this.renderMultiDraw=o}function pg(i,t,e,n){let s;function r(){if(s!==void 0)return s;if(t.has("EXT_texture_filter_anisotropic")===!0){let C=t.get("EXT_texture_filter_anisotropic");s=i.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function a(C){return!(C!==fn&&n.convert(C)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function o(C){let x=C===wn&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(C!==Qe&&C!==En&&!x&&n.convert(C)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(C){if(C==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=e.precision!==void 0?e.precision:"highp",u=l(c);u!==c&&(Bt("WebGLRenderer:",c,"not supported, using",u,"instead."),c=u);let f=e.logarithmicDepthBuffer===!0,h=e.reversedDepthBuffer===!0&&t.has("EXT_clip_control");e.reversedDepthBuffer===!0&&h===!1&&Bt("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");let p=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),b=i.getParameter(i.MAX_TEXTURE_SIZE),m=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),d=i.getParameter(i.MAX_VERTEX_ATTRIBS),E=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),A=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),S=i.getParameter(i.MAX_SAMPLES),M=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:a,textureTypeReadable:o,precision:c,logarithmicDepthBuffer:f,reversedDepthBuffer:h,maxTextures:p,maxVertexTextures:_,maxTextureSize:b,maxCubemapSize:m,maxAttributes:d,maxVertexUniforms:E,maxVaryings:A,maxFragmentUniforms:y,maxSamples:S,samples:M}}function mg(i){let t=this,e=null,n=0,s=!1,r=!1,a=new rn,o=new Vt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(f,h){let p=f.length!==0||h||n!==0||s;return s=h,n=f.length,p},this.beginShadows=function(){r=!0,u(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(f,h){e=u(f,h,0)},this.setState=function(f,h,p){let _=f.clippingPlanes,b=f.clipIntersection,m=f.clipShadows,d=i.get(f);if(!s||_===null||_.length===0||r&&!m)r?u(null):c();else{let E=r?0:n,A=E*4,y=d.clippingState||null;l.value=y,y=u(_,h,A,p);for(let S=0;S!==A;++S)y[S]=e[S];d.clippingState=y,this.numIntersection=b?this.numPlanes:0,this.numPlanes+=E}};function c(){l.value!==e&&(l.value=e,l.needsUpdate=n>0),t.numPlanes=n,t.numIntersection=0}function u(f,h,p,_){let b=f!==null?f.length:0,m=null;if(b!==0){if(m=l.value,_!==!0||m===null){let d=p+b*4,E=h.matrixWorldInverse;o.getNormalMatrix(E),(m===null||m.length<d)&&(m=new Float32Array(d));for(let A=0,y=p;A!==b;++A,y+=4)a.copy(f[A]).applyMatrix4(E,o),a.normal.toArray(m,y),m[y+3]=a.constant}l.value=m,l.needsUpdate=!0}return t.numPlanes=b,t.numIntersection=0,m}}var Ls=4,gg=6,_g=20,xg=256,yr=new Ts,ou=new Xt,sc=null,rc=0,ac=0,oc=!1,yg=new U,Ni=new U,wo=class{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,e=0,n=.1,s=100,r={}){let{size:a=256,position:o=yg}=r;sc=this._renderer.getRenderTarget(),rc=this._renderer.getActiveCubeFace(),ac=this._renderer.getActiveMipmapLevel(),oc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(t,n,s,l,o),e>0&&this._blur(l,0,0,e),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(t,e=null){return this._fromTexture(t,e)}fromCubemap(t,e=null){return this._fromTexture(t,e)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=hu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=cu(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(sc,rc,ac),this._renderer.xr.enabled=oc,t.scissorTest=!1,Is(t,0,0,t.width,t.height)}_fromTexture(t,e){t.mapping===mi||t.mapping===Li?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),sc=this._renderer.getRenderTarget(),rc=this._renderer.getActiveCubeFace(),ac=this._renderer.getActiveMipmapLevel(),oc=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=e||this._allocateTargets();return this._textureToCubeUV(t,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let t=3*Math.max(this._cubeSize,112),e=4*this._cubeSize,n={magFilter:Fe,minFilter:Fe,generateMipmaps:!1,type:wn,format:fn,colorSpace:$s,depthBuffer:!1},s=lu(t,e,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==e){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=lu(t,e,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=vg(r)),this._blurMaterial=Sg(r,t,e),this._ggxMaterial=bg(r,t,e)}return s}_compileMaterial(t){let e=new Me(new Ze,t);this._renderer.compile(e,yr)}_sceneToCubeUV(t,e,n,s,r){let l=new We(90,1,e,n),c=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],f=this._renderer,h=f.autoClear,p=f.toneMapping;f.getClearColor(ou),f.toneMapping=Mn,f.autoClear=!1,f.state.buffers.depth.getReversed()&&(f.setRenderTarget(s),f.clearDepth(),f.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Me(new ys,new Pi({name:"PMREM.Background",side:Je,depthWrite:!1,depthTest:!1})));let b=this._backgroundBox,m=b.material,d=!1,E=t.background;E?E.isColor&&(m.color.copy(E),t.background=null,d=!0):(m.color.copy(ou),d=!0);for(let A=0;A<6;A++){let y=A%3;y===0?(l.up.set(0,c[A],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+u[A],r.y,r.z)):y===1?(l.up.set(0,0,c[A]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+u[A],r.z)):(l.up.set(0,c[A],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+u[A]));let S=this._cubeSize;Is(s,y*S,A>2?S:0,S,S),f.setRenderTarget(s),d&&f.render(b,l),f.render(t,l)}f.toneMapping=p,f.autoClear=h,t.background=E}_textureToCubeUV(t,e){let n=this._renderer,s=t.mapping===mi||t.mapping===Li;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=hu()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=cu());let r=s?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=r;let o=r.uniforms;o.envMap.value=t;let l=this._cubeSize;Is(e,0,0,3*l,2*l),n.setRenderTarget(e),n.render(a,yr)}_applyPMREM(t){let e=this._renderer,n=e.autoClear;e.autoClear=!1;let s=this._lodMeshes.length;for(let r=1;r<s;r++)this._applyGGXFilter(t,r-1,r);e.autoClear=n}_applyGGXFilter(t,e,n){let s=this._renderer,r=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let l=a.uniforms,c=n/(this._lodMeshes.length-1),u=e/(this._lodMeshes.length-1),f=Math.sqrt(c*c-u*u),h=c*1.25,p=f*h,{_lodMax:_}=this,b=this._sizeLods[n],m=3*b*(n>_-Ls?n-_+Ls:0),d=4*(this._cubeSize-b);l.envMap.value=t.texture,l.roughness.value=p,l.mipInt.value=_-e,Is(r,m,d,3*b,2*b),s.setRenderTarget(r),s.render(o,yr),l.envMap.value=r.texture,l.roughness.value=0,l.mipInt.value=_-n,Is(t,m,d,3*b,2*b),s.setRenderTarget(t),s.render(o,yr)}_blur(t,e,n,s){let r=this._pingPongRenderTarget,a=Math.min(s,Math.PI)/Math.SQRT2;this._blurPass(t,r,e,n,a),this._blurPass(r,t,n,n,a)}_blurPass(t,e,n,s,r){let a=this._renderer,o=this._blurMaterial,l=this._lodMeshes[s];l.material=o;let c=o.uniforms;c.envMap.value=t.texture,c.sigma.value=r,c.mipInt.value=this._lodMax-n;let u=this._sizeLods[s],f=3*u*(s>this._lodMax-Ls?s-this._lodMax+Ls:0),h=4*(this._cubeSize-u);Is(e,f,h,3*u,2*u),a.setRenderTarget(e),a.render(l,yr)}};function vg(i){let t=[],e=[],n=i,s=i-Ls+1+gg;for(let r=0;r<s;r++){let a=Math.pow(2,n);t.push(a);let o=1/(a-2),l=-o,c=1+o,u=[l,l,c,l,c,c,l,l,c,c,l,c],f=6,h=6,p=3,_=new Float32Array(p*h*f),b=new Float32Array(p*h*f);for(let d=0;d<f;d++){let E=d%3*2/3-1,A=d>2?0:-1,y=[E,A,0,E+2/3,A,0,E+2/3,A+1,0,E,A,0,E+2/3,A+1,0,E,A+1,0];_.set(y,p*h*d);for(let S=0;S<h;S++){let M=u[S*2]*2-1,C=u[S*2+1]*2-1;d===0?Ni.set(1,C,M):d===1?Ni.set(-M,1,-C):d===2?Ni.set(-M,C,1):d===3?Ni.set(-1,C,-M):d===4?Ni.set(-M,-1,C):Ni.set(M,C,-1),Ni.toArray(b,(d*h+S)*p)}}let m=new Ze;m.setAttribute("position",new an(_,p)),m.setAttribute("outputDirection",new an(b,p)),e.push(new Me(m,null)),n>Ls&&n--}return{lodMeshes:e,sizeLods:t}}function lu(i,t,e){let n=new je(i,t,e);return n.texture.mapping=ur,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Is(i,t,e,n,s){i.viewport.set(t,e,n,s),i.scissor.set(t,e,n,s)}function bg(i,t,e){return new on({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:xg,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Ro(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function Sg(i,t,e){return new on({name:"SphericalGaussianBlur",defines:{SAMPLES:_g,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/e,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Ro(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function cu(){return new on({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ro(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function hu(){return new on({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ro(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function Ro(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var Ao=class extends je{constructor(t=1,e={}){super(t,t,e),this.isWebGLCubeRenderTarget=!0;let n={width:t,height:t,depth:1},s=[n,n,n,n,n,n];this.texture=new nr(s),this._setTextureOptions(e),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,e){this.texture.type=e.type,this.texture.colorSpace=e.colorSpace,this.texture.generateMipmaps=e.generateMipmaps,this.texture.minFilter=e.minFilter,this.texture.magFilter=e.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new ys(5,5,5),r=new on({name:"CubemapFromEquirect",uniforms:Di(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Je,blending:Dn});r.uniforms.tEquirect.value=e;let a=new Me(s,r),o=e.minFilter;return e.minFilter===gi&&(e.minFilter=Fe),new La(1,10,this).update(t,a),e.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(t,e=!0,n=!0,s=!0){let r=t.getRenderTarget();for(let a=0;a<6;a++)t.setRenderTarget(this,a),t.clear(e,n,s);t.setRenderTarget(r)}};function Mg(i){let t=new WeakMap,e=new WeakMap,n=null;function s(h,p=!1){return h==null?null:p?a(h):r(h)}function r(h){if(h&&h.isTexture){let p=h.mapping;if(p===Ua||p===Fa)if(t.has(h)){let _=t.get(h).texture;return o(_,h.mapping)}else{let _=h.image;if(_&&_.height>0){let b=new Ao(_.height);return b.fromEquirectangularTexture(i,h),t.set(h,b),h.addEventListener("dispose",c),o(b.texture,h.mapping)}else return null}}return h}function a(h){if(h&&h.isTexture){let p=h.mapping,_=p===Ua||p===Fa,b=p===mi||p===Li;if(_||b){let m=e.get(h),d=m!==void 0?m.texture.pmremVersion:0;if(h.isRenderTargetTexture&&h.pmremVersion!==d)return n===null&&(n=new wo(i)),m=_?n.fromEquirectangular(h,m):n.fromCubemap(h,m),m.texture.pmremVersion=h.pmremVersion,e.set(h,m),m.texture;if(m!==void 0)return m.texture;{let E=h.image;return _&&E&&E.height>0||b&&E&&l(E)?(n===null&&(n=new wo(i)),m=_?n.fromEquirectangular(h):n.fromCubemap(h),m.texture.pmremVersion=h.pmremVersion,e.set(h,m),h.addEventListener("dispose",u),m.texture):null}}}return h}function o(h,p){return p===Ua?h.mapping=mi:p===Fa&&(h.mapping=Li),h}function l(h){let p=0,_=6;for(let b=0;b<_;b++)h[b]!==void 0&&p++;return p===_}function c(h){let p=h.target;p.removeEventListener("dispose",c);let _=t.get(p);_!==void 0&&(t.delete(p),_.dispose())}function u(h){let p=h.target;p.removeEventListener("dispose",u);let _=e.get(p);_!==void 0&&(e.delete(p),_.dispose())}function f(){t=new WeakMap,e=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:f}}function Tg(i){let t={};function e(n){if(t[n]!==void 0)return t[n];let s=i.getExtension(n);return t[n]=s,s}return{has:function(n){return e(n)!==null},init:function(){e("EXT_color_buffer_float"),e("WEBGL_clip_cull_distance"),e("OES_texture_float_linear"),e("EXT_color_buffer_half_float"),e("WEBGL_multisampled_render_to_texture"),e("WEBGL_render_shared_exponent")},get:function(n){let s=e(n);return s===null&&Ci("WebGLRenderer: "+n+" extension not supported."),s}}}function Eg(i,t,e,n){let s={},r=new WeakMap;function a(f){let h=f.target;h.index!==null&&t.remove(h.index);for(let _ in h.attributes)t.remove(h.attributes[_]);h.removeEventListener("dispose",a),delete s[h.id];let p=r.get(h);p&&(t.remove(p),r.delete(h)),n.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,e.memory.geometries--}function o(f,h){return s[h.id]===!0||(h.addEventListener("dispose",a),s[h.id]=!0,e.memory.geometries++),h}function l(f){let h=f.attributes;for(let p in h)t.update(h[p],i.ARRAY_BUFFER)}function c(f){let h=[],p=f.index,_=f.attributes.position,b=0;if(_===void 0)return;if(p!==null){let E=p.array;b=p.version;for(let A=0,y=E.length;A<y;A+=3){let S=E[A+0],M=E[A+1],C=E[A+2];h.push(S,M,M,C,C,S)}}else{let E=_.array;b=_.version;for(let A=0,y=E.length/3-1;A<y;A+=3){let S=A+0,M=A+1,C=A+2;h.push(S,M,M,C,C,S)}}let m=new(_.count>=65535?tr:Qs)(h,1);m.version=b;let d=r.get(f);d&&t.remove(d),r.set(f,m)}function u(f){let h=r.get(f);if(h){let p=f.index;p!==null&&h.version<p.version&&c(f)}else c(f);return r.get(f)}return{get:o,update:l,getWireframeAttribute:u}}function wg(i,t,e){let n;function s(f){n=f}let r,a;function o(f){r=f.type,a=f.bytesPerElement}function l(f,h){i.drawElements(n,h,r,f*a),e.update(h,n,1)}function c(f,h,p){p!==0&&(i.drawElementsInstanced(n,h,r,f*a,p),e.update(h,n,p))}function u(f,h,p){if(p===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,h,0,r,f,0,p);let b=0;for(let m=0;m<p;m++)b+=h[m];e.update(b,n,1)}this.setMode=s,this.setIndex=o,this.render=l,this.renderInstances=c,this.renderMultiDraw=u}function Ag(i){let t={geometries:0,textures:0},e={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,a,o){switch(e.calls++,a){case i.TRIANGLES:e.triangles+=o*(r/3);break;case i.LINES:e.lines+=o*(r/2);break;case i.LINE_STRIP:e.lines+=o*(r-1);break;case i.LINE_LOOP:e.lines+=o*r;break;case i.POINTS:e.points+=o*r;break;default:zt("WebGLInfo: Unknown draw mode:",a);break}}function s(){e.calls=0,e.triangles=0,e.points=0,e.lines=0}return{memory:t,render:e,programs:null,autoReset:!0,reset:s,update:n}}function Cg(i,t,e){let n=new WeakMap,s=new be;function r(a,o,l){let c=a.morphTargetInfluences,u=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,f=u!==void 0?u.length:0,h=n.get(o);if(h===void 0||h.count!==f){let T=function(){C.dispose(),n.delete(o),o.removeEventListener("dispose",T)};h!==void 0&&h.texture.dispose();let p=o.morphAttributes.position!==void 0,_=o.morphAttributes.normal!==void 0,b=o.morphAttributes.color!==void 0,m=o.morphAttributes.position||[],d=o.morphAttributes.normal||[],E=o.morphAttributes.color||[],A=0;p===!0&&(A=1),_===!0&&(A=2),b===!0&&(A=3);let y=o.attributes.position.count*A,S=1;y>t.maxTextureSize&&(S=Math.ceil(y/t.maxTextureSize),y=t.maxTextureSize);let M=new Float32Array(y*S*4*f),C=new Js(M,y,S,f);C.type=En,C.needsUpdate=!0;let x=A*4;for(let P=0;P<f;P++){let F=m[P],N=d[P],B=E[P],R=y*S*4*P;for(let z=0;z<F.count;z++){let q=z*x;p===!0&&(s.fromBufferAttribute(F,z),M[R+q+0]=s.x,M[R+q+1]=s.y,M[R+q+2]=s.z,M[R+q+3]=0),_===!0&&(s.fromBufferAttribute(N,z),M[R+q+4]=s.x,M[R+q+5]=s.y,M[R+q+6]=s.z,M[R+q+7]=0),b===!0&&(s.fromBufferAttribute(B,z),M[R+q+8]=s.x,M[R+q+9]=s.y,M[R+q+10]=s.z,M[R+q+11]=B.itemSize===4?s.w:1)}}h={count:f,texture:C,size:new Dt(y,S)},n.set(o,h),o.addEventListener("dispose",T)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",a.morphTexture,e);else{let p=0;for(let b=0;b<c.length;b++)p+=c[b];let _=o.morphTargetsRelative?1:1-p;l.getUniforms().setValue(i,"morphTargetBaseInfluence",_),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",h.texture,e),l.getUniforms().setValue(i,"morphTargetsTextureSize",h.size)}return{update:r}}function Rg(i,t,e,n,s){let r=new WeakMap;function a(c){let u=s.render.frame,f=c.geometry,h=t.get(c,f);if(r.get(h)!==u&&(t.update(h),r.set(h,u)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),r.get(c)!==u&&(e.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&e.update(c.instanceColor,i.ARRAY_BUFFER),r.set(c,u))),c.isSkinnedMesh){let p=c.skeleton;r.get(p)!==u&&(p.update(),r.set(p,u))}return h}function o(){r=new WeakMap}function l(c){let u=c.target;u.removeEventListener("dispose",l),n.releaseStatesOfObject(u),e.remove(u.instanceMatrix),u.instanceColor!==null&&e.remove(u.instanceColor)}return{update:a,dispose:o}}var Pg={[Pl]:"LINEAR_TONE_MAPPING",[Il]:"REINHARD_TONE_MAPPING",[Ll]:"CINEON_TONE_MAPPING",[Dl]:"ACES_FILMIC_TONE_MAPPING",[Ul]:"AGX_TONE_MAPPING",[Fl]:"NEUTRAL_TONE_MAPPING",[Nl]:"CUSTOM_TONE_MAPPING"};function Ig(i,t,e,n,s,r){let a=new je(t,e,{type:i,depthBuffer:s,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),o=null,l=null,c=new Ze;c.setAttribute("position",new ve([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new ve([0,2,0,0,2,0],2));let u=new _a({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),f=new Me(c,u),h=new Ts(-1,1,1,-1,0,1),p=null,_=null,b=!1,m,d=null,E=[],A=!1;this.setSize=function(y,S){a.setSize(y,S),o!==null&&o.setSize(y,S),l!==null&&l.setSize(y,S);for(let M=0;M<E.length;M++){let C=E[M];C.setSize&&C.setSize(y,S)}},this.setEffects=function(y){E=y,A=E.length>0&&E[0].isRenderPass===!0;let S=a.width,M=a.height;E.length>0&&o===null&&(o=new je(S,M,{type:wn,depthBuffer:!1,stencilBuffer:!1}),l=new je(S,M,{type:wn,depthBuffer:!1,stencilBuffer:!1}));for(let C=0;C<E.length;C++){let x=E[C];x.setSize&&x.setSize(S,M)}},this.begin=function(y,S){if(b||y.toneMapping===Mn&&E.length===0)return!1;if(d=S,S!==null){let M=S.width,C=S.height;(a.width!==M||a.height!==C)&&this.setSize(M,C)}return A===!1&&y.setRenderTarget(a),m=y.toneMapping,y.toneMapping=Mn,!0},this.hasRenderPass=function(){return A},this.end=function(y,S){y.toneMapping=m,b=!0;let M=a,C=o;for(let x=0;x<E.length;x++){let T=E[x];T.enabled!==!1&&(T.render(y,C,M,S),T.needsSwap!==!1&&(M=C,C=C===o?l:o))}if(p!==y.outputColorSpace||_!==y.toneMapping){p=y.outputColorSpace,_=y.toneMapping,u.defines={},Qt.getTransfer(p)===oe&&(u.defines.SRGB_TRANSFER="");let x=Pg[_];x&&(u.defines[x]=""),u.needsUpdate=!0}u.uniforms.tDiffuse.value=M.texture,y.setRenderTarget(d),y.render(f,h),d=null,b=!1},this.isCompositing=function(){return b},this.dispose=function(){a.dispose(),o!==null&&o.dispose(),l!==null&&l.dispose(),c.dispose(),u.dispose()}}var Pu=new Ye,hc=new oi(1,1),Iu=new Js,Lu=new fa,Du=new nr,uu=[],du=[],fu=new Float32Array(16),pu=new Float32Array(9),mu=new Float32Array(4);function Ns(i,t,e){let n=i[0];if(n<=0||n>0)return i;let s=t*e,r=uu[s];if(r===void 0&&(r=new Float32Array(s),uu[s]=r),t!==0){n.toArray(r,0);for(let a=1,o=0;a!==t;++a)o+=e,i[a].toArray(r,o)}return r}function Re(i,t){if(i.length!==t.length)return!1;for(let e=0,n=i.length;e<n;e++)if(i[e]!==t[e])return!1;return!0}function Pe(i,t){for(let e=0,n=t.length;e<n;e++)i[e]=t[e]}function Po(i,t){let e=du[t];e===void 0&&(e=new Int32Array(t),du[t]=e);for(let n=0;n!==t;++n)e[n]=i.allocateTextureUnit();return e}function Lg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1f(this.addr,t),e[0]=t)}function Dg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2f(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Re(e,t))return;i.uniform2fv(this.addr,t),Pe(e,t)}}function Ng(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3f(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else if(t.r!==void 0)(e[0]!==t.r||e[1]!==t.g||e[2]!==t.b)&&(i.uniform3f(this.addr,t.r,t.g,t.b),e[0]=t.r,e[1]=t.g,e[2]=t.b);else{if(Re(e,t))return;i.uniform3fv(this.addr,t),Pe(e,t)}}function Ug(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4f(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Re(e,t))return;i.uniform4fv(this.addr,t),Pe(e,t)}}function Fg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Re(e,t))return;i.uniformMatrix2fv(this.addr,!1,t),Pe(e,t)}else{if(Re(e,n))return;mu.set(n),i.uniformMatrix2fv(this.addr,!1,mu),Pe(e,n)}}function Og(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Re(e,t))return;i.uniformMatrix3fv(this.addr,!1,t),Pe(e,t)}else{if(Re(e,n))return;pu.set(n),i.uniformMatrix3fv(this.addr,!1,pu),Pe(e,n)}}function Bg(i,t){let e=this.cache,n=t.elements;if(n===void 0){if(Re(e,t))return;i.uniformMatrix4fv(this.addr,!1,t),Pe(e,t)}else{if(Re(e,n))return;fu.set(n),i.uniformMatrix4fv(this.addr,!1,fu),Pe(e,n)}}function kg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1i(this.addr,t),e[0]=t)}function zg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2i(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Re(e,t))return;i.uniform2iv(this.addr,t),Pe(e,t)}}function Hg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3i(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Re(e,t))return;i.uniform3iv(this.addr,t),Pe(e,t)}}function Vg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4i(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Re(e,t))return;i.uniform4iv(this.addr,t),Pe(e,t)}}function Gg(i,t){let e=this.cache;e[0]!==t&&(i.uniform1ui(this.addr,t),e[0]=t)}function Wg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y)&&(i.uniform2ui(this.addr,t.x,t.y),e[0]=t.x,e[1]=t.y);else{if(Re(e,t))return;i.uniform2uiv(this.addr,t),Pe(e,t)}}function Xg(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z)&&(i.uniform3ui(this.addr,t.x,t.y,t.z),e[0]=t.x,e[1]=t.y,e[2]=t.z);else{if(Re(e,t))return;i.uniform3uiv(this.addr,t),Pe(e,t)}}function $g(i,t){let e=this.cache;if(t.x!==void 0)(e[0]!==t.x||e[1]!==t.y||e[2]!==t.z||e[3]!==t.w)&&(i.uniform4ui(this.addr,t.x,t.y,t.z,t.w),e[0]=t.x,e[1]=t.y,e[2]=t.z,e[3]=t.w);else{if(Re(e,t))return;i.uniform4uiv(this.addr,t),Pe(e,t)}}function qg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(hc.compareFunction=e.isReversedDepthBuffer()?Mo:So,r=hc):r=Pu,e.setTexture2D(t||r,s)}function Yg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture3D(t||Lu,s)}function Zg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTextureCube(t||Du,s)}function Jg(i,t,e){let n=this.cache,s=e.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),e.setTexture2DArray(t||Iu,s)}function Kg(i){switch(i){case 5126:return Lg;case 35664:return Dg;case 35665:return Ng;case 35666:return Ug;case 35674:return Fg;case 35675:return Og;case 35676:return Bg;case 5124:case 35670:return kg;case 35667:case 35671:return zg;case 35668:case 35672:return Hg;case 35669:case 35673:return Vg;case 5125:return Gg;case 36294:return Wg;case 36295:return Xg;case 36296:return $g;case 35678:case 36198:case 36298:case 36306:case 35682:return qg;case 35679:case 36299:case 36307:return Yg;case 35680:case 36300:case 36308:case 36293:return Zg;case 36289:case 36303:case 36311:case 36292:return Jg}}function jg(i,t){i.uniform1fv(this.addr,t)}function Qg(i,t){let e=Ns(t,this.size,2);i.uniform2fv(this.addr,e)}function t0(i,t){let e=Ns(t,this.size,3);i.uniform3fv(this.addr,e)}function e0(i,t){let e=Ns(t,this.size,4);i.uniform4fv(this.addr,e)}function n0(i,t){let e=Ns(t,this.size,4);i.uniformMatrix2fv(this.addr,!1,e)}function i0(i,t){let e=Ns(t,this.size,9);i.uniformMatrix3fv(this.addr,!1,e)}function s0(i,t){let e=Ns(t,this.size,16);i.uniformMatrix4fv(this.addr,!1,e)}function r0(i,t){i.uniform1iv(this.addr,t)}function a0(i,t){i.uniform2iv(this.addr,t)}function o0(i,t){i.uniform3iv(this.addr,t)}function l0(i,t){i.uniform4iv(this.addr,t)}function c0(i,t){i.uniform1uiv(this.addr,t)}function h0(i,t){i.uniform2uiv(this.addr,t)}function u0(i,t){i.uniform3uiv(this.addr,t)}function d0(i,t){i.uniform4uiv(this.addr,t)}function f0(i,t,e){let n=this.cache,s=t.length,r=Po(e,s);Re(n,r)||(i.uniform1iv(this.addr,r),Pe(n,r));let a;this.type===i.SAMPLER_2D_SHADOW?a=hc:a=Pu;for(let o=0;o!==s;++o)e.setTexture2D(t[o]||a,r[o])}function p0(i,t,e){let n=this.cache,s=t.length,r=Po(e,s);Re(n,r)||(i.uniform1iv(this.addr,r),Pe(n,r));for(let a=0;a!==s;++a)e.setTexture3D(t[a]||Lu,r[a])}function m0(i,t,e){let n=this.cache,s=t.length,r=Po(e,s);Re(n,r)||(i.uniform1iv(this.addr,r),Pe(n,r));for(let a=0;a!==s;++a)e.setTextureCube(t[a]||Du,r[a])}function g0(i,t,e){let n=this.cache,s=t.length,r=Po(e,s);Re(n,r)||(i.uniform1iv(this.addr,r),Pe(n,r));for(let a=0;a!==s;++a)e.setTexture2DArray(t[a]||Iu,r[a])}function _0(i){switch(i){case 5126:return jg;case 35664:return Qg;case 35665:return t0;case 35666:return e0;case 35674:return n0;case 35675:return i0;case 35676:return s0;case 5124:case 35670:return r0;case 35667:case 35671:return a0;case 35668:case 35672:return o0;case 35669:case 35673:return l0;case 5125:return c0;case 36294:return h0;case 36295:return u0;case 36296:return d0;case 35678:case 36198:case 36298:case 36306:case 35682:return f0;case 35679:case 36299:case 36307:return p0;case 35680:case 36300:case 36308:case 36293:return m0;case 36289:case 36303:case 36311:case 36292:return g0}}var uc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.setValue=Kg(e.type)}},dc=class{constructor(t,e,n){this.id=t,this.addr=n,this.cache=[],this.type=e.type,this.size=e.size,this.setValue=_0(e.type)}},fc=class{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,e,n){let s=this.seq;for(let r=0,a=s.length;r!==a;++r){let o=s[r];o.setValue(t,e[o.id],n)}}},lc=/(\w+)(\])?(\[|\.)?/g;function gu(i,t){i.seq.push(t),i.map[t.id]=t}function x0(i,t,e){let n=i.name,s=n.length;for(lc.lastIndex=0;;){let r=lc.exec(n),a=lc.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===s){gu(e,c===void 0?new uc(o,i,t):new dc(o,i,t));break}else{let f=e.map[o];f===void 0&&(f=new fc(o),gu(e,f)),e=f}}}var Ds=class{constructor(t,e){this.seq=[],this.map={};let n=t.getProgramParameter(e,t.ACTIVE_UNIFORMS);for(let a=0;a<n;++a){let o=t.getActiveUniform(e,a),l=t.getUniformLocation(e,o.name);x0(o,l,this)}let s=[],r=[];for(let a of this.seq)a.type===t.SAMPLER_2D_SHADOW||a.type===t.SAMPLER_CUBE_SHADOW||a.type===t.SAMPLER_2D_ARRAY_SHADOW?s.push(a):r.push(a);s.length>0&&(this.seq=s.concat(r))}setValue(t,e,n,s){let r=this.map[e];r!==void 0&&r.setValue(t,n,s)}setOptional(t,e,n){let s=e[n];s!==void 0&&this.setValue(t,n,s)}static upload(t,e,n,s){for(let r=0,a=e.length;r!==a;++r){let o=e[r],l=n[o.id];l.needsUpdate!==!1&&o.setValue(t,l.value,s)}}static seqWithValue(t,e){let n=[];for(let s=0,r=t.length;s!==r;++s){let a=t[s];a.id in e&&n.push(a)}return n}};function _u(i,t,e){let n=i.createShader(t);return i.shaderSource(n,e),i.compileShader(n),n}var y0=37297,v0=0;function b0(i,t){let e=i.split(`
`),n=[],s=Math.max(t-6,0),r=Math.min(t+6,e.length);for(let a=s;a<r;a++){let o=a+1;n.push(`${o===t?">":" "} ${o}: ${e[a]}`)}return n.join(`
`)}var xu=new Vt;function S0(i){Qt._getMatrix(xu,Qt.workingColorSpace,i);let t=`mat3( ${xu.elements.map(e=>e.toFixed(4))} )`;switch(Qt.getTransfer(i)){case qs:return[t,"LinearTransferOETF"];case oe:return[t,"sRGBTransferOETF"];default:return Bt("WebGLProgram: Unsupported color space: ",i),[t,"LinearTransferOETF"]}}function yu(i,t,e){let n=i.getShaderParameter(t,i.COMPILE_STATUS),r=(i.getShaderInfoLog(t)||"").trim();if(n&&r==="")return"";let a=/ERROR: 0:(\d+)/.exec(r);if(a){let o=parseInt(a[1]);return e.toUpperCase()+`

`+r+`

`+b0(i.getShaderSource(t),o)}else return r}function M0(i,t){let e=S0(t);return[`vec4 ${i}( vec4 value ) {`,`	return ${e[1]}( vec4( value.rgb * ${e[0]}, value.a ) );`,"}"].join(`
`)}var T0={[Pl]:"Linear",[Il]:"Reinhard",[Ll]:"Cineon",[Dl]:"ACESFilmic",[Ul]:"AgX",[Fl]:"Neutral",[Nl]:"Custom"};function E0(i,t){let e=T0[t];return e===void 0?(Bt("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+e+"ToneMapping( color ); }"}var Eo=new U;function w0(){Qt.getLuminanceCoefficients(Eo);let i=Eo.x.toFixed(4),t=Eo.y.toFixed(4),e=Eo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${t}, ${e} );`,"	return dot( weights, rgb );","}"].join(`
`)}function A0(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(br).join(`
`)}function C0(i){let t=[];for(let e in i){let n=i[e];n!==!1&&t.push("#define "+e+" "+n)}return t.join(`
`)}function R0(i,t){let e={},n=i.getProgramParameter(t,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(t,s),a=r.name,o=1;r.type===i.FLOAT_MAT2&&(o=2),r.type===i.FLOAT_MAT3&&(o=3),r.type===i.FLOAT_MAT4&&(o=4),e[a]={type:r.type,location:i.getAttribLocation(t,a),locationSize:o}}return e}function br(i){return i!==""}function vu(i,t){let e=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,e).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function bu(i,t){return i.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var P0=/^[ \t]*#include +<([\w\d./]+)>/gm;function pc(i){return i.replace(P0,L0)}var I0=new Map;function L0(i,t){let e=Zt[t];if(e===void 0){let n=I0.get(t);if(n!==void 0)e=Zt[n],Bt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,n);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+t+">")}return pc(e)}var D0=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Su(i){return i.replace(D0,N0)}function N0(i,t,e,n){let s="";for(let r=parseInt(t);r<parseInt(e);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function Mu(i){let t=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?t+=`
#define HIGH_PRECISION`:i.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}var U0={[hr]:"SHADOWMAP_TYPE_PCF",[As]:"SHADOWMAP_TYPE_VSM"};function F0(i){return U0[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}var O0={[mi]:"ENVMAP_TYPE_CUBE",[Li]:"ENVMAP_TYPE_CUBE",[ur]:"ENVMAP_TYPE_CUBE_UV"};function B0(i){return i.envMap===!1?"ENVMAP_TYPE_CUBE":O0[i.envMapMode]||"ENVMAP_TYPE_CUBE"}var k0={[Li]:"ENVMAP_MODE_REFRACTION"};function z0(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":k0[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}var H0={[Rl]:"ENVMAP_BLENDING_MULTIPLY",[zh]:"ENVMAP_BLENDING_MIX",[Hh]:"ENVMAP_BLENDING_ADD"};function V0(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":H0[i.combine]||"ENVMAP_BLENDING_NONE"}function G0(i){let t=i.envMapCubeUVHeight;if(t===null)return null;let e=Math.log2(t)-2,n=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,e),112)),texelHeight:n,maxMip:e}}function W0(i,t,e,n){let s=i.getContext(),r=e.defines,a=e.vertexShader,o=e.fragmentShader,l=F0(e),c=B0(e),u=z0(e),f=V0(e),h=G0(e),p=A0(e),_=C0(r),b=s.createProgram(),m,d,E=e.glslVersion?"#version "+e.glslVersion+`
`:"";e.isRawShaderMaterial?(m=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_].filter(br).join(`
`),m.length>0&&(m+=`
`),d=["#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_].filter(br).join(`
`),d.length>0&&(d+=`
`)):(m=[Mu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_,e.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",e.batching?"#define USE_BATCHING":"",e.batchingColor?"#define USE_BATCHING_COLOR":"",e.instancing?"#define USE_INSTANCING":"",e.instancingColor?"#define USE_INSTANCING_COLOR":"",e.instancingMorph?"#define USE_INSTANCING_MORPH":"",e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.map?"#define USE_MAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+u:"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.displacementMap?"#define USE_DISPLACEMENTMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.mapUv?"#define MAP_UV "+e.mapUv:"",e.alphaMapUv?"#define ALPHAMAP_UV "+e.alphaMapUv:"",e.lightMapUv?"#define LIGHTMAP_UV "+e.lightMapUv:"",e.aoMapUv?"#define AOMAP_UV "+e.aoMapUv:"",e.emissiveMapUv?"#define EMISSIVEMAP_UV "+e.emissiveMapUv:"",e.bumpMapUv?"#define BUMPMAP_UV "+e.bumpMapUv:"",e.normalMapUv?"#define NORMALMAP_UV "+e.normalMapUv:"",e.displacementMapUv?"#define DISPLACEMENTMAP_UV "+e.displacementMapUv:"",e.metalnessMapUv?"#define METALNESSMAP_UV "+e.metalnessMapUv:"",e.roughnessMapUv?"#define ROUGHNESSMAP_UV "+e.roughnessMapUv:"",e.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+e.anisotropyMapUv:"",e.clearcoatMapUv?"#define CLEARCOATMAP_UV "+e.clearcoatMapUv:"",e.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+e.clearcoatNormalMapUv:"",e.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+e.clearcoatRoughnessMapUv:"",e.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+e.iridescenceMapUv:"",e.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+e.iridescenceThicknessMapUv:"",e.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+e.sheenColorMapUv:"",e.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+e.sheenRoughnessMapUv:"",e.specularMapUv?"#define SPECULARMAP_UV "+e.specularMapUv:"",e.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+e.specularColorMapUv:"",e.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+e.specularIntensityMapUv:"",e.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+e.transmissionMapUv:"",e.thicknessMapUv?"#define THICKNESSMAP_UV "+e.thicknessMapUv:"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexNormals?"#define HAS_NORMAL":"",e.vertexColors?"#define USE_COLOR":"",e.vertexAlphas?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.flatShading?"#define FLAT_SHADED":"",e.skinning?"#define USE_SKINNING":"",e.morphTargets?"#define USE_MORPHTARGETS":"",e.morphNormals&&e.flatShading===!1?"#define USE_MORPHNORMALS":"",e.morphColors?"#define USE_MORPHCOLORS":"",e.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+e.morphTextureStride:"",e.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+e.morphTargetsCount:"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.sizeAttenuation?"#define USE_SIZEATTENUATION":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(br).join(`
`),d=[Mu(e),"#define SHADER_TYPE "+e.shaderType,"#define SHADER_NAME "+e.shaderName,_,e.useFog&&e.fog?"#define USE_FOG":"",e.useFog&&e.fogExp2?"#define FOG_EXP2":"",e.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",e.map?"#define USE_MAP":"",e.matcap?"#define USE_MATCAP":"",e.envMap?"#define USE_ENVMAP":"",e.envMap?"#define "+c:"",e.envMap?"#define "+u:"",e.envMap?"#define "+f:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",e.lightMap?"#define USE_LIGHTMAP":"",e.aoMap?"#define USE_AOMAP":"",e.bumpMap?"#define USE_BUMPMAP":"",e.normalMap?"#define USE_NORMALMAP":"",e.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",e.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",e.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",e.emissiveMap?"#define USE_EMISSIVEMAP":"",e.anisotropy?"#define USE_ANISOTROPY":"",e.anisotropyMap?"#define USE_ANISOTROPYMAP":"",e.clearcoat?"#define USE_CLEARCOAT":"",e.clearcoatMap?"#define USE_CLEARCOATMAP":"",e.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",e.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",e.dispersion?"#define USE_DISPERSION":"",e.retroreflection?"#define USE_RETROREFLECTION":"",e.iridescence?"#define USE_IRIDESCENCE":"",e.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",e.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",e.specularMap?"#define USE_SPECULARMAP":"",e.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",e.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",e.roughnessMap?"#define USE_ROUGHNESSMAP":"",e.metalnessMap?"#define USE_METALNESSMAP":"",e.alphaMap?"#define USE_ALPHAMAP":"",e.alphaTest?"#define USE_ALPHATEST":"",e.alphaHash?"#define USE_ALPHAHASH":"",e.sheen?"#define USE_SHEEN":"",e.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",e.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",e.transmission?"#define USE_TRANSMISSION":"",e.transmissionMap?"#define USE_TRANSMISSIONMAP":"",e.thicknessMap?"#define USE_THICKNESSMAP":"",e.vertexTangents&&e.flatShading===!1?"#define USE_TANGENT":"",e.vertexColors||e.instancingColor?"#define USE_COLOR":"",e.vertexAlphas||e.batchingColor?"#define USE_COLOR_ALPHA":"",e.vertexUv1s?"#define USE_UV1":"",e.vertexUv2s?"#define USE_UV2":"",e.vertexUv3s?"#define USE_UV3":"",e.pointsUvs?"#define USE_POINTS_UV":"",e.gradientMap?"#define USE_GRADIENTMAP":"",e.flatShading?"#define FLAT_SHADED":"",e.doubleSided?"#define DOUBLE_SIDED":"",e.flipSided?"#define FLIP_SIDED":"",e.shadowMapEnabled?"#define USE_SHADOWMAP":"",e.shadowMapEnabled?"#define "+l:"",e.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",e.numLightProbes>0?"#define USE_LIGHT_PROBES":"",e.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",e.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",e.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",e.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",e.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",e.toneMapping!==Mn?"#define TONE_MAPPING":"",e.toneMapping!==Mn?Zt.tonemapping_pars_fragment:"",e.toneMapping!==Mn?E0("toneMapping",e.toneMapping):"",e.dithering?"#define DITHERING":"",e.opaque?"#define OPAQUE":"",Zt.colorspace_pars_fragment,M0("linearToOutputTexel",e.outputColorSpace),w0(),e.useDepthPacking?"#define DEPTH_PACKING "+e.depthPacking:"",`
`].filter(br).join(`
`)),a=pc(a),a=vu(a,e),a=bu(a,e),o=pc(o),o=vu(o,e),o=bu(o,e),a=Su(a),o=Su(o),e.isRawShaderMaterial!==!0&&(E=`#version 300 es
`,m=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,d=["#define varying in",e.glslVersion===$l?"":"layout(location = 0) out highp vec4 pc_fragColor;",e.glslVersion===$l?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+d);let A=E+m+a,y=E+d+o,S=_u(s,s.VERTEX_SHADER,A),M=_u(s,s.FRAGMENT_SHADER,y);s.attachShader(b,S),s.attachShader(b,M),e.index0AttributeName!==void 0?s.bindAttribLocation(b,0,e.index0AttributeName):e.hasPositionAttribute===!0&&s.bindAttribLocation(b,0,"position"),s.linkProgram(b);function C(F){if(i.debug.checkShaderErrors){let N=s.getProgramInfoLog(b)||"",B=s.getShaderInfoLog(S)||"",R=s.getShaderInfoLog(M)||"",z=N.trim(),q=B.trim(),Z=R.trim(),rt=!0,$=!0;if(s.getProgramParameter(b,s.LINK_STATUS)===!1)if(rt=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,b,S,M);else{let K=yu(s,S,"vertex"),st=yu(s,M,"fragment");zt("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(b,s.VALIDATE_STATUS)+`

Material Name: `+F.name+`
Material Type: `+F.type+`

Program Info Log: `+z+`
`+K+`
`+st)}else z!==""?Bt("WebGLProgram: Program Info Log:",z):(q===""||Z==="")&&($=!1);$&&(F.diagnostics={runnable:rt,programLog:z,vertexShader:{log:q,prefix:m},fragmentShader:{log:Z,prefix:d}})}s.deleteShader(S),s.deleteShader(M),x=new Ds(s,b),T=R0(s,b)}let x;this.getUniforms=function(){return x===void 0&&C(this),x};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let P=e.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return P===!1&&(P=s.getProgramParameter(b,y0)),P},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(b),this.program=void 0},this.type=e.shaderType,this.name=e.shaderName,this.id=v0++,this.cacheKey=t,this.usedTimes=1,this.program=b,this.vertexShader=S,this.fragmentShader=M,this}var X0=0,mc=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t,e,n){let s=this._getShaderCacheForMaterial(t);return s.has(e)===!1&&(s.add(e),e.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(t){let e=this.materialCache.get(t);for(let n of e)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(t),this}getVertexShaderStage(t){return this._getShaderStage(t.vertexShader)}getFragmentShaderStage(t){return this._getShaderStage(t.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){let e=this.materialCache,n=e.get(t);return n===void 0&&(n=new Set,e.set(t,n)),n}_getShaderStage(t){let e=this.shaderCache,n=e.get(t);return n===void 0&&(n=new gc(t),e.set(t,n)),n}},gc=class{constructor(t){this.id=X0++,this.code=t,this.usedTimes=0}};function $0(i){return i===xi||i===_r||i===xr}function q0(i,t,e,n,s,r){let a=new Ks,o=new mc,l=new Set,c=[],u=new Map,f=n.logarithmicDepthBuffer,h=n.precision,p={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(x){return l.add(x),x===0?"uv":`uv${x}`}function b(x,T,P,F,N,B){let R=F.fog,z=N.geometry,q=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?F.environment:null,Z=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,rt=t.get(x.envMap||q,Z),$=rt&&rt.mapping===ur?rt.image.height:null,K=p[x.type];x.precision!==null&&(h=n.getMaxPrecision(x.precision),h!==x.precision&&Bt("WebGLProgram.getParameters:",x.precision,"not supported, using",h,"instead."));let st=z.morphAttributes.position||z.morphAttributes.normal||z.morphAttributes.color,Tt=st!==void 0?st.length:0,ht=0;z.morphAttributes.position!==void 0&&(ht=1),z.morphAttributes.normal!==void 0&&(ht=2),z.morphAttributes.color!==void 0&&(ht=3);let Y,J,nt,O;if(K){let fe=Un[K];Y=fe.vertexShader,J=fe.fragmentShader}else{Y=x.vertexShader,J=x.fragmentShader;let fe=o.getVertexShaderStage(x),re=o.getFragmentShaderStage(x);o.update(x,fe,re),nt=fe.id,O=re.id}let H=i.getRenderTarget(),at=i.state.buffers.depth.getReversed(),ut=N.isInstancedMesh===!0,ct=N.isBatchedMesh===!0,bt=!!x.map,Lt=!!x.matcap,At=!!rt,kt=!!x.aoMap,ee=!!x.lightMap,Gt=!!x.bumpMap&&x.wireframe===!1,he=!!x.normalMap,Ht=!!x.displacementMap,$t=!!x.emissiveMap,qt=!!x.metalnessMap,ne=!!x.roughnessMap,L=x.anisotropy>0,jt=x.clearcoat>0,ie=x.dispersion>0,w=x.retroreflectivity>0,g=x.iridescence>0,k=x.sheen>0,W=x.transmission>0,j=L&&!!x.anisotropyMap,dt=jt&&!!x.clearcoatMap,ft=jt&&!!x.clearcoatNormalMap,Q=jt&&!!x.clearcoatRoughnessMap,it=g&&!!x.iridescenceMap,pt=g&&!!x.iridescenceThicknessMap,Nt=k&&!!x.sheenColorMap,xt=k&&!!x.sheenRoughnessMap,mt=!!x.specularMap,Ut=!!x.specularColorMap,Ot=!!x.specularIntensityMap,Wt=W&&!!x.transmissionMap,D=W&&!!x.thicknessMap,gt=!!x.gradientMap,et=!!x.alphaMap,_t=x.alphaTest>0,Mt=!!x.alphaHash,lt=!!x.extensions,Ft=Mn;x.toneMapped&&(H===null||H.isXRRenderTarget===!0)&&(Ft=i.toneMapping);let Pt={shaderID:K,shaderType:x.type,shaderName:x.name,vertexShader:Y,fragmentShader:J,defines:x.defines,customVertexShaderID:nt,customFragmentShaderID:O,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:h,batching:ct,batchingColor:ct&&N._colorsTexture!==null,instancing:ut,instancingColor:ut&&N.instanceColor!==null,instancingMorph:ut&&N.morphTexture!==null,outputColorSpace:H===null?i.outputColorSpace:H.isXRRenderTarget===!0?H.texture.colorSpace:Qt.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:bt,matcap:Lt,envMap:At,envMapMode:At&&rt.mapping,envMapCubeUVHeight:$,aoMap:kt,lightMap:ee,bumpMap:Gt,normalMap:he,displacementMap:Ht,emissiveMap:$t,normalMapObjectSpace:he&&x.normalMapType===Wh,normalMapTangentSpace:he&&x.normalMapType===bo,packedNormalMap:he&&x.normalMapType===bo&&$0(x.normalMap.format),metalnessMap:qt,roughnessMap:ne,anisotropy:L,anisotropyMap:j,clearcoat:jt,clearcoatMap:dt,clearcoatNormalMap:ft,clearcoatRoughnessMap:Q,dispersion:ie,retroreflection:w,iridescence:g,iridescenceMap:it,iridescenceThicknessMap:pt,sheen:k,sheenColorMap:Nt,sheenRoughnessMap:xt,specularMap:mt,specularColorMap:Ut,specularIntensityMap:Ot,transmission:W,transmissionMap:Wt,thicknessMap:D,gradientMap:gt,opaque:x.transparent===!1&&x.blending===Cs&&x.alphaToCoverage===!1,alphaMap:et,alphaTest:_t,alphaHash:Mt,combine:x.combine,mapUv:bt&&_(x.map.channel),aoMapUv:kt&&_(x.aoMap.channel),lightMapUv:ee&&_(x.lightMap.channel),bumpMapUv:Gt&&_(x.bumpMap.channel),normalMapUv:he&&_(x.normalMap.channel),displacementMapUv:Ht&&_(x.displacementMap.channel),emissiveMapUv:$t&&_(x.emissiveMap.channel),metalnessMapUv:qt&&_(x.metalnessMap.channel),roughnessMapUv:ne&&_(x.roughnessMap.channel),anisotropyMapUv:j&&_(x.anisotropyMap.channel),clearcoatMapUv:dt&&_(x.clearcoatMap.channel),clearcoatNormalMapUv:ft&&_(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Q&&_(x.clearcoatRoughnessMap.channel),iridescenceMapUv:it&&_(x.iridescenceMap.channel),iridescenceThicknessMapUv:pt&&_(x.iridescenceThicknessMap.channel),sheenColorMapUv:Nt&&_(x.sheenColorMap.channel),sheenRoughnessMapUv:xt&&_(x.sheenRoughnessMap.channel),specularMapUv:mt&&_(x.specularMap.channel),specularColorMapUv:Ut&&_(x.specularColorMap.channel),specularIntensityMapUv:Ot&&_(x.specularIntensityMap.channel),transmissionMapUv:Wt&&_(x.transmissionMap.channel),thicknessMapUv:D&&_(x.thicknessMap.channel),alphaMapUv:et&&_(x.alphaMap.channel),vertexTangents:!!z.attributes.tangent&&(he||L),vertexNormals:!!z.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!z.attributes.color&&z.attributes.color.itemSize===4,pointsUvs:N.isPoints===!0&&!!z.attributes.uv&&(bt||et),fog:!!R,useFog:x.fog===!0,fogExp2:!!R&&R.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||z.attributes.normal===void 0&&he===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:f,reversedDepthBuffer:at,skinning:N.isSkinnedMesh===!0,hasPositionAttribute:z.attributes.position!==void 0,morphTargets:z.morphAttributes.position!==void 0,morphNormals:z.morphAttributes.normal!==void 0,morphColors:z.morphAttributes.color!==void 0,morphTargetsCount:Tt,morphTextureStride:ht,numSunLights:T.sun.length,numDirLights:T.directional.length,numPointLights:T.point.length,numSpotLights:T.spot.length,numSpotLightMaps:T.spotLightMap.length,numRectAreaLights:T.rectArea.length,numHemiLights:T.hemi.length,numSunLightShadows:T.sunShadowMap.length,numDirLightShadows:T.directionalShadowMap.length,numPointLightShadows:T.pointShadowMap.length,numSpotLightShadows:T.spotShadowMap.length,numSpotLightShadowsWithMaps:T.numSpotLightShadowsWithMaps,numLightProbes:T.numLightProbes,numLightProbeGrids:B.length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:x.dithering,shadowMapEnabled:i.shadowMap.enabled&&P.length>0,shadowMapType:i.shadowMap.type,toneMapping:Ft,decodeVideoTexture:bt&&x.map.isVideoTexture===!0&&Qt.getTransfer(x.map.colorSpace)===oe,decodeVideoTextureEmissive:$t&&x.emissiveMap.isVideoTexture===!0&&Qt.getTransfer(x.emissiveMap.colorSpace)===oe,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===Ke,flipSided:x.side===Je,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:lt&&x.extensions.clipCullDistance===!0&&e.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(lt&&x.extensions.multiDraw===!0||ct)&&e.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:e.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Pt.vertexUv1s=l.has(1),Pt.vertexUv2s=l.has(2),Pt.vertexUv3s=l.has(3),l.clear(),Pt}function m(x){let T=[];if(x.shaderID?T.push(x.shaderID):(T.push(x.customVertexShaderID),T.push(x.customFragmentShaderID)),x.defines!==void 0)for(let P in x.defines)T.push(P),T.push(x.defines[P]);return x.isRawShaderMaterial===!1&&(d(T,x),E(T,x),T.push(i.outputColorSpace)),T.push(x.customProgramCacheKey),T.join()}function d(x,T){x.push(T.precision),x.push(T.outputColorSpace),x.push(T.envMapMode),x.push(T.envMapCubeUVHeight),x.push(T.mapUv),x.push(T.alphaMapUv),x.push(T.lightMapUv),x.push(T.aoMapUv),x.push(T.bumpMapUv),x.push(T.normalMapUv),x.push(T.displacementMapUv),x.push(T.emissiveMapUv),x.push(T.metalnessMapUv),x.push(T.roughnessMapUv),x.push(T.anisotropyMapUv),x.push(T.clearcoatMapUv),x.push(T.clearcoatNormalMapUv),x.push(T.clearcoatRoughnessMapUv),x.push(T.iridescenceMapUv),x.push(T.iridescenceThicknessMapUv),x.push(T.sheenColorMapUv),x.push(T.sheenRoughnessMapUv),x.push(T.specularMapUv),x.push(T.specularColorMapUv),x.push(T.specularIntensityMapUv),x.push(T.transmissionMapUv),x.push(T.thicknessMapUv),x.push(T.combine),x.push(T.fogExp2),x.push(T.sizeAttenuation),x.push(T.morphTargetsCount),x.push(T.morphAttributeCount),x.push(T.numSunLights),x.push(T.numDirLights),x.push(T.numPointLights),x.push(T.numSpotLights),x.push(T.numSpotLightMaps),x.push(T.numHemiLights),x.push(T.numRectAreaLights),x.push(T.numSunLightShadows),x.push(T.numDirLightShadows),x.push(T.numPointLightShadows),x.push(T.numSpotLightShadows),x.push(T.numSpotLightShadowsWithMaps),x.push(T.numLightProbes),x.push(T.shadowMapType),x.push(T.toneMapping),x.push(T.numClippingPlanes),x.push(T.numClipIntersection),x.push(T.depthPacking)}function E(x,T){a.disableAll(),T.instancing&&a.enable(0),T.instancingColor&&a.enable(1),T.instancingMorph&&a.enable(2),T.matcap&&a.enable(3),T.envMap&&a.enable(4),T.normalMapObjectSpace&&a.enable(5),T.normalMapTangentSpace&&a.enable(6),T.clearcoat&&a.enable(7),T.iridescence&&a.enable(8),T.alphaTest&&a.enable(9),T.vertexColors&&a.enable(10),T.vertexAlphas&&a.enable(11),T.vertexUv1s&&a.enable(12),T.vertexUv2s&&a.enable(13),T.vertexUv3s&&a.enable(14),T.vertexTangents&&a.enable(15),T.anisotropy&&a.enable(16),T.alphaHash&&a.enable(17),T.batching&&a.enable(18),T.dispersion&&a.enable(19),T.retroreflection&&a.enable(24),T.batchingColor&&a.enable(20),T.gradientMap&&a.enable(21),T.packedNormalMap&&a.enable(22),T.vertexNormals&&a.enable(23),x.push(a.mask),a.disableAll(),T.fog&&a.enable(0),T.useFog&&a.enable(1),T.flatShading&&a.enable(2),T.logarithmicDepthBuffer&&a.enable(3),T.reversedDepthBuffer&&a.enable(4),T.skinning&&a.enable(5),T.morphTargets&&a.enable(6),T.morphNormals&&a.enable(7),T.morphColors&&a.enable(8),T.premultipliedAlpha&&a.enable(9),T.shadowMapEnabled&&a.enable(10),T.doubleSided&&a.enable(11),T.flipSided&&a.enable(12),T.useDepthPacking&&a.enable(13),T.dithering&&a.enable(14),T.transmission&&a.enable(15),T.sheen&&a.enable(16),T.opaque&&a.enable(17),T.pointsUvs&&a.enable(18),T.decodeVideoTexture&&a.enable(19),T.decodeVideoTextureEmissive&&a.enable(20),T.alphaToCoverage&&a.enable(21),T.numLightProbeGrids>0&&a.enable(22),T.hasPositionAttribute&&a.enable(23),x.push(a.mask)}function A(x){let T=p[x.type],P;if(T){let F=Un[T];P=su.clone(F.uniforms)}else P=x.uniforms;return P}function y(x,T){let P=u.get(T);return P!==void 0?++P.usedTimes:(P=new W0(i,T,x,s),c.push(P),u.set(T,P)),P}function S(x){if(--x.usedTimes===0){let T=c.indexOf(x);c[T]=c[c.length-1],c.pop(),u.delete(x.cacheKey),x.destroy()}}function M(x){o.remove(x)}function C(){o.dispose()}return{getParameters:b,getProgramCacheKey:m,getUniforms:A,acquireProgram:y,releaseProgram:S,releaseShaderCache:M,programs:c,dispose:C}}function Y0(){let i=new WeakMap;function t(a){return i.has(a)}function e(a){let o=i.get(a);return o===void 0&&(o={},i.set(a,o)),o}function n(a){i.delete(a)}function s(a,o,l){i.get(a)[o]=l}function r(){i=new WeakMap}return{has:t,get:e,remove:n,update:s,dispose:r}}function Z0(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.material.id!==t.material.id?i.material.id-t.material.id:i.materialVariant!==t.materialVariant?i.materialVariant-t.materialVariant:i.z!==t.z?i.z-t.z:i.id-t.id}function Tu(i,t){return i.groupOrder!==t.groupOrder?i.groupOrder-t.groupOrder:i.renderOrder!==t.renderOrder?i.renderOrder-t.renderOrder:i.z!==t.z?t.z-i.z:i.id-t.id}function Eu(){let i=[],t=0,e=[],n=[],s=[];function r(){t=0,e.length=0,n.length=0,s.length=0}function a(h){let p=0;return h.isInstancedMesh&&(p+=2),h.isSkinnedMesh&&(p+=1),p}function o(h,p,_,b,m,d){let E=i[t];return E===void 0?(E={id:h.id,object:h,geometry:p,material:_,materialVariant:a(h),groupOrder:b,renderOrder:h.renderOrder,z:m,group:d},i[t]=E):(E.id=h.id,E.object=h,E.geometry=p,E.material=_,E.materialVariant=a(h),E.groupOrder=b,E.renderOrder=h.renderOrder,E.z=m,E.group=d),t++,E}function l(h,p,_,b,m,d,E){E.reversedDepth===!0&&(m=-m);let A=o(h,p,_,b,m,d);_.transmission>0?n.push(A):_.transparent===!0?s.push(A):e.push(A)}function c(h,p,_,b,m,d){let E=o(h,p,_,b,m,d);_.transmission>0?n.unshift(E):_.transparent===!0?s.unshift(E):e.unshift(E)}function u(h,p){e.length>1&&e.sort(h||Z0),n.length>1&&n.sort(p||Tu),s.length>1&&s.sort(p||Tu)}function f(){for(let h=t,p=i.length;h<p;h++){let _=i[h];if(_.id===null)break;_.id=null,_.object=null,_.geometry=null,_.material=null,_.group=null}}return{opaque:e,transmissive:n,transparent:s,init:r,push:l,unshift:c,finish:f,sort:u}}function J0(){let i=new WeakMap;function t(n,s){let r=i.get(n),a;return r===void 0?(a=new Eu,i.set(n,[a])):s>=r.length?(a=new Eu,r.push(a)):a=r[s],a}function e(){i=new WeakMap}return{get:t,dispose:e}}function K0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={direction:new U,color:new Xt};break;case"SpotLight":e={position:new U,direction:new U,color:new Xt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":e={position:new U,color:new Xt,distance:0,decay:0};break;case"HemisphereLight":e={direction:new U,skyColor:new Xt,groundColor:new Xt};break;case"RectAreaLight":e={color:new Xt,position:new U,halfWidth:new U,halfHeight:new U};break}return i[t.id]=e,e}}}function j0(){let i={};return{get:function(t){if(i[t.id]!==void 0)return i[t.id];let e;switch(t.type){case"SunLight":case"DirectionalLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt};break;case"SpotLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt};break;case"PointLight":e={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Dt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[t.id]=e,e}}}var Q0=0;function t_(i,t){return(t.castShadow?2:0)-(i.castShadow?2:0)+(t.map?1:0)-(i.map?1:0)}function e_(i){let t=new K0,e=j0(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new U);let s=new U,r=new ye,a=new ye;function o(c){let u=0,f=0,h=0;for(let N=0;N<9;N++)n.probe[N].set(0,0,0);let p=0,_=0,b=0,m=0,d=0,E=0,A=0,y=0,S=0,M=0,C=0,x=0,T=0,P=0;c.sort(t_);for(let N=0,B=c.length;N<B;N++){let R=c[N],z=R.color,q=R.intensity,Z=R.distance,rt=null;if(R.shadow&&R.shadow.map&&(R.shadow.map.texture.format===xi?rt=R.shadow.map.texture:rt=R.shadow.map.depthTexture||R.shadow.map.texture),R.isAmbientLight)u+=z.r*q,f+=z.g*q,h+=z.b*q;else if(R.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(R.sh.coefficients[$],q);P++}else if(R.isSunLight){let $=t.get(R);if($.color.copy(R.color).multiplyScalar(R.intensity),R.castShadow){let K=R.shadow,st=e.get(R);st.shadowIntensity=K.intensity,st.shadowBias=K.bias,st.shadowNormalBias=K.normalBias,st.shadowRadius=K.radius,st.shadowMapSize.copy(K.mapSize).multiply(K.getFrameExtents()),n.sunShadow[_]=st,n.sunShadowMap[_]=rt;let Tt=K.getViewportCount();for(let ht=0;ht<Tt;ht++)n.sunShadowMatrix[b+ht]=K.getMatrix(ht),n.sunShadowCascade[b+ht]=K._cascadeData[ht];b+=Tt,_++}n.sun[p]=$,p++}else if(R.isDirectionalLight){let $=t.get(R);if($.color.copy(R.color).multiplyScalar(R.intensity),R.castShadow){let K=R.shadow,st=e.get(R);st.shadowIntensity=K.intensity,st.shadowBias=K.bias,st.shadowNormalBias=K.normalBias,st.shadowRadius=K.radius,st.shadowMapSize=K.mapSize,n.directionalShadow[m]=st,n.directionalShadowMap[m]=rt,n.directionalShadowMatrix[m]=R.shadow.matrix,S++}n.directional[m]=$,m++}else if(R.isSpotLight){let $=t.get(R);$.position.setFromMatrixPosition(R.matrixWorld),$.color.copy(z).multiplyScalar(q),$.distance=Z,$.coneCos=Math.cos(R.angle),$.penumbraCos=Math.cos(R.angle*(1-R.penumbra)),$.decay=R.decay,n.spot[E]=$;let K=R.shadow;if(R.map&&(n.spotLightMap[x]=R.map,x++,K.updateMatrices(R),R.castShadow&&T++),n.spotLightMatrix[E]=K.matrix,R.castShadow){let st=e.get(R);st.shadowIntensity=K.intensity,st.shadowBias=K.bias,st.shadowNormalBias=K.normalBias,st.shadowRadius=K.radius,st.shadowMapSize=K.mapSize,n.spotShadow[E]=st,n.spotShadowMap[E]=rt,C++}E++}else if(R.isRectAreaLight){let $=t.get(R);$.color.copy(z).multiplyScalar(q),$.halfWidth.set(R.width*.5,0,0),$.halfHeight.set(0,R.height*.5,0),n.rectArea[A]=$,A++}else if(R.isPointLight){let $=t.get(R);if($.color.copy(R.color).multiplyScalar(R.intensity),$.distance=R.distance,$.decay=R.decay,R.castShadow){let K=R.shadow,st=e.get(R);st.shadowIntensity=K.intensity,st.shadowBias=K.bias,st.shadowNormalBias=K.normalBias,st.shadowRadius=K.radius,st.shadowMapSize=K.mapSize,st.shadowCameraNear=K.camera.near,st.shadowCameraFar=K.camera.far,n.pointShadow[d]=st,n.pointShadowMap[d]=rt,n.pointShadowMatrix[d]=R.shadow.matrix,M++}n.point[d]=$,d++}else if(R.isHemisphereLight){let $=t.get(R);$.skyColor.copy(R.color).multiplyScalar(q),$.groundColor.copy(R.groundColor).multiplyScalar(q),n.hemi[y]=$,y++}}A>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=yt.LTC_FLOAT_1,n.rectAreaLTC2=yt.LTC_FLOAT_2):(n.rectAreaLTC1=yt.LTC_HALF_1,n.rectAreaLTC2=yt.LTC_HALF_2)),n.ambient[0]=u,n.ambient[1]=f,n.ambient[2]=h;let F=n.hash;(F.sunLength!==p||F.directionalLength!==m||F.pointLength!==d||F.spotLength!==E||F.rectAreaLength!==A||F.hemiLength!==y||F.numSunShadows!==_||F.numDirectionalShadows!==S||F.numPointShadows!==M||F.numSpotShadows!==C||F.numSpotMaps!==x||F.numLightProbes!==P)&&(n.sun.length=p,n.directional.length=m,n.spot.length=E,n.rectArea.length=A,n.point.length=d,n.hemi.length=y,n.sunShadow.length=_,n.sunShadowMap.length=_,n.sunShadowMatrix.length=b,n.sunShadowCascade.length=b,n.directionalShadow.length=S,n.directionalShadowMap.length=S,n.directionalShadowMatrix.length=S,n.pointShadow.length=M,n.pointShadowMap.length=M,n.pointShadowMatrix.length=M,n.spotShadow.length=C,n.spotShadowMap.length=C,n.spotLightMatrix.length=C+x-T,n.spotLightMap.length=x,n.numSpotLightShadowsWithMaps=T,n.numLightProbes=P,F.sunLength=p,F.directionalLength=m,F.pointLength=d,F.spotLength=E,F.rectAreaLength=A,F.hemiLength=y,F.numSunShadows=_,F.numDirectionalShadows=S,F.numPointShadows=M,F.numSpotShadows=C,F.numSpotMaps=x,F.numLightProbes=P,n.version=Q0++)}function l(c,u){let f=0,h=0,p=0,_=0,b=0,m=0,d=u.matrixWorldInverse;for(let E=0,A=c.length;E<A;E++){let y=c[E];if(y.isSunLight){let S=n.sun[f];S.direction.setFromMatrixPosition(y.matrixWorld),S.direction.transformDirection(d),f++}else if(y.isDirectionalLight){let S=n.directional[h];S.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),S.direction.sub(s),S.direction.transformDirection(d),h++}else if(y.isSpotLight){let S=n.spot[_];S.position.setFromMatrixPosition(y.matrixWorld),S.position.applyMatrix4(d),S.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),S.direction.sub(s),S.direction.transformDirection(d),_++}else if(y.isRectAreaLight){let S=n.rectArea[b];S.position.setFromMatrixPosition(y.matrixWorld),S.position.applyMatrix4(d),a.identity(),r.copy(y.matrixWorld),r.premultiply(d),a.extractRotation(r),S.halfWidth.set(y.width*.5,0,0),S.halfHeight.set(0,y.height*.5,0),S.halfWidth.applyMatrix4(a),S.halfHeight.applyMatrix4(a),b++}else if(y.isPointLight){let S=n.point[p];S.position.setFromMatrixPosition(y.matrixWorld),S.position.applyMatrix4(d),p++}else if(y.isHemisphereLight){let S=n.hemi[m];S.direction.setFromMatrixPosition(y.matrixWorld),S.direction.transformDirection(d),m++}}}return{setup:o,setupView:l,state:n}}function wu(i){let t=new e_(i),e=[],n=[],s=[];function r(h){f.camera=h,e.length=0,n.length=0,s.length=0}function a(h){e.push(h)}function o(h){n.push(h)}function l(h){s.push(h)}function c(){t.setup(e)}function u(h){t.setupView(e,h)}let f={lightsArray:e,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:f,setupLights:c,setupLightsView:u,pushLight:a,pushShadow:o,pushLightProbeGrid:l}}function n_(i){let t=new WeakMap;function e(s,r=0){let a=t.get(s),o;return a===void 0?(o=new wu(i),t.set(s,[o])):r>=a.length?(o=new wu(i),a.push(o)):o=a[r],o}function n(){t=new WeakMap}return{get:e,dispose:n}}var i_=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,s_=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,r_=[new U(1,0,0),new U(-1,0,0),new U(0,1,0),new U(0,-1,0),new U(0,0,1),new U(0,0,-1)],a_=[new U(0,-1,0),new U(0,-1,0),new U(0,0,1),new U(0,0,-1),new U(0,-1,0),new U(0,-1,0)],Au=new ye,vr=new U,cc=new U;function o_(i,t,e){let n=new _s,s=new Dt,r=new Dt,a=new be,o=new ya,l=new va,c={},u=e.maxTextureSize,f={[pi]:Je,[Je]:pi,[Ke]:Ke},h=new on({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Dt},radius:{value:4}},vertexShader:i_,fragmentShader:s_}),p=h.clone();p.defines.HORIZONTAL_PASS=1;let _=new Ze;_.setAttribute("position",new an(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let b=new Me(_,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=hr;let d=this.type;this.render=function(M,C,x){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||M.length===0)return;this.type===bh&&(Bt("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=hr);let T=i.getRenderTarget(),P=i.getActiveCubeFace(),F=i.getActiveMipmapLevel(),N=i.state;N.setBlending(Dn),N.buffers.depth.getReversed()===!0?N.buffers.color.setClear(0,0,0,0):N.buffers.color.setClear(1,1,1,1),N.buffers.depth.setTest(!0),N.setScissorTest(!1);let B=d!==this.type;B&&C.traverse(function(R){R.material&&(Array.isArray(R.material)?R.material.forEach(z=>z.needsUpdate=!0):R.material.needsUpdate=!0)});for(let R=0,z=M.length;R<z;R++){let q=M[R],Z=q.shadow;if(Z===void 0){Bt("WebGLShadowMap:",q,"has no shadow.");continue}if(Z.autoUpdate===!1&&Z.needsUpdate===!1)continue;s.copy(Z.mapSize);let rt=Z.getFrameExtents();s.multiply(rt),r.copy(Z.mapSize),(s.x>u||s.y>u)&&(s.x>u&&(r.x=Math.floor(u/rt.x),s.x=r.x*rt.x,Z.mapSize.x=r.x),s.y>u&&(r.y=Math.floor(u/rt.y),s.y=r.y*rt.y,Z.mapSize.y=r.y));let $=i.state.buffers.depth.getReversed();if(Z.camera._reversedDepth=$,Z.map===null||B===!0){if(Z.map!==null&&(Z.map.depthTexture!==null&&(Z.map.depthTexture.dispose(),Z.map.depthTexture=null),Z.map.dispose()),this.type===As){if(q.isPointLight){Bt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}Z.map=new je(s.x,s.y,{format:xi,type:wn,minFilter:Fe,magFilter:Fe,generateMipmaps:!1}),Z.map.texture.name=q.name+".shadowMap",Z.map.depthTexture=new oi(s.x,s.y,En),Z.map.depthTexture.name=q.name+".shadowMapDepth",Z.map.depthTexture.format=Ln,Z.map.depthTexture.compareFunction=null,Z.map.depthTexture.minFilter=Ne,Z.map.depthTexture.magFilter=Ne}else q.isPointLight?(Z.map=new Ao(s.x),Z.map.depthTexture=new ga(s.x,Tn)):(Z.map=new je(s.x,s.y),Z.map.depthTexture=new oi(s.x,s.y,Tn)),Z.map.depthTexture.name=q.name+".shadowMap",Z.map.depthTexture.format=Ln,this.type===hr?(Z.map.depthTexture.compareFunction=$?Mo:So,Z.map.depthTexture.minFilter=Fe,Z.map.depthTexture.magFilter=Fe):(Z.map.depthTexture.compareFunction=null,Z.map.depthTexture.minFilter=Ne,Z.map.depthTexture.magFilter=Ne);Z.camera.updateProjectionMatrix()}Z.map.isWebGLCubeRenderTarget!==!0&&(Z.map.width!==s.x||Z.map.height!==s.y)&&Z.map.setSize(s.x,s.y);let K=Z.map.isWebGLCubeRenderTarget?6:Z.getViewportCount();q.isPointLight!==!0&&Z.updateMatrices(q,x);for(let st=0;st<K;st++){let Tt=Z.getCamera(st);if(q.isPointLight){let ht=Z.camera,Y=Z.matrix,J=q.distance||ht.far;J!==ht.far&&(ht.far=J,ht.updateProjectionMatrix()),vr.setFromMatrixPosition(q.matrixWorld),ht.position.copy(vr),cc.copy(ht.position),cc.add(r_[st]),ht.up.copy(a_[st]),ht.lookAt(cc),ht.updateMatrixWorld(),Y.makeTranslation(-vr.x,-vr.y,-vr.z),Au.multiplyMatrices(ht.projectionMatrix,ht.matrixWorldInverse),Z._frustum.setFromProjectionMatrix(Au,ht.coordinateSystem,ht.reversedDepth)}if(Z.map.isWebGLCubeRenderTarget)i.setRenderTarget(Z.map,st),i.clear();else{st===0&&(i.setRenderTarget(Z.map),i.clear());let ht=Z.getViewport(st);a.set(r.x*ht.x,r.y*ht.y,r.x*ht.z,r.y*ht.w),N.viewport(a)}n=Z.getFrustum(st),y(C,x,Tt,q,this.type)}Z.isPointLightShadow!==!0&&this.type===As&&E(Z,x),Z.needsUpdate=!1}d=this.type,m.needsUpdate=!1,i.setRenderTarget(T,P,F)};function E(M,C){let x=t.update(b);h.defines.VSM_SAMPLES!==M.blurSamples&&(h.defines.VSM_SAMPLES=M.blurSamples,p.defines.VSM_SAMPLES=M.blurSamples,h.needsUpdate=!0,p.needsUpdate=!0),M.mapPass===null?M.mapPass=new je(s.x,s.y,{format:xi,type:wn}):(M.mapPass.width!==M.map.width||M.mapPass.height!==M.map.height)&&M.mapPass.setSize(M.map.width,M.map.height),h.uniforms.shadow_pass.value=M.map.depthTexture,h.uniforms.resolution.value.set(M.map.width,M.map.height),h.uniforms.radius.value=M.radius,i.setRenderTarget(M.mapPass),i.clear(),i.renderBufferDirect(C,null,x,h,b,null),p.uniforms.shadow_pass.value=M.mapPass.texture,p.uniforms.resolution.value.set(M.map.width,M.map.height),p.uniforms.radius.value=M.radius,i.setRenderTarget(M.map),i.clear(),i.renderBufferDirect(C,null,x,p,b,null)}function A(M,C,x,T){let P=null,F=x.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(F!==void 0)P=F;else if(P=x.isPointLight===!0?l:o,i.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0||C.alphaToCoverage===!0){let N=P.uuid,B=C.uuid,R=c[N];R===void 0&&(R={},c[N]=R);let z=R[B];z===void 0&&(z=P.clone(),R[B]=z,C.addEventListener("dispose",S)),P=z}if(P.visible=C.visible,P.wireframe=C.wireframe,T===As?P.side=C.shadowSide!==null?C.shadowSide:C.side:P.side=C.shadowSide!==null?C.shadowSide:f[C.side],P.alphaMap=C.alphaMap,P.alphaTest=C.alphaToCoverage===!0?.5:C.alphaTest,P.map=C.map,P.clipShadows=C.clipShadows,P.clippingPlanes=C.clippingPlanes,P.clipIntersection=C.clipIntersection,P.displacementMap=C.displacementMap,P.displacementScale=C.displacementScale,P.displacementBias=C.displacementBias,P.wireframeLinewidth=C.wireframeLinewidth,P.linewidth=C.linewidth,x.isPointLight===!0&&P.isMeshDistanceMaterial===!0){let N=i.properties.get(P);N.light=x}return P}function y(M,C,x,T,P){if(M.visible===!1)return;if(M.layers.test(C.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&P===As)&&(!M.frustumCulled||M.intersectsFrustum(n))){M.modelViewMatrix.multiplyMatrices(x.matrixWorldInverse,M.matrixWorld);let B=t.update(M),R=M.material;if(Array.isArray(R)){let z=B.groups;for(let q=0,Z=z.length;q<Z;q++){let rt=z[q],$=R[rt.materialIndex];if($&&$.visible){let K=A(M,$,T,P);M.onBeforeShadow(i,M,C,x,B,K,rt),i.renderBufferDirect(x,null,B,K,M,rt),M.onAfterShadow(i,M,C,x,B,K,rt)}}}else if(R.visible){let z=A(M,R,T,P);M.onBeforeShadow(i,M,C,x,B,z,null),i.renderBufferDirect(x,null,B,z,M,null),M.onAfterShadow(i,M,C,x,B,z,null)}}let N=M.children;for(let B=0,R=N.length;B<R;B++)y(N[B],C,x,T,P)}function S(M){M.target.removeEventListener("dispose",S);for(let x in c){let T=c[x],P=M.target.uuid;P in T&&(T[P].dispose(),delete T[P])}}}function l_(i,t){function e(){let D=!1,gt=new be,et=null,_t=new be(0,0,0,0);return{setMask:function(Mt){et!==Mt&&!D&&(i.colorMask(Mt,Mt,Mt,Mt),et=Mt)},setLocked:function(Mt){D=Mt},setClear:function(Mt,lt,Ft,Pt,fe){fe===!0&&(Mt*=Pt,lt*=Pt,Ft*=Pt),gt.set(Mt,lt,Ft,Pt),_t.equals(gt)===!1&&(i.clearColor(Mt,lt,Ft,Pt),_t.copy(gt))},reset:function(){D=!1,et=null,_t.set(-1,0,0,0)}}}function n(){let D=!1,gt=!1,et=null,_t=null,Mt=null;return{setReversed:function(lt){if(gt!==lt){let Ft=t.get("EXT_clip_control");lt?Ft.clipControlEXT(Ft.LOWER_LEFT_EXT,Ft.ZERO_TO_ONE_EXT):Ft.clipControlEXT(Ft.LOWER_LEFT_EXT,Ft.NEGATIVE_ONE_TO_ONE_EXT),gt=lt;let Pt=Mt;Mt=null,this.setClear(Pt)}},getReversed:function(){return gt},setTest:function(lt){lt?H(i.DEPTH_TEST):at(i.DEPTH_TEST)},setMask:function(lt){et!==lt&&!D&&(i.depthMask(lt),et=lt)},setFunc:function(lt){if(gt&&(lt=eu[lt]),_t!==lt){switch(lt){case ea:i.depthFunc(i.NEVER);break;case na:i.depthFunc(i.ALWAYS);break;case ia:i.depthFunc(i.LESS);break;case ls:i.depthFunc(i.LEQUAL);break;case sa:i.depthFunc(i.EQUAL);break;case ra:i.depthFunc(i.GEQUAL);break;case aa:i.depthFunc(i.GREATER);break;case oa:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}_t=lt}},setLocked:function(lt){D=lt},setClear:function(lt){Mt!==lt&&(Mt=lt,gt&&(lt=1-lt),i.clearDepth(lt))},reset:function(){D=!1,et=null,_t=null,Mt=null,gt=!1}}}function s(){let D=!1,gt=null,et=null,_t=null,Mt=null,lt=null,Ft=null,Pt=null,fe=null;return{setTest:function(re){D||(re?H(i.STENCIL_TEST):at(i.STENCIL_TEST))},setMask:function(re){gt!==re&&!D&&(i.stencilMask(re),gt=re)},setFunc:function(re,mn,An){(et!==re||_t!==mn||Mt!==An)&&(i.stencilFunc(re,mn,An),et=re,_t=mn,Mt=An)},setOp:function(re,mn,An){(lt!==re||Ft!==mn||Pt!==An)&&(i.stencilOp(re,mn,An),lt=re,Ft=mn,Pt=An)},setLocked:function(re){D=re},setClear:function(re){fe!==re&&(i.clearStencil(re),fe=re)},reset:function(){D=!1,gt=null,et=null,_t=null,Mt=null,lt=null,Ft=null,Pt=null,fe=null}}}let r=new e,a=new n,o=new s,l=new WeakMap,c=new WeakMap,u={},f={},h={},p=new WeakMap,_=[],b=null,m=!1,d=null,E=null,A=null,y=null,S=null,M=null,C=null,x=new Xt(0,0,0),T=0,P=!1,F=null,N=null,B=null,R=null,z=null,q=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),Z=!1,rt=0,$=i.getParameter(i.VERSION);$.indexOf("WebGL")!==-1?(rt=parseFloat(/^WebGL (\d)/.exec($)[1]),Z=rt>=1):$.indexOf("OpenGL ES")!==-1&&(rt=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),Z=rt>=2);let K=null,st={},Tt=i.getParameter(i.SCISSOR_BOX),ht=i.getParameter(i.VIEWPORT),Y=new be().fromArray(Tt),J=new be().fromArray(ht);function nt(D,gt,et,_t){let Mt=new Uint8Array(4),lt=i.createTexture();i.bindTexture(D,lt),i.texParameteri(D,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(D,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let Ft=0;Ft<et;Ft++)D===i.TEXTURE_3D||D===i.TEXTURE_2D_ARRAY?i.texImage3D(gt,0,i.RGBA,1,1,_t,0,i.RGBA,i.UNSIGNED_BYTE,Mt):i.texImage2D(gt+Ft,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Mt);return lt}let O={};O[i.TEXTURE_2D]=nt(i.TEXTURE_2D,i.TEXTURE_2D,1),O[i.TEXTURE_CUBE_MAP]=nt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),O[i.TEXTURE_2D_ARRAY]=nt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),O[i.TEXTURE_3D]=nt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),a.setClear(1),o.setClear(0),H(i.DEPTH_TEST),a.setFunc(ls),Gt(!1),he(Ml),H(i.CULL_FACE),kt(Dn);function H(D){u[D]!==!0&&(i.enable(D),u[D]=!0)}function at(D){u[D]!==!1&&(i.disable(D),u[D]=!1)}function ut(D,gt){return h[D]!==gt?(i.bindFramebuffer(D,gt),h[D]=gt,D===i.DRAW_FRAMEBUFFER&&(h[i.FRAMEBUFFER]=gt),D===i.FRAMEBUFFER&&(h[i.DRAW_FRAMEBUFFER]=gt),!0):!1}function ct(D,gt){let et=_,_t=!1;if(D){et=p.get(gt),et===void 0&&(et=[],p.set(gt,et));let Mt=D.textures;if(et.length!==Mt.length||et[0]!==i.COLOR_ATTACHMENT0){for(let lt=0,Ft=Mt.length;lt<Ft;lt++)et[lt]=i.COLOR_ATTACHMENT0+lt;et.length=Mt.length,_t=!0}}else et[0]!==i.BACK&&(et[0]=i.BACK,_t=!0);_t&&i.drawBuffers(et)}function bt(D){return b!==D?(i.useProgram(D),b=D,!0):!1}let Lt={[Ii]:i.FUNC_ADD,[Mh]:i.FUNC_SUBTRACT,[Th]:i.FUNC_REVERSE_SUBTRACT};Lt[Eh]=i.MIN,Lt[wh]=i.MAX;let At={[Ah]:i.ZERO,[Ch]:i.ONE,[Rh]:i.SRC_COLOR,[Al]:i.SRC_ALPHA,[Uh]:i.SRC_ALPHA_SATURATE,[Dh]:i.DST_COLOR,[Ih]:i.DST_ALPHA,[Ph]:i.ONE_MINUS_SRC_COLOR,[Cl]:i.ONE_MINUS_SRC_ALPHA,[Nh]:i.ONE_MINUS_DST_COLOR,[Lh]:i.ONE_MINUS_DST_ALPHA,[Fh]:i.CONSTANT_COLOR,[Oh]:i.ONE_MINUS_CONSTANT_COLOR,[Bh]:i.CONSTANT_ALPHA,[kh]:i.ONE_MINUS_CONSTANT_ALPHA};function kt(D,gt,et,_t,Mt,lt,Ft,Pt,fe,re){if(D===Dn){m===!0&&(at(i.BLEND),m=!1);return}if(m===!1&&(H(i.BLEND),m=!0),D!==Sh){if(D!==d||re!==P){if((E!==Ii||S!==Ii)&&(i.blendEquation(i.FUNC_ADD),E=Ii,S=Ii),re)switch(D){case Cs:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Tl:i.blendFunc(i.ONE,i.ONE);break;case El:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case wl:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:zt("WebGLState: Invalid blending: ",D);break}else switch(D){case Cs:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Tl:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case El:zt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case wl:zt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:zt("WebGLState: Invalid blending: ",D);break}A=null,y=null,M=null,C=null,x.set(0,0,0),T=0,d=D,P=re}return}Mt=Mt||gt,lt=lt||et,Ft=Ft||_t,(gt!==E||Mt!==S)&&(i.blendEquationSeparate(Lt[gt],Lt[Mt]),E=gt,S=Mt),(et!==A||_t!==y||lt!==M||Ft!==C)&&(i.blendFuncSeparate(At[et],At[_t],At[lt],At[Ft]),A=et,y=_t,M=lt,C=Ft),(Pt.equals(x)===!1||fe!==T)&&(i.blendColor(Pt.r,Pt.g,Pt.b,fe),x.copy(Pt),T=fe),d=D,P=!1}function ee(D,gt){D.side===Ke?at(i.CULL_FACE):H(i.CULL_FACE);let et=D.side===Je;gt&&(et=!et),Gt(et),D.blending===Cs&&D.transparent===!1?kt(Dn):kt(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),a.setFunc(D.depthFunc),a.setTest(D.depthTest),a.setMask(D.depthWrite),r.setMask(D.colorWrite);let _t=D.stencilWrite;o.setTest(_t),_t&&(o.setMask(D.stencilWriteMask),o.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),o.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),$t(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?H(i.SAMPLE_ALPHA_TO_COVERAGE):at(i.SAMPLE_ALPHA_TO_COVERAGE)}function Gt(D){F!==D&&(D?i.frontFace(i.CW):i.frontFace(i.CCW),F=D)}function he(D){D!==yh?(H(i.CULL_FACE),D!==N&&(D===Ml?i.cullFace(i.BACK):D===vh?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):at(i.CULL_FACE),N=D}function Ht(D){D!==B&&(Z&&i.lineWidth(D),B=D)}function $t(D,gt,et){D?(H(i.POLYGON_OFFSET_FILL),(R!==gt||z!==et)&&(R=gt,z=et,a.getReversed()&&(gt=-gt),i.polygonOffset(gt,et))):at(i.POLYGON_OFFSET_FILL)}function qt(D){D?H(i.SCISSOR_TEST):at(i.SCISSOR_TEST)}function ne(D){D===void 0&&(D=i.TEXTURE0+q-1),K!==D&&(i.activeTexture(D),K=D)}function L(D,gt,et){et===void 0&&(K===null?et=i.TEXTURE0+q-1:et=K);let _t=st[et];_t===void 0&&(_t={type:void 0,texture:void 0},st[et]=_t),(_t.type!==D||_t.texture!==gt)&&(K!==et&&(i.activeTexture(et),K=et),i.bindTexture(D,gt||O[D]),_t.type=D,_t.texture=gt)}function jt(){let D=st[K];D!==void 0&&D.type!==void 0&&(i.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function ie(){try{i.compressedTexImage2D(...arguments)}catch(D){zt("WebGLState:",D)}}function w(){try{i.compressedTexImage3D(...arguments)}catch(D){zt("WebGLState:",D)}}function g(){try{i.texSubImage2D(...arguments)}catch(D){zt("WebGLState:",D)}}function k(){try{i.texSubImage3D(...arguments)}catch(D){zt("WebGLState:",D)}}function W(){try{i.compressedTexSubImage2D(...arguments)}catch(D){zt("WebGLState:",D)}}function j(){try{i.compressedTexSubImage3D(...arguments)}catch(D){zt("WebGLState:",D)}}function dt(){try{i.texStorage2D(...arguments)}catch(D){zt("WebGLState:",D)}}function ft(){try{i.texStorage3D(...arguments)}catch(D){zt("WebGLState:",D)}}function Q(){try{i.texImage2D(...arguments)}catch(D){zt("WebGLState:",D)}}function it(){try{i.texImage3D(...arguments)}catch(D){zt("WebGLState:",D)}}function pt(D){return f[D]!==void 0?f[D]:i.getParameter(D)}function Nt(D,gt){f[D]!==gt&&(i.pixelStorei(D,gt),f[D]=gt)}function xt(D){Y.equals(D)===!1&&(i.scissor(D.x,D.y,D.z,D.w),Y.copy(D))}function mt(D){J.equals(D)===!1&&(i.viewport(D.x,D.y,D.z,D.w),J.copy(D))}function Ut(D,gt){let et=c.get(gt);et===void 0&&(et=new WeakMap,c.set(gt,et));let _t=et.get(D);_t===void 0&&(_t=i.getUniformBlockIndex(gt,D.name),et.set(D,_t))}function Ot(D,gt){let _t=c.get(gt).get(D);l.get(gt)!==_t&&(i.uniformBlockBinding(gt,_t,D.__bindingPointIndex),l.set(gt,_t))}function Wt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),a.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),u={},f={},K=null,st={},h={},p=new WeakMap,_=[],b=null,m=!1,d=null,E=null,A=null,y=null,S=null,M=null,C=null,x=new Xt(0,0,0),T=0,P=!1,F=null,N=null,B=null,R=null,z=null,Y.set(0,0,i.canvas.width,i.canvas.height),J.set(0,0,i.canvas.width,i.canvas.height),r.reset(),a.reset(),o.reset()}return{buffers:{color:r,depth:a,stencil:o},enable:H,disable:at,bindFramebuffer:ut,drawBuffers:ct,useProgram:bt,setBlending:kt,setMaterial:ee,setFlipSided:Gt,setCullFace:he,setLineWidth:Ht,setPolygonOffset:$t,setScissorTest:qt,activeTexture:ne,bindTexture:L,unbindTexture:jt,compressedTexImage2D:ie,compressedTexImage3D:w,texImage2D:Q,texImage3D:it,pixelStorei:Nt,getParameter:pt,updateUBOMapping:Ut,uniformBlockBinding:Ot,texStorage2D:dt,texStorage3D:ft,texSubImage2D:g,texSubImage3D:k,compressedTexSubImage2D:W,compressedTexSubImage3D:j,scissor:xt,viewport:mt,reset:Wt}}function c_(i,t,e,n,s,r,a){let o=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new Dt,u=new WeakMap,f=new Set,h,p=new WeakMap,_=!1;try{_=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function b(w,g){return _?new OffscreenCanvas(w,g):Ys("canvas")}function m(w,g,k){let W=1,j=ie(w);if((j.width>k||j.height>k)&&(W=k/Math.max(j.width,j.height)),W<1)if(typeof HTMLImageElement<"u"&&w instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&w instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&w instanceof ImageBitmap||typeof VideoFrame<"u"&&w instanceof VideoFrame){let dt=Math.floor(W*j.width),ft=Math.floor(W*j.height);h===void 0&&(h=b(dt,ft));let Q=g?b(dt,ft):h;return Q.width=dt,Q.height=ft,Q.getContext("2d").drawImage(w,0,0,dt,ft),Bt("WebGLRenderer: Texture has been resized from ("+j.width+"x"+j.height+") to ("+dt+"x"+ft+")."),Q}else return"data"in w&&Bt("WebGLRenderer: Image in DataTexture is too big ("+j.width+"x"+j.height+")."),w;return w}function d(w){return w.generateMipmaps}function E(w){i.generateMipmap(w)}function A(w){return w.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:w.isWebGL3DRenderTarget?i.TEXTURE_3D:w.isWebGLArrayRenderTarget||w.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function y(w,g,k,W,j,dt=!1){if(w!==null){if(i[w]!==void 0)return i[w];Bt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+w+"'")}let ft;W&&(ft=t.get("EXT_texture_norm16"),ft||Bt("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let Q=g;if(g===i.RED&&(k===i.FLOAT&&(Q=i.R32F),k===i.HALF_FLOAT&&(Q=i.R16F),k===i.UNSIGNED_BYTE&&(Q=i.R8),k===i.UNSIGNED_SHORT&&ft&&(Q=ft.R16_EXT),k===i.SHORT&&ft&&(Q=ft.R16_SNORM_EXT)),g===i.RED_INTEGER&&(k===i.UNSIGNED_BYTE&&(Q=i.R8UI),k===i.UNSIGNED_SHORT&&(Q=i.R16UI),k===i.UNSIGNED_INT&&(Q=i.R32UI),k===i.BYTE&&(Q=i.R8I),k===i.SHORT&&(Q=i.R16I),k===i.INT&&(Q=i.R32I)),g===i.RG&&(k===i.FLOAT&&(Q=i.RG32F),k===i.HALF_FLOAT&&(Q=i.RG16F),k===i.UNSIGNED_BYTE&&(Q=i.RG8),k===i.UNSIGNED_SHORT&&ft&&(Q=ft.RG16_EXT),k===i.SHORT&&ft&&(Q=ft.RG16_SNORM_EXT)),g===i.RG_INTEGER&&(k===i.UNSIGNED_BYTE&&(Q=i.RG8UI),k===i.UNSIGNED_SHORT&&(Q=i.RG16UI),k===i.UNSIGNED_INT&&(Q=i.RG32UI),k===i.BYTE&&(Q=i.RG8I),k===i.SHORT&&(Q=i.RG16I),k===i.INT&&(Q=i.RG32I)),g===i.RGB_INTEGER&&(k===i.UNSIGNED_BYTE&&(Q=i.RGB8UI),k===i.UNSIGNED_SHORT&&(Q=i.RGB16UI),k===i.UNSIGNED_INT&&(Q=i.RGB32UI),k===i.BYTE&&(Q=i.RGB8I),k===i.SHORT&&(Q=i.RGB16I),k===i.INT&&(Q=i.RGB32I)),g===i.RGBA_INTEGER&&(k===i.UNSIGNED_BYTE&&(Q=i.RGBA8UI),k===i.UNSIGNED_SHORT&&(Q=i.RGBA16UI),k===i.UNSIGNED_INT&&(Q=i.RGBA32UI),k===i.BYTE&&(Q=i.RGBA8I),k===i.SHORT&&(Q=i.RGBA16I),k===i.INT&&(Q=i.RGBA32I)),g===i.RGB&&(k===i.UNSIGNED_SHORT&&ft&&(Q=ft.RGB16_EXT),k===i.SHORT&&ft&&(Q=ft.RGB16_SNORM_EXT),k===i.UNSIGNED_INT_5_9_9_9_REV&&(Q=i.RGB9_E5),k===i.UNSIGNED_INT_10F_11F_11F_REV&&(Q=i.R11F_G11F_B10F)),g===i.RGBA){let it=dt?qs:Qt.getTransfer(j);k===i.FLOAT&&(Q=i.RGBA32F),k===i.HALF_FLOAT&&(Q=i.RGBA16F),k===i.UNSIGNED_BYTE&&(Q=it===oe?i.SRGB8_ALPHA8:i.RGBA8),k===i.UNSIGNED_SHORT&&ft&&(Q=ft.RGBA16_EXT),k===i.SHORT&&ft&&(Q=ft.RGBA16_SNORM_EXT),k===i.UNSIGNED_SHORT_4_4_4_4&&(Q=i.RGBA4),k===i.UNSIGNED_SHORT_5_5_5_1&&(Q=i.RGB5_A1)}return(Q===i.R16F||Q===i.R32F||Q===i.RG16F||Q===i.RG32F||Q===i.RGBA16F||Q===i.RGBA32F)&&t.get("EXT_color_buffer_float"),Q}function S(w,g){let k;return w?g===null||g===Tn||g===Ps?k=i.DEPTH24_STENCIL8:g===En?k=i.DEPTH32F_STENCIL8:g===Rs&&(k=i.DEPTH24_STENCIL8,Bt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):g===null||g===Tn||g===Ps?k=i.DEPTH_COMPONENT24:g===En?k=i.DEPTH_COMPONENT32F:g===Rs&&(k=i.DEPTH_COMPONENT16),k}function M(w,g){return d(w)===!0||w.isFramebufferTexture&&w.minFilter!==Ne&&w.minFilter!==Fe?Math.log2(Math.max(g.width,g.height))+1:w.mipmaps!==void 0&&w.mipmaps.length>0?w.mipmaps.length:w.isCompressedTexture&&Array.isArray(w.image)?g.mipmaps.length:1}function C(w){let g=w.target;g.removeEventListener("dispose",C),T(g),g.isVideoTexture&&u.delete(g),g.isHTMLTexture&&f.delete(g)}function x(w){let g=w.target;g.removeEventListener("dispose",x),F(g)}function T(w){let g=n.get(w);if(g.__webglInit===void 0)return;let k=w.source,W=p.get(k);if(W){let j=W[g.__cacheKey];j.usedTimes--,j.usedTimes===0&&P(w),Object.keys(W).length===0&&p.delete(k)}n.remove(w)}function P(w){let g=n.get(w);i.deleteTexture(g.__webglTexture);let k=w.source,W=p.get(k);delete W[g.__cacheKey],a.memory.textures--}function F(w){let g=n.get(w);if(w.depthTexture&&(w.depthTexture.dispose(),n.remove(w.depthTexture)),w.isWebGLCubeRenderTarget)for(let W=0;W<6;W++){if(Array.isArray(g.__webglFramebuffer[W]))for(let j=0;j<g.__webglFramebuffer[W].length;j++)i.deleteFramebuffer(g.__webglFramebuffer[W][j]);else i.deleteFramebuffer(g.__webglFramebuffer[W]);g.__webglDepthbuffer&&i.deleteRenderbuffer(g.__webglDepthbuffer[W])}else{if(Array.isArray(g.__webglFramebuffer))for(let W=0;W<g.__webglFramebuffer.length;W++)i.deleteFramebuffer(g.__webglFramebuffer[W]);else i.deleteFramebuffer(g.__webglFramebuffer);if(g.__webglDepthbuffer&&i.deleteRenderbuffer(g.__webglDepthbuffer),g.__webglMultisampledFramebuffer&&i.deleteFramebuffer(g.__webglMultisampledFramebuffer),g.__webglColorRenderbuffer)for(let W=0;W<g.__webglColorRenderbuffer.length;W++)g.__webglColorRenderbuffer[W]&&i.deleteRenderbuffer(g.__webglColorRenderbuffer[W]);g.__webglDepthRenderbuffer&&i.deleteRenderbuffer(g.__webglDepthRenderbuffer)}let k=w.textures;for(let W=0,j=k.length;W<j;W++){let dt=n.get(k[W]);dt.__webglTexture&&(i.deleteTexture(dt.__webglTexture),a.memory.textures--),n.remove(k[W])}n.remove(w)}let N=0;function B(){N=0}function R(){return N}function z(w){N=w}function q(){let w=N;return w>=s.maxTextures&&Bt("WebGLTextures: Trying to use "+(w+1)+" texture units while this GPU supports only "+s.maxTextures),N+=1,w}function Z(w){let g=[];return g.push(w.wrapS),g.push(w.wrapT),g.push(w.wrapR||0),g.push(w.magFilter),g.push(w.minFilter),g.push(w.anisotropy),g.push(w.internalFormat),g.push(w.format),g.push(w.type),g.push(w.generateMipmaps),g.push(w.premultiplyAlpha),g.push(w.flipY),g.push(w.unpackAlignment),g.push(w.colorSpace),g.join()}function rt(w,g){let k=n.get(w);if(w.isVideoTexture&&L(w),w.isRenderTargetTexture===!1&&w.isExternalTexture!==!0&&w.version>0&&k.__version!==w.version){let W=w.image;if(W===null)Bt("WebGLRenderer: Texture marked for update but no image data found.");else if(W.complete===!1)Bt("WebGLRenderer: Texture marked for update but image is incomplete");else{at(k,w,g);return}}else w.isExternalTexture&&(k.__webglTexture=w.sourceTexture?w.sourceTexture:null);e.bindTexture(i.TEXTURE_2D,k.__webglTexture,i.TEXTURE0+g)}function $(w,g){let k=n.get(w);if(w.isRenderTargetTexture===!1&&w.version>0&&k.__version!==w.version){at(k,w,g);return}else w.isExternalTexture&&(k.__webglTexture=w.sourceTexture?w.sourceTexture:null);e.bindTexture(i.TEXTURE_2D_ARRAY,k.__webglTexture,i.TEXTURE0+g)}function K(w,g){let k=n.get(w);if(w.isRenderTargetTexture===!1&&w.version>0&&k.__version!==w.version){at(k,w,g);return}e.bindTexture(i.TEXTURE_3D,k.__webglTexture,i.TEXTURE0+g)}function st(w,g){let k=n.get(w);if(w.isCubeDepthTexture!==!0&&w.version>0&&k.__version!==w.version){ut(k,w,g);return}e.bindTexture(i.TEXTURE_CUBE_MAP,k.__webglTexture,i.TEXTURE0+g)}let Tt={[la]:i.REPEAT,[In]:i.CLAMP_TO_EDGE,[ca]:i.MIRRORED_REPEAT},ht={[Ne]:i.NEAREST,[Vh]:i.NEAREST_MIPMAP_NEAREST,[dr]:i.NEAREST_MIPMAP_LINEAR,[Fe]:i.LINEAR,[Oa]:i.LINEAR_MIPMAP_NEAREST,[gi]:i.LINEAR_MIPMAP_LINEAR},Y={[$h]:i.NEVER,[Kh]:i.ALWAYS,[qh]:i.LESS,[So]:i.LEQUAL,[Yh]:i.EQUAL,[Mo]:i.GEQUAL,[Zh]:i.GREATER,[Jh]:i.NOTEQUAL};function J(w,g){if(g.type===En&&t.has("OES_texture_float_linear")===!1&&(g.magFilter===Fe||g.magFilter===Oa||g.magFilter===dr||g.magFilter===gi||g.minFilter===Fe||g.minFilter===Oa||g.minFilter===dr||g.minFilter===gi)&&Bt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(w,i.TEXTURE_WRAP_S,Tt[g.wrapS]),i.texParameteri(w,i.TEXTURE_WRAP_T,Tt[g.wrapT]),(w===i.TEXTURE_3D||w===i.TEXTURE_2D_ARRAY)&&i.texParameteri(w,i.TEXTURE_WRAP_R,Tt[g.wrapR]),i.texParameteri(w,i.TEXTURE_MAG_FILTER,ht[g.magFilter]),i.texParameteri(w,i.TEXTURE_MIN_FILTER,ht[g.minFilter]),g.compareFunction&&(i.texParameteri(w,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(w,i.TEXTURE_COMPARE_FUNC,Y[g.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(g.magFilter===Ne||g.minFilter!==dr&&g.minFilter!==gi||g.type===En&&t.has("OES_texture_float_linear")===!1)return;if(g.anisotropy>1||n.get(g).__currentAnisotropy){let k=t.get("EXT_texture_filter_anisotropic");i.texParameterf(w,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(g.anisotropy,s.getMaxAnisotropy())),n.get(g).__currentAnisotropy=g.anisotropy}}}function nt(w,g){let k=!1;w.__webglInit===void 0&&(w.__webglInit=!0,g.addEventListener("dispose",C));let W=g.source,j=p.get(W);j===void 0&&(j={},p.set(W,j));let dt=Z(g);if(dt!==w.__cacheKey){j[dt]===void 0&&(j[dt]={texture:i.createTexture(),usedTimes:0},a.memory.textures++,k=!0),j[dt].usedTimes++;let ft=j[w.__cacheKey];ft!==void 0&&(j[w.__cacheKey].usedTimes--,ft.usedTimes===0&&P(g)),w.__cacheKey=dt,w.__webglTexture=j[dt].texture}return k}function O(w,g,k){return Math.floor(Math.floor(w/k)/g)}function H(w,g,k,W){let dt=w.updateRanges;if(dt.length===0)e.texSubImage2D(i.TEXTURE_2D,0,0,0,g.width,g.height,k,W,g.data);else{dt.sort((Nt,xt)=>Nt.start-xt.start);let ft=0;for(let Nt=1;Nt<dt.length;Nt++){let xt=dt[ft],mt=dt[Nt],Ut=xt.start+xt.count,Ot=O(mt.start,g.width,4),Wt=O(xt.start,g.width,4);mt.start<=Ut+1&&Ot===Wt&&O(mt.start+mt.count-1,g.width,4)===Ot?xt.count=Math.max(xt.count,mt.start+mt.count-xt.start):(++ft,dt[ft]=mt)}dt.length=ft+1;let Q=e.getParameter(i.UNPACK_ROW_LENGTH),it=e.getParameter(i.UNPACK_SKIP_PIXELS),pt=e.getParameter(i.UNPACK_SKIP_ROWS);e.pixelStorei(i.UNPACK_ROW_LENGTH,g.width);for(let Nt=0,xt=dt.length;Nt<xt;Nt++){let mt=dt[Nt],Ut=Math.floor(mt.start/4),Ot=Math.ceil(mt.count/4),Wt=Ut%g.width,D=Math.floor(Ut/g.width),gt=Ot,et=1;e.pixelStorei(i.UNPACK_SKIP_PIXELS,Wt),e.pixelStorei(i.UNPACK_SKIP_ROWS,D),e.texSubImage2D(i.TEXTURE_2D,0,Wt,D,gt,et,k,W,g.data)}w.clearUpdateRanges(),e.pixelStorei(i.UNPACK_ROW_LENGTH,Q),e.pixelStorei(i.UNPACK_SKIP_PIXELS,it),e.pixelStorei(i.UNPACK_SKIP_ROWS,pt)}}function at(w,g,k){let W=i.TEXTURE_2D;(g.isDataArrayTexture||g.isCompressedArrayTexture)&&(W=i.TEXTURE_2D_ARRAY),g.isData3DTexture&&(W=i.TEXTURE_3D);let j=nt(w,g),dt=g.source;e.bindTexture(W,w.__webglTexture,i.TEXTURE0+k);let ft=n.get(dt);if(dt.version!==ft.__version||j===!0){if(e.activeTexture(i.TEXTURE0+k),(typeof ImageBitmap<"u"&&g.image instanceof ImageBitmap)===!1){let et=Qt.getPrimaries(Qt.workingColorSpace),_t=g.colorSpace===Zn?null:Qt.getPrimaries(g.colorSpace),Mt=g.colorSpace===Zn||et===_t?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,g.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,g.premultiplyAlpha),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Mt)}e.pixelStorei(i.UNPACK_ALIGNMENT,g.unpackAlignment);let it=m(g.image,!1,s.maxTextureSize);it=jt(g,it);let pt=r.convert(g.format,g.colorSpace),Nt=r.convert(g.type),xt=y(g.internalFormat,pt,Nt,g.normalized,g.colorSpace,g.isVideoTexture);J(W,g);let mt,Ut=g.mipmaps,Ot=g.isVideoTexture!==!0,Wt=ft.__version===void 0||j===!0,D=dt.dataReady,gt=M(g,it);if(g.isDepthTexture)xt=S(g.format===_i,g.type),Wt&&(Ot?e.texStorage2D(i.TEXTURE_2D,1,xt,it.width,it.height):e.texImage2D(i.TEXTURE_2D,0,xt,it.width,it.height,0,pt,Nt,null));else if(g.isDataTexture)if(Ut.length>0){Ot&&Wt&&e.texStorage2D(i.TEXTURE_2D,gt,xt,Ut[0].width,Ut[0].height);for(let et=0,_t=Ut.length;et<_t;et++)mt=Ut[et],Ot?D&&e.texSubImage2D(i.TEXTURE_2D,et,0,0,mt.width,mt.height,pt,Nt,mt.data):e.texImage2D(i.TEXTURE_2D,et,xt,mt.width,mt.height,0,pt,Nt,mt.data);g.generateMipmaps=!1}else Ot?(Wt&&e.texStorage2D(i.TEXTURE_2D,gt,xt,it.width,it.height),D&&H(g,it,pt,Nt)):e.texImage2D(i.TEXTURE_2D,0,xt,it.width,it.height,0,pt,Nt,it.data);else if(g.isCompressedTexture)if(g.isCompressedArrayTexture){Ot&&Wt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,gt,xt,Ut[0].width,Ut[0].height,it.depth);for(let et=0,_t=Ut.length;et<_t;et++)if(mt=Ut[et],g.format!==fn)if(pt!==null)if(Ot){if(D)if(g.layerUpdates.size>0){let Mt=jl(mt.width,mt.height,g.format,g.type);for(let lt of g.layerUpdates){let Ft=mt.data.subarray(lt*Mt/mt.data.BYTES_PER_ELEMENT,(lt+1)*Mt/mt.data.BYTES_PER_ELEMENT);e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,et,0,0,lt,mt.width,mt.height,1,pt,Ft)}}else e.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,et,0,0,0,mt.width,mt.height,it.depth,pt,mt.data)}else e.compressedTexImage3D(i.TEXTURE_2D_ARRAY,et,xt,mt.width,mt.height,it.depth,0,mt.data,0,0);else Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Ot?D&&e.texSubImage3D(i.TEXTURE_2D_ARRAY,et,0,0,0,mt.width,mt.height,it.depth,pt,Nt,mt.data):e.texImage3D(i.TEXTURE_2D_ARRAY,et,xt,mt.width,mt.height,it.depth,0,pt,Nt,mt.data);g.layerUpdates.size>0&&g.clearLayerUpdates()}else{Ot&&Wt&&e.texStorage2D(i.TEXTURE_2D,gt,xt,Ut[0].width,Ut[0].height);for(let et=0,_t=Ut.length;et<_t;et++)mt=Ut[et],g.format!==fn?pt!==null?Ot?D&&e.compressedTexSubImage2D(i.TEXTURE_2D,et,0,0,mt.width,mt.height,pt,mt.data):e.compressedTexImage2D(i.TEXTURE_2D,et,xt,mt.width,mt.height,0,mt.data):Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Ot?D&&e.texSubImage2D(i.TEXTURE_2D,et,0,0,mt.width,mt.height,pt,Nt,mt.data):e.texImage2D(i.TEXTURE_2D,et,xt,mt.width,mt.height,0,pt,Nt,mt.data)}else if(g.isDataArrayTexture)if(Ot){if(Wt&&e.texStorage3D(i.TEXTURE_2D_ARRAY,gt,xt,it.width,it.height,it.depth),D)if(g.layerUpdates.size>0){let et=jl(it.width,it.height,g.format,g.type);for(let _t of g.layerUpdates){let Mt=it.data.subarray(_t*et/it.data.BYTES_PER_ELEMENT,(_t+1)*et/it.data.BYTES_PER_ELEMENT);e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,_t,it.width,it.height,1,pt,Nt,Mt)}g.clearLayerUpdates()}else e.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,it.width,it.height,it.depth,pt,Nt,it.data)}else e.texImage3D(i.TEXTURE_2D_ARRAY,0,xt,it.width,it.height,it.depth,0,pt,Nt,it.data);else if(g.isData3DTexture)Ot?(Wt&&e.texStorage3D(i.TEXTURE_3D,gt,xt,it.width,it.height,it.depth),D&&e.texSubImage3D(i.TEXTURE_3D,0,0,0,0,it.width,it.height,it.depth,pt,Nt,it.data)):e.texImage3D(i.TEXTURE_3D,0,xt,it.width,it.height,it.depth,0,pt,Nt,it.data);else if(g.isFramebufferTexture){if(Wt)if(Ot)e.texStorage2D(i.TEXTURE_2D,gt,xt,it.width,it.height);else{let et=it.width,_t=it.height;for(let Mt=0;Mt<gt;Mt++)e.texImage2D(i.TEXTURE_2D,Mt,xt,et,_t,0,pt,Nt,null),et>>=1,_t>>=1}}else if(g.isHTMLTexture){if("texElementImage2D"in i){let et=i.canvas;if(et.hasAttribute("layoutsubtree")||et.setAttribute("layoutsubtree","true"),it.parentNode!==et){et.appendChild(it),f.add(g),et.onpaint=_t=>{let Mt=_t.changedElements;for(let lt of f)Mt.includes(lt.image)&&(lt.needsUpdate=!0)},et.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,it);else{let Mt=i.RGBA,lt=i.RGBA,Ft=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Mt,lt,Ft,it)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(Ut.length>0){if(Ot&&Wt){let et=ie(Ut[0]);e.texStorage2D(i.TEXTURE_2D,gt,xt,et.width,et.height)}for(let et=0,_t=Ut.length;et<_t;et++)mt=Ut[et],Ot?D&&e.texSubImage2D(i.TEXTURE_2D,et,0,0,pt,Nt,mt):e.texImage2D(i.TEXTURE_2D,et,xt,pt,Nt,mt);g.generateMipmaps=!1}else if(Ot){if(Wt){let et=ie(it);e.texStorage2D(i.TEXTURE_2D,gt,xt,et.width,et.height)}D&&e.texSubImage2D(i.TEXTURE_2D,0,0,0,pt,Nt,it)}else e.texImage2D(i.TEXTURE_2D,0,xt,pt,Nt,it);d(g)&&E(W),ft.__version=dt.version,g.onUpdate&&g.onUpdate(g)}w.__version=g.version}function ut(w,g,k){if(g.image.length!==6)return;let W=nt(w,g),j=g.source;e.bindTexture(i.TEXTURE_CUBE_MAP,w.__webglTexture,i.TEXTURE0+k);let dt=n.get(j);if(j.version!==dt.__version||W===!0){e.activeTexture(i.TEXTURE0+k);let ft=Qt.getPrimaries(Qt.workingColorSpace),Q=g.colorSpace===Zn?null:Qt.getPrimaries(g.colorSpace),it=g.colorSpace===Zn||ft===Q?i.NONE:i.BROWSER_DEFAULT_WEBGL;e.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,g.flipY),e.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,g.premultiplyAlpha),e.pixelStorei(i.UNPACK_ALIGNMENT,g.unpackAlignment),e.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,it);let pt=g.isCompressedTexture||g.image[0].isCompressedTexture,Nt=g.image[0]&&g.image[0].isDataTexture,xt=[];for(let lt=0;lt<6;lt++)!pt&&!Nt?xt[lt]=m(g.image[lt],!0,s.maxCubemapSize):xt[lt]=Nt?g.image[lt].image:g.image[lt],xt[lt]=jt(g,xt[lt]);let mt=xt[0],Ut=r.convert(g.format,g.colorSpace),Ot=r.convert(g.type),Wt=y(g.internalFormat,Ut,Ot,g.normalized,g.colorSpace),D=g.isVideoTexture!==!0,gt=dt.__version===void 0||W===!0,et=j.dataReady,_t=M(g,mt);J(i.TEXTURE_CUBE_MAP,g);let Mt;if(pt){D&&gt&&e.texStorage2D(i.TEXTURE_CUBE_MAP,_t,Wt,mt.width,mt.height);for(let lt=0;lt<6;lt++){Mt=xt[lt].mipmaps;for(let Ft=0;Ft<Mt.length;Ft++){let Pt=Mt[Ft];g.format!==fn?Ut!==null?D?et&&e.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft,0,0,Pt.width,Pt.height,Ut,Pt.data):e.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft,Wt,Pt.width,Pt.height,0,Pt.data):Bt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):D?et&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft,0,0,Pt.width,Pt.height,Ut,Ot,Pt.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft,Wt,Pt.width,Pt.height,0,Ut,Ot,Pt.data)}}}else{if(Mt=g.mipmaps,D&&gt){Mt.length>0&&_t++;let lt=ie(xt[0]);e.texStorage2D(i.TEXTURE_CUBE_MAP,_t,Wt,lt.width,lt.height)}for(let lt=0;lt<6;lt++)if(Nt){D?et&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0,0,0,xt[lt].width,xt[lt].height,Ut,Ot,xt[lt].data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0,Wt,xt[lt].width,xt[lt].height,0,Ut,Ot,xt[lt].data);for(let Ft=0;Ft<Mt.length;Ft++){let fe=Mt[Ft].image[lt].image;D?et&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft+1,0,0,fe.width,fe.height,Ut,Ot,fe.data):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft+1,Wt,fe.width,fe.height,0,Ut,Ot,fe.data)}}else{D?et&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0,0,0,Ut,Ot,xt[lt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,0,Wt,Ut,Ot,xt[lt]);for(let Ft=0;Ft<Mt.length;Ft++){let Pt=Mt[Ft];D?et&&e.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft+1,0,0,Ut,Ot,Pt.image[lt]):e.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+lt,Ft+1,Wt,Ut,Ot,Pt.image[lt])}}}d(g)&&E(i.TEXTURE_CUBE_MAP),dt.__version=j.version,g.onUpdate&&g.onUpdate(g)}w.__version=g.version}function ct(w,g,k,W,j,dt){let ft=r.convert(k.format,k.colorSpace),Q=r.convert(k.type),it=y(k.internalFormat,ft,Q,k.normalized,k.colorSpace),pt=n.get(g),Nt=n.get(k);if(Nt.__renderTarget=g,!pt.__hasExternalTextures){let xt=Math.max(1,g.width>>dt),mt=Math.max(1,g.height>>dt);j===i.TEXTURE_3D||j===i.TEXTURE_2D_ARRAY?e.texImage3D(j,dt,it,xt,mt,g.depth,0,ft,Q,null):e.texImage2D(j,dt,it,xt,mt,0,ft,Q,null)}e.bindFramebuffer(i.FRAMEBUFFER,w),ne(g)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,W,j,Nt.__webglTexture,0,qt(g)):(j===i.TEXTURE_2D||j>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,W,j,Nt.__webglTexture,dt),e.bindFramebuffer(i.FRAMEBUFFER,null)}function bt(w,g,k){if(i.bindRenderbuffer(i.RENDERBUFFER,w),g.depthBuffer){let W=g.depthTexture,j=W&&W.isDepthTexture?W.type:null,dt=S(g.stencilBuffer,j),ft=g.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;ne(g)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,qt(g),dt,g.width,g.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,qt(g),dt,g.width,g.height):i.renderbufferStorage(i.RENDERBUFFER,dt,g.width,g.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ft,i.RENDERBUFFER,w)}else{let W=g.textures;for(let j=0;j<W.length;j++){let dt=W[j],ft=r.convert(dt.format,dt.colorSpace),Q=r.convert(dt.type),it=y(dt.internalFormat,ft,Q,dt.normalized,dt.colorSpace);ne(g)?o.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,qt(g),it,g.width,g.height):k?i.renderbufferStorageMultisample(i.RENDERBUFFER,qt(g),it,g.width,g.height):i.renderbufferStorage(i.RENDERBUFFER,it,g.width,g.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Lt(w,g,k){let W=g.isWebGLCubeRenderTarget===!0;if(e.bindFramebuffer(i.FRAMEBUFFER,w),!(g.depthTexture&&g.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");let j=n.get(g.depthTexture);if(j.__renderTarget=g,(!j.__webglTexture||g.depthTexture.image.width!==g.width||g.depthTexture.image.height!==g.height)&&(g.depthTexture.image.width=g.width,g.depthTexture.image.height=g.height,g.depthTexture.needsUpdate=!0),W){if(j.__webglInit===void 0&&(j.__webglInit=!0,g.depthTexture.addEventListener("dispose",C)),j.__webglTexture===void 0){j.__webglTexture=i.createTexture(),e.bindTexture(i.TEXTURE_CUBE_MAP,j.__webglTexture),J(i.TEXTURE_CUBE_MAP,g.depthTexture);let pt=r.convert(g.depthTexture.format),Nt=r.convert(g.depthTexture.type),xt;g.depthTexture.format===Ln?xt=i.DEPTH_COMPONENT24:g.depthTexture.format===_i&&(xt=i.DEPTH24_STENCIL8);for(let mt=0;mt<6;mt++)i.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0,xt,g.width,g.height,0,pt,Nt,null)}}else rt(g.depthTexture,0);let dt=j.__webglTexture,ft=qt(g),Q=W?i.TEXTURE_CUBE_MAP_POSITIVE_X+k:i.TEXTURE_2D,it=g.depthTexture.format===_i?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(g.depthTexture.format===Ln)ne(g)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,it,Q,dt,0,ft):i.framebufferTexture2D(i.FRAMEBUFFER,it,Q,dt,0);else if(g.depthTexture.format===_i)ne(g)?o.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,it,Q,dt,0,ft):i.framebufferTexture2D(i.FRAMEBUFFER,it,Q,dt,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function At(w){let g=n.get(w),k=w.isWebGLCubeRenderTarget===!0;if(g.__boundDepthTexture!==w.depthTexture){let W=w.depthTexture;if(g.__depthDisposeCallback&&g.__depthDisposeCallback(),W){let j=()=>{delete g.__boundDepthTexture,delete g.__depthDisposeCallback,W.removeEventListener("dispose",j)};W.addEventListener("dispose",j),g.__depthDisposeCallback=j}g.__boundDepthTexture=W}if(w.depthTexture&&!g.__autoAllocateDepthBuffer)if(k)for(let W=0;W<6;W++)Lt(g.__webglFramebuffer[W],w,W);else{let W=w.texture.mipmaps;W&&W.length>0?Lt(g.__webglFramebuffer[0],w,0):Lt(g.__webglFramebuffer,w,0)}else if(k){g.__webglDepthbuffer=[];for(let W=0;W<6;W++)if(e.bindFramebuffer(i.FRAMEBUFFER,g.__webglFramebuffer[W]),g.__webglDepthbuffer[W]===void 0)g.__webglDepthbuffer[W]=i.createRenderbuffer(),bt(g.__webglDepthbuffer[W],w,!1);else{let j=w.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,dt=g.__webglDepthbuffer[W];i.bindRenderbuffer(i.RENDERBUFFER,dt),i.framebufferRenderbuffer(i.FRAMEBUFFER,j,i.RENDERBUFFER,dt)}}else{let W=w.texture.mipmaps;if(W&&W.length>0?e.bindFramebuffer(i.FRAMEBUFFER,g.__webglFramebuffer[0]):e.bindFramebuffer(i.FRAMEBUFFER,g.__webglFramebuffer),g.__webglDepthbuffer===void 0)g.__webglDepthbuffer=i.createRenderbuffer(),bt(g.__webglDepthbuffer,w,!1);else{let j=w.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,dt=g.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,dt),i.framebufferRenderbuffer(i.FRAMEBUFFER,j,i.RENDERBUFFER,dt)}}e.bindFramebuffer(i.FRAMEBUFFER,null)}function kt(w,g,k){let W=n.get(w);g!==void 0&&ct(W.__webglFramebuffer,w,w.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),k!==void 0&&At(w)}function ee(w){let g=w.texture,k=n.get(w),W=n.get(g);w.addEventListener("dispose",x);let j=w.textures,dt=w.isWebGLCubeRenderTarget===!0,ft=j.length>1;if(ft||(W.__webglTexture===void 0&&(W.__webglTexture=i.createTexture()),W.__version=g.version,a.memory.textures++),dt){k.__webglFramebuffer=[];for(let Q=0;Q<6;Q++)if(g.mipmaps&&g.mipmaps.length>0){k.__webglFramebuffer[Q]=[];for(let it=0;it<g.mipmaps.length;it++)k.__webglFramebuffer[Q][it]=i.createFramebuffer()}else k.__webglFramebuffer[Q]=i.createFramebuffer()}else{if(g.mipmaps&&g.mipmaps.length>0){k.__webglFramebuffer=[];for(let Q=0;Q<g.mipmaps.length;Q++)k.__webglFramebuffer[Q]=i.createFramebuffer()}else k.__webglFramebuffer=i.createFramebuffer();if(ft)for(let Q=0,it=j.length;Q<it;Q++){let pt=n.get(j[Q]);pt.__webglTexture===void 0&&(pt.__webglTexture=i.createTexture(),a.memory.textures++)}if(w.samples>0&&ne(w)===!1){k.__webglMultisampledFramebuffer=i.createFramebuffer(),k.__webglColorRenderbuffer=[],e.bindFramebuffer(i.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let Q=0;Q<j.length;Q++){let it=j[Q];k.__webglColorRenderbuffer[Q]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,k.__webglColorRenderbuffer[Q]);let pt=r.convert(it.format,it.colorSpace),Nt=r.convert(it.type),xt=y(it.internalFormat,pt,Nt,it.normalized,it.colorSpace,w.isXRRenderTarget===!0),mt=qt(w);i.renderbufferStorageMultisample(i.RENDERBUFFER,mt,xt,w.width,w.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Q,i.RENDERBUFFER,k.__webglColorRenderbuffer[Q])}i.bindRenderbuffer(i.RENDERBUFFER,null),w.depthBuffer&&(k.__webglDepthRenderbuffer=i.createRenderbuffer(),bt(k.__webglDepthRenderbuffer,w,!0)),e.bindFramebuffer(i.FRAMEBUFFER,null)}}if(dt){e.bindTexture(i.TEXTURE_CUBE_MAP,W.__webglTexture),J(i.TEXTURE_CUBE_MAP,g);for(let Q=0;Q<6;Q++)if(g.mipmaps&&g.mipmaps.length>0)for(let it=0;it<g.mipmaps.length;it++)ct(k.__webglFramebuffer[Q][it],w,g,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,it);else ct(k.__webglFramebuffer[Q],w,g,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+Q,0);d(g)&&E(i.TEXTURE_CUBE_MAP),e.unbindTexture()}else if(ft){for(let Q=0,it=j.length;Q<it;Q++){let pt=j[Q],Nt=n.get(pt),xt=i.TEXTURE_2D;(w.isWebGL3DRenderTarget||w.isWebGLArrayRenderTarget)&&(xt=w.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(xt,Nt.__webglTexture),J(xt,pt),ct(k.__webglFramebuffer,w,pt,i.COLOR_ATTACHMENT0+Q,xt,0),d(pt)&&E(xt)}e.unbindTexture()}else{let Q=i.TEXTURE_2D;if((w.isWebGL3DRenderTarget||w.isWebGLArrayRenderTarget)&&(Q=w.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),e.bindTexture(Q,W.__webglTexture),J(Q,g),g.mipmaps&&g.mipmaps.length>0)for(let it=0;it<g.mipmaps.length;it++)ct(k.__webglFramebuffer[it],w,g,i.COLOR_ATTACHMENT0,Q,it);else ct(k.__webglFramebuffer,w,g,i.COLOR_ATTACHMENT0,Q,0);d(g)&&E(Q),e.unbindTexture()}w.depthBuffer&&At(w)}function Gt(w){let g=w.textures;for(let k=0,W=g.length;k<W;k++){let j=g[k];if(d(j)){let dt=A(w),ft=n.get(j).__webglTexture;e.bindTexture(dt,ft),E(dt),e.unbindTexture()}}}let he=[],Ht=[];function $t(w){if(w.samples>0){if(ne(w)===!1){let g=w.textures,k=w.width,W=w.height,j=i.COLOR_BUFFER_BIT,dt=w.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ft=n.get(w),Q=g.length>1;if(Q)for(let pt=0;pt<g.length;pt++)e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+pt,i.RENDERBUFFER,null),e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+pt,i.TEXTURE_2D,null,0);e.bindFramebuffer(i.READ_FRAMEBUFFER,ft.__webglMultisampledFramebuffer);let it=w.texture.mipmaps;it&&it.length>0?e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglFramebuffer[0]):e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglFramebuffer);for(let pt=0;pt<g.length;pt++){if(w.resolveDepthBuffer&&(w.depthBuffer&&(j|=i.DEPTH_BUFFER_BIT),w.stencilBuffer&&w.resolveStencilBuffer&&(j|=i.STENCIL_BUFFER_BIT)),Q){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ft.__webglColorRenderbuffer[pt]);let Nt=n.get(g[pt]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,Nt,0)}i.blitFramebuffer(0,0,k,W,0,0,k,W,j,i.NEAREST),l===!0&&(he.length=0,Ht.length=0,he.push(i.COLOR_ATTACHMENT0+pt),w.depthBuffer&&w.storeMultisampledDepthBuffer===!1&&(he.push(dt),Ht.push(dt),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,Ht)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,he))}if(e.bindFramebuffer(i.READ_FRAMEBUFFER,null),e.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),Q)for(let pt=0;pt<g.length;pt++){e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+pt,i.RENDERBUFFER,ft.__webglColorRenderbuffer[pt]);let Nt=n.get(g[pt]).__webglTexture;e.bindFramebuffer(i.FRAMEBUFFER,ft.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+pt,i.TEXTURE_2D,Nt,0)}e.bindFramebuffer(i.DRAW_FRAMEBUFFER,ft.__webglMultisampledFramebuffer)}else if(w.depthBuffer&&w.storeMultisampledDepthBuffer===!1&&l){let g=w.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[g])}}}function qt(w){return Math.min(s.maxSamples,w.samples)}function ne(w){let g=n.get(w);return w.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&g.__useRenderToTexture!==!1}function L(w){let g=a.render.frame;u.get(w)!==g&&(u.set(w,g),w.update())}function jt(w,g){let k=w.colorSpace,W=w.format,j=w.type;return w.isCompressedTexture===!0||w.isVideoTexture===!0||k!==$s&&k!==Zn&&(Qt.getTransfer(k)===oe?(W!==fn||j!==Qe)&&Bt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):zt("WebGLTextures: Unsupported texture color space:",k)),g}function ie(w){return typeof HTMLImageElement<"u"&&w instanceof HTMLImageElement?(c.width=w.naturalWidth||w.width,c.height=w.naturalHeight||w.height):typeof VideoFrame<"u"&&w instanceof VideoFrame?(c.width=w.displayWidth,c.height=w.displayHeight):(c.width=w.width,c.height=w.height),c}this.allocateTextureUnit=q,this.resetTextureUnits=B,this.getTextureUnits=R,this.setTextureUnits=z,this.setTexture2D=rt,this.setTexture2DArray=$,this.setTexture3D=K,this.setTextureCube=st,this.rebindTextures=kt,this.setupRenderTarget=ee,this.updateRenderTargetMipmap=Gt,this.updateMultisampleRenderTarget=$t,this.setupDepthRenderbuffer=At,this.setupFrameBufferTexture=ct,this.useMultisampledRTT=ne,this.isReversedDepthBuffer=function(){return e.buffers.depth.getReversed()}}function h_(i,t){function e(n,s=Zn){let r,a=Qt.getTransfer(s);if(n===Qe)return i.UNSIGNED_BYTE;if(n===ka)return i.UNSIGNED_SHORT_4_4_4_4;if(n===za)return i.UNSIGNED_SHORT_5_5_5_1;if(n===zl)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===Hl)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Bl)return i.BYTE;if(n===kl)return i.SHORT;if(n===Rs)return i.UNSIGNED_SHORT;if(n===Ba)return i.INT;if(n===Tn)return i.UNSIGNED_INT;if(n===En)return i.FLOAT;if(n===wn)return i.HALF_FLOAT;if(n===Vl)return i.ALPHA;if(n===Gl)return i.RGB;if(n===fn)return i.RGBA;if(n===Ln)return i.DEPTH_COMPONENT;if(n===_i)return i.DEPTH_STENCIL;if(n===Wl)return i.RED;if(n===Ha)return i.RED_INTEGER;if(n===xi)return i.RG;if(n===Va)return i.RG_INTEGER;if(n===Ga)return i.RGBA_INTEGER;if(n===fr||n===pr||n===mr||n===gr)if(a===oe)if(r=t.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===fr)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===pr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===mr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===gr)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=t.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===fr)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===pr)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===mr)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===gr)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Wa||n===Xa||n===$a||n===qa)if(r=t.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Wa)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Xa)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===$a)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===qa)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Ya||n===Za||n===Ja||n===Ka||n===ja||n===_r||n===Qa)if(r=t.get("WEBGL_compressed_texture_etc"),r!==null){if(n===Ya||n===Za)return a===oe?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===Ja)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===Ka)return r.COMPRESSED_R11_EAC;if(n===ja)return r.COMPRESSED_SIGNED_R11_EAC;if(n===_r)return r.COMPRESSED_RG11_EAC;if(n===Qa)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===to||n===eo||n===no||n===io||n===so||n===ro||n===ao||n===oo||n===lo||n===co||n===ho||n===uo||n===fo||n===po)if(r=t.get("WEBGL_compressed_texture_astc"),r!==null){if(n===to)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===eo)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===no)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===io)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===so)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===ro)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===ao)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===oo)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===lo)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===co)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===ho)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===uo)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===fo)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===po)return a===oe?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===mo||n===go||n===_o)if(r=t.get("EXT_texture_compression_bptc"),r!==null){if(n===mo)return a===oe?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===go)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===_o)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===xo||n===yo||n===xr||n===vo)if(r=t.get("EXT_texture_compression_rgtc"),r!==null){if(n===xo)return r.COMPRESSED_RED_RGTC1_EXT;if(n===yo)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===xr)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===vo)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ps?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:e}}var u_=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,d_=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,_c=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,e){if(this.texture===null){let n=new ir(t.texture);(t.depthNear!==e.depthNear||t.depthFar!==e.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(t){if(this.texture!==null&&this.mesh===null){let e=t.cameras[0].viewport,n=new on({vertexShader:u_,fragmentShader:d_,uniforms:{depthColor:{value:this.texture},depthWidth:{value:e.z},depthHeight:{value:e.w}}});this.mesh=new Me(new sr(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},xc=class extends Sn{constructor(t,e){super();let n=this,s=null,r=1,a=null,o="local-floor",l=1,c=null,u=null,f=null,h=null,p=null,_=null,b=typeof XRWebGLBinding<"u",m=new _c,d={},E=e.getContextAttributes(),A=null,y=null,S=[],M=[],C=new Dt,x=null,T=null,P=new We;P.viewport=new be;let F=new We;F.viewport=new be;let N=[P,F],B=new Da,R=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let H=S[O];return H===void 0&&(H=new fs,S[O]=H),H.getTargetRaySpace()},this.getControllerGrip=function(O){let H=S[O];return H===void 0&&(H=new fs,S[O]=H),H.getGripSpace()},this.getHand=function(O){let H=S[O];return H===void 0&&(H=new fs,S[O]=H),H.getHandSpace()};function q(O){let H=M.indexOf(O.inputSource);if(H===-1)return;let at=S[H];at!==void 0&&(at.update(O.inputSource,O.frame,c||a),at.dispatchEvent({type:O.type,data:O.inputSource}))}function Z(){s.removeEventListener("select",q),s.removeEventListener("selectstart",q),s.removeEventListener("selectend",q),s.removeEventListener("squeeze",q),s.removeEventListener("squeezestart",q),s.removeEventListener("squeezeend",q),s.removeEventListener("end",Z),s.removeEventListener("inputsourceschange",rt);for(let O=0;O<S.length;O++){let H=M[O];H!==null&&(M[O]=null,S[O].disconnect(H))}R=null,z=null,m.reset();for(let O in d)delete d[O];if(t.setRenderTarget(A),p=null,h=null,f=null,s=null,y=null,nt.stop(),n.isPresenting=!1,t.setPixelRatio(x),t.setSize(C.width,C.height,!1),T!==null){let O=T.camera;O.fov=T.fov,O.zoom=T.zoom,O.updateProjectionMatrix(),T=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(O){r=O,n.isPresenting===!0&&Bt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){o=O,n.isPresenting===!0&&Bt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(O){c=O},this.getBaseLayer=function(){return h!==null?h:p},this.getBinding=function(){return f===null&&b&&(f=new XRWebGLBinding(s,e)),f},this.getFrame=function(){return _},this.getSession=function(){return s},this.setSession=async function(O){if(s=O,s!==null){if(A=t.getRenderTarget(),s.addEventListener("select",q),s.addEventListener("selectstart",q),s.addEventListener("selectend",q),s.addEventListener("squeeze",q),s.addEventListener("squeezestart",q),s.addEventListener("squeezeend",q),s.addEventListener("end",Z),s.addEventListener("inputsourceschange",rt),E.xrCompatible!==!0&&await e.makeXRCompatible(),x=t.getPixelRatio(),t.getSize(C),b&&"createProjectionLayer"in XRWebGLBinding.prototype){let at=null,ut=null,ct=null;E.depth&&(ct=E.stencil?e.DEPTH24_STENCIL8:e.DEPTH_COMPONENT24,at=E.stencil?_i:Ln,ut=E.stencil?Ps:Tn);let bt={colorFormat:e.RGBA8,depthFormat:ct,scaleFactor:r};f=this.getBinding(),h=f.createProjectionLayer(bt),s.updateRenderState({layers:[h]}),t.setPixelRatio(1),t.setSize(h.textureWidth,h.textureHeight,!1),y=new je(h.textureWidth,h.textureHeight,{format:fn,type:Qe,depthTexture:new oi(h.textureWidth,h.textureHeight,ut,void 0,void 0,void 0,void 0,void 0,void 0,at),stencilBuffer:E.stencil,colorSpace:t.outputColorSpace,samples:E.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1,storeMultisampledDepthBuffer:h.ignoreDepthValues===!1,storeMultisampledStencilBuffer:h.ignoreDepthValues===!1})}else{let at={antialias:E.antialias,alpha:!0,depth:E.depth,stencil:E.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(s,e,at),s.updateRenderState({baseLayer:p}),t.setPixelRatio(1),t.setSize(p.framebufferWidth,p.framebufferHeight,!1),y=new je(p.framebufferWidth,p.framebufferHeight,{format:fn,type:Qe,colorSpace:t.outputColorSpace,stencilBuffer:E.stencil,resolveDepthBuffer:p.ignoreDepthValues===!1,resolveStencilBuffer:p.ignoreDepthValues===!1,storeMultisampledDepthBuffer:p.ignoreDepthValues===!1,storeMultisampledStencilBuffer:p.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await s.requestReferenceSpace(o),nt.setContext(s),nt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function rt(O){for(let H=0;H<O.removed.length;H++){let at=O.removed[H],ut=M.indexOf(at);ut>=0&&(M[ut]=null,S[ut].disconnect(at))}for(let H=0;H<O.added.length;H++){let at=O.added[H],ut=M.indexOf(at);if(ut===-1){for(let bt=0;bt<S.length;bt++)if(bt>=M.length){M.push(at),ut=bt;break}else if(M[bt]===null){M[bt]=at,ut=bt;break}if(ut===-1)break}let ct=S[ut];ct&&ct.connect(at)}}let $=new U,K=new U;function st(O,H,at){$.setFromMatrixPosition(H.matrixWorld),K.setFromMatrixPosition(at.matrixWorld);let ut=$.distanceTo(K),ct=H.projectionMatrix.elements,bt=at.projectionMatrix.elements,Lt=ct[14]/(ct[10]-1),At=ct[14]/(ct[10]+1),kt=(ct[9]+1)/ct[5],ee=(ct[9]-1)/ct[5],Gt=(ct[8]-1)/ct[0],he=(bt[8]+1)/bt[0],Ht=Lt*Gt,$t=Lt*he,qt=ut/(-Gt+he),ne=qt*-Gt;if(H.matrixWorld.decompose(O.position,O.quaternion,O.scale),O.translateX(ne),O.translateZ(qt),O.matrixWorld.compose(O.position,O.quaternion,O.scale),O.matrixWorldInverse.copy(O.matrixWorld).invert(),ct[10]===-1)O.projectionMatrix.copy(H.projectionMatrix),O.projectionMatrixInverse.copy(H.projectionMatrixInverse);else{let L=Lt+qt,jt=At+qt,ie=Ht-ne,w=$t+(ut-ne),g=kt*At/jt*L,k=ee*At/jt*L;O.projectionMatrix.makePerspective(ie,w,g,k,L,jt),O.projectionMatrixInverse.copy(O.projectionMatrix).invert()}}function Tt(O,H){H===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices(H.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(s===null)return;let H=O.near,at=O.far;m.texture!==null&&(m.depthNear>0&&(H=m.depthNear),m.depthFar>0&&(at=m.depthFar)),B.near=F.near=P.near=H,B.far=F.far=P.far=at,(R!==B.near||z!==B.far)&&(s.updateRenderState({depthNear:B.near,depthFar:B.far}),R=B.near,z=B.far),B.layers.mask=O.layers.mask|6,P.layers.mask=B.layers.mask&-5,F.layers.mask=B.layers.mask&-3;let ut=O.parent,ct=B.cameras;Tt(B,ut);for(let bt=0;bt<ct.length;bt++)Tt(ct[bt],ut);ct.length===2?st(B,P,F):B.projectionMatrix.copy(P.projectionMatrix),T===null&&O.isPerspectiveCamera&&(T={camera:O,fov:O.fov,zoom:O.zoom}),ht(O,B,ut)};function ht(O,H,at){at===null?O.matrix.copy(H.matrixWorld):(O.matrix.copy(at.matrixWorld),O.matrix.invert(),O.matrix.multiply(H.matrixWorld)),O.matrix.decompose(O.position,O.quaternion,O.scale),O.updateMatrixWorld(!0),O.projectionMatrix.copy(H.projectionMatrix),O.projectionMatrixInverse.copy(H.projectionMatrixInverse),O.isPerspectiveCamera&&(O.fov=us*2*Math.atan(1/O.projectionMatrix.elements[5]),O.zoom=1)}this.getCamera=function(){return B},this.getFoveation=function(){if(!(h===null&&p===null))return l},this.setFoveation=function(O){l=O,h!==null&&(h.fixedFoveation=O),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=O)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(B)},this.getCameraTexture=function(O){return d[O]};let Y=null;function J(O,H){if(u=H.getViewerPose(c||a),_=H,u!==null){let at=u.views;p!==null&&(t.setRenderTargetFramebuffer(y,p.framebuffer),t.setRenderTarget(y));let ut=!1;at.length!==B.cameras.length&&(B.cameras.length=0,ut=!0);for(let At=0;At<at.length;At++){let kt=at[At],ee=null;if(p!==null)ee=p.getViewport(kt);else{let he=f.getViewSubImage(h,kt);ee=he.viewport,At===0&&(t.setRenderTargetTextures(y,he.colorTexture,he.depthStencilTexture),t.setRenderTarget(y))}let Gt=N[At];Gt===void 0&&(Gt=new We,Gt.layers.enable(At),Gt.viewport=new be,N[At]=Gt),Gt.matrix.fromArray(kt.transform.matrix),Gt.matrix.decompose(Gt.position,Gt.quaternion,Gt.scale),Gt.projectionMatrix.fromArray(kt.projectionMatrix),Gt.projectionMatrixInverse.copy(Gt.projectionMatrix).invert(),Gt.viewport.set(ee.x,ee.y,ee.width,ee.height),At===0&&(B.matrix.copy(Gt.matrix),B.matrix.decompose(B.position,B.quaternion,B.scale)),ut===!0&&B.cameras.push(Gt)}let ct=s.enabledFeatures;if(ct&&ct.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&b){f=n.getBinding();let At=f.getDepthInformation(at[0]);At&&At.isValid&&At.texture&&m.init(At,s.renderState)}if(ct&&ct.includes("camera-access")&&b){t.state.unbindTexture(),f=n.getBinding();for(let At=0;At<at.length;At++){let kt=at[At].camera;if(kt){let ee=d[kt];ee||(ee=new ir,d[kt]=ee);let Gt=f.getCameraImage(kt);ee.sourceTexture=Gt}}}}for(let at=0;at<S.length;at++){let ut=M[at],ct=S[at];ut!==null&&ct!==void 0&&ct.update(ut,H,c||a)}Y&&Y(O,H),H.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:H}),_=null}let nt=new Cu;nt.setAnimationLoop(J),this.setAnimationLoop=function(O){Y=O},this.dispose=function(){}}},f_=new ye,Nu=new Vt;Nu.set(-1,0,0,0,1,0,0,0,1);function p_(i,t){function e(m,d){m.matrixAutoUpdate===!0&&m.updateMatrix(),d.value.copy(m.matrix)}function n(m,d){d.color.getRGB(m.fogColor.value,Zl(i)),d.isFog?(m.fogNear.value=d.near,m.fogFar.value=d.far):d.isFogExp2&&(m.fogDensity.value=d.density)}function s(m,d,E,A,y){d.isNodeMaterial?d.uniformsNeedUpdate=!1:d.isMeshBasicMaterial?r(m,d):d.isMeshLambertMaterial?(r(m,d),d.envMap&&(m.envMapIntensity.value=d.envMapIntensity)):d.isMeshToonMaterial?(r(m,d),f(m,d)):d.isMeshPhongMaterial?(r(m,d),u(m,d),d.envMap&&(m.envMapIntensity.value=d.envMapIntensity)):d.isMeshStandardMaterial?(r(m,d),h(m,d),d.isMeshPhysicalMaterial&&p(m,d,y)):d.isMeshMatcapMaterial?(r(m,d),_(m,d)):d.isMeshDepthMaterial?r(m,d):d.isMeshDistanceMaterial?(r(m,d),b(m,d)):d.isMeshNormalMaterial?r(m,d):d.isLineBasicMaterial?(a(m,d),d.isLineDashedMaterial&&o(m,d)):d.isPointsMaterial?l(m,d,E,A):d.isSpriteMaterial?c(m,d):d.isShadowMaterial?(m.color.value.copy(d.color),m.opacity.value=d.opacity):d.isShaderMaterial&&(d.uniformsNeedUpdate=!1)}function r(m,d){m.opacity.value=d.opacity,d.color&&m.diffuse.value.copy(d.color),d.emissive&&m.emissive.value.copy(d.emissive).multiplyScalar(d.emissiveIntensity),d.map&&(m.map.value=d.map,e(d.map,m.mapTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.bumpMap&&(m.bumpMap.value=d.bumpMap,e(d.bumpMap,m.bumpMapTransform),m.bumpScale.value=d.bumpScale,d.side===Je&&(m.bumpScale.value*=-1)),d.normalMap&&(m.normalMap.value=d.normalMap,e(d.normalMap,m.normalMapTransform),m.normalScale.value.copy(d.normalScale),d.side===Je&&m.normalScale.value.negate()),d.displacementMap&&(m.displacementMap.value=d.displacementMap,e(d.displacementMap,m.displacementMapTransform),m.displacementScale.value=d.displacementScale,m.displacementBias.value=d.displacementBias),d.emissiveMap&&(m.emissiveMap.value=d.emissiveMap,e(d.emissiveMap,m.emissiveMapTransform)),d.specularMap&&(m.specularMap.value=d.specularMap,e(d.specularMap,m.specularMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest);let E=t.get(d),A=E.envMap,y=E.envMapRotation;A&&(m.envMap.value=A,m.envMapRotation.value.setFromMatrix4(f_.makeRotationFromEuler(y)).transpose(),A.isCubeTexture&&A.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Nu),m.reflectivity.value=d.reflectivity,m.ior.value=d.ior,m.refractionRatio.value=d.refractionRatio),d.lightMap&&(m.lightMap.value=d.lightMap,m.lightMapIntensity.value=d.lightMapIntensity,e(d.lightMap,m.lightMapTransform)),d.aoMap&&(m.aoMap.value=d.aoMap,m.aoMapIntensity.value=d.aoMapIntensity,e(d.aoMap,m.aoMapTransform))}function a(m,d){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,d.map&&(m.map.value=d.map,e(d.map,m.mapTransform))}function o(m,d){m.dashSize.value=d.dashSize,m.totalSize.value=d.dashSize+d.gapSize,m.scale.value=d.scale}function l(m,d,E,A){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,m.size.value=d.size*E,m.scale.value=A*.5,d.map&&(m.map.value=d.map,e(d.map,m.uvTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest)}function c(m,d){m.diffuse.value.copy(d.color),m.opacity.value=d.opacity,m.rotation.value=d.rotation,d.map&&(m.map.value=d.map,e(d.map,m.mapTransform)),d.alphaMap&&(m.alphaMap.value=d.alphaMap,e(d.alphaMap,m.alphaMapTransform)),d.alphaTest>0&&(m.alphaTest.value=d.alphaTest)}function u(m,d){m.specular.value.copy(d.specular),m.shininess.value=Math.max(d.shininess,1e-4)}function f(m,d){d.gradientMap&&(m.gradientMap.value=d.gradientMap)}function h(m,d){m.metalness.value=d.metalness,d.metalnessMap&&(m.metalnessMap.value=d.metalnessMap,e(d.metalnessMap,m.metalnessMapTransform)),m.roughness.value=d.roughness,d.roughnessMap&&(m.roughnessMap.value=d.roughnessMap,e(d.roughnessMap,m.roughnessMapTransform)),d.envMap&&(m.envMapIntensity.value=d.envMapIntensity)}function p(m,d,E){m.ior.value=d.ior,d.sheen>0&&(m.sheenColor.value.copy(d.sheenColor).multiplyScalar(d.sheen),m.sheenRoughness.value=d.sheenRoughness,d.sheenColorMap&&(m.sheenColorMap.value=d.sheenColorMap,e(d.sheenColorMap,m.sheenColorMapTransform)),d.sheenRoughnessMap&&(m.sheenRoughnessMap.value=d.sheenRoughnessMap,e(d.sheenRoughnessMap,m.sheenRoughnessMapTransform))),d.clearcoat>0&&(m.clearcoat.value=d.clearcoat,m.clearcoatRoughness.value=d.clearcoatRoughness,d.clearcoatMap&&(m.clearcoatMap.value=d.clearcoatMap,e(d.clearcoatMap,m.clearcoatMapTransform)),d.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=d.clearcoatRoughnessMap,e(d.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),d.clearcoatNormalMap&&(m.clearcoatNormalMap.value=d.clearcoatNormalMap,e(d.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(d.clearcoatNormalScale),d.side===Je&&m.clearcoatNormalScale.value.negate())),d.dispersion>0&&(m.dispersion.value=d.dispersion),d.retroreflectivity>0&&(m.retroreflectivity.value=d.retroreflectivity),d.iridescence>0&&(m.iridescence.value=d.iridescence,m.iridescenceIOR.value=d.iridescenceIOR,m.iridescenceThicknessMinimum.value=d.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=d.iridescenceThicknessRange[1],d.iridescenceMap&&(m.iridescenceMap.value=d.iridescenceMap,e(d.iridescenceMap,m.iridescenceMapTransform)),d.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=d.iridescenceThicknessMap,e(d.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),d.transmission>0&&(m.transmission.value=d.transmission,m.transmissionSamplerMap.value=E.texture,m.transmissionSamplerSize.value.set(E.width,E.height),d.transmissionMap&&(m.transmissionMap.value=d.transmissionMap,e(d.transmissionMap,m.transmissionMapTransform)),m.thickness.value=d.thickness,d.thicknessMap&&(m.thicknessMap.value=d.thicknessMap,e(d.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=d.attenuationDistance,m.attenuationColor.value.copy(d.attenuationColor)),d.anisotropy>0&&(m.anisotropyVector.value.set(d.anisotropy*Math.cos(d.anisotropyRotation),d.anisotropy*Math.sin(d.anisotropyRotation)),d.anisotropyMap&&(m.anisotropyMap.value=d.anisotropyMap,e(d.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=d.specularIntensity,m.specularColor.value.copy(d.specularColor),d.specularColorMap&&(m.specularColorMap.value=d.specularColorMap,e(d.specularColorMap,m.specularColorMapTransform)),d.specularIntensityMap&&(m.specularIntensityMap.value=d.specularIntensityMap,e(d.specularIntensityMap,m.specularIntensityMapTransform))}function _(m,d){d.matcap&&(m.matcap.value=d.matcap)}function b(m,d){let E=t.get(d).light;m.referencePosition.value.setFromMatrixPosition(E.matrixWorld),m.nearDistance.value=E.shadow.camera.near,m.farDistance.value=E.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function m_(i,t,e,n){let s={},r={},a=[],o=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(y,S){let M=S.program;n.uniformBlockBinding(y,M)}function c(y,S){let M=s[y.id];M===void 0&&(m(y),M=u(y),s[y.id]=M,y.addEventListener("dispose",E));let C=S.program;n.updateUBOMapping(y,C);let x=t.render.frame;r[y.id]!==x&&(h(y),r[y.id]=x)}function u(y){let S=f();y.__bindingPointIndex=S;let M=i.createBuffer(),C=y.__size,x=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,M),i.bufferData(i.UNIFORM_BUFFER,C,x),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,S,M),M}function f(){for(let y=0;y<o;y++)if(a.indexOf(y)===-1)return a.push(y),y;return zt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(y){let S=s[y.id],M=y.uniforms,C=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,S);for(let x=0,T=M.length;x<T;x++){let P=M[x];if(Array.isArray(P))for(let F=0,N=P.length;F<N;F++)p(P[F],x,F,C);else p(P,x,0,C)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function p(y,S,M,C){if(b(y,S,M,C)===!0){let x=y.__offset,T=y.value;if(Array.isArray(T)){let P=0;for(let F=0;F<T.length;F++){let N=T[F],B=d(N);_(N,y.__data,P),typeof N!="number"&&typeof N!="boolean"&&!N.isMatrix3&&!ArrayBuffer.isView(N)&&(P+=B.storage/Float32Array.BYTES_PER_ELEMENT)}}else _(T,y.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,x,y.__data)}}function _(y,S,M){typeof y=="number"||typeof y=="boolean"?S[0]=y:y.isMatrix3?(S[0]=y.elements[0],S[1]=y.elements[1],S[2]=y.elements[2],S[3]=0,S[4]=y.elements[3],S[5]=y.elements[4],S[6]=y.elements[5],S[7]=0,S[8]=y.elements[6],S[9]=y.elements[7],S[10]=y.elements[8],S[11]=0):ArrayBuffer.isView(y)?S.set(new y.constructor(y.buffer,y.byteOffset,S.length)):y.toArray(S,M)}function b(y,S,M,C){let x=y.value,T=S+"_"+M;if(C[T]===void 0)return typeof x=="number"||typeof x=="boolean"?C[T]=x:ArrayBuffer.isView(x)?C[T]=x.slice():C[T]=x.clone(),!0;{let P=C[T];if(typeof x=="number"||typeof x=="boolean"){if(P!==x)return C[T]=x,!0}else{if(ArrayBuffer.isView(x))return!0;if(P.equals(x)===!1)return P.copy(x),!0}}return!1}function m(y){let S=y.uniforms,M=0,C=16;for(let T=0,P=S.length;T<P;T++){let F=Array.isArray(S[T])?S[T]:[S[T]];for(let N=0,B=F.length;N<B;N++){let R=F[N],z=Array.isArray(R.value)?R.value:[R.value];for(let q=0,Z=z.length;q<Z;q++){let rt=z[q],$=d(rt),K=M%C,st=K%$.boundary,Tt=K+st;M+=st,Tt!==0&&C-Tt<$.storage&&(M+=C-Tt),R.__data=new Float32Array($.storage/Float32Array.BYTES_PER_ELEMENT),R.__offset=M,M+=$.storage}}}let x=M%C;return x>0&&(M+=C-x),y.__size=M,y.__cache={},this}function d(y){let S={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(S.boundary=4,S.storage=4):y.isVector2?(S.boundary=8,S.storage=8):y.isVector3||y.isColor?(S.boundary=16,S.storage=12):y.isVector4?(S.boundary=16,S.storage=16):y.isMatrix3?(S.boundary=48,S.storage=48):y.isMatrix4?(S.boundary=64,S.storage=64):y.isTexture?Bt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(y)?(S.boundary=16,S.storage=y.byteLength):Bt("WebGLRenderer: Unsupported uniform value type.",y),S}function E(y){let S=y.target;S.removeEventListener("dispose",E);let M=a.indexOf(S.__bindingPointIndex);a.splice(M,1),i.deleteBuffer(s[S.id]),delete s[S.id],delete r[S.id]}function A(){for(let y in s)i.deleteBuffer(s[y]);a=[],s={},r={}}return{bind:l,update:c,dispose:A}}var g_=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),Nn=null;function __(){return Nn===null&&(Nn=new ma(g_,16,16,xi,wn),Nn.name="DFG_LUT",Nn.minFilter=Fe,Nn.magFilter=Fe,Nn.wrapS=In,Nn.wrapT=In,Nn.generateMipmaps=!1,Nn.needsUpdate=!0),Nn}var Co=class{constructor(t={}){let{canvas:e=jh(),context:n=null,depth:s=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:f=!1,reversedDepthBuffer:h=!1,outputBufferType:p=Qe}=t;this.isWebGLRenderer=!0;let _;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");_=n.getContextAttributes().alpha}else _=a;let b=p,m=new Set([Ga,Va,Ha]),d=new Set([Qe,Tn,Rs,Ps,ka,za]),E=new Uint32Array(4),A=new Int32Array(4),y=new U,S=null,M=null,C=[],x=[],T=null;this.domElement=e,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Mn,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let P=this,F=!1,N=null,B=null,R=null,z=null;this._outputColorSpace=Ge;let q=0,Z=0,rt=null,$=-1,K=null,st=new be,Tt=new be,ht=null,Y=new Xt(0),J=0,nt=e.width,O=e.height,H=1,at=null,ut=null,ct=new be(0,0,nt,O),bt=new be(0,0,nt,O),Lt=!1,At=new _s,kt=!1,ee=!1,Gt=new ye,he=new U,Ht=new be,$t={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},qt=!1;function ne(){return rt===null?H:1}let L=n;function jt(v,I){return e.getContext(v,I)}let ie,w,g,k,W,j,dt,ft,Q,it,pt,Nt,xt,mt,Ut,Ot,Wt,D,gt,et,_t,Mt,lt;try{let v={alpha:!0,depth:s,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:u,failIfMajorPerformanceCaveat:f};if("setAttribute"in e&&e.setAttribute("data-engine",`three.js r${"186"}`),e.addEventListener("webglcontextlost",fe,!1),e.addEventListener("webglcontextrestored",re,!1),e.addEventListener("webglcontextcreationerror",mn,!1),L===null){let I="webgl2";if(L=jt(I,v),L===null)throw jt(I)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}Ft()}catch(v){throw e.removeEventListener("webglcontextlost",fe,!1),e.removeEventListener("webglcontextrestored",re,!1),e.removeEventListener("webglcontextcreationerror",mn,!1),zt("WebGLRenderer: "+v.message),v}function Ft(){ie=new Tg(L),ie.init(),_t=new h_(L,ie),w=new pg(L,ie,t,_t),g=new l_(L,ie),w.reversedDepthBuffer&&h&&g.buffers.depth.setReversed(!0),B=L.createFramebuffer(),R=L.createFramebuffer(),z=L.createFramebuffer(),k=new Ag(L),W=new Y0,j=new c_(L,ie,g,W,w,_t,k),dt=new Mg(P),ft=new Rf(L),Mt=new dg(L,ft),Q=new Eg(L,ft,k,Mt),it=new Rg(L,Q,ft,Mt,k),D=new Cg(L,w,j),Ut=new mg(W),pt=new q0(P,dt,ie,w,Mt,Ut),Nt=new p_(P,W),xt=new J0,mt=new n_(ie),Wt=new ug(P,dt,g,it,_,l),Ot=new o_(P,it,w),lt=new m_(L,k,w,g),gt=new fg(L,ie,k),et=new wg(L,ie,k),k.programs=pt.programs,P.capabilities=w,P.extensions=ie,P.properties=W,P.renderLists=xt,P.shadowMap=Ot,P.state=g,P.info=k}b!==Qe&&(T=new Ig(b,e.width,e.height,o,s,r));let Pt=new xc(P,L);this.xr=Pt,this.getContext=function(){return L},this.getContextAttributes=function(){return L.getContextAttributes()},this.forceContextLoss=function(){let v=ie.get("WEBGL_lose_context");v&&v.loseContext()},this.forceContextRestore=function(){let v=ie.get("WEBGL_lose_context");v&&v.restoreContext()},this.getPixelRatio=function(){return H},this.setPixelRatio=function(v){v!==void 0&&(H=v,this.setSize(nt,O,!1))},this.getSize=function(v){return v.set(nt,O)},this.setSize=function(v,I,X=!0){if(Pt.isPresenting){Bt("WebGLRenderer: Can't change size while VR device is presenting.");return}nt=v,O=I,e.width=Math.floor(v*H),e.height=Math.floor(I*H),X===!0&&(e.style.width=v+"px",e.style.height=I+"px"),T!==null&&T.setSize(e.width,e.height),this.setViewport(0,0,v,I)},this.getDrawingBufferSize=function(v){return v.set(nt*H,O*H).floor()},this.setDrawingBufferSize=function(v,I,X){nt=v,O=I,H=X,e.width=Math.floor(v*X),e.height=Math.floor(I*X),this.setViewport(0,0,v,I)},this.setEffects=function(v){if(b===Qe){zt("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(v){for(let I=0;I<v.length;I++)if(v[I].isOutputPass===!0){Bt("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}T.setEffects(v||[])},this.getCurrentViewport=function(v){return v.copy(st)},this.getViewport=function(v){return v.copy(ct)},this.setViewport=function(v,I,X,V){v.isVector4?ct.set(v.x,v.y,v.z,v.w):ct.set(v,I,X,V),g.viewport(st.copy(ct).multiplyScalar(H).round())},this.getScissor=function(v){return v.copy(bt)},this.setScissor=function(v,I,X,V){v.isVector4?bt.set(v.x,v.y,v.z,v.w):bt.set(v,I,X,V),g.scissor(Tt.copy(bt).multiplyScalar(H).round())},this.getScissorTest=function(){return Lt},this.setScissorTest=function(v){g.setScissorTest(Lt=v)},this.setOpaqueSort=function(v){at=v},this.setTransparentSort=function(v){ut=v},this.getClearColor=function(v){return v.copy(Wt.getClearColor())},this.setClearColor=function(){Wt.setClearColor(...arguments)},this.getClearAlpha=function(){return Wt.getClearAlpha()},this.setClearAlpha=function(){Wt.setClearAlpha(...arguments)},this.clear=function(v=!0,I=!0,X=!0){let V=0;if(v){let G=!1;if(rt!==null){let St=rt.texture.format;G=m.has(St)}if(G){let St=rt.texture.type,wt=d.has(St),vt=Wt.getClearColor(),Ct=Wt.getClearAlpha(),It=vt.r,Yt=vt.g,Kt=vt.b;wt?(E[0]=It,E[1]=Yt,E[2]=Kt,E[3]=Ct,L.clearBufferuiv(L.COLOR,0,E)):(A[0]=It,A[1]=Yt,A[2]=Kt,A[3]=Ct,L.clearBufferiv(L.COLOR,0,A))}else V|=L.COLOR_BUFFER_BIT}I&&(V|=L.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),X&&(V|=L.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),V!==0&&L.clear(V)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(v){v.setRenderer(this),N=v},this.dispose=function(){e.removeEventListener("webglcontextlost",fe,!1),e.removeEventListener("webglcontextrestored",re,!1),e.removeEventListener("webglcontextcreationerror",mn,!1),Wt.dispose(),xt.dispose(),mt.dispose(),W.dispose(),dt.dispose(),it.dispose(),Mt.dispose(),lt.dispose(),pt.dispose(),Pt.dispose(),Pt.removeEventListener("sessionstart",Ic),Pt.removeEventListener("sessionend",Lc),vi.stop()};function fe(v){v.preventDefault(),Zs("WebGLRenderer: Context Lost."),F=!0}function re(){Zs("WebGLRenderer: Context Restored."),F=!1;let v=k.autoReset,I=Ot.enabled,X=Ot.autoUpdate,V=Ot.needsUpdate,G=Ot.type;Ft(),k.autoReset=v,Ot.enabled=I,Ot.autoUpdate=X,Ot.needsUpdate=V,Ot.type=G}function mn(v){zt("WebGLRenderer: A WebGL context could not be created. Reason: ",v.statusMessage)}function An(v){let I=v.target;I.removeEventListener("dispose",An),Qu(I)}function Qu(v){td(v),W.remove(v)}function td(v){let I=W.get(v).programs;I!==void 0&&(I.forEach(function(X){pt.releaseProgram(X)}),v.isShaderMaterial&&pt.releaseShaderCache(v))}this.renderBufferDirect=function(v,I,X,V,G,St){I===null&&(I=$t);let wt=G.isMesh&&G.matrixWorld.determinantAffine()<0,vt=id(v,I,X,V,G);g.setMaterial(V,wt);let Ct=X.index,It=1;if(V.wireframe===!0){if(Ct=Q.getWireframeAttribute(X),Ct===void 0)return;It=2}let Yt=X.drawRange,Kt=X.attributes.position,Rt=Yt.start*It,ae=(Yt.start+Yt.count)*It;St!==null&&(Rt=Math.max(Rt,St.start*It),ae=Math.min(ae,(St.start+St.count)*It)),Ct!==null?(Rt=Math.max(Rt,0),ae=Math.min(ae,Ct.count)):Kt!=null&&(Rt=Math.max(Rt,0),ae=Math.min(ae,Kt.count));let Ae=ae-Rt;if(Ae<0||Ae===1/0)return;Mt.setup(G,V,vt,X,Ct);let ge,de=gt;if(Ct!==null&&(ge=ft.get(Ct),de=et,de.setIndex(ge)),G.isMesh)V.wireframe===!0?(g.setLineWidth(V.wireframeLinewidth*ne()),de.setMode(L.LINES)):de.setMode(L.TRIANGLES);else if(G.isLine){let ke=V.linewidth;ke===void 0&&(ke=1),g.setLineWidth(ke*ne()),G.isLineSegments?de.setMode(L.LINES):G.isLineLoop?de.setMode(L.LINE_LOOP):de.setMode(L.LINE_STRIP)}else G.isPoints?de.setMode(L.POINTS):G.isSprite&&de.setMode(L.TRIANGLES);if(G.isBatchedMesh)if(ie.get("WEBGL_multi_draw"))de.renderMultiDraw(G._multiDrawStarts,G._multiDrawCounts,G._multiDrawCount);else{let ke=G._multiDrawStarts,Et=G._multiDrawCounts,$e=G._multiDrawCount,se=Ct?ft.get(Ct).bytesPerElement:1,hn=W.get(V).currentProgram.getUniforms();for(let Cn=0;Cn<$e;Cn++)hn.setValue(L,"_gl_DrawID",Cn),de.render(ke[Cn]/se,Et[Cn])}else if(G.isInstancedMesh)de.renderInstances(Rt,Ae,G.count);else if(X.isInstancedBufferGeometry){let ke=X._maxInstanceCount!==void 0?X._maxInstanceCount:1/0,Et=Math.min(X.instanceCount,ke);de.renderInstances(Rt,Ae,Et)}else de.render(Rt,Ae)};function Pc(v,I,X,V){N!==null&&v.isNodeMaterial&&N.setObject(V,v),kt===!0&&Ut.setState(v,X,!1),v.transparent===!0&&v.side===Ke&&v.forceSinglePass===!1?(v.side=Je,v.needsUpdate=!0,wr(v,I,V),v.side=pi,v.needsUpdate=!0,wr(v,I,V),v.side=Ke):wr(v,I,V)}this.compile=function(v,I,X=null){X===null&&(X=v),N!==null&&N.renderStart(v,I,X),M=mt.get(X),M.init(I),x.push(M),X.traverseVisible(function(G){G.isLight&&G.layers.test(I.layers)&&(M.pushLight(G),G.castShadow&&M.pushShadow(G))}),v!==X&&v.traverseVisible(function(G){G.isLight&&G.layers.test(I.layers)&&(M.pushLight(G),G.castShadow&&M.pushShadow(G))}),M.setupLights(),N!==null&&N.updateLights(M.state.lightsArray),ee=this.localClippingEnabled,kt=Ut.init(this.clippingPlanes,ee),kt===!0&&Ut.setGlobalState(this.clippingPlanes,I),N!==null&&Ot.render(M.state.shadowsArray,X,I);let V=new Set;return v.traverse(function(G){if(!(G.isMesh||G.isPoints||G.isLine||G.isSprite))return;let St=G.material;if(St)if(Array.isArray(St))for(let wt=0;wt<St.length;wt++){let vt=St[wt];Pc(vt,X,I,G),V.add(vt)}else Pc(St,X,I,G),V.add(St)}),M=x.pop(),N!==null&&N.renderEnd(),V},this.compileAsync=function(v,I,X=null){let V=this.compile(v,I,X);return new Promise(G=>{function St(){if(V.forEach(function(wt){let Ct=W.get(wt).currentProgram;(Ct===void 0||Ct.isReady())&&V.delete(wt)}),V.size===0){G(v);return}setTimeout(St,10)}ie.get("KHR_parallel_shader_compile")!==null?St():setTimeout(St,10)})};let zo=null;function ed(v){zo&&zo(v)}function Ic(){vi.stop()}function Lc(){vi.start()}let vi=new Cu;vi.setAnimationLoop(ed),typeof self<"u"&&vi.setContext(self),this.setAnimationLoop=function(v){zo=v,Pt.setAnimationLoop(v),v===null?vi.stop():vi.start()},Pt.addEventListener("sessionstart",Ic),Pt.addEventListener("sessionend",Lc),this.render=function(v,I){if(I!==void 0&&I.isCamera!==!0){zt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(F===!0)return;N!==null&&N.renderStart(v,I);let X=Pt.enabled===!0&&Pt.isPresenting===!0,V=T!==null&&(rt===null||X)&&T.begin(P,rt);if(v.matrixWorldAutoUpdate===!0&&v.updateMatrixWorld(),I.parent===null&&I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),Pt.enabled===!0&&Pt.isPresenting===!0&&(T===null||T.isCompositing()===!1)&&(Pt.cameraAutoUpdate===!0&&Pt.updateCamera(I),I=Pt.getCamera()),v.isScene===!0&&v.onBeforeRender(P,v,I,rt),M=mt.get(v,x.length),M.init(I),M.state.textureUnits=j.getTextureUnits(),x.push(M),Gt.multiplyMatrices(I.projectionMatrix,I.matrixWorldInverse),At.setFromProjectionMatrix(Gt,bn,I.reversedDepth),ee=this.localClippingEnabled,kt=Ut.init(this.clippingPlanes,ee),S=xt.get(v,C.length),S.init(),C.push(S),Pt.enabled===!0&&Pt.isPresenting===!0){let wt=P.xr.getDepthSensingMesh();wt!==null&&Ho(wt,I,-1/0,P.sortObjects)}Ho(v,I,0,P.sortObjects),S.finish(),N!==null&&N.updateLights(M.state.lightsArray),P.sortObjects===!0&&S.sort(at,ut),qt=Pt.enabled===!1||Pt.isPresenting===!1||Pt.hasDepthSensing()===!1,qt&&Wt.addToRenderList(S,v),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),kt===!0&&Ut.beginShadows();let G=M.state.shadowsArray;if(Ot.render(G,v,I),kt===!0&&Ut.endShadows(),(V&&T.hasRenderPass())===!1){let wt=S.opaque,vt=S.transmissive;if(M.setupLights(),I.isArrayCamera){let Ct=I.cameras;if(vt.length>0)for(let It=0,Yt=Ct.length;It<Yt;It++){let Kt=Ct[It];Nc(wt,vt,v,Kt)}qt&&Wt.render(v);for(let It=0,Yt=Ct.length;It<Yt;It++){let Kt=Ct[It];Dc(S,v,Kt,Kt.viewport)}}else vt.length>0&&Nc(wt,vt,v,I),qt&&Wt.render(v),Dc(S,v,I)}rt!==null&&Z===0&&(j.updateMultisampleRenderTarget(rt),j.updateRenderTargetMipmap(rt)),V&&T.end(P),v.isScene===!0&&v.onAfterRender(P,v,I),Mt.resetDefaultState(),$=-1,K=null,x.pop(),x.length>0?(M=x[x.length-1],j.setTextureUnits(M.state.textureUnits),kt===!0&&Ut.setGlobalState(P.clippingPlanes,M.state.camera)):M=null,C.pop(),C.length>0?S=C[C.length-1]:S=null,N!==null&&N.renderEnd()};function Ho(v,I,X,V){if(v.visible===!1)return;if(v.layers.test(I.layers)){if(v.isGroup)X=v.renderOrder;else if(v.isLOD)v.autoUpdate===!0&&v.update(I);else if(v.isLightProbeGrid)M.pushLightProbeGrid(v);else if(v.isLight)M.pushLight(v),v.castShadow&&M.pushShadow(v);else if(v.isSprite){if(!v.frustumCulled||v.intersectsFrustum(At)){V&&Ht.setFromMatrixPosition(v.matrixWorld).applyMatrix4(Gt);let wt=it.update(v),vt=v.material;vt.visible&&S.push(v,wt,vt,X,Ht.z,null,I)}}else if((v.isMesh||v.isLine||v.isPoints)&&(!v.frustumCulled||v.intersectsFrustum(At))){let wt=it.update(v),vt=v.material;if(V&&(v.boundingSphere!==void 0?(v.boundingSphere===null&&v.computeBoundingSphere(),Ht.copy(v.boundingSphere.center)):(wt.boundingSphere===null&&wt.computeBoundingSphere(),Ht.copy(wt.boundingSphere.center)),Ht.applyMatrix4(v.matrixWorld).applyMatrix4(Gt)),Array.isArray(vt)){let Ct=wt.groups;for(let It=0,Yt=Ct.length;It<Yt;It++){let Kt=Ct[It],Rt=vt[Kt.materialIndex];Rt&&Rt.visible&&S.push(v,wt,Rt,X,Ht.z,Kt,I)}}else vt.visible&&S.push(v,wt,vt,X,Ht.z,null,I)}}let St=v.children;for(let wt=0,vt=St.length;wt<vt;wt++)Ho(St[wt],I,X,V)}function Dc(v,I,X,V){let{opaque:G,transmissive:St,transparent:wt}=v;M.setupLightsView(X),kt===!0&&Ut.setGlobalState(P.clippingPlanes,X),V&&g.viewport(st.copy(V)),G.length>0&&Er(G,I,X),St.length>0&&Er(St,I,X),wt.length>0&&Er(wt,I,X),g.buffers.depth.setTest(!0),g.buffers.depth.setMask(!0),g.buffers.color.setMask(!0),g.setPolygonOffset(!1)}function Nc(v,I,X,V){if((X.isScene===!0?X.overrideMaterial:null)!==null)return;if(M.state.transmissionRenderTarget[V.id]===void 0){let Rt=ie.has("EXT_color_buffer_half_float")||ie.has("EXT_color_buffer_float");M.state.transmissionRenderTarget[V.id]=new je(1,1,{generateMipmaps:!0,type:Rt?wn:Qe,minFilter:gi,samples:Math.max(4,w.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Qt.workingColorSpace})}let St=M.state.transmissionRenderTarget[V.id],wt=V.viewport||st;St.setSize(wt.z*P.transmissionResolutionScale,wt.w*P.transmissionResolutionScale);let vt=P.getRenderTarget(),Ct=P.getActiveCubeFace(),It=P.getActiveMipmapLevel();P.setRenderTarget(St),P.getClearColor(Y),J=P.getClearAlpha(),J<1&&P.setClearColor(16777215,.5),P.clear(),qt&&Wt.render(X);let Yt=P.toneMapping;P.toneMapping=Mn;let Kt=V.viewport;if(V.viewport!==void 0&&(V.viewport=void 0),M.setupLightsView(V),kt===!0&&Ut.setGlobalState(P.clippingPlanes,V),Er(v,X,V),j.updateMultisampleRenderTarget(St),j.updateRenderTargetMipmap(St),ie.has("WEBGL_multisampled_render_to_texture")===!1){let Rt=!1;for(let ae=0,Ae=I.length;ae<Ae;ae++){let ge=I[ae],{object:de,geometry:ke,material:Et,group:$e}=ge;if(Et.side===Ke&&de.layers.test(V.layers)){let se=Et.side;Et.side=Je,Et.needsUpdate=!0,Uc(de,X,V,ke,Et,$e),Et.side=se,Et.needsUpdate=!0,Rt=!0}}Rt===!0&&(j.updateMultisampleRenderTarget(St),j.updateRenderTargetMipmap(St))}P.setRenderTarget(vt,Ct,It),P.setClearColor(Y,J),Kt!==void 0&&(V.viewport=Kt),P.toneMapping=Yt}function Er(v,I,X){let V=I.isScene===!0?I.overrideMaterial:null;for(let G=0,St=v.length;G<St;G++){let wt=v[G],{object:vt,geometry:Ct,group:It}=wt,Yt=wt.material;Yt.allowOverride===!0&&V!==null&&(Yt=V),vt.layers.test(X.layers)&&Uc(vt,I,X,Ct,Yt,It)}}function Uc(v,I,X,V,G,St){N!==null&&G.isNodeMaterial&&N.setObject(v,G),v.onBeforeRender(P,I,X,V,G,St),v.modelViewMatrix.multiplyMatrices(X.matrixWorldInverse,v.matrixWorld),v.normalMatrix.getNormalMatrix(v.modelViewMatrix),G.onBeforeRender(P,I,X,V,v,St),G.transparent===!0&&G.side===Ke&&G.forceSinglePass===!1?(G.side=Je,G.needsUpdate=!0,P.renderBufferDirect(X,I,V,G,v,St),G.side=pi,G.needsUpdate=!0,P.renderBufferDirect(X,I,V,G,v,St),G.side=Ke):P.renderBufferDirect(X,I,V,G,v,St),v.onAfterRender(P,I,X,V,G,St)}function wr(v,I,X){I.isScene!==!0&&(I=$t);let V=W.get(v),G=M.state.lights,St=M.state.shadowsArray,wt=G.state.version,vt=pt.getParameters(v,G.state,St,I,X,M.state.lightProbeGridArray),Ct=pt.getProgramCacheKey(vt),It=V.programs;V.environment=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?I.environment:null,V.fog=I.fog;let Yt=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap;V.envMap=dt.get(v.envMap||V.environment,Yt),V.envMapRotation=V.environment!==null&&v.envMap===null?I.environmentRotation:v.envMapRotation,It===void 0&&(v.addEventListener("dispose",An),It=new Map,V.programs=It);let Kt=It.get(Ct);if(Kt!==void 0){if(V.currentProgram===Kt&&V.lightsStateVersion===wt)return Oc(v,vt),Kt}else vt.uniforms=pt.getUniforms(v),N!==null&&v.isNodeMaterial&&N.build(v,X,vt),v.onBeforeCompile(vt,P),Kt=pt.acquireProgram(vt,Ct),It.set(Ct,Kt),V.uniforms=vt.uniforms;let Rt=V.uniforms;return(!v.isShaderMaterial&&!v.isRawShaderMaterial||v.clipping===!0)&&(Rt.clippingPlanes=Ut.uniform),Oc(v,vt),V.needsLights=rd(v),V.lightsStateVersion=wt,V.needsLights&&(Rt.ambientLightColor.value=G.state.ambient,Rt.lightProbe.value=G.state.probe,Rt.sunLights.value=G.state.sun,Rt.sunLightShadows.value=G.state.sunShadow,Rt.directionalLights.value=G.state.directional,Rt.directionalLightShadows.value=G.state.directionalShadow,Rt.spotLights.value=G.state.spot,Rt.spotLightShadows.value=G.state.spotShadow,Rt.rectAreaLights.value=G.state.rectArea,Rt.ltc_1.value=G.state.rectAreaLTC1,Rt.ltc_2.value=G.state.rectAreaLTC2,Rt.pointLights.value=G.state.point,Rt.pointLightShadows.value=G.state.pointShadow,Rt.hemisphereLights.value=G.state.hemi,Rt.sunShadowMatrix.value=G.state.sunShadowMatrix,Rt.sunShadowCascade.value=G.state.sunShadowCascade,Rt.directionalShadowMatrix.value=G.state.directionalShadowMatrix,Rt.spotLightMatrix.value=G.state.spotLightMatrix,Rt.spotLightMap.value=G.state.spotLightMap,Rt.pointShadowMatrix.value=G.state.pointShadowMatrix),V.lightProbeGrid=M.state.lightProbeGridArray.length>0,V.currentProgram=Kt,V.uniformsList=null,Kt}function Fc(v){if(v.uniformsList===null){let I=v.currentProgram.getUniforms();v.uniformsList=Ds.seqWithValue(I.seq,v.uniforms)}return v.uniformsList}function Oc(v,I){let X=W.get(v);X.outputColorSpace=I.outputColorSpace,X.batching=I.batching,X.batchingColor=I.batchingColor,X.instancing=I.instancing,X.instancingColor=I.instancingColor,X.instancingMorph=I.instancingMorph,X.skinning=I.skinning,X.morphTargets=I.morphTargets,X.morphNormals=I.morphNormals,X.morphColors=I.morphColors,X.morphTargetsCount=I.morphTargetsCount,X.numClippingPlanes=I.numClippingPlanes,X.numIntersection=I.numClipIntersection,X.vertexAlphas=I.vertexAlphas,X.vertexTangents=I.vertexTangents,X.toneMapping=I.toneMapping}function nd(v,I){if(v.length===0)return null;if(v.length===1)return v[0].texture!==null?v[0]:null;y.setFromMatrixPosition(I.matrixWorld);for(let X=0,V=v.length;X<V;X++){let G=v[X];if(G.texture!==null&&G.boundingBox.containsPoint(y))return G}return null}function id(v,I,X,V,G){I.isScene!==!0&&(I=$t),j.resetTextureUnits();let St=I.fog,wt=V.isMeshStandardMaterial||V.isMeshLambertMaterial||V.isMeshPhongMaterial?I.environment:null,vt=rt===null?P.outputColorSpace:rt.isXRRenderTarget===!0?rt.texture.colorSpace:Qt.workingColorSpace,Ct=V.isMeshStandardMaterial||V.isMeshLambertMaterial&&!V.envMap||V.isMeshPhongMaterial&&!V.envMap,It=dt.get(V.envMap||wt,Ct),Yt=V.vertexColors===!0&&!!X.attributes.color&&X.attributes.color.itemSize===4,Kt=!!X.attributes.tangent&&(!!V.normalMap||V.anisotropy>0),Rt=!!X.morphAttributes.position,ae=!!X.morphAttributes.normal,Ae=!!X.morphAttributes.color,ge=Mn;V.toneMapped&&(rt===null||rt.isXRRenderTarget===!0)&&(ge=P.toneMapping);let de=X.morphAttributes.position||X.morphAttributes.normal||X.morphAttributes.color,ke=de!==void 0?de.length:0,Et=W.get(V),$e=M.state.lights;if(kt===!0&&(ee===!0||v!==K)){let pe=v===K&&V.id===$;Ut.setState(V,v,pe)}let se=!1;V.version===Et.__version?(Et.needsLights&&Et.lightsStateVersion!==$e.state.version||Et.outputColorSpace!==vt||G.isBatchedMesh&&Et.batching===!1||!G.isBatchedMesh&&Et.batching===!0||G.isBatchedMesh&&Et.batchingColor===!0&&G._colorsTexture===null||G.isBatchedMesh&&Et.batchingColor===!1&&G._colorsTexture!==null||G.isInstancedMesh&&Et.instancing===!1||!G.isInstancedMesh&&Et.instancing===!0||G.isSkinnedMesh&&Et.skinning===!1||!G.isSkinnedMesh&&Et.skinning===!0||G.isInstancedMesh&&Et.instancingColor===!0&&G.instanceColor===null||G.isInstancedMesh&&Et.instancingColor===!1&&G.instanceColor!==null||G.isInstancedMesh&&Et.instancingMorph===!0&&G.morphTexture===null||G.isInstancedMesh&&Et.instancingMorph===!1&&G.morphTexture!==null||Et.envMap!==It||V.fog===!0&&Et.fog!==St||Et.numClippingPlanes!==void 0&&(Et.numClippingPlanes!==Ut.numPlanes||Et.numIntersection!==Ut.numIntersection)||Et.vertexAlphas!==Yt||Et.vertexTangents!==Kt||Et.morphTargets!==Rt||Et.morphNormals!==ae||Et.morphColors!==Ae||Et.toneMapping!==ge||Et.morphTargetsCount!==ke||!!Et.lightProbeGrid!=M.state.lightProbeGridArray.length>0)&&(se=!0):(se=!0,Et.__version=V.version);let hn=Et.currentProgram;se===!0&&(hn=wr(V,I,G),N&&V.isNodeMaterial&&N.onUpdateProgram(V,hn,Et));let Cn=!1,Kn=!1,ki=!1,ue=hn.getUniforms(),Ee=Et.uniforms;if(g.useProgram(hn.program)&&(Cn=!0,Kn=!0,ki=!0),V.id!==$&&($=V.id,Kn=!0),Et.needsLights){let pe=nd(M.state.lightProbeGridArray,G);Et.lightProbeGrid!==pe&&(Et.lightProbeGrid=pe,Kn=!0)}if(Cn||K!==v){g.buffers.depth.getReversed()&&v.reversedDepth!==!0&&(v._reversedDepth=!0,v.updateProjectionMatrix()),ue.setValue(L,"projectionMatrix",v.projectionMatrix),ue.setValue(L,"viewMatrix",v.matrixWorldInverse);let Qn=ue.map.cameraPosition;Qn!==void 0&&Qn.setValue(L,he.setFromMatrixPosition(v.matrixWorld)),w.logarithmicDepthBuffer&&ue.setValue(L,"logDepthBufFC",2/(Math.log(v.far+1)/Math.LN2)),(V.isMeshPhongMaterial||V.isMeshToonMaterial||V.isMeshLambertMaterial||V.isMeshBasicMaterial||V.isMeshStandardMaterial||V.isShaderMaterial)&&ue.setValue(L,"isOrthographic",v.isOrthographicCamera===!0),K!==v&&(K=v,Kn=!0,ki=!0)}if(Et.needsLights&&($e.state.sunShadowMap.length>0&&ue.setValue(L,"sunShadowMap",$e.state.sunShadowMap,j),$e.state.directionalShadowMap.length>0&&ue.setValue(L,"directionalShadowMap",$e.state.directionalShadowMap,j),$e.state.spotShadowMap.length>0&&ue.setValue(L,"spotShadowMap",$e.state.spotShadowMap,j),$e.state.pointShadowMap.length>0&&ue.setValue(L,"pointShadowMap",$e.state.pointShadowMap,j)),G.isSkinnedMesh){ue.setOptional(L,G,"bindMatrix"),ue.setOptional(L,G,"bindMatrixInverse");let pe=G.skeleton;pe&&(pe.boneTexture===null&&pe.computeBoneTexture(),ue.setValue(L,"boneTexture",pe.boneTexture,j))}G.isBatchedMesh&&(ue.setOptional(L,G,"batchingTexture"),ue.setValue(L,"batchingTexture",G._matricesTexture,j),ue.setOptional(L,G,"batchingIdTexture"),ue.setValue(L,"batchingIdTexture",G._indirectTexture,j),ue.setOptional(L,G,"batchingColorTexture"),G._colorsTexture!==null&&ue.setValue(L,"batchingColorTexture",G._colorsTexture,j));let jn=X.morphAttributes;if((jn.position!==void 0||jn.normal!==void 0||jn.color!==void 0)&&D.update(G,X,hn),(Kn||Et.receiveShadow!==G.receiveShadow)&&(Et.receiveShadow=G.receiveShadow,ue.setValue(L,"receiveShadow",G.receiveShadow)),(V.isMeshStandardMaterial||V.isMeshLambertMaterial||V.isMeshPhongMaterial)&&V.envMap===null&&I.environment!==null&&(Ee.envMapIntensity.value=I.environmentIntensity),Ee.dfgLUT!==void 0&&(Ee.dfgLUT.value=__()),Kn){if(ue.setValue(L,"toneMappingExposure",P.toneMappingExposure),Et.needsLights&&sd(Ee,ki),St&&V.fog===!0&&Nt.refreshFogUniforms(Ee,St),Nt.refreshMaterialUniforms(Ee,V,H,O,M.state.transmissionRenderTarget[v.id]),Et.needsLights&&Et.lightProbeGrid){let pe=Et.lightProbeGrid;Ee.probesSH.value=pe.texture,Ee.probesMin.value.copy(pe.boundingBox.min),Ee.probesMax.value.copy(pe.boundingBox.max),Ee.probesResolution.value.copy(pe.resolution)}Ds.upload(L,Fc(Et),Ee,j)}if(V.isShaderMaterial&&V.uniformsNeedUpdate===!0&&(Ds.upload(L,Fc(Et),Ee,j),V.uniformsNeedUpdate=!1),V.isSpriteMaterial&&ue.setValue(L,"center",G.center),ue.setValue(L,"modelViewMatrix",G.modelViewMatrix),ue.setValue(L,"normalMatrix",G.normalMatrix),ue.setValue(L,"modelMatrix",G.matrixWorld),V.uniformsGroups!==void 0){let pe=V.uniformsGroups;for(let Qn=0,zi=pe.length;Qn<zi;Qn++){let kc=pe[Qn];lt.update(kc,hn),lt.bind(kc,hn)}}return hn}function sd(v,I){v.ambientLightColor.needsUpdate=I,v.lightProbe.needsUpdate=I,v.sunLights.needsUpdate=I,v.sunLightShadows.needsUpdate=I,v.directionalLights.needsUpdate=I,v.directionalLightShadows.needsUpdate=I,v.pointLights.needsUpdate=I,v.pointLightShadows.needsUpdate=I,v.spotLights.needsUpdate=I,v.spotLightShadows.needsUpdate=I,v.rectAreaLights.needsUpdate=I,v.hemisphereLights.needsUpdate=I}function rd(v){return v.isMeshLambertMaterial||v.isMeshToonMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isShadowMaterial||v.isShaderMaterial&&v.lights===!0}this.getActiveCubeFace=function(){return q},this.getActiveMipmapLevel=function(){return Z},this.getRenderTarget=function(){return rt},this.setRenderTargetTextures=function(v,I,X){let V=W.get(v);V.__autoAllocateDepthBuffer=v.resolveDepthBuffer===!1,V.__autoAllocateDepthBuffer===!1&&(V.__useRenderToTexture=!1),W.get(v.texture).__webglTexture=I,W.get(v.depthTexture).__webglTexture=V.__autoAllocateDepthBuffer?void 0:X,V.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(v,I){let X=W.get(v);X.__webglFramebuffer=I,X.__useDefaultFramebuffer=I===void 0},this.setRenderTarget=function(v,I=0,X=0){rt=v,q=I,Z=X;let V=null,G=!1,St=!1;if(v){let vt=W.get(v);if(vt.__useDefaultFramebuffer!==void 0){g.bindFramebuffer(L.FRAMEBUFFER,vt.__webglFramebuffer),st.copy(v.viewport),Tt.copy(v.scissor),ht=v.scissorTest,g.viewport(st),g.scissor(Tt),g.setScissorTest(ht),$=-1;return}else if(vt.__webglFramebuffer===void 0)j.setupRenderTarget(v);else if(vt.__hasExternalTextures)j.rebindTextures(v,W.get(v.texture).__webglTexture,W.get(v.depthTexture).__webglTexture);else if(v.depthBuffer){let Yt=v.depthTexture;if(vt.__boundDepthTexture!==Yt){if(Yt!==null&&W.has(Yt)&&(v.width!==Yt.image.width||v.height!==Yt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");j.setupDepthRenderbuffer(v)}}let Ct=v.texture;(Ct.isData3DTexture||Ct.isDataArrayTexture||Ct.isCompressedArrayTexture)&&(St=!0);let It=W.get(v).__webglFramebuffer;v.isWebGLCubeRenderTarget?(Array.isArray(It[I])?V=It[I][X]:V=It[I],G=!0):v.samples>0&&j.useMultisampledRTT(v)===!1?V=W.get(v).__webglMultisampledFramebuffer:Array.isArray(It)?V=It[X]:V=It,st.copy(v.viewport),Tt.copy(v.scissor),ht=v.scissorTest}else st.copy(ct).multiplyScalar(H).floor(),Tt.copy(bt).multiplyScalar(H).floor(),ht=Lt;if(X!==0&&(V=B),g.bindFramebuffer(L.FRAMEBUFFER,V)&&g.drawBuffers(v,V),g.viewport(st),g.scissor(Tt),g.setScissorTest(ht),G){let vt=W.get(v.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_CUBE_MAP_POSITIVE_X+I,vt.__webglTexture,X)}else if(St){let vt=I;for(let Ct=0;Ct<v.textures.length;Ct++){let It=W.get(v.textures[Ct]);L.framebufferTextureLayer(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0+Ct,It.__webglTexture,X,vt)}}else if(v!==null&&X!==0){let vt=W.get(v.texture);L.framebufferTexture2D(L.FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,vt.__webglTexture,X)}$=-1};function Bc(v){let I=W.get(v);return(I.__readFormat!==v.format||I.__readType!==v.type)&&(I.__readFormat=v.format,I.__readType=v.type,I.__formatReadable=w.textureFormatReadable(v.format),I.__typeReadable=w.textureTypeReadable(v.type)),I}this.readRenderTargetPixels=function(v,I,X,V,G,St,wt,vt=0){if(!(v&&v.isWebGLRenderTarget)){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ct=W.get(v).__webglFramebuffer;if(v.isWebGLCubeRenderTarget&&wt!==void 0&&(Ct=Ct[wt]),Ct){g.bindFramebuffer(L.FRAMEBUFFER,Ct);try{let It=v.textures[vt],Yt=It.format,Kt=It.type;v.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+vt);let Rt=Bc(It);if(Rt.__formatReadable===!1){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Rt.__typeReadable===!1){zt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}I>=0&&I<=v.width-V&&X>=0&&X<=v.height-G&&L.readPixels(I,X,V,G,_t.convert(Yt),_t.convert(Kt),St)}finally{let It=rt!==null?W.get(rt).__webglFramebuffer:null;g.bindFramebuffer(L.FRAMEBUFFER,It)}}},this.readRenderTargetPixelsAsync=async function(v,I,X,V,G,St,wt,vt=0){if(!(v&&v.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ct=W.get(v).__webglFramebuffer;if(v.isWebGLCubeRenderTarget&&wt!==void 0&&(Ct=Ct[wt]),Ct)if(I>=0&&I<=v.width-V&&X>=0&&X<=v.height-G){g.bindFramebuffer(L.FRAMEBUFFER,Ct);let It=v.textures[vt],Yt=It.format,Kt=It.type;v.textures.length>1&&L.readBuffer(L.COLOR_ATTACHMENT0+vt);let Rt=Bc(It);if(Rt.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Rt.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let ae=L.createBuffer();L.bindBuffer(L.PIXEL_PACK_BUFFER,ae),L.bufferData(L.PIXEL_PACK_BUFFER,St.byteLength,L.STREAM_READ),L.readPixels(I,X,V,G,_t.convert(Yt),_t.convert(Kt),0),L.bindBuffer(L.PIXEL_PACK_BUFFER,null);let Ae=rt!==null?W.get(rt).__webglFramebuffer:null;g.bindFramebuffer(L.FRAMEBUFFER,Ae);let ge=L.fenceSync(L.SYNC_GPU_COMMANDS_COMPLETE,0);return L.flush(),await tu(L,ge,4),L.bindBuffer(L.PIXEL_PACK_BUFFER,ae),L.getBufferSubData(L.PIXEL_PACK_BUFFER,0,St),L.bindBuffer(L.PIXEL_PACK_BUFFER,null),L.deleteBuffer(ae),L.deleteSync(ge),St}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(v,I=null,X=0){let V=Math.pow(2,-X),G=Math.floor(v.image.width*V),St=Math.floor(v.image.height*V),wt=I!==null?I.x:0,vt=I!==null?I.y:0;j.setTexture2D(v,0),L.copyTexSubImage2D(L.TEXTURE_2D,X,0,0,wt,vt,G,St),g.unbindTexture()},this.copyTextureToTexture=function(v,I,X=null,V=null,G=0,St=0){let wt,vt,Ct,It,Yt,Kt,Rt,ae,Ae,ge=v.isCompressedTexture?v.mipmaps[St]:v.image;if(X!==null)wt=X.max.x-X.min.x,vt=X.max.y-X.min.y,Ct=X.isBox3?X.max.z-X.min.z:1,It=X.min.x,Yt=X.min.y,Kt=X.isBox3?X.min.z:0;else{let Ee=Math.pow(2,-G);wt=Math.floor(ge.width*Ee),vt=Math.floor(ge.height*Ee),v.isDataArrayTexture?Ct=ge.depth:v.isData3DTexture?Ct=Math.floor(ge.depth*Ee):Ct=1,It=0,Yt=0,Kt=0}V!==null?(Rt=V.x,ae=V.y,Ae=V.z):(Rt=0,ae=0,Ae=0);let de=_t.convert(I.format),ke=_t.convert(I.type),Et;I.isData3DTexture?(j.setTexture3D(I,0),Et=L.TEXTURE_3D):I.isDataArrayTexture||I.isCompressedArrayTexture?(j.setTexture2DArray(I,0),Et=L.TEXTURE_2D_ARRAY):(j.setTexture2D(I,0),Et=L.TEXTURE_2D),g.activeTexture(L.TEXTURE0),g.pixelStorei(L.UNPACK_FLIP_Y_WEBGL,I.flipY),g.pixelStorei(L.UNPACK_PREMULTIPLY_ALPHA_WEBGL,I.premultiplyAlpha),g.pixelStorei(L.UNPACK_ALIGNMENT,I.unpackAlignment);let $e=g.getParameter(L.UNPACK_ROW_LENGTH),se=g.getParameter(L.UNPACK_IMAGE_HEIGHT),hn=g.getParameter(L.UNPACK_SKIP_PIXELS),Cn=g.getParameter(L.UNPACK_SKIP_ROWS),Kn=g.getParameter(L.UNPACK_SKIP_IMAGES);g.pixelStorei(L.UNPACK_ROW_LENGTH,ge.width),g.pixelStorei(L.UNPACK_IMAGE_HEIGHT,ge.height),g.pixelStorei(L.UNPACK_SKIP_PIXELS,It),g.pixelStorei(L.UNPACK_SKIP_ROWS,Yt),g.pixelStorei(L.UNPACK_SKIP_IMAGES,Kt);let ki=v.isDataArrayTexture||v.isData3DTexture,ue=I.isDataArrayTexture||I.isData3DTexture;if(v.isDepthTexture){let Ee=W.get(v),jn=W.get(I),pe=W.get(Ee.__renderTarget),Qn=W.get(jn.__renderTarget);g.bindFramebuffer(L.READ_FRAMEBUFFER,pe.__webglFramebuffer),g.bindFramebuffer(L.DRAW_FRAMEBUFFER,Qn.__webglFramebuffer);for(let zi=0;zi<Ct;zi++)ki&&(L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,W.get(v).__webglTexture,G,Kt+zi),L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,W.get(I).__webglTexture,St,Ae+zi)),L.blitFramebuffer(It,Yt,wt,vt,Rt,ae,wt,vt,L.DEPTH_BUFFER_BIT,L.NEAREST);g.bindFramebuffer(L.READ_FRAMEBUFFER,null),g.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else if(G!==0||v.isRenderTargetTexture||W.has(v)){let Ee=W.get(v),jn=W.get(I);g.bindFramebuffer(L.READ_FRAMEBUFFER,R),g.bindFramebuffer(L.DRAW_FRAMEBUFFER,z);for(let pe=0;pe<Ct;pe++)ki?L.framebufferTextureLayer(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,Ee.__webglTexture,G,Kt+pe):L.framebufferTexture2D(L.READ_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,Ee.__webglTexture,G),ue?L.framebufferTextureLayer(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,jn.__webglTexture,St,Ae+pe):L.framebufferTexture2D(L.DRAW_FRAMEBUFFER,L.COLOR_ATTACHMENT0,L.TEXTURE_2D,jn.__webglTexture,St),G!==0?L.blitFramebuffer(It,Yt,wt,vt,Rt,ae,wt,vt,L.COLOR_BUFFER_BIT,L.NEAREST):ue?L.copyTexSubImage3D(Et,St,Rt,ae,Ae+pe,It,Yt,wt,vt):L.copyTexSubImage2D(Et,St,Rt,ae,It,Yt,wt,vt);g.bindFramebuffer(L.READ_FRAMEBUFFER,null),g.bindFramebuffer(L.DRAW_FRAMEBUFFER,null)}else ue?v.isDataTexture||v.isData3DTexture?L.texSubImage3D(Et,St,Rt,ae,Ae,wt,vt,Ct,de,ke,ge.data):I.isCompressedArrayTexture?L.compressedTexSubImage3D(Et,St,Rt,ae,Ae,wt,vt,Ct,de,ge.data):L.texSubImage3D(Et,St,Rt,ae,Ae,wt,vt,Ct,de,ke,ge):v.isDataTexture?L.texSubImage2D(L.TEXTURE_2D,St,Rt,ae,wt,vt,de,ke,ge.data):v.isCompressedTexture?L.compressedTexSubImage2D(L.TEXTURE_2D,St,Rt,ae,ge.width,ge.height,de,ge.data):L.texSubImage2D(L.TEXTURE_2D,St,Rt,ae,wt,vt,de,ke,ge);g.pixelStorei(L.UNPACK_ROW_LENGTH,$e),g.pixelStorei(L.UNPACK_IMAGE_HEIGHT,se),g.pixelStorei(L.UNPACK_SKIP_PIXELS,hn),g.pixelStorei(L.UNPACK_SKIP_ROWS,Cn),g.pixelStorei(L.UNPACK_SKIP_IMAGES,Kn),St===0&&I.generateMipmaps&&L.generateMipmap(Et),g.unbindTexture()},this.initRenderTarget=function(v){W.get(v).__webglFramebuffer===void 0&&j.setupRenderTarget(v)},this.initTexture=function(v){v.isCubeTexture?j.setTextureCube(v,0):v.isData3DTexture?j.setTexture3D(v,0):v.isDataArrayTexture||v.isCompressedArrayTexture?j.setTexture2DArray(v,0):j.setTexture2D(v,0),g.unbindTexture()},this.resetState=function(){q=0,Z=0,rt=null,g.reset(),Mt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return bn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;let e=this.getContext();e.drawingBufferColorSpace=Qt._getDrawingBufferColorSpace(t),e.unpackColorSpace=Qt._getUnpackColorSpace()}};var Uu={type:"change"},vc={type:"start"},Ou={type:"end"},Io=new gs,Fu=new rn,y_=Math.cos(70*Yl.DEG2RAD),Ie=new U,tn=2*Math.PI,ce={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},yc=1e-6,Lo=class extends cr{constructor(t,e=null){super(t,e),this.state=ce.NONE,this.target=new U,this.cursor=new U,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:di.ROTATE,MIDDLE:di.DOLLY,RIGHT:di.PAN},this.touches={ONE:fi.ROTATE,TWO:fi.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new U,this._lastQuaternion=new Oe,this._lastTargetPosition=new U,this._quat=new Oe().setFromUnitVectors(t.up,new U(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new ws,this._sphericalDelta=new ws,this._scale=1,this._panOffset=new U,this._rotateStart=new Dt,this._rotateEnd=new Dt,this._rotateDelta=new Dt,this._panStart=new Dt,this._panEnd=new Dt,this._panDelta=new Dt,this._dollyStart=new Dt,this._dollyEnd=new Dt,this._dollyDelta=new Dt,this._dollyDirection=new U,this._mouse=new Dt,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=b_.bind(this),this._onPointerDown=v_.bind(this),this._onPointerUp=S_.bind(this),this._onContextMenu=R_.bind(this),this._onMouseWheel=E_.bind(this),this._onKeyDown=w_.bind(this),this._onTouchStart=A_.bind(this),this._onTouchMove=C_.bind(this),this._onMouseDown=M_.bind(this),this._onMouseMove=T_.bind(this),this._interceptControlDown=P_.bind(this),this._interceptControlUp=I_.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(t){this._cursorStyle=t,t==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(t){super.connect(t),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.state=ce.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents();let t=this.domElement.getRootNode();t.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),t.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this.domElement.style.cursor="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(t){t.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=t}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Uu),this.update(),this.state=ce.NONE}pan(t,e){this._pan(t,e),this.update()}dollyIn(t){this._dollyIn(t),this.update()}dollyOut(t){this._dollyOut(t),this.update()}rotateLeft(t){this._rotateLeft(t),this.update()}rotateUp(t){this._rotateUp(t),this.update()}update(t=null){let e=this.object.position;Ie.copy(e).sub(this.target),Ie.applyQuaternion(this._quat),this._spherical.setFromVector3(Ie),this.autoRotate&&this.state===ce.NONE&&this._rotateLeft(this._getAutoRotationAngle(t)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(n)&&isFinite(s)&&(n<-Math.PI?n+=tn:n>Math.PI&&(n-=tn),s<-Math.PI?s+=tn:s>Math.PI&&(s-=tn),n<=s?this._spherical.theta=Math.max(n,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+s)/2?Math.max(n,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let a=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=a!=this._spherical.radius}if(Ie.setFromSpherical(this._spherical),Ie.applyQuaternion(this._quatInverse),e.copy(this.target).add(Ie),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let a=null;if(this.object.isPerspectiveCamera){let o=Ie.length();a=this._clampDistance(o*this._scale);let l=o-a;this.object.position.addScaledVector(this._dollyDirection,l),this.object.updateMatrixWorld(),r=!!l}else if(this.object.isOrthographicCamera){let o=new U(this._mouse.x,this._mouse.y,0);o.unproject(this.object);let l=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=l!==this.object.zoom;let c=new U(this._mouse.x,this._mouse.y,0);c.unproject(this.object),this.object.position.sub(c).add(o),this.object.updateMatrixWorld(),a=Ie.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;a!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(a).add(this.object.position):(Io.origin.copy(this.object.position),Io.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Io.direction))<y_?this.object.lookAt(this.target):(Fu.setFromNormalAndCoplanarPoint(this.object.up,this.target),Io.intersectPlane(Fu,this.target))))}else if(this.object.isOrthographicCamera){let a=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),a!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>yc||8*(1-this._lastQuaternion.dot(this.object.quaternion))>yc||this._lastTargetPosition.distanceToSquared(this.target)>yc?(this.dispatchEvent(Uu),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(t){return t!==null?tn/60*this.autoRotateSpeed*t:tn/60/60*this.autoRotateSpeed}_getZoomScale(t){let e=Math.abs(t*.01);return Math.pow(.95,this.zoomSpeed*e)}_rotateLeft(t){this._sphericalDelta.theta-=t}_rotateUp(t){this._sphericalDelta.phi-=t}_panLeft(t,e){Ie.setFromMatrixColumn(e,0),Ie.multiplyScalar(-t),this._panOffset.add(Ie)}_panUp(t,e){this.screenSpacePanning===!0?Ie.setFromMatrixColumn(e,1):(Ie.setFromMatrixColumn(e,0),Ie.crossVectors(this.object.up,Ie)),Ie.multiplyScalar(t),this._panOffset.add(Ie)}_pan(t,e){let n=this.domElement;if(this.object.isPerspectiveCamera){let s=this.object.position;Ie.copy(s).sub(this.target);let r=Ie.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*t*r/n.clientHeight,this.object.matrix),this._panUp(2*e*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(t*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(e*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(t){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=t:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(t,e){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let n=this.domElement.getBoundingClientRect(),s=t-n.left,r=e-n.top,a=n.width,o=n.height;this._mouse.x=s/a*2-1,this._mouse.y=-(r/o)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(t){return Math.max(this.minDistance,Math.min(this.maxDistance,t))}_handleMouseDownRotate(t){this._rotateStart.set(t.clientX,t.clientY)}_handleMouseDownDolly(t){this._updateZoomParameters(t.clientX,t.clientX),this._dollyStart.set(t.clientX,t.clientY)}_handleMouseDownPan(t){this._panStart.set(t.clientX,t.clientY)}_handleMouseMoveRotate(t){this._rotateEnd.set(t.clientX,t.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let e=this.domElement;this._rotateLeft(tn*this._rotateDelta.x/e.clientHeight),this._rotateUp(tn*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(t){this._dollyEnd.set(t.clientX,t.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(t){this._panEnd.set(t.clientX,t.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(t){this._updateZoomParameters(t.clientX,t.clientY),t.deltaY<0?this._dollyIn(this._getZoomScale(t.deltaY)):t.deltaY>0&&this._dollyOut(this._getZoomScale(t.deltaY)),this.update()}_handleKeyDown(t){let e=!1;switch(t.code){case this.keys.UP:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(tn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),e=!0;break;case this.keys.BOTTOM:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateUp(-tn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),e=!0;break;case this.keys.LEFT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(tn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),e=!0;break;case this.keys.RIGHT:t.ctrlKey||t.metaKey||t.shiftKey?this.enableRotate&&this._rotateLeft(-tn*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),e=!0;break}e&&(t.preventDefault(),this.update())}_handleTouchStartRotate(t){if(this._pointers.length===1)this._rotateStart.set(t.pageX,t.pageY);else{let e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._rotateStart.set(n,s)}}_handleTouchStartPan(t){if(this._pointers.length===1)this._panStart.set(t.pageX,t.pageY);else{let e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._panStart.set(n,s)}}_handleTouchStartDolly(t){let e=this._getSecondPointerPosition(t),n=t.pageX-e.x,s=t.pageY-e.y,r=Math.sqrt(n*n+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enablePan&&this._handleTouchStartPan(t)}_handleTouchStartDollyRotate(t){this.enableZoom&&this._handleTouchStartDolly(t),this.enableRotate&&this._handleTouchStartRotate(t)}_handleTouchMoveRotate(t){if(this._pointers.length==1)this._rotateEnd.set(t.pageX,t.pageY);else{let n=this._getSecondPointerPosition(t),s=.5*(t.pageX+n.x),r=.5*(t.pageY+n.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let e=this.domElement;this._rotateLeft(tn*this._rotateDelta.x/e.clientHeight),this._rotateUp(tn*this._rotateDelta.y/e.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(t){if(this._pointers.length===1)this._panEnd.set(t.pageX,t.pageY);else{let e=this._getSecondPointerPosition(t),n=.5*(t.pageX+e.x),s=.5*(t.pageY+e.y);this._panEnd.set(n,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(t){let e=this._getSecondPointerPosition(t),n=t.pageX-e.x,s=t.pageY-e.y,r=Math.sqrt(n*n+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let a=(t.pageX+e.x)*.5,o=(t.pageY+e.y)*.5;this._updateZoomParameters(a,o)}_handleTouchMoveDollyPan(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enablePan&&this._handleTouchMovePan(t)}_handleTouchMoveDollyRotate(t){this.enableZoom&&this._handleTouchMoveDolly(t),this.enableRotate&&this._handleTouchMoveRotate(t)}_addPointer(t){this._pointers.push(t.pointerId)}_removePointer(t){delete this._pointerPositions[t.pointerId];for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId){this._pointers.splice(e,1);return}}_isTrackingPointer(t){for(let e=0;e<this._pointers.length;e++)if(this._pointers[e]==t.pointerId)return!0;return!1}_trackPointer(t){let e=this._pointerPositions[t.pointerId];e===void 0&&(e=new Dt,this._pointerPositions[t.pointerId]=e),e.set(t.pageX,t.pageY)}_getSecondPointerPosition(t){let e=t.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[e]}_customWheelEvent(t){let e=t.deltaMode,n={clientX:t.clientX,clientY:t.clientY,deltaY:t.deltaY};switch(e){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return t.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}};function v_(i){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(i.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(i)&&(this._addPointer(i),i.pointerType==="touch"?this._onTouchStart(i):this._onMouseDown(i),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function b_(i){this.enabled!==!1&&(i.pointerType==="touch"?this._onTouchMove(i):this._onMouseMove(i))}function S_(i){switch(this._removePointer(i),this._pointers.length){case 0:this.domElement.releasePointerCapture(i.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Ou),this.state=ce.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:let t=this._pointers[0],e=this._pointerPositions[t];this._onTouchStart({pointerId:t,pageX:e.x,pageY:e.y});break}}function M_(i){let t;switch(i.button){case 0:t=this.mouseButtons.LEFT;break;case 1:t=this.mouseButtons.MIDDLE;break;case 2:t=this.mouseButtons.RIGHT;break;default:t=-1}switch(t){case di.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(i),this.state=ce.DOLLY;break;case di.ROTATE:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=ce.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=ce.ROTATE}break;case di.PAN:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=ce.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=ce.PAN}break;default:this.state=ce.NONE}this.state!==ce.NONE&&this.dispatchEvent(vc)}function T_(i){switch(this.state){case ce.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(i);break;case ce.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(i);break;case ce.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(i);break}}function E_(i){this.enabled===!1||this.enableZoom===!1||this.state!==ce.NONE||(i.preventDefault(),this.dispatchEvent(vc),this._handleMouseWheel(this._customWheelEvent(i)),this.dispatchEvent(Ou))}function w_(i){this.enabled!==!1&&this._handleKeyDown(i)}function A_(i){switch(this._trackPointer(i),this._pointers.length){case 1:switch(this.touches.ONE){case fi.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(i),this.state=ce.TOUCH_ROTATE;break;case fi.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(i),this.state=ce.TOUCH_PAN;break;default:this.state=ce.NONE}break;case 2:switch(this.touches.TWO){case fi.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(i),this.state=ce.TOUCH_DOLLY_PAN;break;case fi.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(i),this.state=ce.TOUCH_DOLLY_ROTATE;break;default:this.state=ce.NONE}break;default:this.state=ce.NONE}this.state!==ce.NONE&&this.dispatchEvent(vc)}function C_(i){switch(this._trackPointer(i),this.state){case ce.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(i),this.update();break;case ce.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(i),this.update();break;case ce.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(i),this.update();break;case ce.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(i),this.update();break;default:this.state=ce.NONE}}function R_(i){this.enabled!==!1&&i.preventDefault()}function P_(i){i.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function I_(i){i.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}var L_={2:58879,3:3014538,4:16770560,5:12938239,6:16747039};function Uo(i){if(i.kind==="C")return L_[i.n]??3723504;if(i.kind==="S")return 16727462;if(i.kind==="i")return 13041434;if(i.kind==="sigma"){let t=i.label.s;return t==="h"?16742957:t==="d"?13651455:4033535}return 16777215}var Fo=i=>`#${i.toString(16).padStart(6,"0")}`,bc=i=>i<.5?4*i*i*i:1-Math.pow(-2*i+2,3)/2,Tc=new U(0,1,0),Bu=new U(0,0,1),Sr=i=>new U(i[0],i[1],i[2]);function Sc(i,t,e){let n=document.createElement("canvas");n.width=220,n.height=110;let s=n.getContext("2d"),r='600 58px "IBM Plex Sans", system-ui, sans-serif',a='600 36px "IBM Plex Sans", system-ui, sans-serif';s.font=r;let o=s.measureText(i.b).width;s.font=a;let l=i.s?s.measureText(i.s).width:0;s.font=r;let c=i.x?s.measureText(i.x).width:0,u=(n.width-(o+l+c))/2,f=70;s.lineJoin="round",s.lineWidth=9,s.strokeStyle="rgba(8,12,22,0.9)",s.fillStyle=Fo(t);let h=(b,m,d,E)=>{s.font=m,s.strokeText(b,u,f+d),s.fillText(b,u,f+d),u+=E};h(i.b,r,0,o),i.s&&h(i.s,a,14,l),i.x&&h(i.x,r,0,c);let p=new xs(n);p.colorSpace=Ge;let _=new ms(new Ri({map:p,depthTest:!1,transparent:!0}));return _.scale.set(e,e/2,1),_.renderOrder=20,_}var Mc=new Map;function D_(i){if(!Mc.has(i)){let e=document.createElement("canvas");e.width=96,e.height=96;let n=e.getContext("2d");n.fillStyle="rgba(8,12,22,0.82)",n.beginPath(),n.arc(48,48,34,0,Math.PI*2),n.fill(),n.strokeStyle="rgba(255,255,255,0.85)",n.lineWidth=4,n.stroke(),n.fillStyle="#fff",n.font='600 40px "IBM Plex Sans", system-ui, sans-serif',n.textAlign="center",n.textBaseline="middle",n.fillText(String(i),48,51);let s=new xs(e);s.colorSpace=Ge,Mc.set(i,s)}let t=new ms(new Ri({map:Mc.get(i),depthTest:!1,transparent:!0}));return t.renderOrder=30,t}var N_=new Ss(1,32,22),U_=new li(1,1,1,14,1,!0),Do=class{constructor(t,{numbers:e=!1}={}){this.mol=t,this.group=new dn,this.atoms=t.atoms.map((n,s)=>{let r=new Me(N_,new Ms({color:Xo[n.el]??13421772,emissive:Xo[n.el]??13421772,emissiveIntensity:.16,roughness:.22,metalness:.08,clearcoat:1,clearcoatRoughness:.12}));return this.group.add(r),r}),this.bondMeshes=t.bonds.map(()=>{let n=new Me(U_,new Ms({color:13623551,emissive:7310591,emissiveIntensity:.25,roughness:.25,metalness:.2,clearcoat:.8}));return this.group.add(n),n}),this.sprites=e?t.atoms.map((n,s)=>{let r=D_(s+1);return r.scale.set(.42,.42,1),this.group.add(r),r}):null,this.style="ball",this.setStyle("ball"),this.setPositions(t.atoms.map(n=>n.p))}setStyle(t){this.style=t,this.mol.atoms.forEach((e,n)=>{let s=t==="space"?Vc[e.el]*.58:.12+.25*Ar[e.el];this.atoms[n].scale.setScalar(s)}),this.bondMeshes.forEach(e=>{e.visible=t!=="space"})}setPositions(t){t.forEach((e,n)=>{this.atoms[n].position.set(e[0],e[1],e[2]),this.sprites&&this.sprites[n].position.set(e[0],e[1],e[2])}),this.mol.bonds.forEach(([e,n],s)=>{let r=Sr(t[e]),o=Sr(t[n]).clone().sub(r),l=o.length(),c=this.bondMeshes[s];c.position.copy(r).addScaledVector(o,.5),c.quaternion.setFromUnitVectors(Tc,o.normalize()),c.scale.set(.07,l,.07)})}setOpacity(t){let e=[...this.atoms,...this.bondMeshes];for(let n of e)n.material.transparent=t<1,n.material.opacity=t,n.material.depthWrite=t>=1}dispose(){this.group.traverse(t=>{t.material&&!t.isSprite&&t.material.dispose()})}};function F_(i,t,e,n){let s=new dn,r=[],a=Uo(i),o=(c,u={})=>{let f=new Pi({color:a,transparent:!0,opacity:c,...u});return r.push({m:f,base:c,focus:Math.min(1,c*1+(u.side?.2:0))}),f},l=c=>(s.add(c),c);if(i.kind==="C"||i.kind==="S"){let c=Sr(i.dir).normalize(),u=new Oe().setFromUnitVectors(Tc,c),f=new Oe().setFromUnitVectors(Bu,c),h=i.kind==="S"?t+.22:t;if(i.kind==="C")l(new Me(new li(.034,.034,h*2,10),o(.95))).quaternion.copy(u);else{let b=h*2/15;for(let m=0;m<15;m++){let d=l(new Me(new li(.03,.03,b*.55,8),o(.95)));d.quaternion.copy(u),d.position.copy(c).multiplyScalar(-h+b*(m+.5))}}for(let _ of[1,-1]){let b;if(i.kind==="S"){let m=Number.isFinite(i.n)?i.n:40;b=new Me(new bs(.1,.17,m),o(.95,{side:Ke}))}else{let m=Number.isFinite(i.n)?i.n===2?36:i.n:40;b=new Me(new vs(.17,m),o(.95,{side:Ke})),i.n===2&&b.scale.set(1.25,.5,1)}b.quaternion.copy(f),i.kind==="C"&&i.n===2&&b.rotateZ(Math.PI/2*0),b.position.copy(c).multiplyScalar(_*h),s.add(b)}let p=Sc(i.label,a,n);p.position.copy(c).multiplyScalar(h+.42+(i.kind==="S"?.3:0)),s.add(p),s.userData.labels=[p]}else if(i.kind==="sigma"){let c=Sr(i.normal).normalize(),u=new Oe().setFromUnitVectors(Bu,c),f=l(new Me(new vs(e,72),o(.13,{side:Ke,depthWrite:!1})));f.quaternion.copy(u),f.renderOrder=5,r[r.length-1].focus=.3;let h=l(new Me(new bs(e*.987,e,72),o(.7,{side:Ke,depthWrite:!1})));h.quaternion.copy(u),h.renderOrder=6,r[r.length-1].focus=1;let p=Math.abs(c.y)<.9?new U(0,1,0):new U(1,0,0),_=new U().crossVectors(c,p).normalize(),b=Sc(i.label,a,n);b.position.copy(_).multiplyScalar(e*.9),s.add(b),s.userData.labels=[b]}else if(i.kind==="i"){let c=l(new Me(new Ss(.11,18,12),o(1)));c.renderOrder=8;for(let f of[[1,0,0],[0,1,0],[0,0,1]])l(new Me(new li(.02,.02,.9,6),o(.9))).quaternion.setFromUnitVectors(Tc,Sr(f));let u=Sc(i.label,a,n*.8);u.position.set(.28,.34,.28),s.add(u),s.userData.labels=[u]}return s.userData.mats=r,s.userData.el=i,s.traverse(c=>{c.material&&c.isMesh&&(c.renderOrder=c.renderOrder||10)}),s}var No=class i{constructor(t,e){this.container=e,this.renderer=new Co({canvas:t,antialias:!0,alpha:!0,powerPreference:"high-performance"}),this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)),this.renderer.setClearColor(0,0),this.scene=new js,this.camera=new We(38,1,.1,200),this.scene.add(new or(15134975,6957706,1.25)),this.key=new Es(16777215,1.35),this.scene.add(this.key),this.scene.add(this.key.target),this.fill=new Es(16736210,.7),this.fill.position.set(-4,-3,-2),this.scene.add(this.fill),this.controls=new Lo(this.camera,t),this.controls.enableDamping=!0,this.controls.dampingFactor=.09,this.controls.enablePan=!1,this.controls.autoRotateSpeed=1.1,this.controls.addEventListener("start",()=>{var n;this.userTouched=!0,(n=this.onInteract)==null||n.call(this)}),this.molRoot=new dn,this.elRoot=new dn,this.scene.add(this.molRoot,this.elRoot),this.style="ball",this.showLabels=!0,this.playing=null,this._raf=0,this.ro=new ResizeObserver(()=>this.resize()),this.ro.observe(e),this.resize(),this.renderer.setAnimationLoop(n=>this.frame(n))}resize(){let t=this.container.clientWidth||300,e=this.container.clientHeight||300;this.renderer.setSize(t,e,!1),this.camera.aspect=t/e,this.camera.updateProjectionMatrix(),this.reach&&this.fit(!1)}fit(t=!0){let e=this.reach,n=this.camera.fov*Math.PI/360,s=Math.atan(Math.tan(n)*this.camera.aspect),r=e/Math.sin(Math.min(n,s))*1.04;if(t){let a=new U(.62,.5,.82).normalize();this.camera.position.copy(a.multiplyScalar(r))}else{let a=this.camera.position.clone().normalize();this.camera.position.copy(a.multiplyScalar(r))}this.controls.minDistance=r*.45,this.controls.maxDistance=r*1.8,this.controls.target.set(0,0,0),this.controls.update()}resetView(){this.fit(!0)}load(t,e){var a;this.cancelPlay();for(let o of[this.molRoot,this.elRoot])for(;o.children.length;){let l=o.children.pop();(a=l.traverse)==null||a.call(l,c=>{var u,f;(f=(u=c.geometry)==null?void 0:u.dispose)==null||f.call(u)})}this.mol=t,this.main=new Do(t),this.main.setStyle(this.style),this.molRoot.add(this.main.group);let n=t.radius+.75,s=t.radius+.35;this.reach=s+.45;let r=Math.max(.8,t.radius*.36);this.elObjects=new Map;for(let o of e.elements){if(o.kind==="E")continue;let l=F_(o,n,s,r);l.visible=!1,this.elRoot.add(l),this.elObjects.set(o.id,l)}this.fit(!0),this.userTouched=!1}setElements(t,e){for(let[n,s]of this.elObjects){let r=!e||e.has(n);s.visible=!!(t.has(n)||e&&e.has(n));for(let{m:a,base:o,focus:l}of s.userData.mats)a.opacity=e?r?Math.max(l,o):o*.22:o;for(let a of s.userData.labels||[])a.visible=this.showLabels,a.material.opacity=!e||r?1:.25}}setLabels(t){var e;this.showLabels=t;for(let n of((e=this.elObjects)==null?void 0:e.values())||[])for(let s of n.userData.labels||[])s.visible=t}setStyle(t){var e,n;this.style=t,(e=this.main)==null||e.setStyle(t),(n=this.mover)==null||n.setStyle(t)}setAutoRotate(t){this.controls.autoRotate=t}positionsAt(t,e,n){let s=this.mol.atoms.map(a=>a.p),r=bc(n);switch(t.type){case"rot":return s.map(a=>Gi(a,t.axis,t.angle*e*r));case"refl":return s.map(a=>{let o=2*r*(a[0]*t.normal[0]+a[1]*t.normal[1]+a[2]*t.normal[2]);return[a[0]-o*t.normal[0],a[1]-o*t.normal[1],a[2]-o*t.normal[2]]});case"inv":return s.map(a=>a.map(o=>o*(1-2*r)));case"imp":{if(n<.5)return s.map(o=>Gi(o,t.axis,t.angle*bc(n*2)));let a=bc(n*2-1);return s.map(o=>{let l=Gi(o,t.axis,t.angle),c=2*a*(l[0]*t.axis[0]+l[1]*t.axis[1]+l[2]*t.axis[2]);return[l[0]-c*t.axis[0],l[1]-c*t.axis[1],l[2]-c*t.axis[2]]})}default:return s}}static duration(t,e=1){return{id:1400,rot:1700+500*(e-1),refl:2200,inv:2600,imp:3600}[t.type]||1800}play(t,e=1){return this.cancelPlay(),new Promise(n=>{let s=new Do(this.mol,{numbers:!0});s.setStyle(this.style),this.mover=s,this.molRoot.add(s.group),this.main.setOpacity(.3);let r=i.duration(t,e),a=1300;this.playing={op:t,k:e,t0:performance.now(),dur:r,hold:a,resolve:n}})}cancelPlay(){if(!this.playing)return;let t=this.playing;this.playing=null,this.endPlay(),t.resolve(!1)}endPlay(){var t;this.mover&&(this.molRoot.remove(this.mover.group),this.mover.dispose(),this.mover=null),(t=this.main)==null||t.setOpacity(1)}frame(t){if(this.playing){let e=this.playing,n=t-e.t0,s=Math.min(1,n/e.dur);this.mover.setPositions(this.positionsAt(e.op,e.k,s)),n>e.dur+e.hold&&(this.playing=null,this.endPlay(),e.resolve(!0))}this.controls.update(),this.key.position.copy(this.camera.position).add(new U(2,3,1)),this.renderer.render(this.scene,this.camera)}};var ku=(i,t,e)=>Math.min(e,Math.max(t,i)),Ec=(i,t,e)=>{let n=ku((e-i)/(t-i),0,1);return n*n*(3-2*n)},O_=i=>1-Math.pow(1-i,3);function zu({root:i,canvas:t,kicker:e,sub:n,skip:s,onDone:r,lines:a,fontStyle:o="italic 600",fontFam:l='"Cormorant Garamond", "Iowan Old Style", Georgia, serif',rtl:c=!1}){let u=a,f=window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches,h=t.getContext("2d"),p=Math.min(window.devicePixelRatio||1,2),_=0,b=0,m=0,d=!1,E=0,A=null,y=null;function S(){_=i.clientWidth,b=i.clientHeight,t.width=Math.round(_*p),t.height=Math.round(b*p),t.style.width=`${_}px`,t.style.height=`${b}px`}function M(){S();let B=document.createElement("canvas");B.width=_,B.height=b;let R=B.getContext("2d");R.font=`${o} 100px ${l}`;let z=Math.max(...u.map(H=>R.measureText(H).width)),q=Math.min(_*.8/z*100,b*.17,150);R.font=`${o} ${q}px ${l}`,R.direction=c?"rtl":"ltr",R.textAlign="center",R.textBaseline="alphabetic",R.fillStyle="#fff";let Z=q*.98,rt=b*.4-Z;u.forEach((H,at)=>R.fillText(H,_/2,rt+Z*(at+1)-q*.08));let $=R.getImageData(0,0,_,b).data,K=Math.max(2,Math.round(q/30)),st;for(;;){st=[];for(let H=0;H<b;H+=K)for(let at=0;at<_;at+=K)$[(H*_+at)*4+3]>110&&st.push(at,H);if(st.length/2<=6500)break;K++}let Tt=st.length/2,ht=b,Y=0;for(let H=0;H<Tt;H++)ht=Math.min(ht,st[2*H+1]),Y=Math.max(Y,st[2*H+1]);A={n:Tt,tx:new Float32Array(Tt),ty:new Float32Array(Tt),sx:new Float32Array(Tt),sy:new Float32Array(Tt),dl:new Float32Array(Tt),du:new Float32Array(Tt),tw:new Uint8Array(Tt),sz:K};let J=_/2,nt=b/2,O=Math.max(_,b)*.75;for(let H=0;H<Tt;H++){A.tx[H]=st[2*H],A.ty[H]=st[2*H+1];let at=Math.random()*Math.PI*2,ut=O*(.45+Math.random()*.7);A.sx[H]=J+Math.cos(at)*ut,A.sy[H]=nt+Math.sin(at)*ut*.8,A.dl[H]=Math.random()*900,A.du[H]=1250+Math.random()*600,A.tw[H]=Math.random()<.12?1:0}y={minY:ht,maxY:Y,mirrorY:Y+q*.32,fs:q,blockH:Y-ht},e.style.top=`${Math.max(14,ht-q*.62)}px`,n.style.top=`${Math.min(b-150,y.mirrorY+y.blockH*.78)}px`}function C(B){let R=h.createRadialGradient(_/2,b*.42,0,_/2,b*.42,Math.max(_,b)*.8);R.addColorStop(0,"#3a1670"),R.addColorStop(.55,"#14204f"),R.addColorStop(1,"#050a22"),h.fillStyle=R,h.fillRect(0,0,_,b);let z=Math.min(_,b)*.44,q=_/2,Z=b*.42,rt=B*7e-5;h.save(),h.translate(q,Z),h.rotate(rt),h.strokeStyle="rgba(0,229,255,0.16)",h.lineWidth=1.2,h.beginPath();for(let $=0;$<6;$++){let K=$*Math.PI/3;h.lineTo(Math.cos(K)*z,Math.sin(K)*z)}h.closePath(),h.stroke(),h.beginPath();for(let $=0;$<3;$++){let K=$*Math.PI/3;h.moveTo(Math.cos(K)*z*1.12,Math.sin(K)*z*1.12),h.lineTo(-Math.cos(K)*z*1.12,-Math.sin(K)*z*1.12)}h.stroke(),h.restore()}function x(B){if(d)return;E||(E=B);let R=f?9999:(B-E)/1.5;h.setTransform(p,0,0,p,0,0),C(R);let z=-_*.1+Ec(2300,3700,R)*_*1.2,q=_*.06,Z=Ec(1700,2800,R),rt=A.sz*.78,$=8,K=Array.from({length:$},()=>[]),st=[];for(let ht=0;ht<A.n;ht++){let Y=ku((R-A.dl[ht])/A.du[ht],0,1),J=O_(Y),nt=A.tx[ht],O=A.ty[ht];if(Y<1){let ut=(A.sx[ht]-nt)*(1-J),ct=(A.sy[ht]-O)*(1-J),bt=(1-J)*1.7,Lt=Math.cos(bt),At=Math.sin(bt);nt+=ut*Lt-ct*At,O+=ut*At+ct*Lt}let at=R>2300&&Math.abs(A.tx[ht]-z)<q?7:A.tw[ht]&&Y>=1?6:Math.min(5,Math.max(0,Math.floor(A.tx[ht]/_*6)));K[at].push(nt,O,Y)}let Tt=["#ffd23f","#ff9a1f","#ff3d8b","#b14dff","#2f9bff","#19f0c8","#fff3b0","#ffffff"];for(let ht=0;ht<$;ht++){h.fillStyle=Tt[ht];let Y=K[ht];for(let J=0;J<Y.length;J+=3)h.globalAlpha=.25+.75*Y[J+2],h.fillRect(Y[J]-rt/2,Y[J+1]-rt/2,rt,rt)}if(Z>.01){let ht=y.mirrorY;for(let J=0;J<$;J++){h.fillStyle=Tt[J];let nt=K[J];for(let O=0;O<nt.length;O+=3){let H=2*ht-nt[O+1],at=1-(H-ht)/(y.blockH*.95);at<=0||nt[O+2]<1||(h.globalAlpha=.3*Z*at,h.fillRect(nt[O]-rt/2,H-rt/2,rt,rt))}}h.globalAlpha=Z;let Y=h.createLinearGradient(_*.08,0,_*.92,0);Y.addColorStop(0,"rgba(56,208,240,0)"),Y.addColorStop(.5,"rgba(56,208,240,0.8)"),Y.addColorStop(1,"rgba(56,208,240,0)"),h.fillStyle=Y,h.fillRect(_*.08,ht-.5,_*.84,1.2),h.fillStyle="rgba(56,208,240,0.85)",h.font='italic 600 15px "Cormorant Garamond", Georgia, serif',h.textAlign="left",h.fillText("\u03C3",_*.08,ht-7),h.font='italic 600 10px "Cormorant Garamond", Georgia, serif',h.fillText("h",_*.08+9,ht-3)}if(R>2300&&R<3800){let ht=Math.sin(Ec(2300,3800,R)*Math.PI);h.globalAlpha=.55*ht,h.fillStyle="#9fe9ff",h.fillRect(z-.6,y.minY-y.fs*.25,1.2,y.blockH+y.fs*.5)}if(h.globalAlpha=1,R>(f?0:700)&&e.classList.add("on"),R>(f?0:2500)&&n.classList.add("on"),R>(f?1800:5600))return T();m=requestAnimationFrame(x)}function T(){d||(d=!0,cancelAnimationFrame(m),i.classList.add("out"),setTimeout(()=>{i.remove(),r==null||r()},650))}s.addEventListener("click",T),i.addEventListener("pointerdown",T);let P=()=>{M(),m=requestAnimationFrame(x)},F=!1,N=()=>{F||(F=!0,P())};document.fonts&&document.fonts.load?Promise.race([document.fonts.load(`${o} 64px ${l.split(",")[0]}`,u.join("")),new Promise(B=>setTimeout(B,1200))]).then(N,N):N()}var Us={lang:"en"},Jn=()=>Us.lang==="fa",tt=(i,t)=>Jn()?t:i,B_="\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9",Te=i=>Jn()?String(i).replace(/\d/g,t=>B_[t]):String(i);function Hu(){let i=null;try{i=localStorage.getItem("msl-lang")}catch{}return i||(i=(navigator.language||"").toLowerCase().startsWith("fa")?"fa":"en"),Us.lang=i==="fa"?"fa":"en",Us.lang}function wc(i){Us.lang=i;try{localStorage.setItem("msl-lang",i)}catch{}let t=document.documentElement;t.lang=i,t.dir=i==="fa"?"rtl":"ltr"}var Se=(i,t=document)=>t.querySelector(i),k_=i=>new Promise(t=>setTimeout(t,i)),Ac=new Map,Wu=i=>(Ac.has(i.id)||Ac.set(i.id,Yc(i.atoms)),Ac.get(i.id)),Xu=i=>Jn()?$o[i.id][0]:i.name,z_=i=>Jn()?$o[i.id][1]:i.note,Fi=i=>i.steps[Us.lang],Oo=i=>`<bdi dir="ltr">${Te(i)}\xB0</bdi>`,Mr=i=>i?tt("Yes","\u0628\u0644\u0647"):tt("No","\u062E\u06CC\u0631"),$u="msl-v2",ot={i:0,tab:"elements",visibleTypes:new Set,sel:null,ded:{},revealed:new Set,quiz:{score:0,total:0,streak:0,picked:null},rotate:!0,labels:!0,style:"ball",tour:null,busy:!1,focus:null};try{let i=JSON.parse(localStorage.getItem($u)||"null");i&&(ot.revealed=new Set(i.revealed||[]),Object.assign(ot.quiz,i.quiz||{},{picked:null}))}catch{}var qu=()=>{try{localStorage.setItem($u,JSON.stringify({revealed:[...ot.revealed],quiz:{score:ot.quiz.score,total:ot.quiz.total,streak:ot.quiz.streak}}))}catch{}},pn=()=>gn[ot.i],cn=()=>Wu(pn()),me=null,H_={title:["Molecular Symmetry Lab","\u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647 \u062A\u0642\u0627\u0631\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644\u06CC"],by:["Devised by Dr. Alireza Khorshidi","\u0637\u0631\u0627\u062D\u06CC \u0648 \u062A\u0623\u0644\u06CC\u0641: \u062F\u06A9\u062A\u0631 \u0639\u0644\u06CC\u0631\u0636\u0627 \u062E\u0648\u0631\u0634\u06CC\u062F\u06CC"],tabElements:["Elements","\u0639\u0646\u0627\u0635\u0631"],tabDeduce:["Deduce","\u0627\u0633\u062A\u0646\u062A\u0627\u062C"],tabLearn:["Learn","\u0622\u0645\u0648\u0632\u0634"],tabQuiz:["Quiz","\u0622\u0632\u0645\u0648\u0646"],aboutBtn:["About this app","\u062F\u0631\u0628\u0627\u0631\u0647\u0654 \u0628\u0631\u0646\u0627\u0645\u0647"],aboutCredit:["Devised and developed by","\u0637\u0631\u0627\u062D\u06CC \u0648 \u062A\u0623\u0644\u06CC\u0641"],aboutName:["Dr. Alireza Khorshidi","\u062F\u06A9\u062A\u0631 \u0639\u0644\u06CC\u0631\u0636\u0627 \u062E\u0648\u0631\u0634\u06CC\u062F\u06CC"],aboutRole:["Professor of Inorganic Chemistry, University of Guilan, Rasht, Iran","\u0627\u0633\u062A\u0627\u062F \u0634\u06CC\u0645\u06CC \u0645\u0639\u062F\u0646\u06CC\u060C \u062F\u0627\u0646\u0634\u06AF\u0627\u0647 \u06AF\u06CC\u0644\u0627\u0646\u060C \u0631\u0634\u062A\u060C \u0627\u06CC\u0631\u0627\u0646"],about1:["Drag to rotate the molecule and pinch to zoom.","\u0628\u0631\u0627\u06CC \u0686\u0631\u062E\u0627\u0646\u062F\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u06A9\u0634\u06CC\u062F \u0648 \u0628\u0631\u0627\u06CC \u0628\u0632\u0631\u06AF\u200C\u0646\u0645\u0627\u06CC\u06CC \u062F\u0648 \u0627\u0646\u06AF\u0634\u062A \u0631\u0627 \u0627\u0632 \u0647\u0645 \u062F\u0648\u0631 \u06A9\u0646\u06CC\u062F."],about2:["<b>Elements</b> lists every axis, plane and centre this molecule has, and plays each operation atom by atom.","<b>\u0639\u0646\u0627\u0635\u0631</b> \u0647\u0645\u0647\u0654 \u0645\u062D\u0648\u0631\u0647\u0627\u060C \u0635\u0641\u062D\u0647\u200C\u0647\u0627 \u0648 \u0645\u0631\u0627\u06A9\u0632 \u062A\u0642\u0627\u0631\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0641\u0647\u0631\u0633\u062A \u0645\u06CC\u200C\u06A9\u0646\u062F \u0648 \u0647\u0631 \u0639\u0645\u0644 \u0631\u0627 \u0627\u062A\u0645\u200C\u0628\u0647\u200C\u0627\u062A\u0645 \u0646\u0634\u0627\u0646 \u0645\u06CC\u200C\u062F\u0647\u062F."],about3:["<b>Deduce</b> takes you through the point-group flowchart one question at a time.","<b>\u0627\u0633\u062A\u0646\u062A\u0627\u062C</b> \u0634\u0645\u0627 \u0631\u0627 \u067E\u0631\u0633\u0634\u200C\u0628\u0647\u200C\u067E\u0631\u0633\u0634 \u062F\u0631 \u0646\u0645\u0648\u062F\u0627\u0631 \u06AF\u0631\u062F\u0634\u06CC \u06AF\u0631\u0648\u0647\u200C\u0647\u0627\u06CC \u0646\u0642\u0637\u0647\u200C\u0627\u06CC \u0647\u0645\u0631\u0627\u0647\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F."],about4:["<b>Quiz</b> asks for the point group of a molecule you have not seen yet.","<b>\u0622\u0632\u0645\u0648\u0646</b> \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC \u0645\u0648\u0644\u06A9\u0648\u0644\u06CC \u0631\u0627 \u0645\u06CC\u200C\u067E\u0631\u0633\u062F \u06A9\u0647 \u0647\u0646\u0648\u0632 \u0646\u062F\u06CC\u062F\u0647\u200C\u0627\u06CC\u062F."],aboutSmall:["Symmetry elements are found by the app itself from the 3D coordinates, then fed into the flowchart. Geometries are idealised textbook values and bond orders are not drawn.","\u0639\u0646\u0627\u0635\u0631 \u062A\u0642\u0627\u0631\u0646 \u0631\u0627 \u062E\u0648\u062F \u0628\u0631\u0646\u0627\u0645\u0647 \u0627\u0632 \u0645\u062E\u062A\u0635\u0627\u062A \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u067E\u06CC\u062F\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F \u0648 \u0633\u067E\u0633 \u0628\u0647 \u0646\u0645\u0648\u062F\u0627\u0631 \u06AF\u0631\u062F\u0634\u06CC \u0645\u06CC\u200C\u062F\u0647\u062F. \u0647\u0646\u062F\u0633\u0647\u200C\u0647\u0627 \u0645\u0642\u0627\u062F\u06CC\u0631 \u0622\u0631\u0645\u0627\u0646\u06CC \u06A9\u062A\u0627\u0628\u200C\u0647\u0627\u06CC \u062F\u0631\u0633\u06CC\u200C\u0627\u0646\u062F \u0648 \u0645\u0631\u062A\u0628\u0647\u0654 \u067E\u06CC\u0648\u0646\u062F\u0647\u0627 \u0631\u0633\u0645 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A."],close:["Close","\u0628\u0633\u062A\u0646"],pgLabel:["Point group","\u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC"],langBtn:["\u0641\u0627","EN"],langAria:["Switch to Persian","\u062A\u063A\u06CC\u06CC\u0631 \u0628\u0647 \u0627\u0646\u06AF\u0644\u06CC\u0633\u06CC"],aRotate:["Auto-rotate","\u0686\u0631\u062E\u0634 \u062E\u0648\u062F\u06A9\u0627\u0631"],aLabels:["Element labels","\u0628\u0631\u0686\u0633\u0628 \u0639\u0646\u0627\u0635\u0631"],aStyle:["Space-filling model","\u0645\u062F\u0644 \u0641\u0636\u0627\u067E\u0631\u06A9\u0646"],aReset:["Reset view","\u0628\u0627\u0632\u0646\u0634\u0627\u0646\u06CC \u0646\u0645\u0627"],aPrev:["Previous molecule","\u0645\u0648\u0644\u06A9\u0648\u0644 \u0642\u0628\u0644\u06CC"],aNext:["Next molecule","\u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0639\u062F\u06CC"],sKicker:["Devised by","\u0637\u0631\u0627\u062D\u06CC \u0648 \u062A\u0623\u0644\u06CC\u0641"],sTitle:["Molecular Symmetry Lab","\u0622\u0632\u0645\u0627\u06CC\u0634\u06AF\u0627\u0647 \u062A\u0642\u0627\u0631\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644\u06CC"],sRole:["Professor of Inorganic Chemistry","\u0627\u0633\u062A\u0627\u062F \u0634\u06CC\u0645\u06CC \u0645\u0639\u062F\u0646\u06CC"],sUni:["University of Guilan \xB7 Rasht, Iran","\u062F\u0627\u0646\u0634\u06AF\u0627\u0647 \u06AF\u06CC\u0644\u0627\u0646 \xB7 \u0631\u0634\u062A\u060C \u0627\u06CC\u0631\u0627\u0646"],sSkip:["Skip","\u0631\u062F \u0634\u062F\u0646"]},Oi=i=>H_[i][Jn()?1:0];function Yu(){document.querySelectorAll("[data-i18n]").forEach(i=>{i.innerHTML=Oi(i.dataset.i18n)}),document.querySelectorAll("[data-i18n-aria]").forEach(i=>{i.setAttribute("aria-label",Oi(i.dataset.i18nAria))}),document.title=Oi("title")}var V_={2:"Two-fold",3:"Three-fold",4:"Four-fold",5:"Five-fold",6:"Six-fold"},Vu={h:"\u0627\u0641\u0642\u06CC",v:"\u0639\u0645\u0648\u062F\u06CC",d:"\u062F\u0648\u0648\u062C\u0647\u06CC"};function yi(i){if(i.kind==="E")return"\u06CC\u06A9\u0633\u0627\u0646\u06CC";if(i.kind==="i")return"\u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC";let t=Number.isFinite(i.n)?Te(i.n):"\u221E";return i.kind==="C"?`\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 ${t}${i.label.x?" "+i.label.x:""}`:i.kind==="S"?`\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 ${t}`:`\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646${Vu[i.label.s]?" "+Vu[i.label.s]:""}`}var Zu=i=>Jn()?yi(i):Si(i.label);function Ju(i){let t=i.label;if(i.kind==="E")return{name:tt("Identity","\u06CC\u06A9\u0633\u0627\u0646\u06CC"),desc:tt("Do nothing at all. Every molecule has this operation, and every point group contains it. It is the reference that other operations are compared with.","\u0647\u06CC\u0686 \u06A9\u0627\u0631\u06CC \u0646\u06A9\u0646\u06CC\u062F. \u0647\u0631 \u0645\u0648\u0644\u06A9\u0648\u0644\u06CC \u0627\u06CC\u0646 \u0639\u0645\u0644 \u0631\u0627 \u062F\u0627\u0631\u062F \u0648 \u0647\u0631 \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC \u0622\u0646 \u0631\u0627 \u0634\u0627\u0645\u0644 \u0645\u06CC\u200C\u0634\u0648\u062F. \u0627\u06CC\u0646 \u0639\u0645\u0644 \u0645\u0628\u0646\u0627\u06CC\u06CC \u0627\u0633\u062A \u06A9\u0647 \u0628\u0642\u06CC\u0647\u0654 \u0639\u0645\u0644\u200C\u0647\u0627 \u0628\u0627 \u0622\u0646 \u0633\u0646\u062C\u06CC\u062F\u0647 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F.")};if(i.kind==="i")return{name:tt("Centre of inversion","\u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC"),desc:tt("Every atom at (x, y, z) is carried through the centre to (\u2212x, \u2212y, \u2212z). This works only if each atom has an identical partner on the opposite side at the same distance.","\u0647\u0631 \u0627\u062A\u0645 \u0648\u0627\u0642\u0639 \u062F\u0631 (x, y, z) \u0627\u0632 \u0645\u0631\u06A9\u0632 \u0645\u06CC\u200C\u06AF\u0630\u0631\u062F \u0648 \u0628\u0647 (\u2212x, \u2212y, \u2212z) \u0645\u06CC\u200C\u0631\u0648\u062F. \u0627\u06CC\u0646 \u0641\u0642\u0637 \u0648\u0642\u062A\u06CC \u0634\u062F\u0646\u06CC \u0627\u0633\u062A \u06A9\u0647 \u0647\u0631 \u0627\u062A\u0645 \u062F\u0631 \u0633\u0645\u062A \u0645\u0642\u0627\u0628\u0644 \u0648 \u0628\u0627 \u0647\u0645\u0627\u0646 \u0641\u0627\u0635\u0644\u0647 \u06CC\u06A9 \u0647\u0645\u200C\u0627\u0631\u0632 \u06CC\u06A9\u0633\u0627\u0646 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.")};if(i.kind==="C"){if(!Number.isFinite(i.n))return{name:tt("Infinite-fold axis",yi(i)),desc:tt("The molecule is linear, so a rotation by any angle about the bond axis leaves it unchanged.","\u0645\u0648\u0644\u06A9\u0648\u0644 \u062E\u0637\u06CC \u0627\u0633\u062A\u061B \u067E\u0633 \u0686\u0631\u062E\u0634 \u0628\u0627 \u0647\u0631 \u0632\u0627\u0648\u06CC\u0647\u200C\u0627\u06CC \u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u067E\u06CC\u0648\u0646\u062F \u0622\u0646 \u0631\u0627 \u0628\u062F\u0648\u0646 \u062A\u063A\u06CC\u06CC\u0631 \u0645\u06CC\u200C\u06AF\u0630\u0627\u0631\u062F.")};let s=i.members.some(a=>a.principal),r=360/i.n;return{name:tt(`${V_[i.n]} rotation axis`,yi(i)),desc:tt(`Rotate the molecule by 360\xB0/${i.n} = ${r}\xB0 about the axis and it looks exactly as before; identical atoms simply swap places.${i.n>2?` Repeating the turn gives C<sub>${i.n}</sub><sup>2</sup>, C<sub>${i.n}</sub><sup>3</sup> and so on; ${i.n} turns return to E.`:""}${s?" This is the <b>principal axis</b>, the axis of highest order.":""}${t.x==="\u2032"?" The prime marks an axis perpendicular to the principal axis.":""}${t.x==="\u2033"?" Two primes mark the second set of perpendicular axes, the ones lying between the single-prime axes.":""}`,`\u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0628\u0647 \u0627\u0646\u062F\u0627\u0632\u0647\u0654 <bdi dir="ltr">360\xB0/${i.n} = ${r}\xB0</bdi> \u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F\u061B \u062F\u0642\u06CC\u0642\u0627\u064B \u0647\u0645\u0627\u0646 \u0634\u06A9\u0644 \u067E\u06CC\u0634\u06CC\u0646 \u0628\u0647 \u062F\u0633\u062A \u0645\u06CC\u200C\u0622\u06CC\u062F \u0648 \u0627\u062A\u0645\u200C\u0647\u0627\u06CC \u06CC\u06A9\u0633\u0627\u0646 \u0641\u0642\u0637 \u062C\u0627\u06CC \u0647\u0645 \u0631\u0627 \u0645\u06CC\u200C\u06AF\u06CC\u0631\u0646\u062F.${i.n>2?` \u062A\u06A9\u0631\u0627\u0631 \u0686\u0631\u062E\u0634\u060C \u0645\u0636\u0631\u0628\u200C\u0647\u0627\u06CC \u0628\u0639\u062F\u06CC \u0632\u0627\u0648\u06CC\u0647 \u0631\u0627 \u0645\u06CC\u200C\u062F\u0647\u062F \u0648 \u067E\u0633 \u0627\u0632 ${Te(i.n)} \u0686\u0631\u062E\u0634 \u0628\u0647 \u06CC\u06A9\u0633\u0627\u0646\u06CC \u0645\u06CC\u200C\u0631\u0633\u06CC\u0645.`:""}${s?" \u0627\u06CC\u0646 <b>\u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC</b> \u0627\u0633\u062A\u060C \u06CC\u0639\u0646\u06CC \u0645\u062D\u0648\u0631\u06CC \u0628\u0627 \u0628\u0627\u0644\u0627\u062A\u0631\u06CC\u0646 \u0645\u0631\u062A\u0628\u0647.":""}${t.x==="\u2032"?" \u0639\u0644\u0627\u0645\u062A \u2032 \u0646\u0634\u0627\u0646 \u0645\u06CC\u200C\u062F\u0647\u062F \u0645\u062D\u0648\u0631 \u0628\u0631 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0639\u0645\u0648\u062F \u0627\u0633\u062A.":""}${t.x==="\u2033"?" \u0639\u0644\u0627\u0645\u062A \u2033 \u062F\u0633\u062A\u0647\u0654 \u062F\u0648\u0645 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u0639\u0645\u0648\u062F\u06CC \u0631\u0627 \u0646\u0634\u0627\u0646 \u0645\u06CC\u200C\u062F\u0647\u062F\u060C \u06CC\u0639\u0646\u06CC \u0622\u0646\u200C\u0647\u0627\u06CC\u06CC \u06A9\u0647 \u0645\u06CC\u0627\u0646 \u0645\u062D\u0648\u0631\u0647\u0627\u06CC \u062A\u06A9\u200C\u067E\u0631\u0627\u06CC\u0645 \u0642\u0631\u0627\u0631 \u062F\u0627\u0631\u0646\u062F.":""}`)}}if(i.kind==="S"){let s=Number.isFinite(i.n)?i.n:null;return{name:tt("Improper rotation axis",yi(i)),desc:tt(`S<sub>${s??"\u221E"}</sub> is a two-step operation: rotate by 360\xB0/${s??"n"}, then reflect in the plane perpendicular to the axis. The pair counts as one operation, even if neither step works alone. (S<sub>1</sub> is just \u03C3 and S<sub>2</sub> is just i.)`,`${yi(i)} \u06CC\u06A9 \u0639\u0645\u0644 \u062F\u0648\u0645\u0631\u062D\u0644\u0647\u200C\u0627\u06CC \u0627\u0633\u062A: \u0627\u0628\u062A\u062F\u0627 <bdi dir="ltr">360\xB0/${s??"n"}</bdi> \u0628\u0686\u0631\u062E\u06CC\u062F \u0648 \u0633\u067E\u0633 \u062F\u0631 \u0635\u0641\u062D\u0647\u0654 \u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F. \u0627\u06CC\u0646 \u062F\u0648 \u06AF\u0627\u0645 \u0628\u0627 \u0647\u0645 \u06CC\u06A9 \u0639\u0645\u0644 \u0628\u0647 \u0634\u0645\u0627\u0631 \u0645\u06CC\u200C\u0622\u06CC\u0646\u062F\u060C \u062D\u062A\u06CC \u0627\u06AF\u0631 \u0647\u06CC\u0686\u200C\u06CC\u06A9 \u0628\u0647\u200C\u062A\u0646\u0647\u0627\u06CC\u06CC \u062A\u0642\u0627\u0631\u0646 \u0646\u0628\u0627\u0634\u062F. (\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F1 \u0647\u0645\u0627\u0646 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0647\u0645\u0627\u0646 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u0633\u062A.)`),extra:i.implied?tt("Here the rotation and the perpendicular mirror plane are both present, so S comes along for free.","\u062F\u0631 \u0627\u06CC\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0647\u0645 \u0686\u0631\u062E\u0634 \u0648 \u0647\u0645 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061B \u067E\u0633 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u062E\u0648\u062F\u0628\u0647\u200C\u062E\u0648\u062F \u0628\u0647 \u062F\u0633\u062A \u0645\u06CC\u200C\u0622\u06CC\u062F."):tt("<b>A genuine improper axis.</b> Neither the rotation by itself nor the reflection by itself is a symmetry operation here. Only the combination is.","<b>\u06CC\u06A9 \u0645\u062D\u0648\u0631 \u0645\u0631\u06A9\u0628\u0654 \u0648\u0627\u0642\u0639\u06CC.</b> \u062F\u0631 \u0627\u06CC\u0646\u062C\u0627 \u0646\u0647 \u0686\u0631\u062E\u0634 \u0628\u0647\u200C\u062A\u0646\u0647\u0627\u06CC\u06CC \u0639\u0645\u0644 \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A \u0648 \u0646\u0647 \u0628\u0627\u0632\u062A\u0627\u0628 \u0628\u0647\u200C\u062A\u0646\u0647\u0627\u06CC\u06CC\u061B \u0641\u0642\u0637 \u062A\u0631\u06A9\u06CC\u0628 \u0622\u0646\u200C\u0647\u0627 \u062A\u0642\u0627\u0631\u0646 \u0627\u0633\u062A.")}}let e=t.s,n=e==="h"?tt("It lies perpendicular to the principal axis.","\u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0628\u0631 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0639\u0645\u0648\u062F \u0627\u0633\u062A."):e==="v"?tt("It contains the principal axis.","\u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F."):e==="d"?tt("It contains the principal axis and bisects the angle between two C<sub>2</sub> axes.","\u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0631\u0627 \u062F\u0631 \u0628\u0631 \u062F\u0627\u0631\u062F \u0648 \u0632\u0627\u0648\u06CC\u0647\u0654 \u0645\u06CC\u0627\u0646 \u062F\u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0631\u0627 \u0646\u0635\u0641 \u0645\u06CC\u200C\u06A9\u0646\u062F."):"";return{name:e==="h"?tt("Horizontal mirror plane","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC"):e==="v"?tt("Vertical mirror plane","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC"):e==="d"?tt("Dihedral mirror plane","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC"):tt("Mirror plane","\u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646"),desc:tt(`Reflecting every atom through this plane gives back the same molecule. Atoms on one side trade places with identical atoms on the other; atoms lying in the plane stay where they are. ${n}${i.infinite?" A linear molecule has infinitely many such planes, all containing the axis.":""}`,`\u0628\u0627\u0632\u062A\u0627\u0628 \u0647\u0645\u0647\u0654 \u0627\u062A\u0645\u200C\u0647\u0627 \u062F\u0631 \u0627\u06CC\u0646 \u0635\u0641\u062D\u0647 \u0647\u0645\u0627\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0628\u0631\u0645\u06CC\u200C\u06AF\u0631\u062F\u0627\u0646\u062F. \u0627\u062A\u0645\u200C\u0647\u0627\u06CC \u06CC\u06A9 \u0633\u0648\u06CC \u0635\u0641\u062D\u0647 \u0628\u0627 \u0627\u062A\u0645\u200C\u0647\u0627\u06CC \u06CC\u06A9\u0633\u0627\u0646 \u0633\u0648\u06CC \u062F\u06CC\u06AF\u0631 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F \u0648 \u0627\u062A\u0645\u200C\u0647\u0627\u06CC\u06CC \u06A9\u0647 \u0631\u0648\u06CC \u0635\u0641\u062D\u0647\u200C\u0627\u0646\u062F \u0633\u0631 \u062C\u0627\u06CC\u0634\u0627\u0646 \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F. ${n}${i.infinite?" \u0645\u0648\u0644\u06A9\u0648\u0644 \u062E\u0637\u06CC \u0628\u06CC\u200C\u0634\u0645\u0627\u0631 \u0635\u0641\u062D\u0647\u0654 \u0627\u06CC\u0646\u200C\u0686\u0646\u06CC\u0646\u06CC \u062F\u0627\u0631\u062F \u06A9\u0647 \u0647\u0645\u06AF\u06CC \u0645\u062D\u0648\u0631 \u0631\u0627 \u062F\u0631 \u0628\u0631 \u0645\u06CC\u200C\u06AF\u06CC\u0631\u0646\u062F.":""}`)}}var G_=i=>Ju(i).name;function W_(i,t){if(i.kind==="C"){if(!Number.isFinite(i.n))return tt("Rotate about the axis","\u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u0628\u0686\u0631\u062E\u0627\u0646");let e=360*t/i.n;return i.n>2?tt(`Rotate ${e}\xB0 (C<sub>${i.n}</sub><sup>${t}</sup>)`,`${Oo(e)} \u0628\u0686\u0631\u062E\u0627\u0646`):tt(`Rotate ${e}\xB0`,`${Oo(e)} \u0628\u0686\u0631\u062E\u0627\u0646`)}return i.kind==="S"?tt("Rotate, then reflect","\u0628\u0686\u0631\u062E\u0627\u0646 \u0648 \u0633\u067E\u0633 \u0628\u0627\u0632\u062A\u0627\u0628 \u0628\u062F\u0647"):i.kind==="sigma"?tt("Reflect","\u0628\u0627\u0632\u062A\u0627\u0628 \u0628\u062F\u0647"):i.kind==="i"?tt("Invert","\u0648\u0627\u0631\u0648\u0646\u0647 \u06A9\u0646"):tt("Apply E","\u06CC\u06A9\u0633\u0627\u0646\u06CC \u0631\u0627 \u0627\u0639\u0645\u0627\u0644 \u06A9\u0646")}function Ku(i,t){if(i.kind==="E")return tt("E: nothing moves. Every atom stays on its own position.","\u06CC\u06A9\u0633\u0627\u0646\u06CC: \u0647\u06CC\u0686 \u0686\u06CC\u0632 \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0646\u0645\u06CC\u200C\u0634\u0648\u062F \u0648 \u0647\u0631 \u0627\u062A\u0645 \u0633\u0631 \u062C\u0627\u06CC \u062E\u0648\u062F\u0634 \u0645\u06CC\u200C\u0645\u0627\u0646\u062F.");if(i.kind==="C"){let e=i.n;if(!Number.isFinite(e))return tt("C<sub>\u221E</sub>: turn by any angle about the axis","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u221E: \u0628\u0627 \u0647\u0631 \u0632\u0627\u0648\u06CC\u0647\u200C\u0627\u06CC \u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F");let n=360*t/e;return tt(`${Si(i.label)}${e>2?`<sup>${t}</sup>`:""}: turn ${n}\xB0 about the axis`,`${yi(i)}: ${Oo(n)} \u062D\u0648\u0644 \u0645\u062D\u0648\u0631 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F`)}return i.kind==="S"?tt(`${Si(i.label)}: turn ${Number.isFinite(i.n)?360/i.n+"\xB0":"by any angle"}, then reflect across the plane perpendicular to the axis`,`${yi(i)}: ${Number.isFinite(i.n)?Oo(360/i.n):"\u0628\u0627 \u0647\u0631 \u0632\u0627\u0648\u06CC\u0647\u200C\u0627\u06CC"} \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F \u0648 \u0633\u067E\u0633 \u062F\u0631 \u0635\u0641\u062D\u0647\u0654 \u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F`):i.kind==="sigma"?tt(`${Si(i.label)}: reflect every atom through the plane`,`${yi(i)}: \u0647\u0645\u0647\u0654 \u0627\u062A\u0645\u200C\u0647\u0627 \u0631\u0627 \u062F\u0631 \u0635\u0641\u062D\u0647 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F`):tt("i: send every atom through the centre to the opposite side","\u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC: \u0647\u0631 \u0627\u062A\u0645 \u0631\u0627 \u0627\u0632 \u0645\u0631\u06A9\u0632 \u0628\u0647 \u0633\u0645\u062A \u0645\u0642\u0627\u0628\u0644 \u0628\u0628\u0631\u06CC\u062F")}function X_(i,t){let e=new Set;for(let n of i.types)t.has(n.key)&&n.members.forEach(s=>e.add(s.id));return e}function $_(){if(!ot.sel)return null;let t=cn().types.find(r=>r.key===ot.sel.key);if(!t)return null;let e=t.members.filter(r=>!r.hidden);if(ot.sel.member==null)return new Set(t.members.map(r=>r.id));let n=e[ot.sel.member]||e[0],s=new Set([n.id]);return t.members.filter(r=>r.hidden&&r.infinite).forEach(r=>s.add(r.id)),s}var Bi=()=>ot.ded[pn().id]||={i:0,log:[],done:!1,wrong:0,hint:!1,lastShow:null};function Ue(){if(!me)return;let i=cn(),t=new Set,e=null;if(ot.tab==="deduce"){let n=Bi(),s=Fi(i);n.log.forEach(a=>(s[a].show||[]).forEach(o=>t.add(o))),n.done&&i.elements.forEach(a=>t.add(a.id));let r=s[n.i];n.hint&&r?e=new Set(r.show):n.lastShow&&n.lastShow.length&&!n.done&&(e=new Set(n.lastShow))}else ot.tab==="quiz"?ot.quiz.picked&&i.elements.forEach(n=>t.add(n.id)):(t=X_(i,ot.visibleTypes),e=ot.focus||$_());me.setElements(t,e&&e.size?e:null)}function Bo(){let i=pn();Se("#mol-name").textContent=Xu(i),Se("#mol-formula").innerHTML=i.formula,Se("#mol-count").textContent=`${Te(ot.i+1)} / ${Te(gn.length)}`;let t=ot.revealed.has(i.id),e=Se("#pg-badge");e.innerHTML=`<span class="k">${Oi("pgLabel")}</span>${t?`<span class="v">${Mi(cn().group)}</span>`:'<span class="v q">?</span>'}`,e.classList.toggle("known",t),Se("#lang-btn").textContent=Oi("langBtn"),Se("#lang-btn").setAttribute("aria-label",Oi("langAria"))}function ko(){let i=Se("#picker");i.innerHTML=gn.map((e,n)=>`<button class="chip${n===ot.i?" on":""}${ot.revealed.has(e.id)?" done":""}" data-act="mol" data-i="${n}" aria-label="${Xu(e).replace(/"/g,"")}"><span class="f">${e.formula}</span>${ot.revealed.has(e.id)?`<span class="g">${Mi(Wu(e).group)}</span>`:""}</button>`).join("");let t=Se(".chip.on",i);if(t){let e=t.offsetLeft-i.clientWidth/2+t.clientWidth/2;i.scrollTo({left:e,behavior:"smooth"})}}function q_(i){let t=Fo(Uo(i.members[0])),e=ot.visibleTypes.has(i.key),n=ot.sel&&ot.sel.key===i.key,s=i.infinite?"\u221E":`\xD7${Te(i.count)}`,r=i.kind==="sigma"?"plane":i.kind==="i"?"dot":i.kind==="S"?"ring":i.kind==="E"?"dot":"axis";return`<li class="row${n?" sel":""}" style="--c:${t}">
    <button class="row-main" data-act="type" data-key="${i.key}">
      <span class="sw ${r}"></span>
      <span class="sy">${Si(i.label)}</span>
      <span class="nm">${G_(i)}${i.implied&&i.kind==="S"?` <i>${tt("(implied)","(\u0636\u0645\u0646\u06CC)")}</i>`:""}</span>
      <span class="ct">${s}</span>
    </button>
    ${i.kind==="E"?'<span class="eye none"></span>':`<button class="eye${e?" on":""}" data-act="eye" data-key="${i.key}" aria-label="${tt("Show or hide","\u0646\u0645\u0627\u06CC\u0634 \u06CC\u0627 \u067E\u0646\u0647\u0627\u0646\u200C\u06A9\u0631\u062F\u0646")} ${i.key}" aria-pressed="${e}"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></button>`}
  </li>`}function Y_(){let i=cn();if(!ot.sel)return`<div class="card tip">${tt("Tap an element in the list to light it up in the 3D view, read what it is, and watch the operation.","\u0631\u0648\u06CC \u06CC\u06A9 \u0639\u0646\u0635\u0631 \u062F\u0631 \u0641\u0647\u0631\u0633\u062A \u0628\u0632\u0646\u06CC\u062F \u062A\u0627 \u062F\u0631 \u0646\u0645\u0627\u06CC \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u0631\u0648\u0634\u0646 \u0634\u0648\u062F\u061B \u062A\u0648\u0636\u06CC\u062D \u0622\u0646 \u0631\u0627 \u0628\u062E\u0648\u0627\u0646\u06CC\u062F \u0648 \u0639\u0645\u0644 \u0631\u0627 \u0628\u0628\u06CC\u0646\u06CC\u062F.")}</div>`;let t=i.types.find(l=>l.key===ot.sel.key);if(!t)return"";let e=Ju(t),n=t.members.filter(l=>!l.hidden),s=ot.sel.k||1,r=Fo(Uo(t.members[0])),a=n.length>1?`<div class="stepper" role="group">
      <button class="pill${ot.sel.member==null?" on":""}" data-act="member" data-m="all">${tt(`All ${n.length}`,`\u0647\u0645\u0647\u0654 ${Te(n.length)}`)}</button>
      ${n.map((l,c)=>`<button class="pill${ot.sel.member===c?" on":""}" data-act="member" data-m="${c}">${Te(c+1)}</button>`).join("")}
    </div>`:"",o=t.infinite?tt("infinitely many","\u0628\u06CC\u200C\u0634\u0645\u0627\u0631"):t.count===1?tt("1 in this molecule","\u06CC\u06A9\u06CC \u062F\u0631 \u0627\u06CC\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644"):tt(`${t.count} in this molecule`,`${Te(t.count)} \u0639\u062F\u062F \u062F\u0631 \u0627\u06CC\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644`);return`<section class="card sel" style="--c:${r}">
    <div class="card-h"><span class="sym">${Si(t.label)}</span><div class="ttl"><b>${e.name}</b><span>${o}</span></div></div>
    <p>${e.desc}</p>
    ${e.extra?`<p class="callout">${e.extra}</p>`:""}
    ${a}
    <div class="btnrow"><button class="btn primary" data-act="perform" ${ot.busy?"disabled":""}>\u25B6 ${W_(t,s)}</button></div>
  </section>`}function Z_(){let i=cn(),t=i.elements.filter(s=>!s.hidden).length,e=i.types.length===1?tt("This molecule has no symmetry beyond the identity.","\u0627\u06CC\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 \u062C\u0632 \u06CC\u06A9\u0633\u0627\u0646\u06CC \u0647\u06CC\u0686 \u062A\u0642\u0627\u0631\u0646\u06CC \u0646\u062F\u0627\u0631\u062F."):tt(`Symmetry elements are the axes, planes and points that operations are carried out about. This molecule has <b>${t}</b> of them in <b>${i.types.length}</b> kinds.`,`\u0639\u0646\u0627\u0635\u0631 \u062A\u0642\u0627\u0631\u0646\u06CC \u0647\u0645\u0627\u0646 \u0645\u062D\u0648\u0631\u0647\u0627\u060C \u0635\u0641\u062D\u0647\u200C\u0647\u0627 \u0648 \u0646\u0642\u0637\u0647\u200C\u0647\u0627\u06CC\u06CC \u0647\u0633\u062A\u0646\u062F \u06A9\u0647 \u0639\u0645\u0644\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646\u06CC \u0646\u0633\u0628\u062A \u0628\u0647 \u0622\u0646\u200C\u0647\u0627 \u0627\u0646\u062C\u0627\u0645 \u0645\u06CC\u200C\u0634\u0648\u062F. \u0627\u06CC\u0646 \u0645\u0648\u0644\u06A9\u0648\u0644 <b>${Te(t)}</b> \u0639\u0646\u0635\u0631 \u062F\u0631 <b>${Te(i.types.length)}</b> \u0646\u0648\u0639 \u062F\u0627\u0631\u062F.`),n=ot.tour?` ${Te(ot.tour.n)}/${Te(i.types.length)}`:"";return`
    <p class="lead">${e}</p>
    <div class="btnrow">
      <button class="btn primary" data-act="tour">${ot.tour?`\u25A0 ${tt("Stop tour","\u062A\u0648\u0642\u0641 \u06AF\u0634\u062A")}${n}`:`\u25B6 ${tt("Tour the elements","\u06AF\u0634\u062A \u062F\u0631 \u0639\u0646\u0627\u0635\u0631")}`}</button>
      <button class="btn" data-act="show-all">${tt("Show all","\u0646\u0645\u0627\u06CC\u0634 \u0647\u0645\u0647")}</button>
      <button class="btn" data-act="hide-all">${tt("Hide all","\u067E\u0646\u0647\u0627\u0646\u200C\u06A9\u0631\u062F\u0646 \u0647\u0645\u0647")}</button>
    </div>
    ${Y_()}
    <ul class="types">${i.types.map(q_).join("")}</ul>
    <p class="note"><b>${tt("About","\u062F\u0631\u0628\u0627\u0631\u0647\u0654")} ${pn().formula}:</b> ${z_(pn())}</p>`}function J_(){let i=cn(),t=pn(),e=Bi(),n=Fi(i),s=e.log.map(a=>{let o=n[a];return o.type==="info"?`<li class="log"><span class="tick">\u2022</span><div><span class="lq">${tt("Principal axis","\u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC")}</span><span class="lw">${o.text}</span></div></li>`:`<li class="log"><span class="tick ${o.a?"":"no"}">${Mr(o.a)}</span><div><span class="lq">${o.q}</span><span class="lw">${o.why}</span></div></li>`}).join(""),r="";if(e.done){let a=i.group,o=i.types.filter(l=>l.kind!=="E").map(l=>`${l.infinite?"\u221E":Te(l.count)} ${Zu(l)}`).join(" \xB7 ")||tt("E","\u06CC\u06A9\u0633\u0627\u0646\u06CC");r=`<section class="card result">
      <div class="kick">${Oi("pgLabel")}</div>
      <div class="pg">${Mi(a)}</div>
      <div class="facts">
        <div><span>${tt("Order h","\u0645\u0631\u062A\u0628\u0647 h")}</span><b>${Te(i.order)}</b></div>
        <div><span>${tt("Polar","\u0642\u0637\u0628\u06CC")}</span><b>${Mr(i.polar)}</b></div>
        <div><span>${tt("Chiral","\u06A9\u0627\u06CC\u0631\u0627\u0644")}</span><b>${Mr(i.chiral)}</b></div>
      </div>
      <p class="muted">${tt("Elements","\u0639\u0646\u0627\u0635\u0631")}: ${tt("E","\u06CC\u06A9\u0633\u0627\u0646\u06CC")} \xB7 ${o}</p>
      <p class="muted small">${i.polar?tt("Polar: the group allows a permanent dipole moment.","\u0642\u0637\u0628\u06CC: \u0627\u06CC\u0646 \u06AF\u0631\u0648\u0647 \u06AF\u0634\u062A\u0627\u0648\u0631 \u062F\u0648\u0642\u0637\u0628\u06CC \u062F\u0627\u0626\u0645\u06CC \u0631\u0627 \u0645\u062C\u0627\u0632 \u0645\u06CC\u200C\u062F\u0627\u0646\u062F."):tt("Non-polar: the symmetry cancels any permanent dipole.","\u0646\u0627\u0642\u0637\u0628\u06CC: \u062A\u0642\u0627\u0631\u0646 \u0647\u0631 \u06AF\u0634\u062A\u0627\u0648\u0631 \u062F\u0648\u0642\u0637\u0628\u06CC \u062F\u0627\u0626\u0645\u06CC \u0631\u0627 \u062E\u0646\u062B\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F.")} ${i.chiral?tt("Chiral: no mirror plane, inversion centre or S<sub>n</sub> axis, so it can be optically active.","\u06A9\u0627\u06CC\u0631\u0627\u0644: \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646\u060C \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u06CC\u0627 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 n \u0646\u062F\u0627\u0631\u062F\u061B \u067E\u0633 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0641\u0639\u0627\u0644 \u0646\u0648\u0631\u06CC \u0628\u0627\u0634\u062F."):tt("Achiral: an improper operation is present.","\u0622\u06A9\u0627\u06CC\u0631\u0627\u0644: \u062F\u0633\u062A\u200C\u06A9\u0645 \u06CC\u06A9 \u0639\u0645\u0644 \u0645\u0631\u06A9\u0628 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F.")}</p>
      <div class="btnrow"><button class="btn primary" data-act="next-mol">${tt("Next molecule \u2192","\u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0639\u062F\u06CC \u2190")}</button><button class="btn" data-act="redo">${tt("Start again","\u0627\u0632 \u0646\u0648")}</button></div>
    </section>`}else{let a=n[e.i];a.type==="info"?r=`<section class="card q"><div class="kick">${tt("Step","\u06AF\u0627\u0645")} ${Te(e.i+1)}</div><p class="qt">${a.text}</p><div class="btnrow"><button class="btn primary" data-act="ded-info">${tt("Continue","\u0627\u062F\u0627\u0645\u0647")}</button></div></section>`:r=`<section class="card q${e.wrong?" shake":""}" id="qcard"><div class="kick">${tt("Step","\u06AF\u0627\u0645")} ${Te(e.i+1)}</div><p class="qt">${a.q}</p>
        <div class="yn"><button class="btn yes" data-act="ans" data-v="1">${Mr(!0)}</button><button class="btn no" data-act="ans" data-v="0">${Mr(!1)}</button></div>
        ${e.wrong?`<p class="wrong">${tt("Not quite.","\u062F\u0631\u0633\u062A \u0646\u06CC\u0633\u062A.")} ${e.hint?tt("The elements to check are lit up in 3D.","\u0639\u0646\u0627\u0635\u0631\u06CC \u06A9\u0647 \u0628\u0627\u06CC\u062F \u0628\u0631\u0631\u0633\u06CC \u06A9\u0646\u06CC\u062F \u062F\u0631 \u0646\u0645\u0627\u06CC \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u0631\u0648\u0634\u0646 \u0634\u062F\u0647\u200C\u0627\u0646\u062F."):""}</p>`:""}
        <div class="btnrow tight">${a.show.length?`<button class="link" data-act="hint">${e.hint?tt("Hide hint","\u067E\u0646\u0647\u0627\u0646\u200C\u06A9\u0631\u062F\u0646 \u0631\u0627\u0647\u0646\u0645\u0627"):tt("Light up what to look for","\u0639\u0646\u0627\u0635\u0631 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u0631\u0627 \u0631\u0648\u0634\u0646 \u06A9\u0646")}</button>`:""}${e.wrong>=2?`<button class="link" data-act="reveal">${tt("Show me the answer","\u067E\u0627\u0633\u062E \u0631\u0627 \u0646\u0634\u0627\u0646 \u0628\u062F\u0647")}</button>`:""}</div>
      </section>`}return`<p class="lead">${tt(`Work out the point group of ${t.formula} with the standard flowchart. Rotate the model, answer each question, and the elements you find stay on screen.`,`\u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC ${t.formula} \u0631\u0627 \u0628\u0627 \u0646\u0645\u0648\u062F\u0627\u0631 \u06AF\u0631\u062F\u0634\u06CC \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u062A\u0639\u06CC\u06CC\u0646 \u06A9\u0646\u06CC\u062F. \u0645\u062F\u0644 \u0631\u0627 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F\u060C \u0628\u0647 \u0647\u0631 \u067E\u0631\u0633\u0634 \u067E\u0627\u0633\u062E \u062F\u0647\u06CC\u062F \u0648 \u0639\u0646\u0627\u0635\u0631\u06CC \u06A9\u0647 \u067E\u06CC\u062F\u0627 \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F \u0631\u0648\u06CC \u0635\u0641\u062D\u0647 \u0645\u06CC\u200C\u0645\u0627\u0646\u0646\u062F.`)}</p>
    ${r}
    ${s?`<ol class="logs">${s}</ol>`:""}`}var K_=[["C<sub>1</sub>","Nothing but E","\u062C\u0632 \u06CC\u06A9\u0633\u0627\u0646\u06CC \u0647\u06CC\u0686 \u0639\u0646\u0635\u0631\u06CC \u0646\u06CC\u0633\u062A","chfclbr"],["C<sub>s</sub>","One mirror plane","\u06CC\u06A9 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646","ch2clf"],["C<sub>i</sub>","Inversion centre only","\u0641\u0642\u0637 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC","meso-ci"],["C<sub>n</sub>","One C<sub>n</sub> axis, nothing else","\u0641\u0642\u0637 \u06CC\u06A9 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n","h2o2"],["C<sub>nv</sub>","C<sub>n</sub> plus n vertical planes","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n \u0648 n \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC","nh3"],["C<sub>nh</sub>","C<sub>n</sub> plus \u03C3<sub>h</sub>","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n \u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC","tdce"],["S<sub>2n</sub>","Only an S<sub>2n</sub> axis","\u0641\u0642\u0637 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F2n","pentaerythritol"],["D<sub>n</sub>","C<sub>n</sub> plus n perpendicular C<sub>2</sub>","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n \u0648 n \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F \u0628\u0631 \u0622\u0646","ethane-30"],["D<sub>nh</sub>","D<sub>n</sub> plus \u03C3<sub>h</sub>","D<sub>n</sub> \u0648 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC","bf3"],["D<sub>nd</sub>","D<sub>n</sub> plus n \u03C3<sub>d</sub>, no \u03C3<sub>h</sub>","D<sub>n</sub> \u0648 n \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC\u060C \u0628\u062F\u0648\u0646 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC","ethane-60"],["C<sub>\u221Ev</sub>","Linear, ends differ","\u062E\u0637\u06CC\u060C \u062F\u0648 \u0633\u0631 \u0645\u062A\u0641\u0627\u0648\u062A","hcl"],["D<sub>\u221Eh</sub>","Linear, ends match","\u062E\u0637\u06CC\u060C \u062F\u0648 \u0633\u0631 \u06CC\u06A9\u0633\u0627\u0646","co2"],["T<sub>d</sub>","Four C<sub>3</sub>, no i","\u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3\u060C \u0628\u062F\u0648\u0646 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC","ch4"],["T<sub>h</sub>","Four C<sub>3</sub>, i, no C<sub>4</sub>","\u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC\u060C \u0628\u062F\u0648\u0646 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F4","conitro"],["O<sub>h</sub>","Three C<sub>4</sub>, four C<sub>3</sub>, i","\u0633\u0647 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F4\u060C \u0686\u0647\u0627\u0631 \u0645\u062D\u0648\u0631 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC","sf6"],["I<sub>h</sub>","Six C<sub>5</sub>, i","\u0634\u0634 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F5 \u0648 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC","b12h12"]];function j_(){return`
  <section class="card">
    <h3>${tt("Symmetry operations and elements","\u0639\u0645\u0644\u200C\u0647\u0627 \u0648 \u0639\u0646\u0627\u0635\u0631 \u062A\u0642\u0627\u0631\u0646\u06CC")}</h3>
    <p>${tt("An <b>operation</b> moves the molecule so that it ends up indistinguishable from the start. The <b>element</b> is the point, line or plane the operation is carried out about.","\u06CC\u06A9 <b>\u0639\u0645\u0644 \u062A\u0642\u0627\u0631\u0646\u06CC</b> \u0645\u0648\u0644\u06A9\u0648\u0644 \u0631\u0627 \u0637\u0648\u0631\u06CC \u062C\u0627\u0628\u0647\u200C\u062C\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F \u06A9\u0647 \u062F\u0631 \u067E\u0627\u06CC\u0627\u0646 \u0627\u0632 \u062D\u0627\u0644\u062A \u0622\u063A\u0627\u0632\u06CC\u0646 \u0642\u0627\u0628\u0644\u200C\u062A\u0634\u062E\u06CC\u0635 \u0646\u0628\u0627\u0634\u062F. <b>\u0639\u0646\u0635\u0631 \u062A\u0642\u0627\u0631\u0646\u06CC</b> \u0646\u0642\u0637\u0647\u060C \u062E\u0637 \u06CC\u0627 \u0635\u0641\u062D\u0647\u200C\u0627\u06CC \u0627\u0633\u062A \u06A9\u0647 \u0639\u0645\u0644 \u0646\u0633\u0628\u062A \u0628\u0647 \u0622\u0646 \u0627\u0646\u062C\u0627\u0645 \u0645\u06CC\u200C\u0634\u0648\u062F.")}</p>
    <div class="scroll-x"><table class="tbl"><thead><tr><th>${tt("Element","\u0639\u0646\u0635\u0631")}</th><th>${tt("Operation","\u0639\u0645\u0644")}</th><th>${tt("Symbol","\u0646\u0645\u0627\u062F")}</th></tr></thead><tbody>
      <tr><td>${tt("Whole molecule","\u06A9\u0644 \u0645\u0648\u0644\u06A9\u0648\u0644")}</td><td>${tt("Identity","\u06CC\u06A9\u0633\u0627\u0646\u06CC")}</td><td>E</td></tr>
      <tr><td>${tt("Axis","\u0645\u062D\u0648\u0631")}</td><td>${tt("Rotation by 360\xB0/n",'\u0686\u0631\u062E\u0634 \u0628\u0647 \u0627\u0646\u062F\u0627\u0632\u0647\u0654 <bdi dir="ltr">360\xB0/n</bdi>')}</td><td>C<sub>n</sub></td></tr>
      <tr><td>${tt("Plane","\u0635\u0641\u062D\u0647")}</td><td>${tt("Reflection","\u0628\u0627\u0632\u062A\u0627\u0628")}</td><td>\u03C3 (\u03C3<sub>h</sub>, \u03C3<sub>v</sub>, \u03C3<sub>d</sub>)</td></tr>
      <tr><td>${tt("Point","\u0646\u0642\u0637\u0647")}</td><td>${tt("Inversion","\u0648\u0627\u0631\u0648\u0646\u06AF\u06CC")}</td><td>i</td></tr>
      <tr><td>${tt("Axis + plane","\u0645\u062D\u0648\u0631 + \u0635\u0641\u062D\u0647")}</td><td>${tt("Improper rotation","\u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628")}</td><td>S<sub>n</sub></td></tr>
    </tbody></table></div>
  </section>
  <section class="card" style="--c:#ff6fb5">
    <h3>${tt("Improper rotation, S<sub>n</sub>","\u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 (\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 n)")}</h3>
    <p>${tt("Rotate by 360\xB0/n, then reflect in the plane perpendicular to the axis. Do both steps and count it as one operation. Sometimes neither step is a symmetry on its own, and yet the pair works.",'\u0627\u0628\u062A\u062F\u0627 <bdi dir="ltr">360\xB0/n</bdi> \u0628\u0686\u0631\u062E\u06CC\u062F\u060C \u0633\u067E\u0633 \u062F\u0631 \u0635\u0641\u062D\u0647\u0654 \u0639\u0645\u0648\u062F \u0628\u0631 \u0645\u062D\u0648\u0631 \u0628\u0627\u0632\u062A\u0627\u0628 \u062F\u0647\u06CC\u062F. \u0647\u0631 \u062F\u0648 \u06AF\u0627\u0645 \u0631\u0627 \u0627\u0646\u062C\u0627\u0645 \u062F\u0647\u06CC\u062F \u0648 \u0622\u0646 \u0631\u0627 \u06CC\u06A9 \u0639\u0645\u0644 \u0628\u0634\u0645\u0627\u0631\u06CC\u062F. \u06AF\u0627\u0647\u06CC \u0647\u06CC\u0686\u200C\u06A9\u062F\u0627\u0645 \u0627\u0632 \u062F\u0648 \u06AF\u0627\u0645 \u0628\u0647\u200C\u062A\u0646\u0647\u0627\u06CC\u06CC \u062A\u0642\u0627\u0631\u0646 \u0646\u06CC\u0633\u062A\u060C \u0627\u0645\u0627 \u062A\u0631\u06A9\u06CC\u0628 \u0622\u0646\u200C\u0647\u0627 \u062A\u0642\u0627\u0631\u0646 \u0627\u0633\u062A.')}</p>
    <p class="callout">${tt("S<sub>1</sub> is the same as \u03C3, and S<sub>2</sub> is the same as i. The first genuinely new case is S<sub>3</sub>, and S<sub>4</sub> is the one that surprises people.","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F1 \u0647\u0645\u0627\u0646 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0648 \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0647\u0645\u0627\u0646 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u0627\u0633\u062A. \u0646\u062E\u0633\u062A\u06CC\u0646 \u062D\u0627\u0644\u062A \u0648\u0627\u0642\u0639\u0627\u064B \u062A\u0627\u0632\u0647 \u0645\u0631\u062A\u0628\u0647\u0654 \u06F3 \u0627\u0633\u062A \u0648 \u0645\u0631\u062A\u0628\u0647\u0654 \u06F4 \u0647\u0645\u0627\u0646 \u0627\u0633\u062A \u06A9\u0647 \u0628\u06CC\u0634\u062A\u0631 \u062F\u0627\u0646\u0634\u062C\u0648\u06CC\u0627\u0646 \u0631\u0627 \u0634\u06AF\u0641\u062A\u200C\u0632\u062F\u0647 \u0645\u06CC\u200C\u06A9\u0646\u062F.")}</p>
    <p>${tt("Watch each one happen, atom by atom:","\u0647\u0631 \u06A9\u062F\u0627\u0645 \u0631\u0627 \u0627\u062A\u0645\u200C\u0628\u0647\u200C\u0627\u062A\u0645 \u0628\u0628\u06CC\u0646\u06CC\u062F:")}</p>
    <div class="btnrow wrapb">
      <button class="btn" data-act="demo" data-id="allene" data-key="S4">${tt("S<sub>4</sub> in allene","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u062F\u0631 \u0622\u0644\u0646")}</button>
      <button class="btn" data-act="demo" data-id="ethane-60" data-key="S6">${tt("S<sub>6</sub> in staggered ethane","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6 \u062F\u0631 \u0627\u062A\u0627\u0646 \u06A9\u062C\u200C\u0627\u06CC\u0633\u062A\u0627")}</button>
      <button class="btn" data-act="demo" data-id="bf3" data-key="S3">${tt("S<sub>3</sub> in BF<sub>3</sub>","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F3 \u062F\u0631 BF<sub>3</sub>")}</button>
      <button class="btn" data-act="demo" data-id="ch4" data-key="S4">${tt("S<sub>4</sub> in methane","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u062F\u0631 \u0645\u062A\u0627\u0646")}</button>
      <button class="btn" data-act="demo" data-id="pentaerythritol" data-key="S4">${tt("S<sub>4</sub> as the only axis","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F4 \u0628\u0647\u200C\u0639\u0646\u0648\u0627\u0646 \u062A\u0646\u0647\u0627 \u0645\u062D\u0648\u0631")}</button>
      <button class="btn" data-act="demo" data-id="hexol" data-key="S6">${tt("S<sub>6</sub> as the only axis","\u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F6 \u0628\u0647\u200C\u0639\u0646\u0648\u0627\u0646 \u062A\u0646\u0647\u0627 \u0645\u062D\u0648\u0631")}</button>
    </div>
  </section>
  <section class="card">
    <h3>${tt("Point-group cheat sheet","\u0631\u0627\u0647\u0646\u0645\u0627\u06CC \u0633\u0631\u06CC\u0639 \u06AF\u0631\u0648\u0647\u200C\u0647\u0627\u06CC \u0646\u0642\u0637\u0647\u200C\u0627\u06CC")}</h3>
    <p class="small muted">${tt("Tap an example to load it.","\u0628\u0631\u0627\u06CC \u0628\u0627\u0631\u06AF\u0630\u0627\u0631\u06CC\u060C \u0631\u0648\u06CC \u06CC\u06A9 \u0645\u062B\u0627\u0644 \u0628\u0632\u0646\u06CC\u062F.")}</p>
    <ul class="cheat">${K_.map(([i,t,e,n])=>{let s=gn.find(r=>r.id===n);return`<li><span class="cg">${i}</span><span class="cd">${tt(t,e)}</span><button class="pill" data-act="demo" data-id="${n}">${s.formula}</button></li>`}).join("")}</ul>
  </section>
  <section class="card">
    <h3>${tt("The flowchart in one breath","\u0646\u0645\u0648\u062F\u0627\u0631 \u06AF\u0631\u062F\u0634\u06CC \u062F\u0631 \u06CC\u06A9 \u0646\u06AF\u0627\u0647")}</h3>
    <ol class="flow">
      <li>${tt("Linear? <b>D<sub>\u221Eh</sub></b> with i, otherwise <b>C<sub>\u221Ev</sub></b>.","\u062E\u0637\u06CC \u0627\u0633\u062A\u061F \u0627\u06AF\u0631 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC \u062F\u0627\u0631\u062F <b>D<sub>\u221Eh</sub></b>\u060C \u0648\u06AF\u0631\u0646\u0647 <b>C<sub>\u221Ev</sub></b>.")}</li>
      <li>${tt("Several C<sub>n</sub> with n \u2265 3? Cubic family: <b>T<sub>d</sub>, T<sub>h</sub>, O<sub>h</sub>, I<sub>h</sub></b> and their rotation-only cousins.","\u0686\u0646\u062F \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 n \u0628\u0627 n \u2265 \u06F3\u061F \u062E\u0627\u0646\u0648\u0627\u062F\u0647\u0654 \u0645\u06A9\u0639\u0628\u06CC \u0648 \u0628\u06CC\u0633\u062A\u0648\u062C\u0647\u06CC: <b>T<sub>d</sub>\u060C T<sub>h</sub>\u060C O<sub>h</sub>\u060C I<sub>h</sub></b> \u0648 \u0647\u0645\u062A\u0627\u06CC\u0627\u0646 \u062A\u0646\u0647\u0627\u200C\u062F\u0648\u0631\u0627\u0646\u06CC \u0622\u0646\u200C\u0647\u0627.")}</li>
      <li>${tt("No axis? <b>C<sub>s</sub></b> with a plane, <b>C<sub>i</sub></b> with i, else <b>C<sub>1</sub></b>.","\u0645\u062D\u0648\u0631 \u0646\u062F\u0627\u0631\u062F\u061F \u0628\u0627 \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 <b>C<sub>s</sub></b>\u060C \u0628\u0627 \u0645\u0631\u06A9\u0632 \u0648\u0627\u0631\u0648\u0646\u06AF\u06CC <b>C<sub>i</sub></b>\u060C \u0648\u06AF\u0631\u0646\u0647 <b>C<sub>1</sub></b>.")}</li>
      <li>${tt("Find the principal axis. n perpendicular C<sub>2</sub>? Then D: \u03C3<sub>h</sub> gives <b>D<sub>nh</sub></b>, n \u03C3<sub>d</sub> gives <b>D<sub>nd</sub></b>, else <b>D<sub>n</sub></b>.","\u0645\u062D\u0648\u0631 \u0627\u0635\u0644\u06CC \u0631\u0627 \u067E\u06CC\u062F\u0627 \u06A9\u0646\u06CC\u062F. n \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u062D\u0636 \u0645\u0631\u062A\u0628\u0647 \u06F2 \u0639\u0645\u0648\u062F\u06CC \u062F\u0627\u0631\u062F\u061F \u067E\u0633 D \u0627\u0633\u062A: \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u06CC\u0639\u0646\u06CC <b>D<sub>nh</sub></b>\u060C n \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u062F\u0648\u0648\u062C\u0647\u06CC \u06CC\u0639\u0646\u06CC <b>D<sub>nd</sub></b>\u060C \u0648\u06AF\u0631\u0646\u0647 <b>D<sub>n</sub></b>.")}</li>
      <li>${tt("Otherwise C: \u03C3<sub>h</sub> gives <b>C<sub>nh</sub></b>, \u03C3<sub>v</sub> planes give <b>C<sub>nv</sub></b>, an S<sub>2n</sub> axis gives <b>S<sub>2n</sub></b>, else <b>C<sub>n</sub></b>.","\u062F\u0631 \u063A\u06CC\u0631 \u0627\u06CC\u0646 \u0635\u0648\u0631\u062A \u06AF\u0631\u0648\u0647 C \u0627\u0633\u062A: \u0635\u0641\u062D\u0647 \u062A\u0642\u0627\u0631\u0646 \u0627\u0641\u0642\u06CC \u06CC\u0639\u0646\u06CC <b>C<sub>nh</sub></b>\u060C \u0635\u0641\u062D\u0647\u200C\u0647\u0627\u06CC \u062A\u0642\u0627\u0631\u0646 \u0639\u0645\u0648\u062F\u06CC \u06CC\u0639\u0646\u06CC <b>C<sub>nv</sub></b>\u060C \u0645\u062D\u0648\u0631 \u062F\u0648\u0631\u0627\u0646 \u0645\u0631\u06A9\u0628 \u0645\u0631\u062A\u0628\u0647 \u06F2n \u06CC\u0639\u0646\u06CC <b>S<sub>2n</sub></b>\u060C \u0648\u06AF\u0631\u0646\u0647 <b>C<sub>n</sub></b>.")}</li>
    </ol>
  </section>`}var Q_=["C1","Cs","Ci","C2","C3","S4","S6","C2v","C3v","C4v","C5v","C2h","C3h","D2","D3","D2h","D3h","D4h","D5h","D6h","C\u221Ev","D\u221Eh","D2d","D3d","D4d","D5d","Td","Th","Oh","Ih"];function tx(i){let t=r=>(r.match(/\d|∞/)||[""])[0],e=r=>(r[0]===i[0]?2:0)+(t(r)===t(i)?1.5:0)+Math.random()*1.8,n=Q_.filter(r=>r!==i).sort((r,a)=>e(a)-e(r)).slice(0,3),s=[i,...n];for(let r=s.length-1;r>0;r--){let a=Math.floor(Math.random()*(r+1));[s[r],s[a]]=[s[a],s[r]]}return s}var Cc=new Map;function ex(){let i=cn(),t=pn(),e=ot.quiz;Cc.has(t.id)||Cc.set(t.id,tx(i.group));let n=Cc.get(t.id),s=e.picked,r=n.map(l=>`<button class="opt${s?l===i.group?" good":l===s?" bad":" dim":""}" data-act="pick" data-g="${l}" ${s?"disabled":""}>${Mi(l)}</button>`).join(""),a=i.types.filter(l=>l.kind!=="E").map(l=>`${l.infinite?"\u221E":Te(l.count)} ${Zu(l)}`).join(" \xB7 ")||tt("E","\u06CC\u06A9\u0633\u0627\u0646\u06CC"),o=s===i.group;return`<div class="scorebar"><span>${tt("Score","\u0627\u0645\u062A\u06CC\u0627\u0632")} <b>${Te(e.score)}</b> / ${Te(e.total)}</span><span>${tt("Streak","\u067E\u06CC\u0627\u067E\u06CC")} <b>${Te(e.streak)}</b></span></div>
    <section class="card q"><div class="kick">${tt("Quiz","\u0622\u0632\u0645\u0648\u0646")}</div><p class="qt">${tt(`Which point group does ${t.formula} belong to?`,`${t.formula} \u0628\u0647 \u06A9\u062F\u0627\u0645 \u06AF\u0631\u0648\u0647 \u0646\u0642\u0637\u0647\u200C\u0627\u06CC \u062A\u0639\u0644\u0642 \u062F\u0627\u0631\u062F\u061F`)}</p>
      <div class="opts">${r}</div>
      ${s?`<div class="verdict ${o?"ok":"no"}"><b>${o?tt("Correct.","\u062F\u0631\u0633\u062A \u0627\u0633\u062A."):tt(`It is ${Mi(i.group)}.`,`\u067E\u0627\u0633\u062E \u062F\u0631\u0633\u062A ${Mi(i.group)} \u0627\u0633\u062A.`)}</b> ${tt("Elements found","\u0639\u0646\u0627\u0635\u0631 \u06CC\u0627\u0641\u062A\u200C\u0634\u062F\u0647")}: ${tt("E","\u06CC\u06A9\u0633\u0627\u0646\u06CC")} \xB7 ${a}. ${tt("All of them are now shown in 3D.","\u0647\u0645\u0647\u0654 \u0622\u0646\u200C\u0647\u0627 \u0627\u06A9\u0646\u0648\u0646 \u062F\u0631 \u0646\u0645\u0627\u06CC \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u0646\u0645\u0627\u06CC\u0634 \u062F\u0627\u062F\u0647 \u0634\u062F\u0647\u200C\u0627\u0646\u062F.")}</div>`:`<p class="small muted">${tt("Rotate the model and look for axes, planes and a centre. Not sure? The Deduce tab walks through it.","\u0645\u062F\u0644 \u0631\u0627 \u0628\u0686\u0631\u062E\u0627\u0646\u06CC\u062F \u0648 \u062F\u0646\u0628\u0627\u0644 \u0645\u062D\u0648\u0631\u0647\u0627\u060C \u0635\u0641\u062D\u0647\u200C\u0647\u0627 \u0648 \u0645\u0631\u06A9\u0632 \u062A\u0642\u0627\u0631\u0646 \u0628\u06AF\u0631\u062F\u06CC\u062F. \u0645\u0637\u0645\u0626\u0646 \u0646\u06CC\u0633\u062A\u06CC\u062F\u061F \u0632\u0628\u0627\u0646\u0647\u0654 \xAB\u0627\u0633\u062A\u0646\u062A\u0627\u062C\xBB \u06AF\u0627\u0645\u200C\u0628\u0647\u200C\u06AF\u0627\u0645 \u0634\u0645\u0627 \u0631\u0627 \u0631\u0627\u0647\u0646\u0645\u0627\u06CC\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F.")}</p>`}
      <div class="btnrow"><button class="btn primary" data-act="quiz-next">${s?tt("Next molecule \u2192","\u0645\u0648\u0644\u06A9\u0648\u0644 \u0628\u0639\u062F\u06CC \u2190"):tt("Skip \u2192","\u0631\u062F \u06A9\u0631\u062F\u0646 \u2190")}</button></div>
    </section>`}function we(i=!1){let t=Se("#panel-body"),e=t.scrollTop;t.innerHTML={elements:Z_,deduce:J_,learn:j_,quiz:ex}[ot.tab](),t.scrollTop=i?e:0,document.querySelectorAll(".tab").forEach(n=>{let s=n.dataset.tab===ot.tab;n.classList.toggle("on",s),n.setAttribute("aria-selected",s)})}function Fn(i){let t=Se("#caption");t.innerHTML=i||"",t.classList.toggle("on",!!i)}function Ui(i,{tab:t}={}){Tr(),me.cancelPlay(),ot.i=(i+gn.length)%gn.length;let e=cn();ot.sel=null,ot.focus=null,ot.quiz.picked=null;let n=e.elements.filter(s=>s.kind!=="E").length;ot.visibleTypes=new Set(n<=10?e.types.map(s=>s.key):[]),t&&(ot.tab=t),me.load(pn(),e),Fn(""),Bo(),ko(),we(),Ue()}function Rc(i,t=null){ot.sel={key:i,member:t,k:1},ot.visibleTypes.add(i)}async function Gu(){if(!ot.sel||ot.busy)return;let t=cn().types.find(o=>o.key===ot.sel.key),e=t.members.filter(o=>!o.hidden),n=e[ot.sel.member??0]||e[0],s=ot.sel.k||1;ot.busy=!0,Fn(Ku(t,s)),we(!0);let r=me.controls.autoRotate;me.setAutoRotate(!1);let a=await me.play(n.op,s);me.setAutoRotate(r&&!me.userTouched),ot.busy=!1,a?(Fn(t.kind==="E"?tt("E leaves everything where it was.","\u06CC\u06A9\u0633\u0627\u0646\u06CC \u0647\u0645\u0647 \u0686\u06CC\u0632 \u0631\u0627 \u0633\u0631 \u062C\u0627\u06CC\u0634 \u0646\u06AF\u0647 \u0645\u06CC\u200C\u062F\u0627\u0631\u062F."):tt("The molecule ends up indistinguishable from the start, so this is a symmetry operation.","\u0645\u0648\u0644\u06A9\u0648\u0644 \u0627\u0632 \u062D\u0627\u0644\u062A \u0622\u063A\u0627\u0632\u06CC\u0646 \u0642\u0627\u0628\u0644\u200C\u062A\u0634\u062E\u06CC\u0635 \u0646\u06CC\u0633\u062A\u061B \u067E\u0633 \u0627\u06CC\u0646 \u06CC\u06A9 \u0639\u0645\u0644 \u062A\u0642\u0627\u0631\u0646\u06CC \u0627\u0633\u062A.")),setTimeout(()=>{ot.busy||Fn("")},2600),t.kind==="C"&&Number.isFinite(t.n)&&t.n>2&&ot.sel&&(ot.sel.k=s%(t.n-1)+1)):Fn(""),ot.sel&&we(!0)}function Tr(){ot.tour&&(ot.tour.stop=!0,ot.tour=null,me==null||me.cancelPlay())}async function nx(){if(ot.tour){Tr(),Fn(""),we(!0);return}let i=cn(),t={stop:!1,n:0};ot.tour=t,ot.visibleTypes=new Set(i.types.filter(e=>e.kind!=="E").map(e=>e.key));for(let e=0;e<i.types.length&&!t.stop;e++){let n=i.types[e];t.n=e+1,Rc(n.key,null),ot.sel.member=null,we(),Ue(),Se("#panel-body").scrollTop=0;let s=n.members.filter(a=>!a.hidden);Fn(Ku(n,1)),ot.busy=!0;let r=await me.play(s[0].op,1);if(ot.busy=!1,!r||t.stop)break;await k_(250)}ot.tour===t&&(ot.tour=null,Fn(""),we(!0),Ue())}function ix(i){let t=cn(),e=Bi(),n=Fi(t)[e.i];if(!(!n||n.type!=="yn")&&(n.a===!!i?(e.log.push(e.i),e.lastShow=n.show,e.i++,e.wrong=0,e.hint=!1,e.i>=Fi(t).length&&ju()):e.wrong++,we(!0),Ue(),e.wrong)){let s=Se("#qcard");s==null||s.classList.remove("shake"),s==null||s.offsetWidth,s==null||s.classList.add("shake")}}function ju(){let i=Bi();i.done=!0,i.lastShow=null,ot.revealed.add(pn().id),qu(),Bo(),ko()}function sx(){Yu(),Bo(),ko(),we(!0),Ue(),Fn("")}document.addEventListener("click",i=>{let t=i.target.closest("[data-act]");if(!t)return;let e=t.dataset.act,n=me?cn():null;switch(e){case"mol":Ui(+t.dataset.i);break;case"prev":Ui(ot.i-1);break;case"next":Ui(ot.i+1);break;case"lang":Tr(),me==null||me.cancelPlay(),wc(Jn()?"en":"fa"),sx();break;case"tab":Tr(),me.cancelPlay(),Fn(""),ot.tab=t.dataset.tab,ot.focus=null,we(),Ue();break;case"type":{Tr();let s=t.dataset.key;ot.sel&&ot.sel.key===s?ot.sel=null:Rc(s,null),we(!0),Ue();break}case"eye":{let s=t.dataset.key;ot.visibleTypes.has(s)?ot.visibleTypes.delete(s):ot.visibleTypes.add(s),we(!0),Ue();break}case"member":{ot.sel.member=t.dataset.m==="all"?null:+t.dataset.m,we(!0),Ue();break}case"show-all":ot.visibleTypes=new Set(n.types.filter(s=>s.kind!=="E").map(s=>s.key)),we(!0),Ue();break;case"hide-all":ot.visibleTypes=new Set,ot.sel=null,we(!0),Ue();break;case"perform":Gu();break;case"tour":nx();break;case"ans":ix(t.dataset.v==="1");break;case"ded-info":{let s=Bi(),r=Fi(n)[s.i];s.log.push(s.i),s.lastShow=r.show,s.i++,we(!0),Ue();break}case"hint":{let s=Bi();s.hint=!s.hint,we(!0),Ue();break}case"reveal":{let s=Bi(),r=Fi(n)[s.i];s.log.push(s.i),s.lastShow=r.show,s.i++,s.wrong=0,s.hint=!1,s.i>=Fi(n).length&&ju(),we(!0),Ue();break}case"redo":{delete ot.ded[pn().id],we(),Ue();break}case"next-mol":Ui(ot.i+1);break;case"demo":{let s=gn.findIndex(r=>r.id===t.dataset.id);if(Ui(s,{tab:"elements"}),t.dataset.key){let a=cn().types.find(o=>o.key===t.dataset.key);a&&(Rc(a.key,null),ot.sel.member=null,we(),Ue(),setTimeout(Gu,400))}break}case"pick":{let s=ot.quiz;if(s.picked)break;s.picked=t.dataset.g,s.total++,s.picked===n.group?(s.score++,s.streak++):s.streak=0,ot.revealed.add(pn().id),qu(),Bo(),ko(),we(!0),Ue();break}case"quiz-next":{let s=gn.map((o,l)=>l).filter(o=>o!==ot.i&&!ot.revealed.has(gn[o].id)),r=gn.map((o,l)=>l).filter(o=>o!==ot.i),a=s.length?s:r;Ui(a[Math.floor(Math.random()*a.length)]);break}case"rotate":ot.rotate=!ot.rotate,me.setAutoRotate(ot.rotate),t.classList.toggle("on",ot.rotate);break;case"labels":ot.labels=!ot.labels,me.setLabels(ot.labels),t.classList.toggle("on",ot.labels);break;case"style":ot.style=ot.style==="ball"?"space":"ball",me.setStyle(ot.style),t.classList.toggle("on",ot.style==="space");break;case"reset":me.resetView();break;case"about":Se("#about").hidden=!1;break;case"close-about":Se("#about").hidden=!0;break;case"badge":ot.revealed.has(pn().id)||(ot.tab="deduce",we(),Ue());break;default:break}});function rx(){try{me=new No(Se("#gl"),Se("#viewport"))}catch{Se("#viewport").innerHTML=`<p class="nogl">${tt("This device could not start WebGL, which the 3D view needs. Try updating Android System WebView or Chrome.","\u0627\u06CC\u0646 \u062F\u0633\u062A\u06AF\u0627\u0647 \u0646\u062A\u0648\u0627\u0646\u0633\u062A WebGL \u0631\u0627 \u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u06A9\u0646\u062F \u06A9\u0647 \u0646\u0645\u0627\u06CC \u0633\u0647\u200C\u0628\u0639\u062F\u06CC \u0628\u0647 \u0622\u0646 \u0646\u06CC\u0627\u0632 \u062F\u0627\u0631\u062F. \u0645\u0631\u0648\u0631\u06AF\u0631 \u06CC\u0627 Android System WebView \u0631\u0627 \u0628\u0647\u200C\u0631\u0648\u0632 \u06A9\u0646\u06CC\u062F.")}</p>`;return}me.setAutoRotate(!0),me.onInteract=()=>{ot.rotate&&(ot.rotate=!1,me.setAutoRotate(!1),Se('[data-act="rotate"]').classList.remove("on"))},Ui(0)}wc(Hu());Yu();var ax=['600 20px "IBM Plex Sans"','400 14px "IBM Plex Sans"','500 13px "IBM Plex Mono"','italic 600 24px "Cormorant Garamond"','400 14px "Vazirmatn"','600 14px "Vazirmatn"','700 24px "Vazirmatn"'],ox=document.fonts&&document.fonts.load?Promise.race([Promise.all(ax.map(i=>document.fonts.load(i,"\u03C3\u221EC2\u2032\u062F\u06A9\u062A\u0631"))),new Promise(i=>setTimeout(i,1500))]).catch(()=>{}):Promise.resolve();ox.then(()=>{let i=Se("#splash"),t=Se("#app");if(rx(),i){let e=Jn();zu({root:i,canvas:Se("#splash-canvas"),kicker:Se("#s-kicker"),sub:Se("#s-sub"),skip:Se("#s-skip"),lines:e?["\u062F\u06A9\u062A\u0631 \u0639\u0644\u06CC\u0631\u0636\u0627","\u062E\u0648\u0631\u0634\u06CC\u062F\u06CC"]:["Dr. Alireza","Khorshidi"],fontStyle:e?"700":"italic 600",fontFam:e?'"Vazirmatn", system-ui, sans-serif':'"Cormorant Garamond", "Iowan Old Style", Georgia, serif',rtl:e,onDone:()=>{t.removeAttribute("aria-hidden")}}),t.classList.add("ready")}else t.removeAttribute("aria-hidden"),t.classList.add("ready")});})();
