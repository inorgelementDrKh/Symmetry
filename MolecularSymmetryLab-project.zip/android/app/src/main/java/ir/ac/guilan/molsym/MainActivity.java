package ir.ac.guilan.molsym;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
