import { MOLECULES } from '../src/molecules.js';
import { analyze, symText } from '../src/symmetry.js';
let bad = 0;
for (const m of MOLECULES) {
  const t0 = performance.now();
  const a = analyze(m.atoms);
  const ms = (performance.now() - t0).toFixed(0);
  const ok = a.group === m.expected;
  if (!ok) bad++;
  const summary = a.types.map((t) => `${t.count}${t.infinite ? '∞' : ''}×${t.key}`).join(' ');
  console.log(`${ok ? 'OK ' : 'BAD'} ${m.id.padEnd(11)} expected ${m.expected.padEnd(4)} got ${a.group.padEnd(4)} h=${a.order} chiral=${a.chiral} polar=${a.polar} ${ms}ms | ${summary}`);
}
console.log(bad ? `${bad} mismatches` : 'all point groups match');
process.exit(bad ? 1 : 0);
