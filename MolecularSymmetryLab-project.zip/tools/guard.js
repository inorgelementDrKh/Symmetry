(function () {
  function sha256(str) {
    var d = new TextEncoder().encode(str), l = d.length, n = ((l + 9 + 63) >> 6) << 6, b = new Uint8Array(n);
    b.set(d); b[l] = 128; var v = new DataView(b.buffer); v.setUint32(n - 4, (l * 8) >>> 0); v.setUint32(n - 8, Math.floor(l / 536870912));
    var K = [], H = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], p = 2, c = 0, i, j;
    function pr(x) { for (var k = 2; k * k <= x; k++) if (x % k === 0) return false; return true; }
    for (; c < 64; p++) if (pr(p)) K[c++] = (Math.cbrt(p) % 1 * 4294967296) | 0;
    var w = new Int32Array(64), R = function (x, s) { return (x >>> s) | (x << (32 - s)); };
    for (i = 0; i < n; i += 64) {
      for (j = 0; j < 16; j++) w[j] = v.getInt32(i + j * 4);
      for (j = 16; j < 64; j++) { var a0 = w[j - 15], a1 = w[j - 2]; w[j] = (w[j - 16] + (R(a0, 7) ^ R(a0, 18) ^ (a0 >>> 3)) + w[j - 7] + (R(a1, 17) ^ R(a1, 19) ^ (a1 >>> 10))) | 0; }
      var h = H.slice(), x;
      for (j = 0; j < 64; j++) {
        var t1 = (h[7] + (R(h[4], 6) ^ R(h[4], 11) ^ R(h[4], 25)) + ((h[4] & h[5]) ^ (~h[4] & h[6])) + K[j] + w[j]) | 0;
        var t2 = ((R(h[0], 2) ^ R(h[0], 13) ^ R(h[0], 22)) + ((h[0] & h[1]) ^ (h[0] & h[2]) ^ (h[1] & h[2]))) | 0;
        h = [(t1 + t2) | 0, h[0], h[1], h[2], (h[3] + t1) | 0, h[4], h[5], h[6]];
      }
      for (j = 0; j < 8; j++) H[j] = (H[j] + h[j]) | 0;
    }
    return H.map(function (x) { return ('0000000' + (x >>> 0).toString(16)).slice(-8); }).join('');
  }
  var me = document.currentScript, src = document.getElementById('app-src');
  var cl = document.body.cloneNode(true), s = cl.querySelectorAll('script'), k;
  for (k = 0; k < s.length; k++) s[k].remove();
  var st = document.querySelectorAll('style'), css = '';
  for (k = 0; k < st.length; k++) css += st[k].textContent;
  var digest = sha256(css + '\u0001' + cl.innerHTML + '\u0001' + (src ? src.textContent : '') + '\u0001' + me.textContent);
  if (me.getAttribute('data-h') === 'BUILD') { window.__digest = digest; return; }
  if (digest !== me.getAttribute('data-h') || !src) {
    document.documentElement.innerHTML = '<body style="margin:0;display:grid;place-items:center;height:100vh;background:#0a0720;color:#fff;font:16px/1.8 system-ui,Tahoma,sans-serif;text-align:center;padding:24px"><div><h2 style="color:#ff3da6">Modified copy · نسخهٔ دستکاری‌شده</h2><p>This file differs from the original Molecular Symmetry Lab by Dr. Alireza Khorshidi and will not run.<br>این فایل با نسخهٔ اصلی «آزمایشگاه تقارن مولکولی» (دکتر علیرضا خورشیدی) تفاوت دارد و اجرا نمی‌شود.</p></div></body>';
    return;
  }
  var run = document.createElement('script'); run.textContent = src.textContent; document.body.appendChild(run);
})();
