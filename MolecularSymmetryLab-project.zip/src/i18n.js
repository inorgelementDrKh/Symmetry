// Language state and small helpers shared by the UI.
export const I = { lang: 'en' };
export const isFa = () => I.lang === 'fa';
export const L = (en, fa) => (isFa() ? fa : en);
const FAD = '۰۱۲۳۴۵۶۷۸۹';
export const num = (x) => (isFa() ? String(x).replace(/\d/g, (d) => FAD[d]) : String(x));
export function initLang() {
  let l = null;
  try { l = localStorage.getItem('msl-lang'); } catch (e) { /* ignore */ }
  if (!l) l = (navigator.language || '').toLowerCase().startsWith('fa') ? 'fa' : 'en';
  I.lang = l === 'fa' ? 'fa' : 'en';
  return I.lang;
}
export function setLang(l) {
  I.lang = l;
  try { localStorage.setItem('msl-lang', l); } catch (e) { /* ignore */ }
  const r = document.documentElement;
  r.lang = l; r.dir = l === 'fa' ? 'rtl' : 'ltr';
}
