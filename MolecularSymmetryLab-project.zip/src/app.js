import { MOLECULES } from './molecules.js';
import { FA } from './fa-mols.js';
import { analyze, formatGroup, symHTML } from './symmetry.js';
import { Viewer, elementColor, hex } from './viewer.js';
import { runSplash } from './splash.js';
import { I, isFa, L, num, initLang, setLang } from './i18n.js';

const $ = (s, r = document) => r.querySelector(s);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cache = new Map();
const analysisFor = (m) => { if (!cache.has(m.id)) cache.set(m.id, analyze(m.atoms)); return cache.get(m.id); };
const mname = (m) => (isFa() ? FA[m.id][0] : m.name);
const mnote = (m) => (isFa() ? FA[m.id][1] : m.note);
const stepsOf = (an) => an.steps[I.lang];
const dg = (x) => `<bdi dir="ltr">${num(x)}°</bdi>`;
const yesNo = (v) => (v ? L('Yes', 'بله') : L('No', 'خیر'));

const STORE = 'msl-v2';
const state = {
  i: 0, tab: 'elements', visibleTypes: new Set(), sel: null, ded: {}, revealed: new Set(),
  quiz: { score: 0, total: 0, streak: 0, picked: null }, rotate: true, labels: true, style: 'ball', tour: null, busy: false, focus: null,
};
try {
  const s = JSON.parse(localStorage.getItem(STORE) || 'null');
  if (s) { state.revealed = new Set(s.revealed || []); Object.assign(state.quiz, s.quiz || {}, { picked: null }); }
} catch (e) { /* storage unavailable */ }
const save = () => { try { localStorage.setItem(STORE, JSON.stringify({ revealed: [...state.revealed], quiz: { score: state.quiz.score, total: state.quiz.total, streak: state.quiz.streak } })); } catch (e) { /* ignore */ } };

const mol = () => MOLECULES[state.i];
const cur = () => analysisFor(mol());
let viewer = null;

// ------------------------------------------------------------------ static text

const STATIC = {
  title: ['Molecular Symmetry Lab', 'آزمایشگاه تقارن مولکولی'],
  by: ['Devised by Dr. Alireza Khorshidi', 'طراحی و تألیف: دکتر علیرضا خورشیدی'],
  tabElements: ['Elements', 'عناصر'], tabDeduce: ['Deduce', 'استنتاج'], tabLearn: ['Learn', 'آموزش'], tabQuiz: ['Quiz', 'آزمون'],
  aboutBtn: ['About this app', 'دربارهٔ برنامه'],
  aboutCredit: ['Devised and developed by', 'طراحی و تألیف'],
  aboutName: ['Dr. Alireza Khorshidi', 'دکتر علیرضا خورشیدی'],
  aboutRole: ['Professor of Inorganic Chemistry, University of Guilan, Rasht, Iran', 'استاد شیمی معدنی، دانشگاه گیلان، رشت، ایران'],
  about1: ['Drag to rotate the molecule and pinch to zoom.', 'برای چرخاندن مولکول بکشید و برای بزرگ‌نمایی دو انگشت را از هم دور کنید.'],
  about2: ['<b>Elements</b> lists every axis, plane and centre this molecule has, and plays each operation atom by atom.', '<b>عناصر</b> همهٔ محورها، صفحه‌ها و مراکز تقارن مولکول را فهرست می‌کند و هر عمل را اتم‌به‌اتم نشان می‌دهد.'],
  about3: ['<b>Deduce</b> takes you through the point-group flowchart one question at a time.', '<b>استنتاج</b> شما را پرسش‌به‌پرسش در نمودار گردشی گروه‌های نقطه‌ای همراهی می‌کند.'],
  about4: ['<b>Quiz</b> asks for the point group of a molecule you have not seen yet.', '<b>آزمون</b> گروه نقطه‌ای مولکولی را می‌پرسد که هنوز ندیده‌اید.'],
  aboutSmall: ['Symmetry elements are found by the app itself from the 3D coordinates, then fed into the flowchart. Geometries are idealised textbook values and bond orders are not drawn.', 'عناصر تقارن را خود برنامه از مختصات سه‌بعدی پیدا می‌کند و سپس به نمودار گردشی می‌دهد. هندسه‌ها مقادیر آرمانی کتاب‌های درسی‌اند و مرتبهٔ پیوندها رسم نشده است.'],
  close: ['Close', 'بستن'],
  pgLabel: ['Point group', 'گروه نقطه‌ای'],
  langBtn: ['فا', 'EN'], langAria: ['Switch to Persian', 'تغییر به انگلیسی'],
  aRotate: ['Auto-rotate', 'چرخش خودکار'], aLabels: ['Element labels', 'برچسب عناصر'], aStyle: ['Space-filling model', 'مدل فضاپرکن'], aReset: ['Reset view', 'بازنشانی نما'],
  aPrev: ['Previous molecule', 'مولکول قبلی'], aNext: ['Next molecule', 'مولکول بعدی'],
  sKicker: ['Devised by', 'طراحی و تألیف'], sTitle: ['Molecular Symmetry Lab', 'آزمایشگاه تقارن مولکولی'],
  sRole: ['Professor of Inorganic Chemistry', 'استاد شیمی معدنی'], sUni: ['University of Guilan · Rasht, Iran', 'دانشگاه گیلان · رشت، ایران'], sSkip: ['Skip', 'رد شدن'],
};
const T = (k) => STATIC[k][isFa() ? 1 : 0];
function applyStatic() {
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.innerHTML = T(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', T(el.dataset.i18nAria)); });
  document.title = T('title');
}

// ------------------------------------------------------------------ explanations

const FOLD_FA = { 2: 'دوگانه', 3: 'سه‌گانه', 4: 'چهارگانه', 5: 'پنج‌گانه', 6: 'شش‌گانه' };
const FOLD_EN = { 2: 'Two-fold', 3: 'Three-fold', 4: 'Four-fold', 5: 'Five-fold', 6: 'Six-fold' };

const SIG_FA = { h: 'افقی', v: 'عمودی', d: 'دووجهی' };
function faName(t) {
  if (t.kind === 'E') return 'یکسانی';
  if (t.kind === 'i') return 'مرکز وارونگی';
  const n = Number.isFinite(t.n) ? num(t.n) : '∞';
  if (t.kind === 'C') return `محور دوران محض مرتبه ${n}${t.label.x ? ' ' + t.label.x : ''}`;
  if (t.kind === 'S') return `محور دوران مرکب مرتبه ${n}`;
  return `صفحه تقارن${SIG_FA[t.label.s] ? ' ' + SIG_FA[t.label.s] : ''}`;
}
const elTxt = (t) => (isFa() ? faName(t) : symHTML(t.label));

function describe(t) {
  const Lb = t.label;
  if (t.kind === 'E') return { name: L('Identity', 'یکسانی'), desc: L('Do nothing at all. Every molecule has this operation, and every point group contains it. It is the reference that other operations are compared with.', 'هیچ کاری نکنید. هر مولکولی این عمل را دارد و هر گروه نقطه‌ای آن را شامل می‌شود. این عمل مبنایی است که بقیهٔ عمل‌ها با آن سنجیده می‌شوند.') };
  if (t.kind === 'i') return { name: L('Centre of inversion', 'مرکز وارونگی'), desc: L('Every atom at (x, y, z) is carried through the centre to (−x, −y, −z). This works only if each atom has an identical partner on the opposite side at the same distance.', 'هر اتم واقع در (x, y, z) از مرکز می‌گذرد و به (−x, −y, −z) می‌رود. این فقط وقتی شدنی است که هر اتم در سمت مقابل و با همان فاصله یک هم‌ارز یکسان داشته باشد.') };
  if (t.kind === 'C') {
    if (!Number.isFinite(t.n)) return { name: L('Infinite-fold axis', faName(t)), desc: L('The molecule is linear, so a rotation by any angle about the bond axis leaves it unchanged.', 'مولکول خطی است؛ پس چرخش با هر زاویه‌ای حول محور پیوند آن را بدون تغییر می‌گذارد.') };
    const principal = t.members.some((m) => m.principal);
    const deg = 360 / t.n;
    return {
      name: L(`${FOLD_EN[t.n]} rotation axis`, faName(t)),
      desc: L(
        `Rotate the molecule by 360°/${t.n} = ${deg}° about the axis and it looks exactly as before; identical atoms simply swap places.${t.n > 2 ? ` Repeating the turn gives C<sub>${t.n}</sub><sup>2</sup>, C<sub>${t.n}</sub><sup>3</sup> and so on; ${t.n} turns return to E.` : ''}${principal ? ' This is the <b>principal axis</b>, the axis of highest order.' : ''}${Lb.x === '′' ? ' The prime marks an axis perpendicular to the principal axis.' : ''}${Lb.x === '″' ? ' Two primes mark the second set of perpendicular axes, the ones lying between the single-prime axes.' : ''}`,
        `مولکول را به اندازهٔ <bdi dir="ltr">360°/${t.n} = ${deg}°</bdi> حول محور بچرخانید؛ دقیقاً همان شکل پیشین به دست می‌آید و اتم‌های یکسان فقط جای هم را می‌گیرند.${t.n > 2 ? ` تکرار چرخش، مضرب‌های بعدی زاویه را می‌دهد و پس از ${num(t.n)} چرخش به یکسانی می‌رسیم.` : ''}${principal ? ' این <b>محور اصلی</b> است، یعنی محوری با بالاترین مرتبه.' : ''}${Lb.x === '′' ? ' علامت ′ نشان می‌دهد محور بر محور اصلی عمود است.' : ''}${Lb.x === '″' ? ' علامت ″ دستهٔ دوم محورهای عمودی را نشان می‌دهد، یعنی آن‌هایی که میان محورهای تک‌پرایم قرار دارند.' : ''}`),
    };
  }
  if (t.kind === 'S') {
    const n = Number.isFinite(t.n) ? t.n : null;
    return {
      name: L('Improper rotation axis', faName(t)),
      desc: L(`S<sub>${n ?? '∞'}</sub> is a two-step operation: rotate by 360°/${n ?? 'n'}, then reflect in the plane perpendicular to the axis. The pair counts as one operation, even if neither step works alone. (S<sub>1</sub> is just σ and S<sub>2</sub> is just i.)`,
        `${faName(t)} یک عمل دومرحله‌ای است: ابتدا <bdi dir="ltr">360°/${n ?? 'n'}</bdi> بچرخید و سپس در صفحهٔ عمود بر محور بازتاب دهید. این دو گام با هم یک عمل به شمار می‌آیند، حتی اگر هیچ‌یک به‌تنهایی تقارن نباشد. (محور دوران مرکب مرتبه ۱ همان صفحه تقارن و محور دوران مرکب مرتبه ۲ همان مرکز وارونگی است.)`),
      extra: t.implied
        ? L('Here the rotation and the perpendicular mirror plane are both present, so S comes along for free.', 'در این مولکول هم چرخش و هم صفحه تقارن عمود بر محور وجود دارد؛ پس محور دوران مرکب خودبه‌خود به دست می‌آید.')
        : L('<b>A genuine improper axis.</b> Neither the rotation by itself nor the reflection by itself is a symmetry operation here. Only the combination is.', '<b>یک محور مرکبٔ واقعی.</b> در اینجا نه چرخش به‌تنهایی عمل تقارنی است و نه بازتاب به‌تنهایی؛ فقط ترکیب آن‌ها تقارن است.'),
    };
  }
  const s = Lb.s;
  const where = s === 'h' ? L('It lies perpendicular to the principal axis.', 'این صفحه بر محور اصلی عمود است.')
    : s === 'v' ? L('It contains the principal axis.', 'این صفحه محور اصلی را در بر دارد.')
      : s === 'd' ? L('It contains the principal axis and bisects the angle between two C<sub>2</sub> axes.', 'این صفحه محور اصلی را در بر دارد و زاویهٔ میان دو محور دوران محض مرتبه ۲ را نصف می‌کند.') : '';
  return {
    name: s === 'h' ? L('Horizontal mirror plane', 'صفحه تقارن افقی') : s === 'v' ? L('Vertical mirror plane', 'صفحه تقارن عمودی') : s === 'd' ? L('Dihedral mirror plane', 'صفحه تقارن دووجهی') : L('Mirror plane', 'صفحه تقارن'),
    desc: L(`Reflecting every atom through this plane gives back the same molecule. Atoms on one side trade places with identical atoms on the other; atoms lying in the plane stay where they are. ${where}${t.infinite ? ' A linear molecule has infinitely many such planes, all containing the axis.' : ''}`,
      `بازتاب همهٔ اتم‌ها در این صفحه همان مولکول را برمی‌گرداند. اتم‌های یک سوی صفحه با اتم‌های یکسان سوی دیگر جابه‌جا می‌شوند و اتم‌هایی که روی صفحه‌اند سر جایشان می‌مانند. ${where}${t.infinite ? ' مولکول خطی بی‌شمار صفحهٔ این‌چنینی دارد که همگی محور را در بر می‌گیرند.' : ''}`),
  };
}
const shortName = (t) => describe(t).name;
function opLabel(t, k) {
  if (t.kind === 'C') {
    if (!Number.isFinite(t.n)) return L('Rotate about the axis', 'حول محور بچرخان');
    const deg = (360 * k) / t.n;
    return t.n > 2 ? L(`Rotate ${deg}° (C<sub>${t.n}</sub><sup>${k}</sup>)`, `${dg(deg)} بچرخان`) : L(`Rotate ${deg}°`, `${dg(deg)} بچرخان`);
  }
  if (t.kind === 'S') return L('Rotate, then reflect', 'بچرخان و سپس بازتاب بده');
  if (t.kind === 'sigma') return L('Reflect', 'بازتاب بده');
  if (t.kind === 'i') return L('Invert', 'وارونه کن');
  return L('Apply E', 'یکسانی را اعمال کن');
}
function captionFor(t, k) {
  if (t.kind === 'E') return L('E: nothing moves. Every atom stays on its own position.', 'یکسانی: هیچ چیز جابه‌جا نمی‌شود و هر اتم سر جای خودش می‌ماند.');
  if (t.kind === 'C') {
    const n = t.n;
    if (!Number.isFinite(n)) return L('C<sub>∞</sub>: turn by any angle about the axis', 'محور دوران محض مرتبه ∞: با هر زاویه‌ای حول محور بچرخانید');
    const deg = (360 * k) / n;
    return L(`${symHTML(t.label)}${n > 2 ? `<sup>${k}</sup>` : ''}: turn ${deg}° about the axis`, `${faName(t)}: ${dg(deg)} حول محور بچرخانید`);
  }
  if (t.kind === 'S') return L(`${symHTML(t.label)}: turn ${Number.isFinite(t.n) ? 360 / t.n + '°' : 'by any angle'}, then reflect across the plane perpendicular to the axis`, `${faName(t)}: ${Number.isFinite(t.n) ? dg(360 / t.n) : 'با هر زاویه‌ای'} بچرخانید و سپس در صفحهٔ عمود بر محور بازتاب دهید`);
  if (t.kind === 'sigma') return L(`${symHTML(t.label)}: reflect every atom through the plane`, `${faName(t)}: همهٔ اتم‌ها را در صفحه بازتاب دهید`);
  return L('i: send every atom through the centre to the opposite side', 'مرکز وارونگی: هر اتم را از مرکز به سمت مقابل ببرید');
}

// ------------------------------------------------------------------ view

function idsOfTypes(an, keys) {
  const out = new Set();
  for (const t of an.types) if (keys.has(t.key)) t.members.forEach((m) => out.add(m.id));
  return out;
}
function selIds() {
  if (!state.sel) return null;
  const an = cur();
  const t = an.types.find((x) => x.key === state.sel.key);
  if (!t) return null;
  const vis = t.members.filter((m) => !m.hidden);
  if (state.sel.member == null) return new Set(t.members.map((m) => m.id));
  const m = vis[state.sel.member] || vis[0];
  const out = new Set([m.id]);
  t.members.filter((x) => x.hidden && x.infinite).forEach((x) => out.add(x.id));
  return out;
}
const ded = () => (state.ded[mol().id] ||= { i: 0, log: [], done: false, wrong: 0, hint: false, lastShow: null });

function refreshView() {
  if (!viewer) return;
  const an = cur();
  let visible = new Set(), focus = null;
  if (state.tab === 'deduce') {
    const d = ded();
    const st = stepsOf(an);
    d.log.forEach((idx) => (st[idx].show || []).forEach((id) => visible.add(id)));
    if (d.done) an.elements.forEach((e) => visible.add(e.id));
    const step = st[d.i];
    if (d.hint && step) focus = new Set(step.show);
    else if (d.lastShow && d.lastShow.length && !d.done) focus = new Set(d.lastShow);
  } else if (state.tab === 'quiz') {
    if (state.quiz.picked) an.elements.forEach((e) => visible.add(e.id));
  } else {
    visible = idsOfTypes(an, state.visibleTypes);
    focus = state.focus || selIds();
  }
  viewer.setElements(visible, focus && focus.size ? focus : null);
}

// ------------------------------------------------------------------ rendering

function renderHeader() {
  const m = mol();
  $('#mol-name').textContent = mname(m);
  $('#mol-formula').innerHTML = m.formula;
  $('#mol-count').textContent = `${num(state.i + 1)} / ${num(MOLECULES.length)}`;
  const rev = state.revealed.has(m.id);
  const b = $('#pg-badge');
  b.innerHTML = `<span class="k">${T('pgLabel')}</span>${rev ? `<span class="v">${formatGroup(cur().group)}</span>` : '<span class="v q">?</span>'}`;
  b.classList.toggle('known', rev);
  $('#lang-btn').textContent = T('langBtn');
  $('#lang-btn').setAttribute('aria-label', T('langAria'));
}

function renderPicker() {
  const el = $('#picker');
  el.innerHTML = MOLECULES.map((m, i) => `<button class="chip${i === state.i ? ' on' : ''}${state.revealed.has(m.id) ? ' done' : ''}" data-act="mol" data-i="${i}" aria-label="${mname(m).replace(/"/g, '')}"><span class="f">${m.formula}</span>${state.revealed.has(m.id) ? `<span class="g">${formatGroup(analysisFor(m).group)}</span>` : ''}</button>`).join('');
  const on = $('.chip.on', el);
  if (on) {
    const target = on.offsetLeft - el.clientWidth / 2 + on.clientWidth / 2;
    el.scrollTo({ left: target, behavior: 'smooth' });
  }
}

function rowHTML(t) {
  const col = hex(elementColor(t.members[0]));
  const on = state.visibleTypes.has(t.key);
  const sel = state.sel && state.sel.key === t.key;
  const cnt = t.infinite ? '∞' : `×${num(t.count)}`;
  const shape = t.kind === 'sigma' ? 'plane' : t.kind === 'i' ? 'dot' : t.kind === 'S' ? 'ring' : t.kind === 'E' ? 'dot' : 'axis';
  return `<li class="row${sel ? ' sel' : ''}" style="--c:${col}">
    <button class="row-main" data-act="type" data-key="${t.key}">
      <span class="sw ${shape}"></span>
      <span class="sy">${symHTML(t.label)}</span>
      <span class="nm">${shortName(t)}${t.implied && t.kind === 'S' ? ` <i>${L('(implied)', '(ضمنی)')}</i>` : ''}</span>
      <span class="ct">${cnt}</span>
    </button>
    ${t.kind === 'E' ? '<span class="eye none"></span>' : `<button class="eye${on ? ' on' : ''}" data-act="eye" data-key="${t.key}" aria-label="${L('Show or hide', 'نمایش یا پنهان‌کردن')} ${t.key}" aria-pressed="${on}"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></button>`}
  </li>`;
}

function selCardHTML() {
  const an = cur();
  if (!state.sel) return `<div class="card tip">${L('Tap an element in the list to light it up in the 3D view, read what it is, and watch the operation.', 'روی یک عنصر در فهرست بزنید تا در نمای سه‌بعدی روشن شود؛ توضیح آن را بخوانید و عمل را ببینید.')}</div>`;
  const t = an.types.find((x) => x.key === state.sel.key);
  if (!t) return '';
  const d = describe(t);
  const vis = t.members.filter((m) => !m.hidden);
  const k = state.sel.k || 1;
  const col = hex(elementColor(t.members[0]));
  const stepper = vis.length > 1 ? `<div class="stepper" role="group">
      <button class="pill${state.sel.member == null ? ' on' : ''}" data-act="member" data-m="all">${L(`All ${vis.length}`, `همهٔ ${num(vis.length)}`)}</button>
      ${vis.map((_, i) => `<button class="pill${state.sel.member === i ? ' on' : ''}" data-act="member" data-m="${i}">${num(i + 1)}</button>`).join('')}
    </div>` : '';
  const count = t.infinite ? L('infinitely many', 'بی‌شمار') : t.count === 1 ? L('1 in this molecule', 'یکی در این مولکول') : L(`${t.count} in this molecule`, `${num(t.count)} عدد در این مولکول`);
  return `<section class="card sel" style="--c:${col}">
    <div class="card-h"><span class="sym">${symHTML(t.label)}</span><div class="ttl"><b>${d.name}</b><span>${count}</span></div></div>
    <p>${d.desc}</p>
    ${d.extra ? `<p class="callout">${d.extra}</p>` : ''}
    ${stepper}
    <div class="btnrow"><button class="btn primary" data-act="perform" ${state.busy ? 'disabled' : ''}>▶ ${opLabel(t, k)}</button></div>
  </section>`;
}

function elementsHTML() {
  const an = cur();
  const total = an.elements.filter((e) => !e.hidden).length;
  const lead = an.types.length === 1
    ? L('This molecule has no symmetry beyond the identity.', 'این مولکول جز یکسانی هیچ تقارنی ندارد.')
    : L(`Symmetry elements are the axes, planes and points that operations are carried out about. This molecule has <b>${total}</b> of them in <b>${an.types.length}</b> kinds.`,
      `عناصر تقارنی همان محورها، صفحه‌ها و نقطه‌هایی هستند که عمل‌های تقارنی نسبت به آن‌ها انجام می‌شود. این مولکول <b>${num(total)}</b> عنصر در <b>${num(an.types.length)}</b> نوع دارد.`);
  const tour = state.tour ? ` ${num(state.tour.n)}/${num(an.types.length)}` : '';
  return `
    <p class="lead">${lead}</p>
    <div class="btnrow">
      <button class="btn primary" data-act="tour">${state.tour ? `■ ${L('Stop tour', 'توقف گشت')}${tour}` : `▶ ${L('Tour the elements', 'گشت در عناصر')}`}</button>
      <button class="btn" data-act="show-all">${L('Show all', 'نمایش همه')}</button>
      <button class="btn" data-act="hide-all">${L('Hide all', 'پنهان‌کردن همه')}</button>
    </div>
    ${selCardHTML()}
    <ul class="types">${an.types.map(rowHTML).join('')}</ul>
    <p class="note"><b>${L('About', 'دربارهٔ')} ${mol().formula}:</b> ${mnote(mol())}</p>`;
}

function deduceHTML() {
  const an = cur(), m = mol(), d = ded();
  const st = stepsOf(an);
  const log = d.log.map((idx) => {
    const s = st[idx];
    if (s.type === 'info') return `<li class="log"><span class="tick">•</span><div><span class="lq">${L('Principal axis', 'محور اصلی')}</span><span class="lw">${s.text}</span></div></li>`;
    return `<li class="log"><span class="tick ${s.a ? '' : 'no'}">${yesNo(s.a)}</span><div><span class="lq">${s.q}</span><span class="lw">${s.why}</span></div></li>`;
  }).join('');
  let cardHTML = '';
  if (d.done) {
    const g = an.group;
    const els = an.types.filter((t) => t.kind !== 'E').map((t) => `${t.infinite ? '∞' : num(t.count)} ${elTxt(t)}`).join(' · ') || L('E', 'یکسانی');
    cardHTML = `<section class="card result">
      <div class="kick">${T('pgLabel')}</div>
      <div class="pg">${formatGroup(g)}</div>
      <div class="facts">
        <div><span>${L('Order h', 'مرتبه h')}</span><b>${num(an.order)}</b></div>
        <div><span>${L('Polar', 'قطبی')}</span><b>${yesNo(an.polar)}</b></div>
        <div><span>${L('Chiral', 'کایرال')}</span><b>${yesNo(an.chiral)}</b></div>
      </div>
      <p class="muted">${L('Elements', 'عناصر')}: ${L('E', 'یکسانی')} · ${els}</p>
      <p class="muted small">${an.polar ? L('Polar: the group allows a permanent dipole moment.', 'قطبی: این گروه گشتاور دوقطبی دائمی را مجاز می‌داند.') : L('Non-polar: the symmetry cancels any permanent dipole.', 'ناقطبی: تقارن هر گشتاور دوقطبی دائمی را خنثی می‌کند.')} ${an.chiral ? L('Chiral: no mirror plane, inversion centre or S<sub>n</sub> axis, so it can be optically active.', 'کایرال: صفحه تقارن، مرکز وارونگی یا محور دوران مرکب مرتبه n ندارد؛ پس می‌تواند فعال نوری باشد.') : L('Achiral: an improper operation is present.', 'آکایرال: دست‌کم یک عمل مرکب وجود دارد.')}</p>
      <div class="btnrow"><button class="btn primary" data-act="next-mol">${L('Next molecule →', 'مولکول بعدی ←')}</button><button class="btn" data-act="redo">${L('Start again', 'از نو')}</button></div>
    </section>`;
  } else {
    const s = st[d.i];
    if (s.type === 'info') {
      cardHTML = `<section class="card q"><div class="kick">${L('Step', 'گام')} ${num(d.i + 1)}</div><p class="qt">${s.text}</p><div class="btnrow"><button class="btn primary" data-act="ded-info">${L('Continue', 'ادامه')}</button></div></section>`;
    } else {
      cardHTML = `<section class="card q${d.wrong ? ' shake' : ''}" id="qcard"><div class="kick">${L('Step', 'گام')} ${num(d.i + 1)}</div><p class="qt">${s.q}</p>
        <div class="yn"><button class="btn yes" data-act="ans" data-v="1">${yesNo(true)}</button><button class="btn no" data-act="ans" data-v="0">${yesNo(false)}</button></div>
        ${d.wrong ? `<p class="wrong">${L('Not quite.', 'درست نیست.')} ${d.hint ? L('The elements to check are lit up in 3D.', 'عناصری که باید بررسی کنید در نمای سه‌بعدی روشن شده‌اند.') : ''}</p>` : ''}
        <div class="btnrow tight">${s.show.length ? `<button class="link" data-act="hint">${d.hint ? L('Hide hint', 'پنهان‌کردن راهنما') : L('Light up what to look for', 'عناصر مورد نظر را روشن کن')}</button>` : ''}${d.wrong >= 2 ? `<button class="link" data-act="reveal">${L('Show me the answer', 'پاسخ را نشان بده')}</button>` : ''}</div>
      </section>`;
    }
  }
  return `<p class="lead">${L(`Work out the point group of ${m.formula} with the standard flowchart. Rotate the model, answer each question, and the elements you find stay on screen.`, `گروه نقطه‌ای ${m.formula} را با نمودار گردشی استاندارد تعیین کنید. مدل را بچرخانید، به هر پرسش پاسخ دهید و عناصری که پیدا می‌کنید روی صفحه می‌مانند.`)}</p>
    ${cardHTML}
    ${log ? `<ol class="logs">${log}</ol>` : ''}`;
}

const GROUP_ROWS = [
  ['C<sub>1</sub>', 'Nothing but E', 'جز یکسانی هیچ عنصری نیست', 'chfclbr'], ['C<sub>s</sub>', 'One mirror plane', 'یک صفحه تقارن', 'ch2clf'], ['C<sub>i</sub>', 'Inversion centre only', 'فقط مرکز وارونگی', 'meso-ci'],
  ['C<sub>n</sub>', 'One C<sub>n</sub> axis, nothing else', 'فقط یک محور دوران محض مرتبه n', 'h2o2'], ['C<sub>nv</sub>', 'C<sub>n</sub> plus n vertical planes', 'محور دوران محض مرتبه n و n صفحه تقارن عمودی', 'nh3'], ['C<sub>nh</sub>', 'C<sub>n</sub> plus σ<sub>h</sub>', 'محور دوران محض مرتبه n و صفحه تقارن افقی', 'tdce'],
  ['S<sub>2n</sub>', 'Only an S<sub>2n</sub> axis', 'فقط محور دوران مرکب مرتبه ۲n', 'pentaerythritol'],
  ['D<sub>n</sub>', 'C<sub>n</sub> plus n perpendicular C<sub>2</sub>', 'محور دوران محض مرتبه n و n محور دوران محض مرتبه ۲ عمود بر آن', 'ethane-30'], ['D<sub>nh</sub>', 'D<sub>n</sub> plus σ<sub>h</sub>', 'D<sub>n</sub> و صفحه تقارن افقی', 'bf3'], ['D<sub>nd</sub>', 'D<sub>n</sub> plus n σ<sub>d</sub>, no σ<sub>h</sub>', 'D<sub>n</sub> و n صفحه تقارن دووجهی، بدون صفحه تقارن افقی', 'ethane-60'],
  ['C<sub>∞v</sub>', 'Linear, ends differ', 'خطی، دو سر متفاوت', 'hcl'], ['D<sub>∞h</sub>', 'Linear, ends match', 'خطی، دو سر یکسان', 'co2'],
  ['T<sub>d</sub>', 'Four C<sub>3</sub>, no i', 'چهار محور دوران محض مرتبه ۳، بدون مرکز وارونگی', 'ch4'], ['T<sub>h</sub>', 'Four C<sub>3</sub>, i, no C<sub>4</sub>', 'چهار محور دوران محض مرتبه ۳ و مرکز وارونگی، بدون محور مرتبه ۴', 'conitro'], ['O<sub>h</sub>', 'Three C<sub>4</sub>, four C<sub>3</sub>, i', 'سه محور دوران محض مرتبه ۴، چهار محور مرتبه ۳ و مرکز وارونگی', 'sf6'], ['I<sub>h</sub>', 'Six C<sub>5</sub>, i', 'شش محور دوران محض مرتبه ۵ و مرکز وارونگی', 'b12h12'],
];
function learnHTML() {
  return `
  <section class="card">
    <h3>${L('Symmetry operations and elements', 'عمل‌ها و عناصر تقارنی')}</h3>
    <p>${L('An <b>operation</b> moves the molecule so that it ends up indistinguishable from the start. The <b>element</b> is the point, line or plane the operation is carried out about.', 'یک <b>عمل تقارنی</b> مولکول را طوری جابه‌جا می‌کند که در پایان از حالت آغازین قابل‌تشخیص نباشد. <b>عنصر تقارنی</b> نقطه، خط یا صفحه‌ای است که عمل نسبت به آن انجام می‌شود.')}</p>
    <div class="scroll-x"><table class="tbl"><thead><tr><th>${L('Element', 'عنصر')}</th><th>${L('Operation', 'عمل')}</th><th>${L('Symbol', 'نماد')}</th></tr></thead><tbody>
      <tr><td>${L('Whole molecule', 'کل مولکول')}</td><td>${L('Identity', 'یکسانی')}</td><td>E</td></tr>
      <tr><td>${L('Axis', 'محور')}</td><td>${L('Rotation by 360°/n', 'چرخش به اندازهٔ <bdi dir="ltr">360°/n</bdi>')}</td><td>C<sub>n</sub></td></tr>
      <tr><td>${L('Plane', 'صفحه')}</td><td>${L('Reflection', 'بازتاب')}</td><td>σ (σ<sub>h</sub>, σ<sub>v</sub>, σ<sub>d</sub>)</td></tr>
      <tr><td>${L('Point', 'نقطه')}</td><td>${L('Inversion', 'وارونگی')}</td><td>i</td></tr>
      <tr><td>${L('Axis + plane', 'محور + صفحه')}</td><td>${L('Improper rotation', 'دوران مرکب')}</td><td>S<sub>n</sub></td></tr>
    </tbody></table></div>
  </section>
  <section class="card" style="--c:#ff6fb5">
    <h3>${L('Improper rotation, S<sub>n</sub>', 'دوران مرکب (محور دوران مرکب مرتبه n)')}</h3>
    <p>${L('Rotate by 360°/n, then reflect in the plane perpendicular to the axis. Do both steps and count it as one operation. Sometimes neither step is a symmetry on its own, and yet the pair works.', 'ابتدا <bdi dir="ltr">360°/n</bdi> بچرخید، سپس در صفحهٔ عمود بر محور بازتاب دهید. هر دو گام را انجام دهید و آن را یک عمل بشمارید. گاهی هیچ‌کدام از دو گام به‌تنهایی تقارن نیست، اما ترکیب آن‌ها تقارن است.')}</p>
    <p class="callout">${L('S<sub>1</sub> is the same as σ, and S<sub>2</sub> is the same as i. The first genuinely new case is S<sub>3</sub>, and S<sub>4</sub> is the one that surprises people.', 'محور دوران مرکب مرتبه ۱ همان صفحه تقارن و محور دوران مرکب مرتبه ۲ همان مرکز وارونگی است. نخستین حالت واقعاً تازه مرتبهٔ ۳ است و مرتبهٔ ۴ همان است که بیشتر دانشجویان را شگفت‌زده می‌کند.')}</p>
    <p>${L('Watch each one happen, atom by atom:', 'هر کدام را اتم‌به‌اتم ببینید:')}</p>
    <div class="btnrow wrapb">
      <button class="btn" data-act="demo" data-id="allene" data-key="S4">${L('S<sub>4</sub> in allene', 'محور دوران مرکب مرتبه ۴ در آلن')}</button>
      <button class="btn" data-act="demo" data-id="ethane-60" data-key="S6">${L('S<sub>6</sub> in staggered ethane', 'محور دوران مرکب مرتبه ۶ در اتان کج‌ایستا')}</button>
      <button class="btn" data-act="demo" data-id="bf3" data-key="S3">${L('S<sub>3</sub> in BF<sub>3</sub>', 'محور دوران مرکب مرتبه ۳ در BF<sub>3</sub>')}</button>
      <button class="btn" data-act="demo" data-id="ch4" data-key="S4">${L('S<sub>4</sub> in methane', 'محور دوران مرکب مرتبه ۴ در متان')}</button>
      <button class="btn" data-act="demo" data-id="pentaerythritol" data-key="S4">${L('S<sub>4</sub> as the only axis', 'محور دوران مرکب مرتبه ۴ به‌عنوان تنها محور')}</button>
      <button class="btn" data-act="demo" data-id="hexol" data-key="S6">${L('S<sub>6</sub> as the only axis', 'محور دوران مرکب مرتبه ۶ به‌عنوان تنها محور')}</button>
    </div>
  </section>
  <section class="card">
    <h3>${L('Point-group cheat sheet', 'راهنمای سریع گروه‌های نقطه‌ای')}</h3>
    <p class="small muted">${L('Tap an example to load it.', 'برای بارگذاری، روی یک مثال بزنید.')}</p>
    <ul class="cheat">${GROUP_ROWS.map(([g, en, fa, id]) => { const mm = MOLECULES.find((x) => x.id === id); return `<li><span class="cg">${g}</span><span class="cd">${L(en, fa)}</span><button class="pill" data-act="demo" data-id="${id}">${mm.formula}</button></li>`; }).join('')}</ul>
  </section>
  <section class="card">
    <h3>${L('The flowchart in one breath', 'نمودار گردشی در یک نگاه')}</h3>
    <ol class="flow">
      <li>${L('Linear? <b>D<sub>∞h</sub></b> with i, otherwise <b>C<sub>∞v</sub></b>.', 'خطی است؟ اگر مرکز وارونگی دارد <b>D<sub>∞h</sub></b>، وگرنه <b>C<sub>∞v</sub></b>.')}</li>
      <li>${L('Several C<sub>n</sub> with n ≥ 3? Cubic family: <b>T<sub>d</sub>, T<sub>h</sub>, O<sub>h</sub>, I<sub>h</sub></b> and their rotation-only cousins.', 'چند محور دوران محض مرتبه n با n ≥ ۳؟ خانوادهٔ مکعبی و بیستوجهی: <b>T<sub>d</sub>، T<sub>h</sub>، O<sub>h</sub>، I<sub>h</sub></b> و همتایان تنها‌دورانی آن‌ها.')}</li>
      <li>${L('No axis? <b>C<sub>s</sub></b> with a plane, <b>C<sub>i</sub></b> with i, else <b>C<sub>1</sub></b>.', 'محور ندارد؟ با صفحه تقارن <b>C<sub>s</sub></b>، با مرکز وارونگی <b>C<sub>i</sub></b>، وگرنه <b>C<sub>1</sub></b>.')}</li>
      <li>${L('Find the principal axis. n perpendicular C<sub>2</sub>? Then D: σ<sub>h</sub> gives <b>D<sub>nh</sub></b>, n σ<sub>d</sub> gives <b>D<sub>nd</sub></b>, else <b>D<sub>n</sub></b>.', 'محور اصلی را پیدا کنید. n محور دوران محض مرتبه ۲ عمودی دارد؟ پس D است: صفحه تقارن افقی یعنی <b>D<sub>nh</sub></b>، n صفحه تقارن دووجهی یعنی <b>D<sub>nd</sub></b>، وگرنه <b>D<sub>n</sub></b>.')}</li>
      <li>${L('Otherwise C: σ<sub>h</sub> gives <b>C<sub>nh</sub></b>, σ<sub>v</sub> planes give <b>C<sub>nv</sub></b>, an S<sub>2n</sub> axis gives <b>S<sub>2n</sub></b>, else <b>C<sub>n</sub></b>.', 'در غیر این صورت گروه C است: صفحه تقارن افقی یعنی <b>C<sub>nh</sub></b>، صفحه‌های تقارن عمودی یعنی <b>C<sub>nv</sub></b>، محور دوران مرکب مرتبه ۲n یعنی <b>S<sub>2n</sub></b>، وگرنه <b>C<sub>n</sub></b>.')}</li>
    </ol>
  </section>`;
}

const POOL = ['C1', 'Cs', 'Ci', 'C2', 'C3', 'S4', 'S6', 'C2v', 'C3v', 'C4v', 'C5v', 'C2h', 'C3h', 'D2', 'D3', 'D2h', 'D3h', 'D4h', 'D5h', 'D6h', 'C∞v', 'D∞h', 'D2d', 'D3d', 'D4d', 'D5d', 'Td', 'Th', 'Oh', 'Ih'];
function quizOptions(correct) {
  const digit = (g) => (g.match(/\d|∞/) || [''])[0];
  const score = (g) => (g[0] === correct[0] ? 2 : 0) + (digit(g) === digit(correct) ? 1.5 : 0) + Math.random() * 1.8;
  const others = POOL.filter((g) => g !== correct).sort((a, b) => score(b) - score(a)).slice(0, 3);
  const all = [correct, ...others];
  for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; }
  return all;
}
const quizOpts = new Map();
function quizHTML() {
  const an = cur(), m = mol(), q = state.quiz;
  if (!quizOpts.has(m.id)) quizOpts.set(m.id, quizOptions(an.group));
  const opts = quizOpts.get(m.id);
  const picked = q.picked;
  const buttons = opts.map((g) => {
    const cls = picked ? (g === an.group ? ' good' : g === picked ? ' bad' : ' dim') : '';
    return `<button class="opt${cls}" data-act="pick" data-g="${g}" ${picked ? 'disabled' : ''}>${formatGroup(g)}</button>`;
  }).join('');
  const els = an.types.filter((t) => t.kind !== 'E').map((t) => `${t.infinite ? '∞' : num(t.count)} ${elTxt(t)}`).join(' · ') || L('E', 'یکسانی');
  const ok = picked === an.group;
  return `<div class="scorebar"><span>${L('Score', 'امتیاز')} <b>${num(q.score)}</b> / ${num(q.total)}</span><span>${L('Streak', 'پیاپی')} <b>${num(q.streak)}</b></span></div>
    <section class="card q"><div class="kick">${L('Quiz', 'آزمون')}</div><p class="qt">${L(`Which point group does ${m.formula} belong to?`, `${m.formula} به کدام گروه نقطه‌ای تعلق دارد؟`)}</p>
      <div class="opts">${buttons}</div>
      ${picked ? `<div class="verdict ${ok ? 'ok' : 'no'}"><b>${ok ? L('Correct.', 'درست است.') : L(`It is ${formatGroup(an.group)}.`, `پاسخ درست ${formatGroup(an.group)} است.`)}</b> ${L('Elements found', 'عناصر یافت‌شده')}: ${L('E', 'یکسانی')} · ${els}. ${L('All of them are now shown in 3D.', 'همهٔ آن‌ها اکنون در نمای سه‌بعدی نمایش داده شده‌اند.')}</div>` : `<p class="small muted">${L('Rotate the model and look for axes, planes and a centre. Not sure? The Deduce tab walks through it.', 'مدل را بچرخانید و دنبال محورها، صفحه‌ها و مرکز تقارن بگردید. مطمئن نیستید؟ زبانهٔ «استنتاج» گام‌به‌گام شما را راهنمایی می‌کند.')}</p>`}
      <div class="btnrow"><button class="btn primary" data-act="quiz-next">${picked ? L('Next molecule →', 'مولکول بعدی ←') : L('Skip →', 'رد کردن ←')}</button></div>
    </section>`;
}

function renderPanel(keepScroll = false) {
  const body = $('#panel-body');
  const top = body.scrollTop;
  body.innerHTML = { elements: elementsHTML, deduce: deduceHTML, learn: learnHTML, quiz: quizHTML }[state.tab]();
  body.scrollTop = keepScroll ? top : 0;
  document.querySelectorAll('.tab').forEach((t) => { const on = t.dataset.tab === state.tab; t.classList.toggle('on', on); t.setAttribute('aria-selected', on); });
}

function setCaption(html) {
  const c = $('#caption');
  c.innerHTML = html || '';
  c.classList.toggle('on', !!html);
}

// ------------------------------------------------------------------ actions

function setMolecule(i, { tab } = {}) {
  stopTour();
  viewer.cancelPlay();
  state.i = (i + MOLECULES.length) % MOLECULES.length;
  const an = cur();
  state.sel = null; state.focus = null;
  state.quiz.picked = null;
  const members = an.elements.filter((e) => e.kind !== 'E').length;
  state.visibleTypes = new Set(members <= 10 ? an.types.map((t) => t.key) : []);
  if (tab) state.tab = tab;
  viewer.load(mol(), an);
  setCaption('');
  renderHeader(); renderPicker(); renderPanel(); refreshView();
}

function selectType(key, member = null) {
  state.sel = { key, member, k: 1 };
  state.visibleTypes.add(key);
}

async function perform() {
  if (!state.sel || state.busy) return;
  const an = cur();
  const t = an.types.find((x) => x.key === state.sel.key);
  const vis = t.members.filter((m) => !m.hidden);
  const m = vis[state.sel.member ?? 0] || vis[0];
  const k = state.sel.k || 1;
  state.busy = true;
  setCaption(captionFor(t, k));
  renderPanel(true);
  const prevRot = viewer.controls.autoRotate;
  viewer.setAutoRotate(false);
  const ok = await viewer.play(m.op, k);
  viewer.setAutoRotate(prevRot && !viewer.userTouched);
  state.busy = false;
  if (ok) {
    setCaption(t.kind === 'E' ? L('E leaves everything where it was.', 'یکسانی همه چیز را سر جایش نگه می‌دارد.') : L('The molecule ends up indistinguishable from the start, so this is a symmetry operation.', 'مولکول از حالت آغازین قابل‌تشخیص نیست؛ پس این یک عمل تقارنی است.'));
    setTimeout(() => { if (!state.busy) setCaption(''); }, 2600);
    if (t.kind === 'C' && Number.isFinite(t.n) && t.n > 2 && state.sel) state.sel.k = (k % (t.n - 1)) + 1;
  } else setCaption('');
  if (state.sel) renderPanel(true);
}

function stopTour() {
  if (!state.tour) return;
  state.tour.stop = true;
  state.tour = null;
  viewer?.cancelPlay();
}

async function tour() {
  if (state.tour) { stopTour(); setCaption(''); renderPanel(true); return; }
  const an = cur();
  const token = { stop: false, n: 0 };
  state.tour = token;
  state.visibleTypes = new Set(an.types.filter((t) => t.kind !== 'E').map((t) => t.key));
  for (let n = 0; n < an.types.length && !token.stop; n++) {
    const t = an.types[n];
    token.n = n + 1;
    selectType(t.key, null);
    state.sel.member = null;
    renderPanel(); refreshView();
    $('#panel-body').scrollTop = 0;
    const vis = t.members.filter((m) => !m.hidden);
    setCaption(captionFor(t, 1));
    state.busy = true;
    const ok = await viewer.play(vis[0].op, 1);
    state.busy = false;
    if (!ok || token.stop) break;
    await sleep(250);
  }
  if (state.tour === token) { state.tour = null; setCaption(''); renderPanel(true); refreshView(); }
}

function answer(v) {
  const an = cur(), d = ded();
  const s = stepsOf(an)[d.i];
  if (!s || s.type !== 'yn') return;
  if (s.a === !!v) {
    d.log.push(d.i);
    d.lastShow = s.show; d.i++; d.wrong = 0; d.hint = false;
    if (d.i >= stepsOf(an).length) finishDeduce();
  } else { d.wrong++; }
  renderPanel(true); refreshView();
  if (d.wrong) { const c = $('#qcard'); c?.classList.remove('shake'); void c?.offsetWidth; c?.classList.add('shake'); }
}
function finishDeduce() {
  const d = ded();
  d.done = true; d.lastShow = null;
  state.revealed.add(mol().id); save();
  renderHeader(); renderPicker();
}

function rerenderAll() {
  applyStatic();
  renderHeader(); renderPicker(); renderPanel(true); refreshView();
  setCaption('');
}

document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const act = b.dataset.act;
  const an = viewer ? cur() : null;
  switch (act) {
    case 'mol': setMolecule(+b.dataset.i); break;
    case 'prev': setMolecule(state.i - 1); break;
    case 'next': setMolecule(state.i + 1); break;
    case 'lang': stopTour(); viewer?.cancelPlay(); setLang(isFa() ? 'en' : 'fa'); rerenderAll(); break;
    case 'tab': stopTour(); viewer.cancelPlay(); setCaption(''); state.tab = b.dataset.tab; state.focus = null; renderPanel(); refreshView(); break;
    case 'type': {
      stopTour();
      const key = b.dataset.key;
      if (state.sel && state.sel.key === key) state.sel = null; else selectType(key, null);
      renderPanel(true); refreshView(); break;
    }
    case 'eye': {
      const key = b.dataset.key;
      if (state.visibleTypes.has(key)) state.visibleTypes.delete(key); else state.visibleTypes.add(key);
      renderPanel(true); refreshView(); break;
    }
    case 'member': { state.sel.member = b.dataset.m === 'all' ? null : +b.dataset.m; renderPanel(true); refreshView(); break; }
    case 'show-all': state.visibleTypes = new Set(an.types.filter((t) => t.kind !== 'E').map((t) => t.key)); renderPanel(true); refreshView(); break;
    case 'hide-all': state.visibleTypes = new Set(); state.sel = null; renderPanel(true); refreshView(); break;
    case 'perform': perform(); break;
    case 'tour': tour(); break;
    case 'ans': answer(b.dataset.v === '1'); break;
    case 'ded-info': { const d = ded(), s = stepsOf(an)[d.i]; d.log.push(d.i); d.lastShow = s.show; d.i++; renderPanel(true); refreshView(); break; }
    case 'hint': { const d = ded(); d.hint = !d.hint; renderPanel(true); refreshView(); break; }
    case 'reveal': { const d = ded(), s = stepsOf(an)[d.i]; d.log.push(d.i); d.lastShow = s.show; d.i++; d.wrong = 0; d.hint = false; if (d.i >= stepsOf(an).length) finishDeduce(); renderPanel(true); refreshView(); break; }
    case 'redo': { delete state.ded[mol().id]; renderPanel(); refreshView(); break; }
    case 'next-mol': setMolecule(state.i + 1); break;
    case 'demo': {
      const idx = MOLECULES.findIndex((m) => m.id === b.dataset.id);
      setMolecule(idx, { tab: 'elements' });
      if (b.dataset.key) {
        const a2 = cur();
        const t = a2.types.find((x) => x.key === b.dataset.key);
        if (t) { selectType(t.key, null); state.sel.member = null; renderPanel(); refreshView(); setTimeout(perform, 400); }
      }
      break;
    }
    case 'pick': {
      const q = state.quiz;
      if (q.picked) break;
      q.picked = b.dataset.g; q.total++;
      const ok = q.picked === an.group;
      if (ok) { q.score++; q.streak++; } else q.streak = 0;
      state.revealed.add(mol().id); save();
      renderHeader(); renderPicker(); renderPanel(true); refreshView(); break;
    }
    case 'quiz-next': {
      const pool = MOLECULES.map((_, i) => i).filter((i) => i !== state.i && !state.revealed.has(MOLECULES[i].id));
      const all = MOLECULES.map((_, i) => i).filter((i) => i !== state.i);
      const list = pool.length ? pool : all;
      setMolecule(list[Math.floor(Math.random() * list.length)]);
      break;
    }
    case 'rotate': state.rotate = !state.rotate; viewer.setAutoRotate(state.rotate); b.classList.toggle('on', state.rotate); break;
    case 'labels': state.labels = !state.labels; viewer.setLabels(state.labels); b.classList.toggle('on', state.labels); break;
    case 'style': state.style = state.style === 'ball' ? 'space' : 'ball'; viewer.setStyle(state.style); b.classList.toggle('on', state.style === 'space'); break;
    case 'reset': viewer.resetView(); break;
    case 'about': $('#about').hidden = false; break;
    case 'close-about': $('#about').hidden = true; break;
    case 'badge': if (!state.revealed.has(mol().id)) { state.tab = 'deduce'; renderPanel(); refreshView(); } break;
    default: break;
  }
});

// ------------------------------------------------------------------ boot

function boot() {
  try {
    viewer = new Viewer($('#gl'), $('#viewport'));
  } catch (err) {
    $('#viewport').innerHTML = `<p class="nogl">${L('This device could not start WebGL, which the 3D view needs. Try updating Android System WebView or Chrome.', 'این دستگاه نتوانست WebGL را راه‌اندازی کند که نمای سه‌بعدی به آن نیاز دارد. مرورگر یا Android System WebView را به‌روز کنید.')}</p>`;
    return;
  }
  viewer.setAutoRotate(true);
  viewer.onInteract = () => { if (state.rotate) { state.rotate = false; viewer.setAutoRotate(false); $('[data-act="rotate"]').classList.remove('on'); } };
  setMolecule(0);
}

setLang(initLang());
applyStatic();

const FONT_PRELOAD = ['600 20px "IBM Plex Sans"', '400 14px "IBM Plex Sans"', '500 13px "IBM Plex Mono"', 'italic 600 24px "Cormorant Garamond"', '400 14px "Vazirmatn"', '600 14px "Vazirmatn"', '700 24px "Vazirmatn"'];
const fontsReady = (document.fonts && document.fonts.load)
  ? Promise.race([
    Promise.all(FONT_PRELOAD.map((f) => document.fonts.load(f, 'σ∞C2′دکتر'))),
    new Promise((r) => setTimeout(r, 1500)),
  ]).catch(() => {})
  : Promise.resolve();

fontsReady.then(() => {
  const splash = $('#splash');
  const app = $('#app');
  boot();
  if (splash) {
    const fa = isFa();
    runSplash({
      root: splash, canvas: $('#splash-canvas'), kicker: $('#s-kicker'), sub: $('#s-sub'), skip: $('#s-skip'),
      lines: fa ? ['دکتر علیرضا', 'خورشیدی'] : ['Dr. Alireza', 'Khorshidi'],
      fontStyle: fa ? '700' : 'italic 600',
      fontFam: fa ? '"Vazirmatn", system-ui, sans-serif' : '"Cormorant Garamond", "Iowan Old Style", Georgia, serif',
      rtl: fa,
      onDone: () => { app.removeAttribute('aria-hidden'); },
    });
    app.classList.add('ready');
  } else {
    app.removeAttribute('aria-hidden');
    app.classList.add('ready');
  }
});
