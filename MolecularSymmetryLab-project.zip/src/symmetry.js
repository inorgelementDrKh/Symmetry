// Numerical symmetry perception and step-by-step point-group deduction.
// Pure functions only, so the same code runs in the app and in Node tests.

export const TOL = 0.08; // Å, tolerance for matching an atom to its image

const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const norm = (a) => Math.hypot(a[0], a[1], a[2]);
const unit = (a) => { const l = norm(a); return l < 1e-6 ? null : [a[0] / l, a[1] / l, a[2] / l]; };

export function rotatePoint(p, u, ang) {
  const c = Math.cos(ang), s = Math.sin(ang), d = dot(u, p) * (1 - c), x = cross(u, p);
  return [p[0] * c + x[0] * s + u[0] * d, p[1] * c + x[1] * s + u[1] * d, p[2] * c + x[2] * s + u[2] * d];
}
export function reflectPoint(p, n) {
  const d = 2 * dot(p, n);
  return [p[0] - d * n[0], p[1] - d * n[1], p[2] - d * n[2]];
}

// canonical sign so that +v and -v give the same key
function canon(v) {
  for (let i = 0; i < 3; i++) {
    if (Math.abs(v[i]) > 1e-4) return v[i] < 0 ? [-v[0], -v[1], -v[2]] : v;
  }
  return v;
}
const keyOf = (v) => canon(v).map((x) => Math.round(x * 400)).join(',');
const parallel = (a, b) => Math.abs(dot(a, b)) > 0.9995;
const perpendicular = (a, b) => Math.abs(dot(a, b)) < 0.02;

// symbol helper: {b: base, s: subscript, x: suffix}
export const S = (b, s = '', x = '') => ({ b, s: String(s), x });
export const symHTML = (y) => `${y.b}${y.s ? `<sub>${y.s}</sub>` : ''}${y.x || ''}`;
export const symText = (y) => `${y.b}${y.s}${y.x || ''}`;

const ORDERS_C = [2, 3, 4, 5, 6];
const ORDERS_S = [3, 4, 5, 6, 8, 10, 12];

export function groupOrder(g) {
  const m = /^([A-Za-z]+)(\d*|∞)([a-z]*)$/.exec(g);
  if (!m) return null;
  const [, L, nStr, suf] = m;
  const n = nStr === '∞' ? Infinity : parseInt(nStr || '1', 10);
  if (n === Infinity) return '∞';
  if (L === 'C' && suf === '') return n;
  if (L === 'C' && (suf === 'v' || suf === 'h')) return 2 * n;
  if (L === 'D' && suf === '') return 2 * n;
  if (L === 'D' && (suf === 'h' || suf === 'd')) return 4 * n;
  if (L === 'S') return n;
  if (g === 'Cs' || g === 'Ci') return 2;
  const cubic = { T: 12, Td: 24, Th: 24, O: 24, Oh: 48, I: 60, Ih: 120 };
  return cubic[g] ?? null;
}

export function formatGroup(g) {
  // C3v -> C<sub>3</sub>v ; D∞h -> D<sub>∞</sub>h ; Cs, Ci, Td, Oh, Ih stay as they are
  const m = /^([CDS])(\d+|∞)([a-z]?)$/.exec(g);
  if (m) return `${m[1]}<sub>${m[2]}</sub>${m[3]}`;
  return g;
}

export function analyze(atoms) {
  const P = atoms.map((a) => a.p);
  const E = atoms.map((a) => a.el);
  const N = P.length;

  const maps = (f) => {
    const hit = new Set();
    for (let i = 0; i < N; i++) {
      const q = f(P[i]);
      let found = -1;
      for (let j = 0; j < N; j++) {
        if (E[j] !== E[i]) continue;
        if (Math.hypot(P[j][0] - q[0], P[j][1] - q[1], P[j][2] - q[2]) < TOL) { found = j; break; }
      }
      if (found < 0) return false;
      hit.add(found);
    }
    return hit.size === N;
  };
  const isC = (u, n) => maps((p) => rotatePoint(p, u, (2 * Math.PI) / n));
  const isS = (u, n) => maps((p) => reflectPoint(rotatePoint(p, u, (2 * Math.PI) / n), u));
  const isSigma = (u) => maps((p) => reflectPoint(p, u));
  const inv = maps((p) => [-p[0], -p[1], -p[2]]);

  const far = P.reduce((b, p) => (norm(p) > norm(b) ? p : b), [0, 0, 0]);
  const lin = unit(far);
  const linear = !!lin && P.every((p) => norm(cross(p, lin)) < 0.02);

  let rawAxes = [];
  let rawPlanes = [];

  if (!linear) {
    const seenAxis = new Set();
    const seenPlane = new Set();
    const testCandidates = (list) => {
      let added = false;
      for (const d of list) {
        const k = keyOf(d);
        if (!seenAxis.has(k)) {
          seenAxis.add(k);
          let n = 0, sn = 0;
          for (const m of ORDERS_C) if (isC(d, m)) n = m;
          for (const m of ORDERS_S) if (isS(d, m)) sn = m;
          if ((n || sn) && !rawAxes.some((a) => parallel(a.dir, d))) { rawAxes.push({ dir: canon(d), n, sn }); added = true; }
        }
        if (!seenPlane.has(k)) {
          seenPlane.add(k);
          if (isSigma(d) && !rawPlanes.some((p) => parallel(p.normal, d))) { rawPlanes.push({ normal: canon(d) }); added = true; }
        }
      }
      return added;
    };
    const base = [];
    const push = (v) => { const u = unit(v); if (u) base.push(u); };
    for (let i = 0; i < N; i++) {
      push(P[i]);
      for (let j = i + 1; j < N; j++) {
        push(cross(P[i], P[j]));
        if (E[i] === E[j]) { push(add(P[i], P[j])); push(sub(P[i], P[j])); }
      }
    }
    testCandidates(base);
    for (let round = 0; round < 3; round++) {
      const els = rawAxes.map((a) => a.dir).concat(rawPlanes.map((p) => p.normal));
      const next = [];
      const pushN = (v) => { const u = unit(v); if (u) next.push(u); };
      for (let i = 0; i < els.length; i++) {
        for (let j = i + 1; j < els.length; j++) {
          pushN(cross(els[i], els[j])); pushN(add(els[i], els[j])); pushN(sub(els[i], els[j]));
          if (els.length <= 14) {
            for (let k = j + 1; k < els.length; k++) {
              for (const s1 of [1, -1]) for (const s2 of [1, -1]) {
                pushN(add(add(els[i], [s1 * els[j][0], s1 * els[j][1], s1 * els[j][2]]), [s2 * els[k][0], s2 * els[k][1], s2 * els[k][2]]));
              }
            }
          }
        }
      }
      if (!testCandidates(next)) break;
    }
  }

  // ---------------- classification ----------------
  const rotAxes = rawAxes.filter((a) => a.n >= 2);
  const maxN = rotAxes.reduce((m, a) => Math.max(m, a.n), 0);
  const highAxes = rotAxes.filter((a) => a.n >= 3);
  const cubic = !linear && highAxes.length >= 2;
  const cnt = (n) => rotAxes.filter((a) => a.n === n).length;

  let principal = null;
  if (!linear && !cubic && maxN >= 2) {
    const top = rotAxes.filter((a) => a.n === maxN);
    principal = top.length === 1 ? top[0] : (maxN === 2 ? top.find((a) => a.sn === 4) || top[0] : null);
  }
  const nP = principal ? principal.n : 0;
  const perpC2 = principal ? rotAxes.filter((a) => a !== principal && perpendicular(a.dir, principal.dir)) : [];
  const hPlanes = principal ? rawPlanes.filter((p) => parallel(p.normal, principal.dir)) : [];
  const vPlanes = principal ? rawPlanes.filter((p) => perpendicular(p.normal, principal.dir)) : [];

  let group = 'C1';
  let family = '';
  if (linear) group = inv ? 'D∞h' : 'C∞v';
  else if (cubic) {
    if (cnt(5)) group = inv ? 'Ih' : 'I';
    else if (cnt(4)) group = inv ? 'Oh' : 'O';
    else group = inv ? 'Th' : (rawPlanes.length ? 'Td' : 'T');
  } else if (!principal) {
    group = rawPlanes.length ? 'Cs' : inv ? 'Ci' : 'C1';
  } else if (perpC2.length === nP) {
    group = hPlanes.length ? `D${nP}h` : vPlanes.length === nP ? `D${nP}d` : `D${nP}`;
  } else if (hPlanes.length) group = `C${nP}h`;
  else if (vPlanes.length) group = `C${nP}v`;
  else if (principal.sn === 2 * nP) group = `S${2 * nP}`;
  else group = `C${nP}`;

  // For D(n)h and C(n)v with even n >= 4 the vertical planes fall into two classes (e.g. 2 sigma_v + 2 sigma_d in D4h).
  // The class holding more atoms is called sigma_v; its C2 axes (if any) get one prime, the others two.
  const vClass = new Map();
  if (principal && nP >= 4 && nP % 2 === 0 && /^(D\d+h|C\d+v)$/.test(group) && vPlanes.length === nP) {
    const ref = Math.abs(principal.dir[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
    const e1 = unit(cross(principal.dir, ref)), e2 = cross(principal.dir, e1);
    const ang = (v) => Math.atan2(dot(v, e2), dot(v, e1));
    const a0 = ang(vPlanes[0].normal);
    const idx = new Map(vPlanes.map((pl) => {
      let r = (((ang(pl.normal) - a0) % Math.PI) + Math.PI) % Math.PI;
      return [pl, Math.round(r / (Math.PI / nP)) % nP];
    }));
    const atomsIn = (pl) => P.filter((q) => Math.abs(dot(q, pl.normal)) < TOL).length;
    const sc2 = [0, 0];
    for (const pl of vPlanes) sc2[idx.get(pl) % 2] += atomsIn(pl);
    const vPar = sc2[1] > sc2[0] ? 1 : 0;
    for (const pl of vPlanes) vClass.set(pl, idx.get(pl) % 2 === vPar ? 'v' : 'd');
  }
  const primeOf = (a) => {
    if (!principal || a === principal || !perpendicular(a.dir, principal.dir) || a.n !== 2 || nP < 3) return '';
    if (vClass.size) {
      const nrm = unit(cross(principal.dir, a.dir));
      const pl = vPlanes.find((q) => parallel(q.normal, nrm));
      return pl && vClass.get(pl) === 'd' ? '″' : '′';
    }
    return '′';
  };

  // ---------------- element list ----------------
  const elements = [];
  const addEl = (o) => { o.id = `${o.kind}${elements.length}`; o.typeKey = symText(o.label); elements.push(o); return o; };

  addEl({ kind: 'E', label: S('E'), op: { type: 'id' } });
  const cubicLike = cubic;

  if (linear) {
    const perp1 = unit(cross(lin, Math.abs(lin[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0]));
    const perp2 = cross(lin, perp1);
    addEl({ kind: 'C', n: Infinity, dir: lin, label: S('C', '∞'), op: { type: 'rot', axis: lin, angle: Math.PI / 3 } });
    if (inv) addEl({ kind: 'S', n: Infinity, dir: lin, label: S('S', '∞'), op: { type: 'imp', axis: lin, angle: Math.PI / 3 }, implied: true });
    addEl({ kind: 'sigma', normal: perp1, label: S('σ', 'v'), infinite: true, op: { type: 'refl', normal: perp1 } });
    addEl({ kind: 'sigma', normal: perp2, label: S('σ', 'v'), infinite: true, hidden: true, op: { type: 'refl', normal: perp2 } });
    if (inv) {
      addEl({ kind: 'i', label: S('i'), op: { type: 'inv' } });
      addEl({ kind: 'sigma', normal: lin, label: S('σ', 'h'), op: { type: 'refl', normal: lin } });
      addEl({ kind: 'C', n: 2, dir: perp1, label: S('C', '2', '′'), infinite: true, op: { type: 'rot', axis: perp1, angle: Math.PI } });
      addEl({ kind: 'C', n: 2, dir: perp2, label: S('C', '2', '′'), infinite: true, hidden: true, op: { type: 'rot', axis: perp2, angle: Math.PI } });
    }
  } else {
    if (inv) addEl({ kind: 'i', label: S('i'), op: { type: 'inv' } });
    const axesSorted = [...rotAxes].sort((a, b) => b.n - a.n);
    for (const a of axesSorted) {
      addEl({ kind: 'C', n: a.n, dir: a.dir, label: S('C', a.n, primeOf(a)), op: { type: 'rot', axis: a.dir, angle: (2 * Math.PI) / a.n }, principal: a === principal });
    }
    for (const a of axesSorted.concat(rawAxes.filter((x) => x.n < 2))) {
      if (a.sn >= 3) {
        const perpPlane = rawPlanes.some((p) => parallel(p.normal, a.dir));
        const implied = a.n === a.sn && perpPlane;
        addEl({ kind: 'S', n: a.sn, dir: a.dir, label: S('S', a.sn), implied, op: { type: 'imp', axis: a.dir, angle: (2 * Math.PI) / a.sn } });
      }
    }
    for (const p of rawPlanes) {
      let name = 'σ';
      let sub = '';
      if (principal) {
        if (parallel(p.normal, principal.dir)) sub = 'h';
        else if (vClass.has(p)) sub = vClass.get(p);
        else {
          const holdsC2 = perpC2.some((a) => perpendicular(a.dir, p.normal));
          sub = perpC2.length === nP && !holdsC2 ? 'd' : 'v';
        }
      } else if (cubicLike) {
        if (group === 'Td') sub = 'd';
        else if (group === 'Th') sub = 'h';
        else if (group === 'Oh') sub = rotAxes.some((a) => a.n === 4 && parallel(a.dir, p.normal)) ? 'h' : 'd';
      }
      addEl({ kind: 'sigma', normal: p.normal, label: S(name, sub), op: { type: 'refl', normal: p.normal } });
    }
  }

  // sort so the list reads E, C..., S..., σ..., i
  const rank = { E: 0, C: 1, S: 2, sigma: 3, i: 4 };
  elements.sort((a, b) => rank[a.kind] - rank[b.kind] || (b.n || 0) - (a.n || 0));
  elements.forEach((e, i) => { e.id = `${e.kind}${i}`; });

  // groups of equal type for the list view
  const types = [];
  for (const e of elements) {
    let t = types.find((x) => x.key === e.typeKey);
    if (!t) { t = { key: e.typeKey, kind: e.kind, label: e.label, members: [], n: e.n, implied: false }; types.push(t); }
    t.members.push(e);
    if (e.implied) t.implied = true;
  }
  for (const t of types) {
    t.count = t.members.filter((m) => !m.hidden).length;
    t.infinite = t.members.some((m) => m.infinite) || (t.kind === 'C' && t.n === Infinity);
  }

  // ---------------- deduction steps (built once per language) ----------------
  const FAD = '۰۱۲۳۴۵۶۷۸۹';
  function buildSteps(lang) {
    const fa = lang === 'fa';
    const L = (en, f) => (fa ? f : en);
    const num = (x) => (fa ? String(x).replace(/\d/g, (d) => FAD[d]) : String(x));
    const steps = [];
    const ids = (arr) => arr.map((e) => e.id);
    const byKind = (k) => elements.filter((e) => e.kind === k).map((e) => e.id);
    const withLabel = (txt) => elements.filter((e) => e.typeKey === txt).map((e) => e.id);
    const yn = (q, a, why, show = []) => steps.push({ type: 'yn', q, a, why, show });
    const info = (text, show = []) => steps.push({ type: 'info', text, show });
    const Cn = (n) => `C<sub>${n}</sub>`;
    const cntTxt = (k, en, f) => (fa ? `${num(k)} ${f}` : `${k} ${en}${k === 1 ? '' : 's'}`);
    const hasHq = L('Is there a horizontal mirror plane σ<sub>h</sub> (perpendicular to the principal axis)?', 'آیا صفحه تقارن افقی (عمود بر محور اصلی) وجود دارد؟');
    const noH = L('No σ<sub>h</sub>.', 'صفحه تقارن افقی وجود ندارد.');
    const qInv = L('Is there a centre of inversion?', 'آیا مرکز وارونگی وجود دارد؟');

    if (linear) {
      yn(L('Is the molecule linear?', 'آیا مولکول خطی است؟'), true,
        L('Every atom lies on one line. That line is a C<sub>∞</sub> axis: any rotation about it leaves the molecule unchanged.', 'همهٔ اتم‌ها روی یک خط قرار دارند. این خط یک محور دوران محض مرتبه ∞ است: هر چرخشی به دور آن، مولکول را بدون تغییر می‌گذارد.'), withLabel('C∞'));
      yn(qInv, inv,
        inv ? L('Moving every atom through the midpoint to the opposite side gives the same arrangement, so i is present.', 'اگر هر اتم را از وسط مولکول به سمت مقابل ببریم، همان آرایش به دست می‌آید؛ پس مرکز وارونگی وجود دارد.')
          : L('The two ends are different, so inversion would swap unlike atoms. There is no i.', 'دو سر مولکول با هم فرق دارند و وارونگی اتم‌های ناهمانند را جابه‌جا می‌کند. پس مرکز وارونگی وجود ندارد.'), inv ? withLabel('i') : []);
    } else {
      yn(L('Is the molecule linear?', 'آیا مولکول خطی است؟'), false, L('The atoms do not all lie on a single line.', 'اتم‌ها همگی روی یک خط نیستند.'), []);
      if (cubic) {
        const ex = highAxes.reduce((o, a) => { o[a.n] = (o[a.n] || 0) + 1; return o; }, {});
        const list = Object.keys(ex).sort((a, b) => b - a).map((n) => `${num(ex[n])} × ${Cn(n)}`).join(L(', ', '، '));
        yn(L('Are there two or more C<sub>n</sub> axes with n ≥ 3?', 'آیا دو محور دوران محض مرتبه n یا بیشتر با n ≥ ۳ وجود دارد؟'), true,
          L(`Yes: ${list}. Several high-order axes at once mark a cubic or icosahedral group.`, `بله: ${list}. وجود هم‌زمان چند محور با مرتبهٔ بالا نشانهٔ گروه مکعبی یا بیستوجهی است.`),
          highAxes.map((a) => elements.find((e) => e.kind === 'C' && e.dir === a.dir)?.id).filter(Boolean));
        if (cnt(5)) {
          yn(L('Is there a C<sub>5</sub> axis?', 'آیا محور دوران محض مرتبه ۵ وجود دارد؟'), true,
            L(`${cntTxt(cnt(5), 'C<sub>5</sub> axis', '')} found: the icosahedral family (I or I<sub>h</sub>).`.replace('axiss', 'axes'), `${num(cnt(5))} محور دوران محض مرتبه ۵ یافت شد: خانوادهٔ بیستوجهی (I یا I<sub>h</sub>).`), withLabel('C5'));
        } else {
          yn(L('Is there a C<sub>5</sub> axis?', 'آیا محور دوران محض مرتبه ۵ وجود دارد؟'), false, L('No fivefold axis, so it is not icosahedral.', 'محور پنج‌گانه وجود ندارد؛ پس مولکول بیستوجهی نیست.'), []);
          if (cnt(4)) yn(L('Is there a C<sub>4</sub> axis?', 'آیا محور دوران محض مرتبه ۴ وجود دارد؟'), true,
            L(`${cnt(4)} C<sub>4</sub> axes found: the octahedral family (O or O<sub>h</sub>).`, `${num(cnt(4))} محور دوران محض مرتبه ۴ یافت شد: خانوادهٔ هشت‌وجهی (O یا O<sub>h</sub>).`), withLabel('C4'));
          else yn(L('Is there a C<sub>4</sub> axis?', 'آیا محور دوران محض مرتبه ۴ وجود دارد؟'), false,
            L('No fourfold axis, so it is not octahedral. Only C<sub>3</sub> and C<sub>2</sub> axes remain: the tetrahedral family (T, T<sub>d</sub>, T<sub>h</sub>).', 'محور چهارگانه وجود ندارد؛ پس هشت‌وجهی نیست. فقط محورهای دوران محض مرتبه ۳ و ۲ باقی می‌مانند: خانوادهٔ چهاروجهی (T، T<sub>d</sub>، T<sub>h</sub>).'), []);
        }
        yn(qInv, inv, inv ? L('Yes, i is present.', 'بله، مرکز وارونگی وجود دارد.') : L('No inversion centre.', 'مرکز وارونگی وجود ندارد.'), inv ? withLabel('i') : []);
        if (!cnt(5) && !cnt(4) && !inv) {
          yn(L('Are there any mirror planes?', 'آیا صفحه تقارن وجود دارد؟'), rawPlanes.length > 0,
            rawPlanes.length ? L(`${rawPlanes.length} mirror planes found (σ<sub>d</sub>), each containing a C<sub>2</sub> axis.`, `${num(rawPlanes.length)} صفحه تقارن دووجهی یافت شد که هر کدام یک محور دوران محض مرتبه ۲ را در بر دارد.`)
              : L('No mirror planes: the pure rotation group T.', 'صفحه تقارن وجود ندارد: گروه دورانی خالص T.'), byKind('sigma'));
        }
      } else {
        yn(L('Is there a rotation axis C<sub>n</sub> with n ≥ 2?', 'آیا محور دوران محض (مرتبهٔ n با n ≥ ۲) وجود دارد؟'), rotAxes.length > 0,
          rotAxes.length ? L(`Yes. The highest order found is n = ${maxN}.`, `بله. بالاترین مرتبهٔ یافت‌شده n = ${num(maxN)} است.`) : L('No proper rotation axis exists.', 'هیچ محور دوران محض وجود ندارد.'),
          rotAxes.length ? ids(elements.filter((e) => e.kind === 'C')) : []);
        if (!rotAxes.length) {
          yn(L('Is there a mirror plane σ?', 'آیا صفحه تقارن وجود دارد؟'), rawPlanes.length > 0,
            rawPlanes.length ? L('One mirror plane maps the molecule onto itself: point group C<sub>s</sub>.', 'یک صفحه تقارن مولکول را بر خودش می‌نگارد: گروه نقطه‌ای C<sub>s</sub>.') : L('No mirror plane.', 'صفحه تقارن وجود ندارد.'), byKind('sigma'));
          if (!rawPlanes.length) yn(qInv, inv,
            inv ? L('Yes, i is present: point group C<sub>i</sub>.', 'بله، مرکز وارونگی وجود دارد: گروه نقطه‌ای C<sub>i</sub>.') : L('Nothing at all except the identity: point group C<sub>1</sub>.', 'جز یکسانی هیچ عنصری وجود ندارد: گروه نقطه‌ای C<sub>1</sub>.'), inv ? withLabel('i') : []);
        } else {
          const pe = elements.find((e) => e.principal);
          const extra = cnt(maxN) > 1 ? L(` (there are ${cnt(maxN)} equal-order axes, so pick the one that is also an S<sub>4</sub> axis if any)`, ` (${num(cnt(maxN))} محور هم‌مرتبه وجود دارد؛ اگر یکی از آن‌ها محور دوران مرکب مرتبه ۴ هم هست، همان را برگزینید)`) : '';
          info(L(`The <b>principal axis</b> is the C<sub>n</sub> of highest order: C<sub>${nP}</sub>${extra}. Treat it as the vertical z axis.`, `<b>محور اصلی</b> همان محور دوران محض با بالاترین مرتبه است: محور دوران محض مرتبه ${num(nP)}${extra}. آن را محور عمودی z در نظر بگیرید.`), pe ? [pe.id] : []);
          const perpIds = elements.filter((e) => e.kind === 'C' && !e.principal && principal && perpendicular(e.dir, principal.dir)).map((e) => e.id);
          yn(L(`Are there ${nP} C<sub>2</sub> axes perpendicular to the principal axis?`, `آیا ${num(nP)} محور دوران محض مرتبه ۲ عمود بر محور اصلی وجود دارد؟`), perpC2.length === nP,
            perpC2.length === nP ? L(`Yes, ${perpC2.length} perpendicular C<sub>2</sub> axes: a dihedral group (D).`, `بله، ${num(perpC2.length)} محور دوران محض مرتبه ۲ عمودی: یک گروه دووجهی (D).`)
              : L(`Found ${perpC2.length}; ${nP} would be needed. Not a dihedral group: look at the C family.`, `${num(perpC2.length)} محور یافت شد، اما ${num(nP)} محور لازم است. گروه دووجهی نیست؛ خانوادهٔ گروه‌های C را بررسی کنید.`), perpIds);
          const hIds = elements.filter((e) => e.kind === 'sigma' && principal && parallel(e.normal, principal.dir)).map((e) => e.id);
          const vIds = elements.filter((e) => e.kind === 'sigma' && principal && perpendicular(e.normal, principal.dir)).map((e) => e.id);
          if (perpC2.length === nP) {
            yn(hasHq, hPlanes.length > 0, hPlanes.length ? L(`Yes: point group D<sub>${nP}h</sub>.`, `بله: گروه نقطه‌ای D<sub>${nP}h</sub>.`) : noH, hIds);
            if (!hPlanes.length) yn(L(`Are there ${nP} vertical planes σ<sub>d</sub> that bisect the C<sub>2</sub> axes?`, `آیا ${num(nP)} صفحه تقارن دووجهی وجود دارد که زاویهٔ میان محورهای دوران محض مرتبه ۲ را نصف می‌کند؟`), vPlanes.length === nP,
              vPlanes.length === nP ? L(`Yes, ${nP} σ<sub>d</sub> planes: point group D<sub>${nP}d</sub>.`, `بله، ${num(nP)} صفحه تقارن دووجهی: گروه نقطه‌ای D<sub>${nP}d</sub>.`) : L(`No vertical planes: point group D<sub>${nP}</sub>.`, `صفحه تقارن عمودی وجود ندارد: گروه نقطه‌ای D<sub>${nP}</sub>.`), vIds);
          } else {
            yn(hasHq, hPlanes.length > 0, hPlanes.length ? L(`Yes: point group C<sub>${nP}h</sub>.`, `بله: گروه نقطه‌ای C<sub>${nP}h</sub>.`) : noH, hIds);
            if (!hPlanes.length) {
              yn(L('Are there vertical mirror planes σ<sub>v</sub> containing the principal axis?', 'آیا صفحه‌های تقارن عمودی شامل محور اصلی وجود دارند؟'), vPlanes.length > 0,
                vPlanes.length ? L(`Yes, ${cntTxt(vPlanes.length, 'σ<sub>v</sub> plane')}: point group C<sub>${nP}v</sub>.`, `بله، ${num(vPlanes.length)} صفحه تقارن عمودی: گروه نقطه‌ای C<sub>${nP}v</sub>.`) : L('No vertical planes.', 'صفحه تقارن عمودی وجود ندارد.'), vIds);
              if (!vPlanes.length) {
                const sIds = elements.filter((e) => e.kind === 'S').map((e) => e.id);
                yn(L(`Is there an improper axis S<sub>${2 * nP}</sub> along the principal axis?`, `آیا محور دوران مرکب مرتبه ${num(2 * nP)} در امتداد محور اصلی وجود دارد؟`), principal.sn === 2 * nP,
                  principal.sn === 2 * nP ? L(`Yes: rotating by ${360 / (2 * nP)}° and reflecting is a symmetry. Point group S<sub>${2 * nP}</sub>.`, `بله: چرخش ${num(360 / (2 * nP))} درجه و سپس بازتاب یک عملیات تقارنی است. گروه نقطه‌ای S<sub>${2 * nP}</sub>.`)
                    : L(`No improper axis: point group C<sub>${nP}</sub>.`, `محور دوران مرکب وجود ندارد: گروه نقطه‌ای C<sub>${nP}</sub>.`), sIds);
              }
            }
          }
        }
      }
    }
    return steps;
  }
  const steps = { en: buildSteps('en'), fa: buildSteps('fa') };

  const hasImproper = rawPlanes.length > 0 || inv || rawAxes.some((a) => a.sn) || linear;
  const chiral = !linear && !hasImproper;
  const polar = /^(C1|Cs|C\d+|C\d+v|C∞v)$/.test(group);

  return {
    linear, cubic, group, order: groupOrder(group), elements, types, steps,
    counts: { axes: rotAxes.length, planes: rawPlanes.length, inv },
    chiral, polar, principalId: elements.find((e) => e.principal)?.id || null,
  };
}
