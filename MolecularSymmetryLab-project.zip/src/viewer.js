import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { COV, VDW, COLOR } from './molecules.js';
import { rotatePoint, reflectPoint } from './symmetry.js';

// ---- colours of symmetry elements (shared with the UI) ----
const AXIS_COL = { 2: 0x00e5ff, 3: 0x2dff8a, 4: 0xffe600, 5: 0xc56bff, 6: 0xff8a1f };
export function elementColor(el) {
  if (el.kind === 'C') return AXIS_COL[el.n] ?? 0x38d0f0;
  if (el.kind === 'S') return 0xff3da6;
  if (el.kind === 'i') return 0xc6ff1a;
  if (el.kind === 'sigma') {
    const s = el.label.s;
    return s === 'h' ? 0xff7a2d : s === 'd' ? 0xd04dff : 0x3d8bff;
  }
  return 0xffffff;
}
export const hex = (n) => `#${n.toString(16).padStart(6, '0')}`;

const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const Y = new THREE.Vector3(0, 1, 0);
const Z = new THREE.Vector3(0, 0, 1);
const V = (a) => new THREE.Vector3(a[0], a[1], a[2]);

function labelSprite(sym, color, scale) {
  const c = document.createElement('canvas');
  c.width = 220; c.height = 110;
  const g = c.getContext('2d');
  const big = '600 58px "IBM Plex Sans", system-ui, sans-serif';
  const small = '600 36px "IBM Plex Sans", system-ui, sans-serif';
  g.font = big; const wb = g.measureText(sym.b).width;
  g.font = small; const ws = sym.s ? g.measureText(sym.s).width : 0;
  g.font = big; const wx = sym.x ? g.measureText(sym.x).width : 0;
  let x = (c.width - (wb + ws + wx)) / 2;
  const y = 70;
  g.lineJoin = 'round'; g.lineWidth = 9; g.strokeStyle = 'rgba(8,12,22,0.9)'; g.fillStyle = hex(color);
  const draw = (txt, font, dy, w) => { g.font = font; g.strokeText(txt, x, y + dy); g.fillText(txt, x, y + dy); x += w; };
  draw(sym.b, big, 0, wb);
  if (sym.s) draw(sym.s, small, 14, ws);
  if (sym.x) draw(sym.x, big, 0, wx);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
  sp.scale.set(scale, scale / 2, 1);
  sp.renderOrder = 20;
  return sp;
}

const numCache = new Map();
function numberSprite(n) {
  if (!numCache.has(n)) {
    const c = document.createElement('canvas');
    c.width = 96; c.height = 96;
    const g = c.getContext('2d');
    g.fillStyle = 'rgba(8,12,22,0.82)';
    g.beginPath(); g.arc(48, 48, 34, 0, Math.PI * 2); g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.85)'; g.lineWidth = 4; g.stroke();
    g.fillStyle = '#fff'; g.font = '600 40px "IBM Plex Sans", system-ui, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(String(n), 48, 51);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    numCache.set(n, t);
  }
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: numCache.get(n), depthTest: false, transparent: true }));
  s.renderOrder = 30;
  return s;
}

const sphereGeo = new THREE.SphereGeometry(1, 32, 22);
const bondGeo = new THREE.CylinderGeometry(1, 1, 1, 14, 1, true);

class MolView {
  constructor(mol, { numbers = false } = {}) {
    this.mol = mol;
    this.group = new THREE.Group();
    this.atoms = mol.atoms.map((a, i) => {
      const m = new THREE.Mesh(sphereGeo, new THREE.MeshPhysicalMaterial({ color: COLOR[a.el] ?? 0xcccccc, emissive: COLOR[a.el] ?? 0xcccccc, emissiveIntensity: 0.16, roughness: 0.22, metalness: 0.08, clearcoat: 1, clearcoatRoughness: 0.12 }));
      this.group.add(m);
      return m;
    });
    this.bondMeshes = mol.bonds.map(() => {
      const m = new THREE.Mesh(bondGeo, new THREE.MeshPhysicalMaterial({ color: 0xcfe0ff, emissive: 0x6f8cff, emissiveIntensity: 0.25, roughness: 0.25, metalness: 0.2, clearcoat: 0.8 }));
      this.group.add(m);
      return m;
    });
    this.sprites = numbers ? mol.atoms.map((a, i) => { const s = numberSprite(i + 1); s.scale.set(0.42, 0.42, 1); this.group.add(s); return s; }) : null;
    this.style = 'ball';
    this.setStyle('ball');
    this.setPositions(mol.atoms.map((a) => a.p));
  }
  setStyle(style) {
    this.style = style;
    this.mol.atoms.forEach((a, i) => {
      const r = style === 'space' ? VDW[a.el] * 0.58 : 0.12 + 0.25 * COV[a.el];
      this.atoms[i].scale.setScalar(r);
    });
    this.bondMeshes.forEach((b) => { b.visible = style !== 'space'; });
  }
  setPositions(pts) {
    pts.forEach((p, i) => {
      this.atoms[i].position.set(p[0], p[1], p[2]);
      if (this.sprites) this.sprites[i].position.set(p[0], p[1], p[2]);
    });
    this.mol.bonds.forEach(([i, j], k) => {
      const a = V(pts[i]), b = V(pts[j]);
      const d = b.clone().sub(a);
      const len = d.length();
      const m = this.bondMeshes[k];
      m.position.copy(a).addScaledVector(d, 0.5);
      m.quaternion.setFromUnitVectors(Y, d.normalize());
      m.scale.set(0.07, len, 0.07);
    });
  }
  setOpacity(o) {
    const all = [...this.atoms, ...this.bondMeshes];
    for (const m of all) { m.material.transparent = o < 1; m.material.opacity = o; m.material.depthWrite = o >= 1; }
  }
  dispose() {
    this.group.traverse((o) => { if (o.material && !o.isSprite) o.material.dispose(); });
  }
}

function buildElementObject(el, L, Rp, labelScale) {
  const g = new THREE.Group();
  const mats = [];
  const color = elementColor(el);
  const basic = (op, extra = {}) => {
    const m = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: op, ...extra });
    mats.push({ m, base: op, focus: Math.min(1, op * 1.0 + (extra.side ? 0.2 : 0)) });
    return m;
  };
  const add = (m) => { g.add(m); return m; };

  if (el.kind === 'C' || el.kind === 'S') {
    const dir = V(el.dir).normalize();
    const q = new THREE.Quaternion().setFromUnitVectors(Y, dir);
    const qz = new THREE.Quaternion().setFromUnitVectors(Z, dir);
    const len = el.kind === 'S' ? L + 0.22 : L;
    if (el.kind === 'C') {
      const cyl = add(new THREE.Mesh(new THREE.CylinderGeometry(0.034, 0.034, len * 2, 10), basic(0.95)));
      cyl.quaternion.copy(q);
    } else {
      const N = 15, step = (len * 2) / N;
      for (let i = 0; i < N; i++) {
        const d = add(new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, step * 0.55, 8), basic(0.95)));
        d.quaternion.copy(q);
        d.position.copy(dir).multiplyScalar(-len + step * (i + 0.5));
      }
    }
    for (const sgn of [1, -1]) {
      let mesh;
      if (el.kind === 'S') {
        const sides = Number.isFinite(el.n) ? el.n : 40;
        mesh = new THREE.Mesh(new THREE.RingGeometry(0.1, 0.17, sides), basic(0.95, { side: THREE.DoubleSide }));
      } else {
        const sides = !Number.isFinite(el.n) ? 40 : el.n === 2 ? 36 : el.n;
        mesh = new THREE.Mesh(new THREE.CircleGeometry(0.17, sides), basic(0.95, { side: THREE.DoubleSide }));
        if (el.n === 2) mesh.scale.set(1.25, 0.5, 1);
      }
      mesh.quaternion.copy(qz);
      if (el.kind === 'C' && el.n === 2) mesh.rotateZ(Math.PI / 2 * 0);
      mesh.position.copy(dir).multiplyScalar(sgn * len);
      g.add(mesh);
    }
    const lab = labelSprite(el.label, color, labelScale);
    lab.position.copy(dir).multiplyScalar(len + 0.42 + (el.kind === 'S' ? 0.3 : 0));
    g.add(lab);
    g.userData.labels = [lab];
  } else if (el.kind === 'sigma') {
    const n = V(el.normal).normalize();
    const q = new THREE.Quaternion().setFromUnitVectors(Z, n);
    const disc = add(new THREE.Mesh(new THREE.CircleGeometry(Rp, 72), basic(0.13, { side: THREE.DoubleSide, depthWrite: false })));
    disc.quaternion.copy(q); disc.renderOrder = 5;
    mats[mats.length - 1].focus = 0.3;
    const ring = add(new THREE.Mesh(new THREE.RingGeometry(Rp * 0.987, Rp, 72), basic(0.7, { side: THREE.DoubleSide, depthWrite: false })));
    ring.quaternion.copy(q); ring.renderOrder = 6;
    mats[mats.length - 1].focus = 1;
    const ref = Math.abs(n.y) < 0.9 ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0);
    const u = new THREE.Vector3().crossVectors(n, ref).normalize();
    const lab = labelSprite(el.label, color, labelScale);
    lab.position.copy(u).multiplyScalar(Rp * 0.9);
    g.add(lab);
    g.userData.labels = [lab];
  } else if (el.kind === 'i') {
    const s = add(new THREE.Mesh(new THREE.SphereGeometry(0.11, 18, 12), basic(1)));
    s.renderOrder = 8;
    for (const ax of [[1, 0, 0], [0, 1, 0], [0, 0, 1]]) {
      const c = add(new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.9, 6), basic(0.9)));
      c.quaternion.setFromUnitVectors(Y, V(ax));
    }
    const lab = labelSprite(el.label, color, labelScale * 0.8);
    lab.position.set(0.28, 0.34, 0.28);
    g.add(lab);
    g.userData.labels = [lab];
  }
  g.userData.mats = mats;
  g.userData.el = el;
  g.traverse((o) => { if (o.material && o.isMesh) o.renderOrder = o.renderOrder || 10; });
  return g;
}

export class Viewer {
  constructor(canvas, container) {
    this.container = container;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setClearColor(0x000000, 0);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(38, 1, 0.1, 200);
    this.scene.add(new THREE.HemisphereLight(0xe6f0ff, 0x6a2a8a, 1.25));
    this.key = new THREE.DirectionalLight(0xffffff, 1.35);
    this.scene.add(this.key);
    this.scene.add(this.key.target);
    this.fill = new THREE.DirectionalLight(0xff5fd2, 0.7);
    this.fill.position.set(-4, -3, -2);
    this.scene.add(this.fill);

    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.09;
    this.controls.enablePan = false;
    this.controls.autoRotateSpeed = 1.1;
    this.controls.addEventListener('start', () => { this.userTouched = true; this.onInteract?.(); });

    this.molRoot = new THREE.Group();
    this.elRoot = new THREE.Group();
    this.scene.add(this.molRoot, this.elRoot);
    this.style = 'ball';
    this.showLabels = true;
    this.playing = null;
    this._raf = 0;

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    this.resize();
    this.renderer.setAnimationLoop((t) => this.frame(t));
  }

  resize() {
    const w = this.container.clientWidth || 300, h = this.container.clientHeight || 300;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.reach) this.fit(false);
  }

  fit(resetAngle = true) {
    const R = this.reach;
    const vf = (this.camera.fov * Math.PI) / 360;
    const hf = Math.atan(Math.tan(vf) * this.camera.aspect);
    const d = (R / Math.sin(Math.min(vf, hf))) * 1.04;
    if (resetAngle) {
      const dir = new THREE.Vector3(0.62, 0.5, 0.82).normalize();
      this.camera.position.copy(dir.multiplyScalar(d));
    } else {
      const cur = this.camera.position.clone().normalize();
      this.camera.position.copy(cur.multiplyScalar(d));
    }
    this.controls.minDistance = d * 0.45;
    this.controls.maxDistance = d * 1.8;
    this.controls.target.set(0, 0, 0);
    this.controls.update();
  }

  resetView() { this.fit(true); }

  load(mol, analysis) {
    this.cancelPlay();
    for (const grp of [this.molRoot, this.elRoot]) {
      while (grp.children.length) { const c = grp.children.pop(); c.traverse?.((o) => { o.geometry?.dispose?.(); }); }
    }
    this.mol = mol;
    this.main = new MolView(mol);
    this.main.setStyle(this.style);
    this.molRoot.add(this.main.group);

    const L = mol.radius + 0.75;
    const Rp = mol.radius + 0.35;
    this.reach = Rp + 0.45;
    const labelScale = Math.max(0.8, mol.radius * 0.36);
    this.elObjects = new Map();
    for (const el of analysis.elements) {
      if (el.kind === 'E') continue;
      const obj = buildElementObject(el, L, Rp, labelScale);
      obj.visible = false;
      this.elRoot.add(obj);
      this.elObjects.set(el.id, obj);
    }
    this.fit(true);
    this.userTouched = false;
  }

  // visibleIds: Set of element ids to show; focusIds: Set or null (others dimmed)
  setElements(visibleIds, focusIds) {
    for (const [id, obj] of this.elObjects) {
      const inFocus = !focusIds || focusIds.has(id);
      obj.visible = !!(visibleIds.has(id) || (focusIds && focusIds.has(id)));
      for (const { m, base, focus } of obj.userData.mats) {
        m.opacity = !focusIds ? base : inFocus ? Math.max(focus, base) : base * 0.22;
      }
      for (const lab of obj.userData.labels || []) {
        lab.visible = this.showLabels;
        lab.material.opacity = !focusIds || inFocus ? 1 : 0.25;
      }
    }
  }

  setLabels(on) {
    this.showLabels = on;
    for (const obj of this.elObjects?.values() || []) for (const lab of obj.userData.labels || []) lab.visible = on;
  }

  setStyle(style) {
    this.style = style;
    this.main?.setStyle(style);
    this.mover?.setStyle(style);
  }

  setAutoRotate(on) { this.controls.autoRotate = on; }

  positionsAt(op, k, t) {
    const pts = this.mol.atoms.map((a) => a.p);
    const e = ease(t);
    switch (op.type) {
      case 'rot': return pts.map((p) => rotatePoint(p, op.axis, op.angle * k * e));
      case 'refl': return pts.map((p) => { const d = 2 * e * (p[0] * op.normal[0] + p[1] * op.normal[1] + p[2] * op.normal[2]); return [p[0] - d * op.normal[0], p[1] - d * op.normal[1], p[2] - d * op.normal[2]]; });
      case 'inv': return pts.map((p) => p.map((x) => x * (1 - 2 * e)));
      case 'imp': {
        if (t < 0.5) return pts.map((p) => rotatePoint(p, op.axis, op.angle * ease(t * 2)));
        const e2 = ease(t * 2 - 1);
        return pts.map((p) => {
          const q = rotatePoint(p, op.axis, op.angle);
          const d = 2 * e2 * (q[0] * op.axis[0] + q[1] * op.axis[1] + q[2] * op.axis[2]);
          return [q[0] - d * op.axis[0], q[1] - d * op.axis[1], q[2] - d * op.axis[2]];
        });
      }
      default: return pts;
    }
  }

  static duration(op, k = 1) {
    return { id: 1400, rot: 1700 + 500 * (k - 1), refl: 2200, inv: 2600, imp: 3600 }[op.type] || 1800;
  }

  play(op, k = 1) {
    this.cancelPlay();
    return new Promise((resolve) => {
      const mover = new MolView(this.mol, { numbers: true });
      mover.setStyle(this.style);
      this.mover = mover;
      this.molRoot.add(mover.group);
      this.main.setOpacity(0.3);
      const dur = Viewer.duration(op, k);
      const hold = 1300;
      this.playing = { op, k, t0: performance.now(), dur, hold, resolve };
    });
  }

  cancelPlay() {
    if (!this.playing) return;
    const p = this.playing;
    this.playing = null;
    this.endPlay();
    p.resolve(false);
  }

  endPlay() {
    if (this.mover) { this.molRoot.remove(this.mover.group); this.mover.dispose(); this.mover = null; }
    this.main?.setOpacity(1);
  }

  frame(now) {
    if (this.playing) {
      const p = this.playing;
      const el = now - p.t0;
      const t = Math.min(1, el / p.dur);
      this.mover.setPositions(this.positionsAt(p.op, p.k, t));
      if (el > p.dur + p.hold) { this.playing = null; this.endPlay(); p.resolve(true); }
    }
    this.controls.update();
    this.key.position.copy(this.camera.position).add(new THREE.Vector3(2, 3, 1));
    this.renderer.render(this.scene, this.camera);
  }
}
