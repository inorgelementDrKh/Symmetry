// Opening sequence: particles gather into the author's name, which is then mirrored across a σ plane.

const SLOW = 1.5; // timeline stretch: 1.5 means everything takes one and a half times as long
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const easeOut = (t) => 1 - Math.pow(1 - t, 3);

export function runSplash({ root, canvas, kicker, sub, skip, onDone, lines, fontStyle = 'italic 600', fontFam = '"Cormorant Garamond", "Iowan Old Style", Georgia, serif', rtl = false }) {
  const LINES = lines;
  const reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ctx = canvas.getContext('2d');
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  let W = 0, H = 0, raf = 0, finished = false, t0 = 0;
  let P = null; // particle arrays
  let geo = null;

  function size() {
    W = root.clientWidth; H = root.clientHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    canvas.style.width = `${W}px`; canvas.style.height = `${H}px`;
  }

  function build() {
    size();
    const off = document.createElement('canvas');
    off.width = W; off.height = H;
    const o = off.getContext('2d');
    // fit the longer line to ~80% of the width, bounded by height
    o.font = `${fontStyle} 100px ${fontFam}`;
    const w100 = Math.max(...LINES.map((l) => o.measureText(l).width));
    const fs = Math.min((W * 0.8 / w100) * 100, H * 0.17, 150);
    o.font = `${fontStyle} ${fs}px ${fontFam}`;
    o.direction = rtl ? 'rtl' : 'ltr';
    o.textAlign = 'center'; o.textBaseline = 'alphabetic';
    o.fillStyle = '#fff';
    const lh = fs * 0.98;
    const blockTop = H * 0.4 - lh;
    LINES.forEach((l, i) => o.fillText(l, W / 2, blockTop + lh * (i + 1) - fs * 0.08));
    const img = o.getImageData(0, 0, W, H).data;
    let step = Math.max(2, Math.round(fs / 30));
    let pts;
    for (;;) {
      pts = [];
      for (let y = 0; y < H; y += step) for (let x = 0; x < W; x += step) if (img[(y * W + x) * 4 + 3] > 110) pts.push(x, y);
      if (pts.length / 2 <= 6500) break;
      step++;
    }
    const n = pts.length / 2;
    let minY = H, maxY = 0;
    for (let i = 0; i < n; i++) { minY = Math.min(minY, pts[2 * i + 1]); maxY = Math.max(maxY, pts[2 * i + 1]); }
    P = { n, tx: new Float32Array(n), ty: new Float32Array(n), sx: new Float32Array(n), sy: new Float32Array(n), dl: new Float32Array(n), du: new Float32Array(n), tw: new Uint8Array(n), sz: step };
    const cx = W / 2, cy = H / 2, R = Math.max(W, H) * 0.75;
    for (let i = 0; i < n; i++) {
      P.tx[i] = pts[2 * i]; P.ty[i] = pts[2 * i + 1];
      const a = Math.random() * Math.PI * 2, r = R * (0.45 + Math.random() * 0.7);
      P.sx[i] = cx + Math.cos(a) * r; P.sy[i] = cy + Math.sin(a) * r * 0.8;
      P.dl[i] = Math.random() * 900; P.du[i] = 1250 + Math.random() * 600;
      P.tw[i] = Math.random() < 0.12 ? 1 : 0;
    }
    geo = { minY, maxY, mirrorY: maxY + fs * 0.32, fs, blockH: maxY - minY };
    // place DOM captions relative to the drawn name
    kicker.style.top = `${Math.max(14, minY - fs * 0.62)}px`;
    sub.style.top = `${Math.min(H - 150, geo.mirrorY + geo.blockH * 0.78)}px`;
  }

  function drawBackdrop(t) {
    const g = ctx.createRadialGradient(W / 2, H * 0.42, 0, W / 2, H * 0.42, Math.max(W, H) * 0.8);
    g.addColorStop(0, '#3a1670'); g.addColorStop(0.55, '#14204f'); g.addColorStop(1, '#050a22');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // slowly turning hexagon with its six-fold axes (benzene motif)
    const r = Math.min(W, H) * 0.44, cx = W / 2, cy = H * 0.42;
    const ang = t * 0.00007;
    ctx.save();
    ctx.translate(cx, cy); ctx.rotate(ang);
    ctx.strokeStyle = 'rgba(0,229,255,0.16)'; ctx.lineWidth = 1.2;
    ctx.beginPath();
    for (let k = 0; k < 6; k++) { const a = (k * Math.PI) / 3; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
    ctx.closePath(); ctx.stroke();
    ctx.beginPath();
    for (let k = 0; k < 3; k++) { const a = (k * Math.PI) / 3; ctx.moveTo(Math.cos(a) * r * 1.12, Math.sin(a) * r * 1.12); ctx.lineTo(-Math.cos(a) * r * 1.12, -Math.sin(a) * r * 1.12); }
    ctx.stroke();
    ctx.restore();
  }

  function frame(now) {
    if (finished) return;
    if (!t0) t0 = now;
    const t = reduced ? 9999 : (now - t0) / SLOW;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawBackdrop(t);

    const sweepX = -W * 0.1 + smooth(2300, 3700, t) * W * 1.2;
    const band = W * 0.06;
    const mirrorA = smooth(1700, 2800, t);
    const sz = P.sz * 0.78;
    const NB = 8, buckets = Array.from({ length: NB }, () => []);
    const flying = [];
    for (let i = 0; i < P.n; i++) {
      const u = clamp((t - P.dl[i]) / P.du[i], 0, 1);
      const e = easeOut(u);
      let x = P.tx[i], y = P.ty[i];
      if (u < 1) {
        const ox = (P.sx[i] - x) * (1 - e), oy = (P.sy[i] - y) * (1 - e);
        const a = (1 - e) * 1.7, c = Math.cos(a), s = Math.sin(a);
        x += ox * c - oy * s; y += ox * s + oy * c;
      }
      const lit = t > 2300 && Math.abs(P.tx[i] - sweepX) < band;
      const b = lit ? 7 : P.tw[i] && u >= 1 ? 6 : Math.min(5, Math.max(0, Math.floor((P.tx[i] / W) * 6)));
      buckets[b].push(x, y, u);
    }
    const colors = ['#ffd23f', '#ff9a1f', '#ff3d8b', '#b14dff', '#2f9bff', '#19f0c8', '#fff3b0', '#ffffff'];
    for (let b = 0; b < NB; b++) {
      ctx.fillStyle = colors[b];
      const arr = buckets[b];
      for (let k = 0; k < arr.length; k += 3) {
        ctx.globalAlpha = 0.25 + 0.75 * arr[k + 2];
        ctx.fillRect(arr[k] - sz / 2, arr[k + 1] - sz / 2, sz, sz);
      }
    }
    // reflection across the horizontal mirror plane
    if (mirrorA > 0.01) {
      const my = geo.mirrorY;
      for (let b = 0; b < NB; b++) {
        ctx.fillStyle = colors[b];
        const arr = buckets[b];
        for (let k = 0; k < arr.length; k += 3) {
          const ry = 2 * my - arr[k + 1];
          const fall = 1 - (ry - my) / (geo.blockH * 0.95);
          if (fall <= 0 || arr[k + 2] < 1) continue;
          ctx.globalAlpha = 0.3 * mirrorA * fall;
          ctx.fillRect(arr[k] - sz / 2, ry - sz / 2, sz, sz);
        }
      }
      ctx.globalAlpha = mirrorA;
      const lg = ctx.createLinearGradient(W * 0.08, 0, W * 0.92, 0);
      lg.addColorStop(0, 'rgba(56,208,240,0)'); lg.addColorStop(0.5, 'rgba(56,208,240,0.8)'); lg.addColorStop(1, 'rgba(56,208,240,0)');
      ctx.fillStyle = lg; ctx.fillRect(W * 0.08, my - 0.5, W * 0.84, 1.2);
      ctx.fillStyle = 'rgba(56,208,240,0.85)';
      ctx.font = 'italic 600 15px "Cormorant Garamond", Georgia, serif';
      ctx.textAlign = 'left';
      ctx.fillText('σ', W * 0.08, my - 7);
      ctx.font = 'italic 600 10px "Cormorant Garamond", Georgia, serif';
      ctx.fillText('h', W * 0.08 + 9, my - 3);
    }
    // the sweeping vertical mirror
    if (t > 2300 && t < 3800) {
      const a = Math.sin(smooth(2300, 3800, t) * Math.PI);
      ctx.globalAlpha = 0.55 * a;
      ctx.fillStyle = '#9fe9ff';
      ctx.fillRect(sweepX - 0.6, geo.minY - geo.fs * 0.25, 1.2, geo.blockH + geo.fs * 0.5);
    }
    ctx.globalAlpha = 1;

    if (t > (reduced ? 0 : 700)) kicker.classList.add('on');
    if (t > (reduced ? 0 : 2500)) sub.classList.add('on');
    if (t > (reduced ? 1800 : 5600)) return finish();
    raf = requestAnimationFrame(frame);
  }

  function finish() {
    if (finished) return;
    finished = true;
    cancelAnimationFrame(raf);
    root.classList.add('out');
    setTimeout(() => { root.remove(); onDone?.(); }, 650);
  }

  skip.addEventListener('click', finish);
  root.addEventListener('pointerdown', finish);

  const start = () => { build(); raf = requestAnimationFrame(frame); };
  let started = false;
  const go = () => { if (!started) { started = true; start(); } };
  if (document.fonts && document.fonts.load) {
    Promise.race([document.fonts.load(`${fontStyle} 64px ${fontFam.split(',')[0]}`, LINES.join('')), new Promise((r) => setTimeout(r, 1200))]).then(go, go);
  } else go();
}
