// Idealised molecular geometries (Å). Each molecule is centred on its centre of mass.

export const MASS = { H: 1.008, B: 10.81, C: 12.011, N: 14.007, O: 15.999, F: 18.998, S: 32.06, Cl: 35.45, Br: 79.904, I: 126.904, Xe: 131.29, P: 30.974, Fe: 55.845, Co: 58.933, Re: 186.207, Tl: 204.38 };
export const COV = { H: 0.31, B: 0.84, C: 0.76, N: 0.71, O: 0.66, F: 0.57, S: 1.05, Cl: 1.02, Br: 1.2, I: 1.39, Xe: 1.4, P: 1.07, Fe: 1.32, Co: 1.26, Re: 1.51, Tl: 1.55 };
export const VDW = { H: 1.1, B: 1.92, C: 1.7, N: 1.55, O: 1.52, F: 1.47, S: 1.8, Cl: 1.75, Br: 1.85, I: 1.98, Xe: 2.16, P: 1.8, Fe: 2.0, Co: 2.0, Re: 2.0, Tl: 1.96 };
export const COLOR = { H: 0xffffff, B: 0xff8a6b, C: 0x6b7cff, N: 0x2f6bff, O: 0xff2d55, F: 0x2dffa0, S: 0xffe01a, Cl: 0x1fe04a, Br: 0xff6a00, I: 0xc13dff, Xe: 0x00e5ff, P: 0xff9f0a, Fe: 0xff5a1f, Co: 0xff4fa3, Re: 0x00b7ff, Tl: 0xd4ff3a };

const D2R = Math.PI / 180;
const pol = (r, deg, z = 0) => [r * Math.cos(deg * D2R), r * Math.sin(deg * D2R), z];
const unit3 = (v) => { const l = Math.hypot(...v); return v.map((x) => x / l); };
const sc = (v, s) => v.map((x) => x * s);
const plus = (a, b) => a.map((x, i) => x + b[i]);
const neg = (v) => v.map((x) => -x);
const rotZ = (v, deg) => { const c = Math.cos(deg * D2R), s = Math.sin(deg * D2R); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c, v[2]]; };

const TET = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]].map(unit3);

function ethane(tau) {
  const a = [['C', 0, 0, -0.77], ['C', 0, 0, 0.77]];
  for (let k = 0; k < 3; k++) {
    a.push(['H', ...pol(1.0277, 90 + 120 * k, -0.77 - 0.3633)]);
    a.push(['H', ...pol(1.0277, 90 + 120 * k + tau, 0.77 + 0.3633)]);
  }
  return a;
}

function ciCompound() {
  // staggered, anti conformer: substituents on C2 are the inversion images of those on C1
  const sub = (len, phi) => { const r = len * 0.9428; return [r * Math.cos(phi * D2R), r * Math.sin(phi * D2R), -len / 3]; };
  const c1 = [0, 0, -0.77];
  const ss = [['Br', 1.94, 0], ['Cl', 1.77, 120], ['H', 1.09, 240]];
  const a = [['C', ...c1], ['C', ...neg(c1)]];
  for (const [el, len, phi] of ss) {
    const p = plus(c1, sub(len, phi));
    a.push([el, ...p]);
    a.push([el, ...neg(p)]);
  }
  return a;
}

function boricAcid() {
  const a = [['B', 0, 0, 0]];
  for (let k = 0; k < 3; k++) {
    const o = pol(1.36, 90 + 120 * k);
    const toB = unit3(neg(o));
    const d = rotZ(toB, 113);
    a.push(['O', ...o]);
    a.push(['H', ...plus(o, sc(d, 0.96))]);
  }
  return a;
}

function icosa() {
  const f = (1 + Math.sqrt(5)) / 2;
  const v = [];
  for (const s1 of [1, -1]) for (const s2 of [1, -1]) {
    v.push([0, s1, s2 * f], [s1, s2 * f, 0], [s2 * f, 0, s1]);
  }
  const a = [];
  for (const p of v) a.push(['B', ...sc(unit3(p), 1.693)]);
  for (const p of v) a.push(['H', ...sc(unit3(p), 2.893)]);
  return a;
}


const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

// images of a point under the improper group S_n (n even): k = 0..n-1, rotate by 360k/n, reflect in z when k is odd
function orbitS(p, n) {
  const out = [];
  for (let k = 0; k < n; k++) {
    const q = rotZ(p, (360 * k) / n);
    out.push(k % 2 ? [q[0], q[1], -q[2]] : q);
  }
  return out;
}
// hydroxyl-type substituent: atom H on O, with C-O-H angle 108.5 degrees and a chosen torsion angle psi
function hydroxylH(O, C, psi, len = 0.96) {
  const w = unit3(O.map((x, i) => x - C[i]));
  let r = Math.abs(w[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
  const p1 = unit3(cross3(w, r)), p2 = cross3(w, p1);
  const c = Math.cos(71.5 * D2R), sn = Math.sin(71.5 * D2R);
  return plus(O, sc(plus(sc(w, c), sc(plus(sc(p1, Math.cos(psi * D2R)), sc(p2, Math.sin(psi * D2R))), sn)), len));
}

function pentaerythritol() {
  const u = unit3([1, 1, 1]);
  const e1 = unit3([1, -1, 0]);
  const e2 = unit3(cross3(u, e1));
  const dir = (phi) => plus(sc(u, 1 / 3), sc(plus(sc(e1, Math.cos(phi * D2R)), sc(e2, Math.sin(phi * D2R))), Math.sqrt(8) / 3));
  const Ca = sc(u, 1.53);
  const O = plus(Ca, sc(dir(25), 1.43));
  const H1 = plus(Ca, sc(dir(145), 1.09));
  const H2 = plus(Ca, sc(dir(265), 1.09));
  const HO = hydroxylH(O, Ca, 70);
  const out = [['C', 0, 0, 0]];
  for (const [el, pt] of [['C', Ca], ['O', O], ['H', H1], ['H', H2], ['H', HO]]) for (const q of orbitS(pt, 4)) out.push([el, ...q]);
  return out;
}

function hexahydroxyethane() {
  const C1 = [0, 0, -0.77];
  const out = [['C', ...C1], ['C', 0, 0, 0.77]];
  const O = [1.348 * Math.cos(15 * D2R), 1.348 * Math.sin(15 * D2R), -0.77 - 0.477];
  const H = hydroxylH(O, C1, 80);
  for (const q of orbitS(O, 6)) out.push(['O', ...q]);
  for (const q of orbitS(H, 6)) out.push(['H', ...q]);
  return out;
}

function propellerBoricAcid() {
  return boricAcid().map(([el, x, y, z]) => (el === 'H' ? [el, x, y, z + 0.45] : [el, x, y, z]));
}

function twistedEthylene(theta) {
  const a = [['C', -0.6695, 0, 0], ['C', 0.6695, 0, 0]];
  for (const sg of [1, -1]) {
    a.push(['H', -1.2315, 0.9288 * sg, 0]);
    const c = Math.cos(theta * D2R), s = Math.sin(theta * D2R);
    a.push(['H', 1.2315, 0.9288 * sg * c, 0.9288 * sg * s]);
  }
  return a;
}

function ferrocene(staggered) {
  const a = [['Fe', 0, 0, 0]];
  for (let k = 0; k < 5; k++) {
    a.push(['C', ...pol(1.21, 72 * k, 1.66)], ['H', ...pol(2.29, 72 * k, 1.66)]);
    const off = staggered ? 36 : 0;
    a.push(['C', ...pol(1.21, 72 * k + off, -1.66)], ['H', ...pol(2.29, 72 * k + off, -1.66)]);
  }
  return a;
}

function re2cl8() {
  const a = [['Re', 0, 0, -1.12], ['Re', 0, 0, 1.12]];
  for (const sg of [-1, 1]) for (let k = 0; k < 4; k++) a.push(['Cl', ...pol(2.222, 90 * k, sg * (1.12 + 0.554))]);
  return a;
}

function sulfur8() {
  const a = [];
  for (let k = 0; k < 8; k++) a.push(['S', ...pol(2.35, 45 * k, k % 2 ? -0.49 : 0.49)]);
  return a;
}

function chair() {
  const a = [];
  for (let k = 0; k < 6; k++) {
    const sg = k % 2 ? -1 : 1, zc = 0.25 * sg;
    a.push(['C', ...pol(1.446, 60 * k, zc)]);
    a.push(['H', ...pol(1.446, 60 * k, zc + 1.09 * sg)]);
    a.push(['H', ...pol(1.446 + 1.027, 60 * k, zc - 0.364 * sg)]);
  }
  return a;
}

function adamantane() {
  const a0 = 0.9, b = 1.766;
  const V = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];
  const out = [];
  for (const [x, y, z] of V) out.push(['C', a0 * x, a0 * y, a0 * z], ['H', (a0 + 0.629) * x, (a0 + 0.629) * y, (a0 + 0.629) * z]);
  for (let k = 0; k < 3; k++) for (const sg of [1, -1]) {
    const e = [0, 0, 0]; e[k] = 1;
    const nb = V.filter((v) => v[k] === sg);
    const d = unit3(cross3(e, nb[0].map((x, i) => x - nb[1][i])));
    const c = sc(e, sg * b);
    out.push(['C', ...c]);
    for (const t of [1, -1]) out.push(['H', ...plus(plus(c, sc(e, sg * 0.648)), sc(d, 0.877 * t))]);
  }
  return out;
}

function cubane() {
  const out = [];
  for (const x of [1, -1]) for (const y of [1, -1]) for (const z of [1, -1]) out.push(['C', 0.785 * x, 0.785 * y, 0.785 * z], ['H', 1.414 * x, 1.414 * y, 1.414 * z]);
  return out;
}

function cobaltNitro() {
  const a = [['Co', 0, 0, 0]];
  const E = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  for (let k = 0; k < 3; k++) for (const sg of [1, -1]) {
    const ax = E[k], tr = E[(k + 1) % 3];
    const N = sc(ax, 1.95 * sg);
    a.push(['N', ...N]);
    for (const t of [1, -1]) a.push(['O', ...plus(plus(N, sc(ax, 0.62 * sg)), sc(tr, 1.074 * t))]);
  }
  return a;
}

function diborane() {
  return [['B', -0.885, 0, 0], ['B', 0.885, 0, 0], ['H', 0, 0, 0.993], ['H', 0, 0, -0.993],
    ['H', 1.466, 1.038, 0], ['H', 1.466, -1.038, 0], ['H', -1.466, 1.038, 0], ['H', -1.466, -1.038, 0]];
}

function cyclopropane() {
  const a = [];
  for (let k = 0; k < 3; k++) {
    a.push(['C', ...pol(0.8776, 90 + 120 * k)]);
    for (const sg of [1, -1]) a.push(['H', ...pol(1.459, 90 + 120 * k, 0.913 * sg)]);
  }
  return a;
}

function cpTl() {
  const a = [['Tl', 0, 0, 2.41]];
  for (let k = 0; k < 5; k++) a.push(['C', ...pol(1.207, 72 * k)], ['H', ...pol(2.287, 72 * k)]);
  return a;
}

const RAW = [
  {
    id: 'chfclbr', name: 'Bromochlorofluoromethane', formula: 'CHFClBr', expected: 'C1',
    atoms: [['C', 0, 0, 0], ['H', ...sc(TET[0], 1.09)], ['F', ...sc(TET[1], 1.35)], ['Cl', ...sc(TET[2], 1.77)], ['Br', ...sc(TET[3], 1.94)]],
    note: 'Four different substituents. Nothing maps the molecule onto itself except doing nothing, so E is the only operation. It is chiral.',
  },
  {
    id: 'ch2clf', name: 'Chlorofluoromethane', formula: 'CH<sub>2</sub>ClF', expected: 'Cs',
    atoms: [['C', 0, 0, 0], ['Cl', ...sc(TET[0], 1.77)], ['F', ...sc(TET[1], 1.35)], ['H', ...sc(TET[2], 1.09)], ['H', ...sc(TET[3], 1.09)]],
    note: 'One mirror plane passes through C, Cl and F and swaps the two hydrogens.',
  },
  {
    id: 'meso-ci', name: 'meso-1,2-Dibromo-1,2-dichloroethane (anti)', formula: 'C<sub>2</sub>H<sub>2</sub>Br<sub>2</sub>Cl<sub>2</sub>', expected: 'Ci',
    atoms: ciCompound(),
    note: 'In the anti conformer, the midpoint of the C–C bond is an inversion centre. Every atom has an identical partner directly opposite it. No axis or plane is present.',
  },
  {
    id: 'h2o2', name: 'Hydrogen peroxide', formula: 'H<sub>2</sub>O<sub>2</sub>', expected: 'C2',
    atoms: [['O', 0, 0, -0.73], ['O', 0, 0, 0.73], ['H', ...plus([0, 0, -0.73], sc([0.9848, 0, -0.1736], 0.97))], ['H', ...plus([0, 0, 0.73], sc([0.9848 * Math.cos(111.5 * D2R), 0.9848 * Math.sin(111.5 * D2R), 0.1736], 0.97))]],
    note: 'The skew shape (dihedral about 111°) keeps a single C₂ axis, which bisects the H–O–O–H twist. Mirror planes and i are lost, so it is chiral.',
  },
  {
    id: 'h2o', name: 'Water', formula: 'H<sub>2</sub>O', expected: 'C2v',
    atoms: [['O', 0, 0, 0], ['H', 0.757, 0, 0.586], ['H', -0.757, 0, 0.586]],
    note: 'A C₂ axis through O, the molecular plane, and a second plane at right angles to it that contains the axis.',
  },
  {
    id: 'nh3', name: 'Ammonia', formula: 'NH<sub>3</sub>', expected: 'C3v',
    atoms: [['N', 0, 0, 0], ...[0, 1, 2].map((k) => ['H', ...pol(0.9377, 90 + 120 * k, -0.3816)])],
    note: 'The pyramid has one C₃ axis and three σᵥ planes, each holding N and one H.',
  },
  {
    id: 'brf5', name: 'Bromine pentafluoride', formula: 'BrF<sub>5</sub>', expected: 'C4v',
    atoms: [['Br', 0, 0, 0], ['F', 0, 0, 1.69], ...[0, 1, 2, 3].map((k) => ['F', ...pol(1.7633, 90 * k, 0.1543)])],
    note: 'A square pyramid. The Br lone pair sits opposite the apex and is not drawn. One C₄ axis, four vertical planes.',
  },
  {
    id: 'hcl', name: 'Hydrogen chloride', formula: 'HCl', expected: 'C∞v',
    atoms: [['Cl', 0, 0, 0], ['H', 0, 0, 1.27]],
    note: 'Linear but with unlike ends. Any rotation about the bond axis works (C∞), and every plane containing the axis is a mirror (σᵥ).',
  },
  {
    id: 'tdce', name: 'trans-1,2-Dichloroethene', formula: 'C<sub>2</sub>H<sub>2</sub>Cl<sub>2</sub>', expected: 'C2h',
    atoms: [['C', -0.665, 0, 0], ['C', 0.665, 0, 0], ['Cl', -1.5892, 1.4506, 0], ['Cl', 1.5892, -1.4506, 0], ['H', -1.205, -0.935, 0], ['H', 1.205, 0.935, 0]],
    note: 'Planar and centrosymmetric. The C₂ axis is perpendicular to the molecular plane, which itself is σₕ. Together they generate i.',
  },
  {
    id: 'boh3', name: 'Boric acid', formula: 'B(OH)<sub>3</sub>', expected: 'C3h',
    atoms: boricAcid(),
    note: 'Flat, with all three O–H bonds turned the same way. C₃ plus σₕ makes an S₃ axis, but there are no vertical mirrors.',
  },
  {
    id: 'ethane-30', name: 'Ethane, twisted 30°', formula: 'C<sub>2</sub>H<sub>6</sub>', expected: 'D3',
    atoms: ethane(30),
    note: 'Half-way between eclipsed and staggered. Mirrors and i disappear, leaving C₃ and three perpendicular C₂ axes. It is chiral.',
  },
  {
    id: 'c2h4', name: 'Ethylene', formula: 'C<sub>2</sub>H<sub>4</sub>', expected: 'D2h',
    atoms: [['C', -0.667, 0, 0], ['C', 0.667, 0, 0], ['H', -1.2315, 0.9288, 0], ['H', -1.2315, -0.9288, 0], ['H', 1.2315, 0.9288, 0], ['H', 1.2315, -0.9288, 0]],
    note: 'Three mutually perpendicular C₂ axes, three mirror planes (one is the molecular plane) and an inversion centre.',
  },
  {
    id: 'allene', name: 'Allene (propadiene)', formula: 'C<sub>3</sub>H<sub>4</sub>', expected: 'D2d',
    atoms: [['C', 0, 0, 0], ['C', 0, 0, 1.31], ['C', 0, 0, -1.31], ['H', 0.934, 0, 1.866], ['H', -0.934, 0, 1.866], ['H', 0, 0.934, -1.866], ['H', 0, -0.934, -1.866]],
    note: 'The two CH₂ planes are at 90°. There is no C₄ and no σₕ, yet an S₄ axis exists: turn 90° and reflect. This is a genuine improper axis.',
  },
  {
    id: 'bf3', name: 'Boron trifluoride', formula: 'BF<sub>3</sub>', expected: 'D3h',
    atoms: [['B', 0, 0, 0], ...[0, 1, 2].map((k) => ['F', ...pol(1.313, 90 + 120 * k)])],
    note: 'C₃, three C₂ axes along the B–F bonds, σₕ (the molecular plane), three σᵥ and an S₃ axis.',
  },
  {
    id: 'ethane-0', name: 'Ethane, eclipsed', formula: 'C<sub>2</sub>H<sub>6</sub>', expected: 'D3h',
    atoms: ethane(0),
    note: 'With the CH₃ groups eclipsed, a σₕ plane cuts the C–C bond in half. Compare the staggered form next.',
  },
  {
    id: 'ethane-60', name: 'Ethane, staggered', formula: 'C<sub>2</sub>H<sub>6</sub>', expected: 'D3d',
    atoms: ethane(60),
    note: 'Staggered ethane has no σₕ, but it has i and an S₆ axis along the C–C bond. Spin 60° and reflect: all atoms land on equivalent atoms.',
  },
  {
    id: 'xef4', name: 'Xenon tetrafluoride', formula: 'XeF<sub>4</sub>', expected: 'D4h',
    atoms: [['Xe', 0, 0, 0], ...[0, 1, 2, 3].map((k) => ['F', ...pol(1.95, 90 * k)])],
    note: 'Square planar: C₄ perpendicular to the plane, four C₂ axes (two through F atoms, two between them), σₕ, two σᵥ, two σd, S₄ and i. Order 16.',
  },
  {
    id: 'if7', name: 'Iodine heptafluoride', formula: 'IF<sub>7</sub>', expected: 'D5h',
    atoms: [['I', 0, 0, 0], ['F', 0, 0, 1.786], ['F', 0, 0, -1.786], ...[0, 1, 2, 3, 4].map((k) => ['F', ...pol(1.858, 72 * k)])],
    note: 'A pentagonal bipyramid. Fivefold symmetry is allowed in a molecule even though it never occurs in crystals. C₅, five C₂, σₕ, five σᵥ, S₅.',
  },
  {
    id: 'benzene', name: 'Benzene', formula: 'C<sub>6</sub>H<sub>6</sub>', expected: 'D6h',
    atoms: [...[0, 1, 2, 3, 4, 5].map((k) => ['C', ...pol(1.397, 60 * k)]), ...[0, 1, 2, 3, 4, 5].map((k) => ['H', ...pol(2.481, 60 * k)])],
    note: 'The classic D₆h example: C₆, six perpendicular C₂ axes (3 + 3), σₕ, three σᵥ, three σd, i and S₆. Order 24.',
  },
  {
    id: 'co2', name: 'Carbon dioxide', formula: 'CO<sub>2</sub>', expected: 'D∞h',
    atoms: [['C', 0, 0, 0], ['O', 0, 0, 1.16], ['O', 0, 0, -1.16]],
    note: 'Linear and symmetric: all the symmetry of HCl plus i, σₕ and infinitely many perpendicular C₂ axes.',
  },
  {
    id: 'ch4', name: 'Methane', formula: 'CH<sub>4</sub>', expected: 'Td',
    atoms: [['C', 0, 0, 0], ...TET.map((v) => ['H', ...sc(v, 1.09)])],
    note: 'Four C₃ axes (through each C–H), three C₂ axes, six σd planes and three S₄ axes. No inversion centre.',
  },
  {
    id: 'sf6', name: 'Sulfur hexafluoride', formula: 'SF<sub>6</sub>', expected: 'Oh',
    atoms: [['S', 0, 0, 0], ...[[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].map((v) => ['F', ...sc(v, 1.56)])],
    note: 'The octahedron: 3 C₄, 4 C₃, 6 C₂, 3 σₕ, 6 σd, i, S₄ and S₆. Order 48.',
  },
  {
    id: 'b12h12', name: 'closo-Dodecaborate dianion', formula: 'B<sub>12</sub>H<sub>12</sub><sup>2−</sup>', expected: 'Ih',
    atoms: icosa(),
    note: 'The icosahedron: 6 C₅, 10 C₃, 15 C₂, 15 mirror planes, i, plus S₁₀ and S₆ axes. Order 120, the largest of the cubic and icosahedral groups.',
  },
  {
    id: 'pentaerythritol', name: 'Pentaerythritol (idealised)', formula: 'C(CH<sub>2</sub>OH)<sub>4</sub>', expected: 'S4',
    atoms: pentaerythritol(),
    note: 'Four identical arms twisted the same way around a central carbon. No mirror plane, no inversion centre and no C₄ axis, yet turning 90° and reflecting is a symmetry. The point group has only E, C₂, S₄ and S₄³.',
  },
  {
    id: 'hexol', name: 'Hexahydroxyethane, twisted', formula: 'C<sub>2</sub>(OH)<sub>6</sub>', expected: 'S6',
    atoms: hexahydroxyethane(),
    note: 'Staggered like ethane, but every O–H points the same way around the axis. That removes the σd planes of D₃d and leaves C₃, i and the S₆ axis (rotate 60°, reflect).',
  },
  {
    id: 'boh3-prop', name: 'Boric acid, propeller form', formula: 'B(OH)<sub>3</sub>', expected: 'C3',
    atoms: propellerBoricAcid(),
    note: 'Lift each hydrogen out of the plane in the same sense and σₕ is lost. Only the C₃ axis remains, and the molecule is a chiral propeller.',
  },
  {
    id: 'sf4', name: 'Sulfur tetrafluoride', formula: 'SF<sub>4</sub>', expected: 'C2v',
    atoms: [['S', 0, 0, 0], ['F', 1.643, 0, -0.1], ['F', -1.643, 0, -0.1], ['F', 0, 1.197, 0.977], ['F', 0, -1.197, 0.977]],
    note: 'A see-saw. The lone pair on S (not drawn) sits in the equatorial plane. One C₂ axis and two vertical planes.',
  },
  {
    id: 'h2co', name: 'Formaldehyde', formula: 'H<sub>2</sub>CO', expected: 'C2v',
    atoms: [['C', 0, 0, 0], ['O', 0, 0, 1.205], ['H', 0.935, 0, -0.526], ['H', -0.935, 0, -0.526]],
    note: 'Planar, with the C₂ axis along C=O. One σᵥ is the molecular plane, the other cuts through it and swaps the hydrogens.',
  },
  {
    id: 'chcl3', name: 'Chloroform', formula: 'CHCl<sub>3</sub>', expected: 'C3v',
    atoms: [['C', 0, 0, 0], ['H', 0, 0, 1.073], ...[0, 1, 2].map((k) => ['Cl', ...pol(1.677, 90 + 120 * k, -0.5405)])],
    note: 'Like ammonia: a C₃ axis along C–H and three σᵥ planes, each holding H, C and one Cl.',
  },
  {
    id: 'cptl', name: 'Cyclopentadienylthallium', formula: 'CpTl', expected: 'C5v',
    atoms: cpTl(),
    note: 'A five-membered ring capped by one atom. The C₅ axis passes through Tl and the ring centre, with five vertical planes.',
  },
  {
    id: 'hcn', name: 'Hydrogen cyanide', formula: 'HCN', expected: 'C∞v',
    atoms: [['H', 0, 0, -1.065], ['C', 0, 0, 0], ['N', 0, 0, 1.156]],
    note: 'Linear with different ends, so no inversion centre and no σₕ. Same group as HCl.',
  },
  {
    id: 'socl2', name: 'Thionyl chloride', formula: 'SOCl<sub>2</sub>', expected: 'Cs',
    atoms: [['S', 0, 0, 0], ['O', 0, 0, 1.44], ['Cl', 1.2536, 1.5389, -0.588], ['Cl', 1.2536, -1.5389, -0.588]],
    note: 'A trigonal pyramid with three different corner atoms (O, Cl, Cl). The only symmetry is the plane through S and O that swaps the two chlorines.',
  },
  {
    id: 'tw-ethylene', name: 'Ethylene, twisted 30°', formula: 'C<sub>2</sub>H<sub>4</sub>', expected: 'D2',
    atoms: twistedEthylene(30),
    note: 'Twist one CH₂ group and the planes and inversion centre vanish, but three perpendicular C₂ axes remain. A chiral D₂ molecule.',
  },
  {
    id: 'b2h6', name: 'Diborane', formula: 'B<sub>2</sub>H<sub>6</sub>', expected: 'D2h',
    atoms: diborane(),
    note: 'Two terminal BH₂ groups share a plane, and two bridging hydrogens lie above and below it. Three C₂ axes, three planes and an inversion centre.',
  },
  {
    id: 'pcl5', name: 'Phosphorus pentachloride', formula: 'PCl<sub>5</sub>', expected: 'D3h',
    atoms: [['P', 0, 0, 0], ['Cl', 0, 0, 2.19], ['Cl', 0, 0, -2.19], ...[0, 1, 2].map((k) => ['Cl', ...pol(2.04, 90 + 120 * k)])],
    note: 'A trigonal bipyramid. The equatorial plane is σₕ and the three equatorial P–Cl bonds are the C₂ axes.',
  },
  {
    id: 'c3h6', name: 'Cyclopropane', formula: 'C<sub>3</sub>H<sub>6</sub>', expected: 'D3h',
    atoms: cyclopropane(),
    note: 'C₃ is perpendicular to the ring. Each of the three C₂ axes runs through one carbon and the midpoint of the opposite C–C bond. The ring plane is σₕ, and it swaps the two hydrogens on every carbon.',
  },
  {
    id: 're2cl8', name: 'Octachlorodirhenate(III)', formula: '[Re<sub>2</sub>Cl<sub>8</sub>]<sup>2−</sup>', expected: 'D4h',
    atoms: re2cl8(),
    note: 'A quadruple Re–Re bond holds the two ReCl₄ squares eclipsed. Turn one square by 45° (staggered) and the group would drop to D₄d.',
  },
  {
    id: 's8', name: 'Cyclo-octasulfur (crown)', formula: 'S<sub>8</sub>', expected: 'D4d',
    atoms: sulfur8(),
    note: 'The crown ring has an S₈ axis, which also gives C₄. Four C₂ axes and four σd planes lie between them. There is no σₕ and no inversion centre.',
  },
  {
    id: 'fc-ecl', name: 'Ferrocene, eclipsed', formula: 'Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub>', expected: 'D5h',
    atoms: ferrocene(false),
    note: 'Two Cp rings directly above each other. The group is the same as for IF₇. The plane σₕ passes through Fe and swaps the two rings.',
  },
  {
    id: 'fc-stag', name: 'Ferrocene, staggered', formula: 'Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub>', expected: 'D5d',
    atoms: ferrocene(true),
    note: 'Rotate one ring by 36° and σₕ is lost, but i and an S₁₀ axis appear. The same relationship as eclipsed and staggered ethane.',
  },
  {
    id: 'chair', name: 'Cyclohexane, chair', formula: 'C<sub>6</sub>H<sub>12</sub>', expected: 'D3d',
    atoms: chair(),
    note: 'C₃ through the ring centre, three C₂ axes between opposite bonds, three σd planes, i and S₆. The six axial hydrogens point alternately up and down.',
  },
  {
    id: 'adamantane', name: 'Adamantane', formula: 'C<sub>10</sub>H<sub>16</sub>', expected: 'Td',
    atoms: adamantane(),
    note: 'A fragment of the diamond lattice. Four CH groups form a tetrahedron, six CH₂ groups bridge its edges: 4 C₃, 3 C₂, 3 S₄ and 6 σd.',
  },
  {
    id: 'cubane', name: 'Cubane', formula: 'C<sub>8</sub>H<sub>8</sub>', expected: 'Oh',
    atoms: cubane(),
    note: 'A carbon cube with an H on each corner. Same group as SF₆, even though the atoms sit on the vertices rather than the face centres.',
  },
  {
    id: 'conitro', name: 'Hexanitrocobaltate(III) (idealised)', formula: '[Co(NO<sub>2</sub>)<sub>6</sub>]<sup>3−</sup>', expected: 'Th',
    atoms: cobaltNitro(),
    note: 'Six NO₂ groups on an octahedron, each lying in a different coordinate plane in a cyclic pattern. This destroys the C₄ axes and σd planes of O_h but keeps i, three σₕ and four C₃.',
  },
  {
    id: 'c2h2', name: 'Acetylene', formula: 'C<sub>2</sub>H<sub>2</sub>', expected: 'D∞h',
    atoms: [['H', 0, 0, -1.665], ['C', 0, 0, -0.6], ['C', 0, 0, 0.6], ['H', 0, 0, 1.665]],
    note: 'Linear and symmetric, like CO₂. Any linear molecule with identical ends is D∞h.',
  },

];

function centre(atoms) {
  let m = 0;
  const c = [0, 0, 0];
  for (const [el, x, y, z] of atoms) { const w = MASS[el]; m += w; c[0] += w * x; c[1] += w * y; c[2] += w * z; }
  return c.map((v) => v / m);
}

function bonds(atoms) {
  const out = [];
  for (let i = 0; i < atoms.length; i++) {
    for (let j = i + 1; j < atoms.length; j++) {
      const a = atoms[i], b = atoms[j];
      const d = Math.hypot(a.p[0] - b.p[0], a.p[1] - b.p[1], a.p[2] - b.p[2]);
      if (d < 1.2 * (COV[a.el] + COV[b.el])) out.push([i, j]);
    }
  }
  return out;
}

const ORDER = ['C1', 'Cs', 'Ci', 'C2', 'C3', 'S4', 'S6', 'C2v', 'C3v', 'C4v', 'C5v', 'C∞v', 'C2h', 'C3h', 'D2', 'D3', 'D2h', 'D3h', 'D4h', 'D5h', 'D6h', 'D∞h', 'D2d', 'D3d', 'D4d', 'D5d', 'Td', 'Th', 'Oh', 'Ih'];
const SORTED = RAW.map((m, i) => ({ m, i })).sort((a, b) => ORDER.indexOf(a.m.expected) - ORDER.indexOf(b.m.expected) || a.i - b.i).map((x) => x.m);

export const MOLECULES = SORTED.map((m) => {
  const c = centre(m.atoms);
  const atoms = m.atoms.map(([el, x, y, z]) => ({ el, p: [x - c[0], y - c[1], z - c[2]] }));
  const radius = Math.max(...atoms.map((a) => Math.hypot(...a.p) + 0.5));
  return { ...m, atoms, bonds: bonds(atoms), radius };
});
